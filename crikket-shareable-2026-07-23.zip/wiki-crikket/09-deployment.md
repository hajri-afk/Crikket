# 9. Deployment / Production

[← Kembali ke Home](./README.md)

> Halaman ini ringkasan. Untuk panduan resmi lihat docs proyek: self-hosting quick start, production guide, dan troubleshooting di https://crikket.io/docs/self-hosting.
>
> 💡 Butuh rekomendasi spesifikasi server (CPU/RAM/disk) per skala? Lihat [Spesifikasi Server](./10-spesifikasi-server.md).

---

## 9.1 Self-Host Cepat (Wizard)

Jalur tercepat dari clone segar:
```bash
git clone https://github.com/redpangilinan/crikket
cd crikket
./scripts/setup.sh
```
Wizard menangani: file env, generate secret, prompt domain, setup Caddy, dan Docker startup.

---

## 9.2 Docker Compose

Tersedia tiga konfigurasi:

| File | Skenario |
| --- | --- |
| `docker-compose.yml` | Bundled Postgres (DB ikut di-host) |
| `docker-compose.external-db.yml` | DB eksternal (Supabase/Neon/RDS) |
| `docker-compose.caddy.yml` | Tambah reverse proxy Caddy + auto-HTTPS |

Image siap pakai (GHCR):
- `ghcr.io/redpangilinan/crikket-server`
- `ghcr.io/redpangilinan/crikket-web`

Variabel root `.env` yang relevan (lihat [Environment Variables §6.4](./06-environment-variables.md#64-root-env-docker-compose)): `WEB_PORT`, `SERVER_PORT`, `POSTGRES_PORT`, `CRIKKET_DATABASE_MODE`, `CRIKKET_PROXY_MODE`, `CADDY_*`.

---

## 9.3 Build Manual

```bash
bun run build          # build semua app via turbo (output per app)
```
Health endpoint: `GET /` (server) dan `GET /` (web).

---

## 9.4 Checklist Production

- [ ] **Database** managed (Supabase / Neon / RDS); set `DATABASE_URL`.
- [ ] **Storage** real (AWS S3 / Cloudflare R2); atur `STORAGE_ENDPOINT`, `STORAGE_ADDRESSING_STYLE`, dan `STORAGE_PUBLIC_URL`.
- [ ] **`BETTER_AUTH_SECRET` baru** (jangan reuse secret dev).
- [ ] `NODE_ENV=production`; cookies `Secure` + `SameSite=None` + HTTPS wajib.
- [ ] **Resend** API key untuk email transaksional.
- [ ] **Polar** credentials bila billing aktif (`ENABLE_PAYMENTS=true`) — set semua `POLAR_*` + `POLAR_WEBHOOK_SECRET`.
- [ ] **Upstash Redis** untuk rate limit & replay-protect (public exposure).
- [ ] **Turnstile** keys bila capture publik tanpa auth.
- [ ] **CORS_ORIGINS** memuat origin web production.
- [ ] Reverse proxy via Caddy (`docker-compose.caddy.yml`) atau provider sendiri.
- [ ] Semua secret dikelola via secret manager (AWS SM / Doppler / 1Password CLI), bukan di repo.

---

## 9.5 CI / Quality Gate

| Check | Command |
| --- | --- |
| Type check | `bun run check-types` |
| Lint / format | `bun run check` (ultracite / Biome) |
| Auto fix | `bun run fix` |
| Unit test | Belum global; ditambahkan per package |

Pre-commit hook (Husky + lint-staged) otomatis menjalankan `ultracite fix` pada file yang di-stage.

---

## 9.6 Catatan Skalabilitas & Keamanan

- **API stateless** — session via cookie; bisa di-scale horizontal di belakang load balancer.
- **Postgres pooling** untuk koneksi padat.
- **Storage S3** horizontal by default.
- Presigned URL ber-expiry pendek; submit token HMAC + replay-protect (Upstash).
- GDPR: hapus user → cleanup artefak (job di `packages/bug-reports`).

---

[← Troubleshooting](./08-troubleshooting.md) · [Home](./README.md)
