# 🦗 Wiki Crikket

Dokumentasi internal lengkap untuk proyek **Crikket** — platform open-source untuk *bug reporting* & *session capture* yang dibangun di atas monorepo Bun + Turborepo.

> Crikket membantu tim menangkap bug dalam satu klik, melampirkan konteks replay otomatis (screenshot, video, console log, network), dan membagikan laporan lewat satu tautan. Alternatif open-source untuk jam.dev / marker.io.

---

## 📚 Daftar Halaman

| # | Halaman | Isi |
| --- | --- | --- |
| 1 | [Ikhtisar Produk](./01-ikhtisar.md) | Apa itu Crikket, fitur utama, dan alur kerja |
| 2 | [Teknologi yang Digunakan](./02-teknologi.md) | Stack lengkap: runtime, framework, library, infra |
| 3 | [Arsitektur & Struktur Monorepo](./03-arsitektur.md) | Apps, packages, SDK, dan alur data |
| 4 | [Requirements / Kebutuhan](./04-requirements.md) | Hardware, software, port, service, fungsional & non-fungsional |
| 5 | [Panduan Setup Langkah-demi-Langkah](./05-setup-langkah.md) | Dari nol sampai berjalan + login + extension + upload |
| 6 | [Referensi Environment Variables](./06-environment-variables.md) | Semua variabel `.env` per app |
| 7 | [Skrip & Perintah](./07-skrip.md) | Daftar perintah `bun run` dan kegunaannya |
| 8 | [Troubleshooting](./08-troubleshooting.md) | Solusi error yang sering muncul |
| 9 | [Deployment / Production](./09-deployment.md) | Self-host, Docker Compose, Caddy, secret |
| 10 | [Spesifikasi Server](./10-spesifikasi-server.md) | Rekomendasi spec VPS/server ideal per skala |

---

## 🚀 TL;DR — Jalan Cepat (Dev Lokal)

```bash
# 1. Tooling
curl -fsSL https://bun.sh/install | bash        # Bun ≥ 1.3.5
# + pasang Docker Desktop dan jalankan

# 2. Clone & install
git clone <REPO_URL> crikket && cd crikket
bun install

# 3. Infra lokal (Postgres + MinIO)
docker run -d --name crikket-postgres-dev -e POSTGRES_USER=postgres \
  -e POSTGRES_PASSWORD=postgres -e POSTGRES_DB=crikket -p 5433:5432 postgres:17-alpine
docker run -d --name crikket-minio -p 9000:9000 -p 9001:9001 \
  -e MINIO_ROOT_USER=minioadmin -e MINIO_ROOT_PASSWORD=minioadmin123 \
  minio/minio server /data --console-address ":9001"

# 4. Env + DB + run
cp apps/server/.env.example apps/server/.env   # edit DATABASE_URL & secret
cp apps/web/.env.example apps/web/.env
cp apps/extension/.env.example apps/extension/.env
bun run db:push
bun run dev
```

Detail penuh ada di **[Panduan Setup](./05-setup-langkah.md)**.

---

## 🌐 Port Default

| Service | URL | Fungsi |
| --- | --- | --- |
| Server (Hono API) | http://localhost:3000 | Auth, oRPC, presign upload |
| Web (Next.js) | http://localhost:3001 | Dashboard — **login di sini** |
| Docs (Fumadocs) | http://localhost:4000 | Dokumentasi publik |
| Extension (WXT) | http://localhost:5555 | Dev server / HMR extension |
| Postgres | localhost:5433 | Database (Docker) |
| MinIO | localhost:9000 / :9001 | S3 API / Console |

---

## ⚠️ Catatan Penting

- **Web tidak bisa jalan tanpa Server (port 3000).** Jika muncul error `fetch failed` di halaman dashboard, hampir selalu karena proses server belum berjalan. Cek dengan `lsof -iTCP:3000 -sTCP:LISTEN`.
- Semua secret disimpan di file `.env` masing-masing app, **bukan** di repo.
- Untuk dev lokal, set `ENABLE_PAYMENTS=false` agar tidak butuh kredensial Polar.

---

_Lisensi proyek: AGPL-3.0 · Dokumen wiki ini dipelihara untuk onboarding & referensi internal._
