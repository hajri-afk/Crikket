# 3. Arsitektur & Struktur Monorepo

[← Kembali ke Home](./README.md)

---

Crikket adalah monorepo **Bun + Turborepo** dengan tiga grup workspace: `apps/*`, `packages/*`, dan `sdks/*`.

## 3.1 Struktur Direktori

```
crikket/
├── apps/
│   ├── server/        # Hono API + Better Auth + oRPC + presign upload   (port 3000)
│   ├── web/           # Dashboard Next.js                                 (port 3001)
│   ├── docs/          # Situs dokumentasi Fumadocs                        (port 4000)
│   └── extension/     # Browser extension WXT (Chrome/Firefox, MV3)       (dev 5555)
│
├── packages/
│   ├── api/           # Router oRPC bersama
│   ├── auth/          # Konfigurasi Better Auth (server + client)
│   ├── billing/       # Integrasi Polar.sh
│   ├── bug-reports/   # Storage + cleanup logic artefak
│   ├── capture-core/  # Utilitas capture bersama
│   ├── config/        # Konfigurasi bersama (tsconfig, biome, dll)
│   ├── db/            # Drizzle schema + migrations
│   ├── env/           # Validasi env (Zod / @t3-oss/env)
│   ├── shared/        # Utilitas lintas-app
│   └── ui/            # Komponen UI shadcn-style + styles
│
├── sdks/
│   └── capture/       # SDK publik @crikket-io/capture
│
├── scripts/           # setup.sh, start.sh, restart.sh, update.sh, backup-db.sh, healthcheck.sh
├── docker-compose.yml            # bundled Postgres
├── docker-compose.external-db.yml
├── docker-compose.caddy.yml      # reverse proxy Caddy
├── turbo.json        # Konfigurasi Turborepo
└── package.json      # Workspace root + catalog versi
```

---

## 3.2 Peran Tiap App

### `apps/server` — API (Hono)
- **Autentikasi** via Better Auth: email/password, OTP, OAuth Google, plugin organization & admin.
- **oRPC** endpoints type-safe (+ OpenAPI) untuk dashboard.
- **Presigned upload** ke object storage S3-compatible (AWS SDK S3).
- **Rate limiting** (DB atau Upstash Redis) dan submit token HMAC opsional.
- Health endpoint: `GET /`.
- Base URL: `BETTER_AUTH_URL` (default `http://localhost:3000`).

### `apps/web` — Dashboard (Next.js)
- App Router + Turbopack. React 19 + React Compiler.
- **Server Components** memanggil auth client → fetch ke Server (`NEXT_PUBLIC_SERVER_URL`). Karena itu **web bergantung pada server**: jika server mati, halaman protected melempar `fetch failed`.
- Fitur: list & detail bug report, pemutar replay, manajemen organisasi, settings (profil/organisasi/billing), onboarding, dan kartu "Install Without Web Store".
- Data fetching: TanStack Query + adapter oRPC.

### `apps/docs` — Dokumentasi (Fumadocs)
- Situs MDX publik (getting started, install extension, comparison, dll). Port 4000.

### `apps/extension` — Browser Extension (WXT)
- Merekam: screenshot, video, console log, network, debugger events, input form.
- Env pakai prefix `VITE_` (`VITE_SERVER_URL`, `VITE_APP_URL`).
- Build output unpacked di `.output/chrome-mv3`.

---

## 3.3 Alur Autentikasi (penting untuk debugging)

```
Browser  ──>  apps/web (Next.js, port 3001)
                  │  Server Component / layout protected
                  │  authClient.getSession()
                  v
            fetch NEXT_PUBLIC_SERVER_URL  ──>  apps/server (Hono, port 3000)
                                                    │  Better Auth
                                                    v
                                              PostgreSQL (sesi, user, org)
```

> **Implikasi:** Error runtime `fetch failed` di halaman dashboard hampir selalu berarti **server (port 3000) belum berjalan** atau `NEXT_PUBLIC_SERVER_URL` salah. Cek: `lsof -iTCP:3000 -sTCP:LISTEN`. Lihat [Troubleshooting](./08-troubleshooting.md).

---

## 3.4 Alur Data Capture → Storage

1. Extension/SDK mengumpulkan artefak di browser.
2. Server menerbitkan **presigned PUT URL** untuk tiap artefak.
3. Browser meng-upload langsung ke object storage: `bug-reports/<orgId>/<reportId>/<artifactId>.<ext>`.
4. Metadata laporan disimpan ke Postgres lewat oRPC.
5. Cleanup artefak dijadwalkan via background job di `packages/bug-reports` (mis. saat user/laporan dihapus → GDPR-ready).

---

## 3.5 Data Storage

### Database (PostgreSQL)
- Schema di `packages/db/src/schema/*` (Drizzle ORM).
- Migrasi: `bun run db:generate` + `bun run db:migrate`, atau push langsung `bun run db:push`.
- Tabel utama: `user`, `session`, `account`, `verification`, `organization`, `member`, `invitation`, `bug_report`, `bug_report_artifact`, `rate_limit`, dll.

### Object Storage (S3-compatible)
- Bucket tunggal (default `crikket-development`).
- Path artefak: `bug-reports/<orgId>/<reportId>/<artifactId>.<ext>`.
- CORS perlu mengizinkan `PUT` dari origin web (`http://localhost:3001`) dan origin extension.

---

## 3.6 Orkestrasi Build (Turborepo)

- `turbo run dev` menjalankan task `dev` di semua workspace yang punya.
- Filter per app: `--filter=web`, `--filter=server`, `--filter=@crikket-io/capture`, dll.
- `turbo run build` membangun semua app untuk production (output per app).
- Versi dependency dikunci lewat **workspace catalog** di `package.json` root agar konsisten antar package.

---

[← Teknologi](./02-teknologi.md) · [Home](./README.md) · [Lanjut: Requirements →](./04-requirements.md)
