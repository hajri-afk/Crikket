# 4. Requirements / Kebutuhan

[← Kembali ke Home](./README.md)

Dokumen kebutuhan untuk **menjalankan, mengembangkan, dan men-deploy** Crikket.

---

## 4.1 System Requirements

### Hardware (dev)

| Resource | Minimum | Rekomendasi |
| --- | --- | --- |
| CPU | 4 core | 8 core |
| RAM | 8 GB | 16 GB |
| Disk free | 10 GB | 20 GB+ |
| OS | macOS 13+, Linux x64/arm64, Windows 11 (WSL2) | macOS / Linux |

### Software

| Tool | Versi minimum | Wajib | Catatan |
| --- | --- | --- | --- |
| **Bun** | 1.3.5 | ✅ | Package manager + runtime |
| **Docker** | 24+ | ✅ | Container Postgres + MinIO |
| **Git** | 2.40+ | ✅ | — |
| **Node.js** | 20 LTS | opsional | Untuk tooling tambahan |
| **Chrome / Chromium** | terbaru | ✅ | Load extension unpacked |
| **Firefox** | 115+ | opsional | `bun run --filter extension build:firefox` |

### Network / Port

| Port | Service | Wajib |
| --- | --- | --- |
| 3000 | server (Hono) | ✅ |
| 3001 | web (Next.js) | ✅ |
| 4000 | docs (Next.js) | opsional |
| 5555 | extension dev (WXT) | dev only |
| 5432 atau 5433 | Postgres | ✅ |
| 9000 | MinIO S3 API | ✅ (atau S3 cloud) |
| 9001 | MinIO Console | opsional |

---

## 4.2 Service Dependencies

### Wajib (core)
- **PostgreSQL 17+** — Docker `postgres:17-alpine` direkomendasikan untuk lokal; Supabase/Neon/RDS untuk production.
- **Object Storage S3-compatible** — MinIO (lokal) / AWS S3 / Cloudflare R2.

### Opsional
| Service | Fitur yang dipakai | Wajib bila |
| --- | --- | --- |
| **Resend** | Email OTP, verifikasi, undangan organisasi | Mengaktifkan login OTP / verifikasi email |
| **Upstash Redis** | Rate limit, replay-protect submit token | Production / public exposure |
| **Cloudflare Turnstile** | Anti-bot pada submit capture | Public capture tanpa auth |
| **Polar.sh** | Billing / paid plans | `ENABLE_PAYMENTS=true` |
| **Google OAuth** | Social login | Mengaktifkan tombol Google |
| **Caddy** | Reverse proxy + auto HTTPS | Self-host production |

---

## 4.3 Functional Requirements

### Authentication & Account
- Email + password sign up / sign in (Better Auth).
- Email OTP & email verification (via Resend).
- Optional Google OAuth.
- Session cookie (14 hari, refresh tiap 1 hari, cookie cache 1 jam).
- Domain restriction via `ALLOWED_SIGNUP_DOMAINS` (`*` = bebas).
- Admin plugin & organization plugin (multi-tenant + invitation flow).

### Organization & Membership
- Buat organisasi, undang anggota via email.
- Role-based: owner / admin / member.
- Limit anggota mengikuti entitlement billing (jika payments aktif).

### Bug Report Capture
- Extension merekam: screenshot, video (display recording), console log, network, debugger events, form input.
- Artefak diunggah via **presigned PUT** ke storage S3-compatible.
- Submit token (HMAC) opsional dengan replay-protect (Upstash Redis).
- Rate limit per IP/route (di-enforce DB atau Redis).

### Dashboard Web
- List & detail bug report.
- Pemutar replay session.
- Manajemen anggota organisasi.
- Settings: profil, organisasi, billing portal.
- Onboarding flow (post sign-up).
- Section "Install Without Web Store" untuk panduan extension.

### Billing (opsional)
- Integrasi Polar.sh (checkout + customer portal + webhook).
- Produk: pro, pro-yearly, studio, studio-yearly.
- Customer dibuat otomatis saat sign up bila `ENABLE_PAYMENTS=true`.
- Webhook memvalidasi signature & memproses entitlement.

### Documentation Site
- Fumadocs (MDX) di `apps/docs` (getting started, install extension, comparison, dll).

---

## 4.4 Non-Functional Requirements

| Aspek | Target |
| --- | --- |
| **Performance** | API p95 < 300 ms (lokal); dashboard FCP < 2 s |
| **Reliability** | Server boot < 5 s; DB migration idempoten |
| **Security** | HTTPS-only di prod; cookies `Secure+HttpOnly+SameSite=None`; presigned URL expiry pendek; secret env tidak di-commit |
| **Scalability** | Stateless API (session via cookie); Postgres pooling; storage S3 horizontal |
| **Observability** | Log terstruktur (Hono logger); error capture via PostHog/Sentry (opsional) |
| **Compliance** | GDPR-ready: hapus user → cleanup artifact (job di `packages/bug-reports`) |
| **Accessibility** | UI shadcn / Radix base; kontras WCAG AA |
| **Browser support** | Chrome ≥ 120, Edge ≥ 120, Firefox ≥ 115 (extension MV3) |

---

## 4.5 Security Requirements

- Semua secret disimpan di `.env`, **bukan** di repo (dilindungi `.gitignore`).
- `BETTER_AUTH_SECRET` ≥ 32 byte, di-rotate periodik.
- Production: `useSecureCookies: true`, `sameSite: none`, HTTPS wajib.
- Rate limit aktif untuk sign-in/up dan email OTP (default 3–5 req/menit).
- Webhook Polar memverifikasi signature dengan `POLAR_WEBHOOK_SECRET`.
- Submit token capture (HMAC) dengan TTL dan replay-protect (Upstash).
- Validasi env via Zod (`packages/env`) — boot gagal jika env invalid.

---

## 4.6 Acceptance Checklist (Dev Ready)

- [ ] `bun install` sukses.
- [ ] Container `crikket-postgres-dev` up & `pg_isready` OK.
- [ ] Container `crikket-minio` up dan bucket `crikket-development` ada.
- [ ] `apps/server/.env`, `apps/web/.env`, `apps/extension/.env` terisi.
- [ ] `bun run db:push` sukses tanpa error.
- [ ] `bun run dev` menjalankan server, web, docs, extension tanpa error.
- [ ] Sign up & login berhasil di `http://localhost:3001`.
- [ ] Extension dapat di-load unpacked dari `apps/extension/.output/chrome-mv3`.
- [ ] Record + upload artefak ke MinIO sukses (no 403).
- [ ] (Opsional) Email OTP terkirim via Resend.

---

## 4.7 Out-of-Scope

- Mobile native app.
- On-prem fully air-gapped (storage S3-compatible tetap diperlukan).
- Multi-region active-active database.

---

[← Arsitektur](./03-arsitektur.md) · [Home](./README.md) · [Lanjut: Panduan Setup →](./05-setup-langkah.md)
