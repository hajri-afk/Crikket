# 8. Troubleshooting

[← Kembali ke Home](./README.md)

---

## 8.1 Tabel Cepat

| Gejala | Solusi |
| --- | --- |
| **`Runtime TypeError: fetch failed`** di dashboard | Server (port 3000) belum berjalan / `NEXT_PUBLIC_SERVER_URL` salah. Lihat §8.2 |
| `EADDRINUSE :3000` (atau 3001/4000) | `bun run kill:ports` lalu ulangi |
| `password authentication failed for user "postgres"` | DB lokal lain yang menjawab. Pastikan `DATABASE_URL` pakai port Docker (5433) |
| `Polar customer creation failed (401)` | Set `ENABLE_PAYMENTS=false` di `apps/server/.env`, restart server |
| Upload artifact **403** | `STORAGE_*` belum mengarah ke MinIO. Cek [env server](./06-environment-variables.md#61-server--appsserverenv), restart server |
| CORS error saat upload ke MinIO | Set bucket public/anonymous (lihat §8.5) |
| Folder `.output` tidak terlihat di Finder | `Cmd+Shift+.` toggle hidden, atau paste path via `Cmd+Shift+G` |
| Email OTP tidak masuk | `RESEND_API_KEY` kosong → verifikasi manual via SQL (§8.6) |
| Extension popup "Failed to fetch" | `VITE_SERVER_URL` salah / server mati. Build ulang extension setelah edit `.env` |
| `bun install` lambat / gagal | Koneksi tidak stabil. Hapus `node_modules` & `bun.lock` lalu ulangi |

---

## 8.2 `fetch failed` di Halaman Dashboard (paling umum)

**Penyebab:** Halaman protected di `apps/web` menjalankan auth check di server (`authClient.getSession()`), yang fetch ke `NEXT_PUBLIC_SERVER_URL` → `http://localhost:3000/api/auth/...`. Jika **tidak ada yang listen di port 3000**, Node melempar `fetch failed`.

**Diagnosa:**
```bash
lsof -iTCP:3000 -sTCP:LISTEN -P     # kosong = server mati
```

**Perbaikan:**
```bash
# Jalankan server (dan web) — infra (Postgres/MinIO) harus sudah up
bun run dev            # semua service
# atau spesifik:
bun run dev:server     # port 3000  ← yang sering hilang
bun run dev:web        # port 3001
```

Konfirmasi endpoint hidup:
```bash
curl -s -o /dev/null -w "%{http_code}\n" http://localhost:3000/api/auth/get-session
# 200 = sehat
```

> **Aturan praktis:** `fetch failed` di halaman protected = proses server adalah hal pertama yang dicek.

---

## 8.3 `EADDRINUSE` (port sudah dipakai)

Ada server lama yang masih hidup:
```bash
bun run kill:ports     # membersihkan 3000 / 3001 / 4000
```

---

## 8.4 `password authentication failed for user "postgres"`

Postgres lokal lain (PostgreSQL.app, dll) memakai port 5432 dan menjawab lebih dulu.

- Pakai port **5433** untuk container Docker (lihat [Setup §3.2](./05-setup-langkah.md#langkah-3--jalankan-database-postgresql-via-docker)).
- Pastikan `DATABASE_URL` memakai `:5433`.

---

## 8.5 Upload 403 / CORS ke MinIO

1. Pastikan `STORAGE_*` di `apps/server/.env` mengarah ke MinIO (endpoint `http://localhost:9000`, key `minioadmin`/`minioadmin123`, bucket `crikket-development`).
2. Restart server setelah mengubah env.
3. Set akses bucket bila perlu:
   ```bash
   docker exec crikket-minio mc anonymous set download local/crikket-development
   # atau, jika masih CORS error saat PUT langsung:
   docker exec crikket-minio mc anonymous set public local/crikket-development
   ```

---

## 8.6 Email OTP / Verifikasi Tidak Terkirim

`RESEND_API_KEY` kosong di dev. Tandai user verified langsung via SQL:
```bash
docker exec crikket-postgres-dev psql -U postgres -d crikket \
  -c "UPDATE \"user\" SET email_verified = true WHERE email='admin@crikket.local';"
```

---

## 8.7 Polar 401 (`invalid_token`)

Anda belum punya kredensial Polar tapi payments aktif. Set:
```ini
ENABLE_PAYMENTS=false
```
di `apps/server/.env`, lalu restart server.

---

## 8.8 Extension Tidak Konek ke Server

- Cek `apps/extension/.env` → `VITE_SERVER_URL=http://localhost:3000`.
- **Build ulang** setelah ubah env: `bun run --filter extension build`.
- Reload extension di `chrome://extensions`.

---

## 8.9 Folder `.output` Tidak Terlihat di Finder

Folder diawali titik = hidden. Toggle: `Cmd+Shift+.`. Atau di file picker tekan `Cmd+Shift+G` lalu paste path absolut.

---

## 8.10 Warning Next.js "multiple lockfiles"

Next.js mendeteksi lockfile lain (mis. `~/package-lock.json`) dan salah memilih workspace root. Harmless, tapi bisa dibersihkan dengan menghapus lockfile asing atau set `turbopack.root` di `next.config`.

---

## 8.11 Reset Semua Data

```bash
docker rm -f crikket-postgres-dev crikket-minio
# ulangi Setup LANGKAH 3, 4, lalu:
bun run db:push
```

---

[← Skrip](./07-skrip.md) · [Home](./README.md) · [Lanjut: Deployment →](./09-deployment.md)
