# 10. Spesifikasi Server untuk Deployment

[← Kembali ke Home](./README.md)

Rekomendasi spesifikasi server yang ideal untuk men-deploy Crikket. Kuncinya: **apakah semua komponen di satu server**, atau **DB & storage diserahkan ke layanan managed** (lebih direkomendasikan untuk production).

Crikket terdiri dari: **Hono server (Bun)** + **Next.js web** + **PostgreSQL** + **object storage S3** (+ Redis & Caddy opsional).

---

## 10.1 Rekomendasi per Skala

### Tier 1 — Hobby / Demo / Internal kecil (semua di 1 VPS)
Cocok untuk testing, tim kecil, < ~20 user aktif.

| Resource | Spesifikasi |
| --- | --- |
| **CPU** | 2 vCPU |
| **RAM** | **4 GB** (minimum riil; 2 GB sering OOM saat build Next.js) |
| **Disk** | 40 GB SSD |
| **OS** | Ubuntu 22.04 / 24.04 LTS |
| **Setup** | `docker-compose.yml` (bundled Postgres) + Caddy |

> ⚠️ Build Next.js (Turbopack) rakus RAM. Jika VPS hanya 2 GB, **build di lokal/CI** lalu deploy image dari GHCR (`crikket-server`, `crikket-web`) agar server tidak perlu build.

### Tier 2 — Production kecil–menengah (REKOMENDASI IDEAL)
App di VPS, DB & storage managed. Cocok untuk produk live, ratusan–ribuan user.

| Komponen | Spesifikasi ideal |
| --- | --- |
| **App server** (server + web) | **4 vCPU / 8 GB RAM / 80 GB SSD** |
| **Database** | **Postgres managed** (Supabase / Neon / RDS) — jangan host sendiri |
| **Object storage** | **AWS S3 / Cloudflare R2** (bukan MinIO lokal) |
| **Redis** | Upstash (serverless, opsional) untuk rate limit |
| **Reverse proxy** | Caddy (auto-HTTPS) atau load balancer provider |

Ini konfigurasi paling **direkomendasikan**: app stateless di VPS, sedangkan DB & storage diserahkan ke layanan managed yang tahan beban, backup otomatis, dan mudah di-scale.

### Tier 3 — Skala besar / high traffic (horizontal scaling)

| Komponen | Pendekatan |
| --- | --- |
| **App** | 2+ instance (server & web) di belakang load balancer — **stateless**, session via cookie |
| **CPU/RAM per instance** | 4 vCPU / 8 GB |
| **Database** | Postgres managed + **connection pooling** (PgBouncer) + read replica |
| **Storage** | S3 / R2 (horizontal by default) |
| **Redis** | **Wajib** (Upstash / ElastiCache) untuk rate limit & replay-protect |

---

## 10.2 Kebutuhan RAM per Komponen (perkiraan idle–normal)

| Komponen | RAM |
| --- | --- |
| Hono server (Bun) | ~150–400 MB |
| Next.js web (runtime) | ~300–600 MB |
| **Next.js build** | **1.5–3 GB peak** ← penyebab utama butuh RAM besar |
| PostgreSQL (jika self-host) | ~500 MB – 1 GB+ |
| Caddy | ~50 MB |

> Implikasi: kalau membangun di server, sediakan headroom RAM untuk proses build. Lebih aman build di CI dan deploy image jadi.

---

## 10.3 Ringkasan "Ideal"

- **Mulai aman:** 1 VPS **4 vCPU / 8 GB / 80 GB SSD**, Ubuntu LTS, Docker + Caddy.
- **Pisahkan DB & storage** ke managed (Postgres managed + S3/R2) sejak awal production — langkah paling berpengaruh untuk keandalan & scaling.
- **Build di CI / pakai image GHCR**, jangan build di server kecil.
- **Stateless app** → tambah instance saat traffic naik, taruh di belakang load balancer.

---

## 10.4 Provider yang Umum Cocok

| Provider | Contoh paket (≈ Tier 2) |
| --- | --- |
| **Hetzner** | CPX31 / CPX41 (paling hemat untuk RAM besar) |
| **DigitalOcean** | Premium Droplet 8 GB |
| **Fly.io** | shared-cpu + volume (cocok multi-region) |
| **Railway / Render** | Managed deploy, minim ops |
| **AWS / GCP** | EC2/Compute + RDS + S3 (skala enterprise) |

Untuk DB managed: **Supabase**, **Neon** (serverless Postgres), atau **RDS**.
Untuk storage: **Cloudflare R2** (tanpa egress fee) atau **AWS S3**.

---

## 10.5 Perkiraan Biaya Bulanan

> 💵 Angka indikatif (USD/bulan, kisaran 2025) untuk membandingkan tier. Harga aktual bisa berubah — selalu cek halaman pricing provider. Belum termasuk pajak, egress, dan domain.

### Tier 1 — Hobby (semua di 1 VPS)

| Item | Pilihan | ≈ Biaya/bln |
| --- | --- | --- |
| VPS 2 vCPU / 4 GB | Hetzner CPX21 | $8 |
| | DigitalOcean 4 GB | $24 |
| Domain | (tahunan ÷ 12) | ~$1 |
| Storage | bundled MinIO di VPS | $0 |
| **Total** | **Hetzner** | **≈ $9** |
| | **DigitalOcean** | **≈ $25** |

### Tier 2 — Production ideal (app VPS + DB & storage managed)

| Item | Pilihan | ≈ Biaya/bln |
| --- | --- | --- |
| App VPS 4 vCPU / 8 GB | Hetzner CPX41 | $16 |
| | DigitalOcean 8 GB | $48 |
| Postgres managed | Neon (free→pro) | $0–19 |
| | Supabase Pro | $25 |
| Object storage | Cloudflare R2 (10–50 GB) | ~$1–2 (tanpa egress fee) |
| | AWS S3 (10–50 GB) | ~$1–3 + egress |
| Redis (opsional) | Upstash pay-as-you-go | $0–10 |
| **Total realistis** | **Hetzner + Neon + R2** | **≈ $18–40** |
| | **DO + Supabase + R2** | **≈ $75–90** |

### Tier 3 — Skala besar (horizontal)

| Item | ≈ Biaya/bln |
| --- | --- |
| 2× app instance (4 vCPU/8 GB) | $32–100 |
| Load balancer | $5–20 |
| Postgres managed + pooling + replica | $50–200+ |
| Storage S3/R2 (volume besar) | $10–50+ |
| Redis managed | $10–30 |
| **Total** | **≈ $120–400+** (sangat tergantung traffic) |

### Alternatif PaaS (minim ops, bayar kenyamanan)

| Platform | Catatan | ≈ Biaya/bln |
| --- | --- | --- |
| **Railway** | Deploy dari repo, DB add-on | $5–20+ (usage-based) |
| **Render** | Web service + managed Postgres | $7 (web) + $7+ (DB) |
| **Fly.io** | Multi-region, volume | $5–25+ (usage-based) |

> **Paling hemat untuk production riil:** Hetzner (app) + Neon/Supabase (DB) + Cloudflare R2 (storage) → **±$20–40/bln**. Cloudflare R2 unggul karena **tanpa biaya egress**, cocok untuk artefak capture (video/screenshot) yang sering diunduh.

---

## 10.6 Catatan Jaringan & Keamanan

- Buka hanya port yang perlu: **80/443** (via Caddy/LB). Port app (3000/3001) tetap internal.
- Pasang **HTTPS** (Caddy auto-ACME atau LB) — cookies production butuh `Secure` + `SameSite=None`.
- Set **`CORS_ORIGINS`** ke origin web production saja.
- Firewall: batasi akses DB hanya dari app server (atau gunakan private networking provider).
- Backup DB terjadwal (managed DB biasanya otomatis; jika self-host pakai `./scripts/backup-db.sh`).

---

[← Deployment](./09-deployment.md) · [Home](./README.md)
