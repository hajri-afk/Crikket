# 6. Referensi Environment Variables

[← Kembali ke Home](./README.md)

Semua secret disimpan di file `.env` per app (dilindungi `.gitignore`). Validasi dilakukan via Zod di `packages/env` — boot gagal jika env wajib tidak valid.

---

## 6.1 Server — `apps/server/.env`

| Variable | Required | Default / Contoh | Keterangan |
| --- | --- | --- | --- |
| `NODE_ENV` | ✅ | `development` | `development` \| `production` |
| `DATABASE_URL` | ✅ | `postgresql://postgres:postgres@localhost:5433/crikket` | Koneksi Postgres |
| `CORS_ORIGINS` | ✅ | `http://localhost:3001` | Comma-delimited; dipakai CORS + trusted origins Better Auth |
| `ALLOWED_SIGNUP_DOMAINS` | opsional | `*` | Comma-delimited domain list |
| `BETTER_AUTH_SECRET` | ✅ | random 32-byte base64url | `bun run generate:secret` |
| `BETTER_AUTH_URL` | ✅ | `http://localhost:3000` | Base URL server |
| `BETTER_AUTH_COOKIE_DOMAIN` | opsional | — | Untuk sharing cookie antar subdomain |
| `RESEND_API_KEY` | opsional | — | Wajib untuk email OTP/verifikasi |
| `RESEND_FROM_EMAIL` | kondisional | `noreply@example.com` | Wajib jika Resend aktif |
| `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` | opsional | — | OAuth Google |
| `ENABLE_PAYMENTS` | ✅ | `false` (dev) | `true` mengaktifkan Polar |
| `POLAR_ACCESS_TOKEN` | kondisional | — | Wajib bila payments on |
| `POLAR_WEBHOOK_SECRET` | kondisional | — | Wajib bila payments on |
| `POLAR_SUCCESS_URL` | kondisional | `http://localhost:3001/success?checkout_id={CHECKOUT_ID}` | — |
| `POLAR_PRO_PRODUCT_ID` | kondisional | — | Per produk |
| `POLAR_PRO_YEARLY_PRODUCT_ID` | kondisional | — | — |
| `POLAR_STUDIO_PRODUCT_ID` | kondisional | — | — |
| `POLAR_STUDIO_YEARLY_PRODUCT_ID` | kondisional | — | — |
| `STORAGE_BUCKET` | ✅ | `crikket-development` | Nama bucket |
| `STORAGE_ACCESS_KEY_ID` | ✅ | `minioadmin` | — |
| `STORAGE_SECRET_ACCESS_KEY` | ✅ | `minioadmin123` | — |
| `STORAGE_REGION` | ✅ | `us-east-1` | — |
| `STORAGE_ENDPOINT` | kondisional | `http://localhost:9000` | Wajib untuk MinIO/R2 (kosong = AWS S3) |
| `STORAGE_ADDRESSING_STYLE` | opsional | `path` (MinIO) / `auto` (S3) | `path` \| `virtual` \| `auto` |
| `STORAGE_PUBLIC_URL` | opsional | — | Base URL publik untuk hindari signed URL |
| `UPSTASH_REDIS_REST_URL` | opsional | — | Rate limit + token replay |
| `UPSTASH_REDIS_REST_TOKEN` | opsional | — | — |
| `CAPTURE_SUBMIT_TOKEN_SECRET` | opsional | — | Aktifkan signed submit token |
| `TURNSTILE_SITE_KEY` | opsional | — | Anti-bot |
| `TURNSTILE_SECRET_KEY` | opsional | — | — |

### Catatan `STORAGE_ADDRESSING_STYLE`
- `auto` — endpoint AWS pakai virtual-hosted style, endpoint custom pakai path-style.
- `path` — selalu `https://endpoint/bucket/key` (cocok MinIO).
- `virtual` — selalu `https://bucket.endpoint/key`.

---

## 6.2 Web — `apps/web/.env`

| Variable | Required | Default |
| --- | --- | --- |
| `NEXT_PUBLIC_SITE_URL` | ✅ | `https://crikket.io` |
| `NEXT_PUBLIC_APP_URL` | ✅ | `http://localhost:3001` |
| `NEXT_PUBLIC_SERVER_URL` | ✅ | `http://localhost:3000` |
| `NEXT_PUBLIC_GOOGLE_AUTH_ENABLED` | opsional | `false` (`true`/`false`) |
| `NEXT_PUBLIC_DOCS_URL` | opsional | `http://localhost:4000/docs` |
| `NEXT_PUBLIC_CRIKKET_KEY` | opsional | — (public key capture) |
| `NEXT_PUBLIC_DEMO_URL` | opsional | — |
| `NEXT_PUBLIC_POSTHOG_KEY` | opsional | — |
| `NEXT_PUBLIC_POSTHOG_HOST` | opsional | — |

> ⚠️ `NEXT_PUBLIC_SERVER_URL` **wajib menunjuk ke server yang hidup**. Salah / server mati → halaman protected melempar `fetch failed`.

---

## 6.3 Extension — `apps/extension/.env`

| Variable | Required | Default |
| --- | --- | --- |
| `VITE_APP_URL` | ✅ | `http://localhost:3001` |
| `VITE_SERVER_URL` | ✅ | `http://localhost:3000` |

> Setelah mengubah `.env` extension, **build ulang** (`bun run --filter extension build`) lalu reload di `chrome://extensions`.

---

## 6.4 Root `.env` (Docker Compose)

Dipakai oleh `docker-compose` saat self-host. Tidak perlu diubah untuk dev manual.

| Variable | Default | Keterangan |
| --- | --- | --- |
| `WEB_PORT` | `3001` | Port host untuk web |
| `SERVER_PORT` | `3000` | Port host untuk server |
| `POSTGRES_PORT` | `5432` | Port host Postgres (bundled) |
| `CRIKKET_DATABASE_MODE` | `bundled` | `bundled` \| `external` |
| `CRIKKET_PROXY_MODE` | — | Aktifkan Caddy reverse proxy |
| `CADDY_HTTP_PORT` / `CADDY_HTTPS_PORT` | `80` / `443` | Port Caddy |
| `CADDY_ACME_EMAIL` | — | Email ACME (Let's Encrypt) |
| `CADDY_PUBLIC_HOST` | — | Hostname publik |
| `POSTGRES_USER` / `POSTGRES_PASSWORD` / `POSTGRES_DB` | `postgres` / `postgres` / `crikket` | Kredensial Postgres bundled |
| `POSTGRES_HOST_AUTH_METHOD` | `scram-sha-256` | Metode auth Postgres |

---

## 6.5 Tips

- Generate secret baru: `bun run generate:secret` (random 32-byte base64url).
- Untuk production gunakan secret **berbeda** dari dev, kelola via secret manager (AWS SM / Doppler / 1Password CLI).
- Jangan commit file `.env` — gunakan `.env.example` sebagai template.

---

[← Setup](./05-setup-langkah.md) · [Home](./README.md) · [Lanjut: Skrip & Perintah →](./07-skrip.md)
