# 2. Teknologi yang Digunakan

[← Kembali ke Home](./README.md)

---

Crikket dibangun sebagai **monorepo Bun + Turborepo**. Berikut stack lengkap per kategori. Versi mengacu pada `catalog` di `package.json` root (workspace catalog Bun).

## Ringkasan Cepat

> **Bun · Turborepo · Next.js 16 · Hono · Better Auth · oRPC · Drizzle ORM · PostgreSQL · MinIO/S3 · WXT · Tailwind v4 · shadcn/Radix · TanStack Query · Polar.sh · Resend · Fumadocs**

---

## 2.1 Tooling & Monorepo

| Teknologi | Versi | Fungsi |
| --- | --- | --- |
| **Bun** | 1.3.5+ | Runtime JS/TS + package manager + bundler |
| **Turborepo** | 2.8+ | Orkestrasi build/dev task antar workspace |
| **TypeScript** | 5.x | Bahasa utama (semua app & package) |
| **Biome / Ultracite** | latest | Linter + formatter (pengganti ESLint/Prettier) |
| **Husky + lint-staged** | latest | Git hooks — auto `ultracite fix` saat commit |
| **Changesets** | latest | Versioning & changelog untuk package/SDK |

Workspace: `apps/*`, `packages/*`, `sdks/*`.

---

## 2.2 Backend — `apps/server`

| Teknologi | Versi | Fungsi |
| --- | --- | --- |
| **Hono** | 4.8+ | Web framework API (berjalan di Bun) |
| **Better Auth** | 1.5+ | Autentikasi (email/password, OTP, OAuth, organization, admin) |
| **oRPC** (`@orpc/server`, `/openapi`, `/zod`) | 1.12+ | RPC type-safe + generate OpenAPI |
| **Drizzle ORM** | 0.45+ | ORM TypeScript untuk PostgreSQL |
| **PostgreSQL** | 17+ | Database relasional utama |
| **AWS SDK S3** (`@aws-sdk/client-s3`, `s3-request-presigner`) | 3.1000+ | Presigned upload ke storage S3-compatible |
| **Zod** | 4.x | Validasi schema (env, input, output) |
| **Upstash Redis + Ratelimit** | 1.36 / 2.0 | Rate limiting & replay-protect submit token (opsional) |

---

## 2.3 Frontend — `apps/web`

| Teknologi | Versi | Fungsi |
| --- | --- | --- |
| **Next.js** | 16.1+ | Framework React (App Router, Turbopack) |
| **React** | 19.2+ | UI library |
| **React Compiler** (`babel-plugin-react-compiler`) | 1.0+ | Optimisasi auto-memoization |
| **Tailwind CSS** | 4.1+ | Styling utility-first (via `@tailwindcss/postcss`) |
| **shadcn + Radix / Base UI** | — | Komponen UI (`@base-ui/react`, `@radix-ui/react-slot`) |
| **TanStack Query** | 5.90+ | Data fetching & cache (+ devtools, oRPC adapter) |
| **TanStack Form / Table** | 1.27 / 8.21 | Form state & tabel |
| **nuqs** | 2.8+ | State URL/query-string yang type-safe |
| **next-themes** | 0.4+ | Dark/light mode |
| **lucide-react** | 0.546+ | Ikon |
| **sonner** | 2.0+ | Toast notification |
| **motion** | 12.34+ | Animasi |
| **dnd-kit** | 6.3+ | Drag & drop |
| **cmdk**, **input-otp**, **react-day-picker**, **react-resizable-panels**, **rough-notation**, **nextjs-toploader** | — | Komponen pelengkap UI |
| **PostHog** (`posthog-js`) | 1.354+ | Analytics & product tracking (opsional) |

---

## 2.4 Browser Extension — `apps/extension`

| Teknologi | Fungsi |
| --- | --- |
| **WXT** | Framework extension lintas-browser (Chrome/Firefox, MV3) + HMR |
| **Vite** | Bundler (di balik WXT) — env pakai prefix `VITE_` |
| **React + Tailwind** | UI popup & content script |

Build target: `apps/extension/.output/chrome-mv3` (dan `firefox-mv*` untuk Firefox).

---

## 2.5 Dokumentasi — `apps/docs`

| Teknologi | Versi | Fungsi |
| --- | --- | --- |
| **Fumadocs** (`-core`, `-ui`, `-mdx`) | 16.5 / 14.2 | Situs dokumentasi berbasis MDX |
| **Next.js** | 16.1+ | Hosting situs docs (port 4000) |

---

## 2.6 SDK Publik — `sdks/capture`

- **`@crikket-io/capture`** — SDK browser embeddable untuk memasang launcher capture di produk pihak ketiga. Dibangun dengan Bun + TypeScript (`scripts/build.ts`).

---

## 2.7 Email, Pembayaran & Layanan Eksternal

| Layanan | Library | Fungsi | Wajib? |
| --- | --- | --- | --- |
| **Resend** | `resend`, `@react-email/*` | Email transaksional (OTP, verifikasi, undangan) | Opsional |
| **Polar.sh** | `@polar-sh/sdk`, `@polar-sh/better-auth`, `@polar-sh/checkout` | Billing / paid plans (checkout, portal, webhook) | Opsional (`ENABLE_PAYMENTS=true`) |
| **Google OAuth** | (Better Auth) | Social login | Opsional |
| **Cloudflare Turnstile** | (server) | Anti-bot pada submit capture publik | Opsional |
| **Upstash Redis** | `@upstash/*` | Rate limit & token replay-protect | Opsional |

---

## 2.8 Infrastruktur & DevOps

| Teknologi | Fungsi |
| --- | --- |
| **Docker / Docker Compose** | Menjalankan Postgres + MinIO (dan opsional Caddy) |
| **MinIO** | Object storage S3-compatible untuk dev lokal |
| **AWS S3 / Cloudflare R2** | Object storage untuk production |
| **Caddy** | Reverse proxy + auto-HTTPS (opsional, `docker-compose.caddy.yml`) |
| **GHCR** | Image siap pakai `ghcr.io/redpangilinan/crikket-server` & `crikket-web` |

Compose files tersedia:
- `docker-compose.yml` — bundled Postgres
- `docker-compose.external-db.yml` — pakai DB eksternal
- `docker-compose.caddy.yml` — tambah reverse proxy Caddy

---

## 2.9 Shared Packages (internal)

| Package | Isi / Teknologi |
| --- | --- |
| `packages/api` | Router oRPC bersama |
| `packages/auth` | Konfigurasi Better Auth (server + client) |
| `packages/billing` | Integrasi Polar.sh |
| `packages/bug-reports` | Logika storage + cleanup artefak |
| `packages/capture-core` | Utilitas capture bersama |
| `packages/config` | Konfigurasi bersama (TS, biome, dll) |
| `packages/db` | Schema + migrasi Drizzle |
| `packages/env` | Validasi env via Zod (`@t3-oss/env-nextjs`) |
| `packages/shared` | Utilitas lintas-app |
| `packages/ui` | Komponen UI shadcn-style bersama + style (Tailwind) |

---

[← Ikhtisar](./01-ikhtisar.md) · [Home](./README.md) · [Lanjut: Arsitektur →](./03-arsitektur.md)
