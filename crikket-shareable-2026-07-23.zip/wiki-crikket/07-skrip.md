# 7. Skrip & Perintah

[← Kembali ke Home](./README.md)

---

## 7.1 Skrip `bun run` (dari `package.json` root)

| Skrip | Fungsi |
| --- | --- |
| `bun run dev` | Jalankan semua service (turbo `dev`) |
| `bun run dev:web` | Web only (`--filter=web`) |
| `bun run dev:server` | Server only (`--filter=server`) |
| `bun run dev:capture` | Build watch SDK capture (`--filter=@crikket-io/capture`) |
| `bun run dev:native` | Filter `native` (jika ada) |
| `bun run build` | Build production semua app (turbo `build`) |
| `bun run check-types` | Typecheck semua workspace (`tsc --noEmit`) |
| `bun run check` | Lint/format check via **ultracite** (Biome) |
| `bun run fix` | Auto-fix lint/format |
| `bun run db:push` | Sinkron schema Drizzle → DB (cepat, dev) |
| `bun run db:studio` | Buka Drizzle Studio (GUI database) |
| `bun run db:generate` | Generate migration SQL dari schema |
| `bun run db:migrate` | Apply migration ke DB |
| `bun run kill:ports` | Bunuh proses di port 3000 / 3001 / 4000 |
| `bun run generate:secret` | Cetak random 32-byte base64url (untuk `BETTER_AUTH_SECRET`) |
| `bun run clean` | Hapus `node_modules`, `.next`, `.turbo`, `dist`, dll |
| `bun run changeset:add` | Tambah changeset baru |
| `bun run changeset:status` | Status changeset sejak `master` |
| `bun run changeset:version` | Bump versi dari changeset |
| `bun run changeset:publish` | Publish package |

---

## 7.2 Build Per-App

```bash
bun run --filter extension build           # Build extension (Chrome MV3)
bun run --filter extension build:firefox   # Build extension (Firefox)
bun run --filter web build                 # Build web saja
bun run --filter server build              # Build server saja
```

---

## 7.3 Skrip Shell Self-Host (folder `scripts/`)

| Skrip | Fungsi |
| --- | --- |
| `./scripts/setup.sh` | Wizard interaktif: env, secret, domain, Caddy, Docker startup |
| `./scripts/start.sh` | Start stack self-host |
| `./scripts/restart.sh` | Restart service |
| `./scripts/update.sh` | Update ke versi terbaru |
| `./scripts/backup-db.sh` | Backup database |
| `./scripts/healthcheck.sh` | Cek kesehatan service |

---

## 7.4 Perintah Docker Berguna (dev lokal)

```bash
# Status container
docker ps

# Logs
docker logs -f crikket-postgres-dev
docker logs -f crikket-minio

# Masuk ke psql
docker exec -it crikket-postgres-dev psql -U postgres -d crikket

# List isi bucket MinIO
docker exec crikket-minio mc ls --recursive local/crikket-development

# Start / stop tanpa hapus data
docker start crikket-postgres-dev crikket-minio
docker stop  crikket-postgres-dev crikket-minio

# Reset total (hapus data)
docker rm -f crikket-postgres-dev crikket-minio
```

---

## 7.5 Cek Cepat Port

```bash
# Apa yang listen di port server?
lsof -iTCP:3000 -sTCP:LISTEN -P

# Semua port Crikket sekaligus
lsof -iTCP -sTCP:LISTEN -P | grep -E ':3000|:3001|:4000|:5432|:5433|:9000|:9001'
```

---

[← Environment Variables](./06-environment-variables.md) · [Home](./README.md) · [Lanjut: Troubleshooting →](./08-troubleshooting.md)
