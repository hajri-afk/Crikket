# 1. Ikhtisar Produk

[← Kembali ke Home](./README.md)

---

## Apa itu Crikket?

**Crikket** adalah platform **bug reporting & session capture** open-source. Pengguna merekam aksi di browser — screenshot, video (display recording), console log, network request, debugger events, hingga input form — lewat **browser extension** atau **capture SDK**. Artefak tersebut diunggah ke object storage dan dikelola di **dashboard web**. Backend menyediakan API autentikasi, endpoint oRPC, dan presigned upload.

Crikket adalah alternatif modern dan open-source untuk tools seperti **jam.dev** dan **marker.io**, ditujukan untuk tim yang ingin reproduksi bug lebih cepat tanpa kehilangan kontrol atas stack mereka.

---

## Nilai Utama

Setiap laporan dirancang untuk mengurangi bolak-balik (back-and-forth) saat debugging.

| Area | Yang disediakan Crikket |
| --- | --- |
| **Capture** | Laporan bug satu klik berupa screenshot atau video |
| **Reproduction** | Langkah reproduksi yang terekam untuk memutar ulang kejadian |
| **Technical context** | Console log dan network request otomatis terlampir |
| **Sharing** | Tautan berbagi publik atau privat per laporan |
| **Collaboration** | Workspace tim, undangan, dan manajemen laporan |
| **Deployment** | Self-hosting yang cepat dan mudah |

---

## Komponen Utama

- **apps/server** — Hono API (Better Auth, oRPC, presign upload ke S3)
- **apps/web** — Dashboard Next.js (kelola bug report, organisasi, billing)
- **apps/docs** — Fumadocs (dokumentasi publik & marketing)
- **apps/extension** — Browser extension WXT (Chrome / Firefox, Manifest V3)
- **packages/** — Modul internal bersama: `api`, `auth`, `billing`, `bug-reports`, `capture-core`, `config`, `db`, `env`, `shared`, `ui`
- **sdks/capture** — SDK capture publik yang bisa di-embed di produk lain (`@crikket-io/capture`)

---

## Alur Kerja (High-Level)

```
┌─────────────┐    rekam      ┌──────────────┐   presign PUT   ┌──────────────┐
│  Pengguna   │ ────────────> │  Extension/  │ ──────────────> │  Object      │
│  (browser)  │   bug report  │  Capture SDK │   upload artefak│  Storage     │
└─────────────┘               └──────┬───────┘                 │  (S3/MinIO)  │
                                     │ submit metadata          └──────────────┘
                                     v
                              ┌──────────────┐   query/oRPC    ┌──────────────┐
                              │  Server      │ <─────────────  │  Web         │
                              │  (Hono API)  │   auth + data   │  Dashboard   │
                              └──────┬───────┘                 └──────────────┘
                                     │
                                     v
                              ┌──────────────┐
                              │  PostgreSQL  │  (Drizzle ORM)
                              └──────────────┘
```

1. **Capture** — Pengguna memicu rekaman lewat extension atau SDK. Artefak (screenshot/video/log) dikumpulkan di sisi browser.
2. **Upload** — Server menerbitkan *presigned PUT URL*; artefak diunggah langsung ke object storage (S3 / MinIO / R2).
3. **Submit** — Metadata laporan (judul, langkah, environment) dikirim ke Server dan disimpan di Postgres.
4. **Manage** — Dashboard web menampilkan daftar & detail laporan, pemutar replay, manajemen organisasi, dan settings.
5. **Share** — Setiap laporan bisa dibagikan via tautan publik atau privat.

---

## Cara Memakai (Embed SDK)

Crikket menyediakan capture SDK yang bisa dipasang di website / web app mana pun:

```ts
import { init } from "@crikket-io/capture"

init({
  key: "crk_your_public_key",
  host: "https://api.crikket.io",
})
```

Itu akan memasang *launcher* capture sehingga pengguna bisa mengirim laporan bug (screenshot atau screen recording) tanpa meninggalkan produk Anda.

---

[← Home](./README.md) · [Lanjut: Teknologi yang Digunakan →](./02-teknologi.md)
