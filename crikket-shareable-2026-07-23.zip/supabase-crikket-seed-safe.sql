-- Crikket starter data for Supabase, safer/idempotent version.
-- Run this after supabase-crikket-schema.sql.
--
-- Demo login:
--   Email:    admin@crikket.local
--   Password: Password123!
--
-- If you already created a user with admin@crikket.local, this script reuses
-- that user instead of failing on the unique email constraint.

DO $$
DECLARE
  v_user_id text;
  v_org_id text;
  v_capture_key_id text;
  v_password_hash text := 'f19500e1c7943bbf2445c1a70d4ebbde:dfc04c59ccaf0ee314e0e8b1de9c4928ef2459975d8c7459ef7a38c289fe248e71ad1f1f12f99d1427a6bd77113b35dd45f53e9845c0cadd3b68cc7f1e21aa04';
BEGIN
  SELECT "id"
  INTO v_user_id
  FROM "user"
  WHERE "email" = 'admin@crikket.local'
  LIMIT 1;

  IF v_user_id IS NULL THEN
    v_user_id := 'seed_admin_user';

    INSERT INTO "user" (
      "id",
      "name",
      "email",
      "email_verified",
      "image",
      "created_at",
      "updated_at",
      "role",
      "banned",
      "ban_reason",
      "ban_expires"
    )
    VALUES (
      v_user_id,
      'Crikket Admin',
      'admin@crikket.local',
      true,
      null,
      now(),
      now(),
      'admin',
      false,
      null,
      null
    );
  ELSE
    UPDATE "user"
    SET
      "name" = COALESCE(NULLIF("name", ''), 'Crikket Admin'),
      "email_verified" = true,
      "updated_at" = now(),
      "role" = COALESCE("role", 'admin'),
      "banned" = false
    WHERE "id" = v_user_id;
  END IF;

  IF EXISTS (
    SELECT 1
    FROM "account"
    WHERE "user_id" = v_user_id
      AND "provider_id" = 'credential'
  ) THEN
    UPDATE "account"
    SET
      "account_id" = v_user_id,
      "password" = v_password_hash,
      "updated_at" = now()
    WHERE "user_id" = v_user_id
      AND "provider_id" = 'credential';
  ELSE
    INSERT INTO "account" (
      "id",
      "account_id",
      "provider_id",
      "user_id",
      "access_token",
      "refresh_token",
      "id_token",
      "access_token_expires_at",
      "refresh_token_expires_at",
      "scope",
      "password",
      "created_at",
      "updated_at"
    )
    VALUES (
      'seed_credential_' || v_user_id,
      v_user_id,
      'credential',
      v_user_id,
      null,
      null,
      null,
      null,
      null,
      null,
      v_password_hash,
      now(),
      now()
    );
  END IF;

  SELECT "id"
  INTO v_org_id
  FROM "organization"
  WHERE "slug" = 'crikket-demo'
  LIMIT 1;

  IF v_org_id IS NULL THEN
    v_org_id := 'seed_crikket_org';

    INSERT INTO "organization" (
      "id",
      "name",
      "slug",
      "logo",
      "created_at",
      "metadata"
    )
    VALUES (
      v_org_id,
      'Crikket Demo',
      'crikket-demo',
      null,
      now(),
      null
    );
  ELSE
    UPDATE "organization"
    SET
      "name" = 'Crikket Demo',
      "logo" = null,
      "metadata" = null
    WHERE "id" = v_org_id;
  END IF;

  IF EXISTS (
    SELECT 1
    FROM "member"
    WHERE "organization_id" = v_org_id
      AND "user_id" = v_user_id
  ) THEN
    UPDATE "member"
    SET "role" = 'owner'
    WHERE "organization_id" = v_org_id
      AND "user_id" = v_user_id;
  ELSE
    INSERT INTO "member" (
      "id",
      "organization_id",
      "user_id",
      "role",
      "created_at"
    )
    VALUES (
      'seed_member_' || v_org_id || '_' || v_user_id,
      v_org_id,
      v_user_id,
      'owner',
      now()
    );
  END IF;

  INSERT INTO "organization_billing_account" (
    "organization_id",
    "provider",
    "polar_customer_id",
    "polar_subscription_id",
    "plan",
    "subscription_status",
    "current_period_start",
    "current_period_end",
    "cancel_at_period_end",
    "last_webhook_at",
    "created_at",
    "updated_at"
  )
  VALUES (
    v_org_id,
    'polar',
    null,
    null,
    'free',
    'none',
    null,
    null,
    false,
    null,
    now(),
    now()
  )
  ON CONFLICT ("organization_id") DO UPDATE
  SET
    "plan" = EXCLUDED."plan",
    "subscription_status" = EXCLUDED."subscription_status",
    "cancel_at_period_end" = false,
    "updated_at" = now();

  INSERT INTO "organization_entitlement" (
    "organization_id",
    "plan",
    "entitlements",
    "last_computed_at",
    "source",
    "created_at",
    "updated_at"
  )
  VALUES (
    v_org_id,
    'free',
    '{}'::jsonb,
    now(),
    'seed',
    now(),
    now()
  )
  ON CONFLICT ("organization_id") DO UPDATE
  SET
    "plan" = EXCLUDED."plan",
    "entitlements" = EXCLUDED."entitlements",
    "last_computed_at" = now(),
    "source" = EXCLUDED."source",
    "updated_at" = now();

  SELECT "id"
  INTO v_capture_key_id
  FROM "capture_public_key"
  WHERE "key" = 'crk_seed_demo_key_000000000001'
  LIMIT 1;

  IF v_capture_key_id IS NULL THEN
    v_capture_key_id := 'seed_capture_public_key';

    INSERT INTO "capture_public_key" (
      "id",
      "organization_id",
      "key",
      "label",
      "allowed_origins",
      "status",
      "created_by",
      "rotated_at",
      "revoked_at",
      "created_at",
      "updated_at"
    )
    VALUES (
      v_capture_key_id,
      v_org_id,
      'crk_seed_demo_key_000000000001',
      'localhost',
      ARRAY['http://localhost:3001']::text[],
      'active',
      v_user_id,
      null,
      null,
      now(),
      now()
    );
  ELSE
    UPDATE "capture_public_key"
    SET
      "organization_id" = v_org_id,
      "label" = 'localhost',
      "allowed_origins" = ARRAY['http://localhost:3001']::text[],
      "status" = 'active',
      "created_by" = v_user_id,
      "updated_at" = now()
    WHERE "id" = v_capture_key_id;
  END IF;

  INSERT INTO "bug_report" (
    "id",
    "organization_id",
    "reporter_id",
    "title",
    "description",
    "status",
    "priority",
    "tags",
    "url",
    "attachment_type",
    "capture_key",
    "capture_content_type",
    "capture_size_bytes",
    "capture_uploaded_at",
    "thumbnail_key",
    "thumbnail_content_type",
    "debugger_key",
    "debugger_content_encoding",
    "debugger_size_bytes",
    "debugger_uploaded_at",
    "debugger_ingestion_status",
    "debugger_ingestion_error",
    "debugger_ingested_at",
    "submission_status",
    "visibility",
    "metadata",
    "device_info",
    "created_at",
    "updated_at"
  )
  VALUES (
    'seed_bug_report',
    v_org_id,
    v_user_id,
    'Welcome to Crikket',
    'This sample report confirms the database schema and starter data are ready.',
    'open',
    'medium',
    ARRAY['demo', 'seed']::text[],
    'http://localhost:3001',
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    null,
    'completed',
    null,
    now(),
    'ready',
    'private',
    '{"source":"seed"}'::jsonb,
    '{"browser":"Seed data","os":"Supabase","viewport":{"width":1440,"height":900}}'::jsonb,
    now(),
    now()
  )
  ON CONFLICT ("id") DO UPDATE
  SET
    "organization_id" = EXCLUDED."organization_id",
    "reporter_id" = EXCLUDED."reporter_id",
    "title" = EXCLUDED."title",
    "description" = EXCLUDED."description",
    "status" = EXCLUDED."status",
    "priority" = EXCLUDED."priority",
    "tags" = EXCLUDED."tags",
    "url" = EXCLUDED."url",
    "metadata" = EXCLUDED."metadata",
    "device_info" = EXCLUDED."device_info",
    "updated_at" = now();

  INSERT INTO "bug_report_log" (
    "id",
    "bug_report_id",
    "level",
    "message",
    "timestamp",
    "offset",
    "metadata"
  )
  VALUES (
    'seed_bug_report_log',
    'seed_bug_report',
    'info',
    'Seed data created successfully.',
    now(),
    0,
    '{"source":"seed"}'::jsonb
  )
  ON CONFLICT ("id") DO UPDATE
  SET
    "level" = EXCLUDED."level",
    "message" = EXCLUDED."message",
    "timestamp" = now(),
    "offset" = EXCLUDED."offset",
    "metadata" = EXCLUDED."metadata";
END $$;
