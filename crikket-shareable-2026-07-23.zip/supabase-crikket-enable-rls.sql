-- Optional Supabase RLS helper for Crikket.
-- Use this only if you intentionally want Row Level Security enabled.
-- Crikket normally talks to Postgres through its backend DATABASE_URL, so
-- the base schema in supabase-crikket-schema.sql is usually enough.

ALTER TABLE "account" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "invitation" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "member" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "organization" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "rate_limit" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "session" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "user" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "verification" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "billing_webhook_event" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "organization_billing_account" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "organization_entitlement" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "bug_report" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "bug_report_action" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "bug_report_artifact_cleanup" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "bug_report_ingestion_job" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "bug_report_log" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "bug_report_network_request" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "bug_report_upload_session" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "capture_public_key" ENABLE ROW LEVEL SECURITY;
