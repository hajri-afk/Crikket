-- Crikket starter data for Supabase.
-- Run this after supabase-crikket-schema.sql.
--
-- Demo login:
--   Email:    admin@crikket.local
--   Password: Password123!
--
-- Important:
-- This creates a local demo account. Change the email/password after login,
-- or delete this file/data before using the app publicly.

BEGIN;

INSERT INTO "user" (
  "id",
  "name",
  "email",
  "email_verified",
  "image",
  "created_at",
  "updated_at",
  "role",
  "banned",
  "ban_reason",
  "ban_expires"
)
VALUES (
  'seed_admin_user',
  'Crikket Admin',
  'admin@crikket.local',
  true,
  null,
  now(),
  now(),
  'admin',
  false,
  null,
  null
)
ON CONFLICT ("id") DO UPDATE
SET
  "name" = EXCLUDED."name",
  "email" = EXCLUDED."email",
  "email_verified" = EXCLUDED."email_verified",
  "updated_at" = now(),
  "role" = EXCLUDED."role",
  "banned" = false;

INSERT INTO "account" (
  "id",
  "account_id",
  "provider_id",
  "user_id",
  "access_token",
  "refresh_token",
  "id_token",
  "access_token_expires_at",
  "refresh_token_expires_at",
  "scope",
  "password",
  "created_at",
  "updated_at"
)
VALUES (
  'seed_admin_credential_account',
  'seed_admin_user',
  'credential',
  'seed_admin_user',
  null,
  null,
  null,
  null,
  null,
  null,
  'f19500e1c7943bbf2445c1a70d4ebbde:dfc04c59ccaf0ee314e0e8b1de9c4928ef2459975d8c7459ef7a38c289fe248e71ad1f1f12f99d1427a6bd77113b35dd45f53e9845c0cadd3b68cc7f1e21aa04',
  now(),
  now()
)
ON CONFLICT ("id") DO UPDATE
SET
  "account_id" = EXCLUDED."account_id",
  "provider_id" = EXCLUDED."provider_id",
  "user_id" = EXCLUDED."user_id",
  "password" = EXCLUDED."password",
  "updated_at" = now();

INSERT INTO "organization" (
  "id",
  "name",
  "slug",
  "logo",
  "created_at",
  "metadata"
)
VALUES (
  'seed_crikket_org',
  'Crikket Demo',
  'crikket-demo',
  null,
  now(),
  null
)
ON CONFLICT ("id") DO UPDATE
SET
  "name" = EXCLUDED."name",
  "slug" = EXCLUDED."slug",
  "logo" = EXCLUDED."logo",
  "metadata" = EXCLUDED."metadata";

INSERT INTO "member" (
  "id",
  "organization_id",
  "user_id",
  "role",
  "created_at"
)
VALUES (
  'seed_admin_member',
  'seed_crikket_org',
  'seed_admin_user',
  'owner',
  now()
)
ON CONFLICT ("id") DO UPDATE
SET
  "organization_id" = EXCLUDED."organization_id",
  "user_id" = EXCLUDED."user_id",
  "role" = EXCLUDED."role";

INSERT INTO "organization_billing_account" (
  "organization_id",
  "provider",
  "polar_customer_id",
  "polar_subscription_id",
  "plan",
  "subscription_status",
  "current_period_start",
  "current_period_end",
  "cancel_at_period_end",
  "last_webhook_at",
  "created_at",
  "updated_at"
)
VALUES (
  'seed_crikket_org',
  'polar',
  null,
  null,
  'free',
  'none',
  null,
  null,
  false,
  null,
  now(),
  now()
)
ON CONFLICT ("organization_id") DO UPDATE
SET
  "plan" = EXCLUDED."plan",
  "subscription_status" = EXCLUDED."subscription_status",
  "cancel_at_period_end" = false,
  "updated_at" = now();

INSERT INTO "organization_entitlement" (
  "organization_id",
  "plan",
  "entitlements",
  "last_computed_at",
  "source",
  "created_at",
  "updated_at"
)
VALUES (
  'seed_crikket_org',
  'free',
  '{}'::jsonb,
  now(),
  'seed',
  now(),
  now()
)
ON CONFLICT ("organization_id") DO UPDATE
SET
  "plan" = EXCLUDED."plan",
  "entitlements" = EXCLUDED."entitlements",
  "last_computed_at" = now(),
  "source" = EXCLUDED."source",
  "updated_at" = now();

INSERT INTO "capture_public_key" (
  "id",
  "organization_id",
  "key",
  "label",
  "allowed_origins",
  "status",
  "created_by",
  "rotated_at",
  "revoked_at",
  "created_at",
  "updated_at"
)
VALUES (
  'seed_capture_public_key',
  'seed_crikket_org',
  'crk_seed_demo_key_000000000001',
  'localhost',
  ARRAY['http://localhost:3001']::text[],
  'active',
  'seed_admin_user',
  null,
  null,
  now(),
  now()
)
ON CONFLICT ("id") DO UPDATE
SET
  "organization_id" = EXCLUDED."organization_id",
  "key" = EXCLUDED."key",
  "label" = EXCLUDED."label",
  "allowed_origins" = EXCLUDED."allowed_origins",
  "status" = EXCLUDED."status",
  "created_by" = EXCLUDED."created_by",
  "updated_at" = now();

INSERT INTO "bug_report" (
  "id",
  "organization_id",
  "reporter_id",
  "title",
  "description",
  "status",
  "priority",
  "tags",
  "url",
  "attachment_type",
  "capture_key",
  "capture_content_type",
  "capture_size_bytes",
  "capture_uploaded_at",
  "thumbnail_key",
  "thumbnail_content_type",
  "debugger_key",
  "debugger_content_encoding",
  "debugger_size_bytes",
  "debugger_uploaded_at",
  "debugger_ingestion_status",
  "debugger_ingestion_error",
  "debugger_ingested_at",
  "submission_status",
  "visibility",
  "metadata",
  "device_info",
  "created_at",
  "updated_at"
)
VALUES (
  'seed_bug_report',
  'seed_crikket_org',
  'seed_admin_user',
  'Welcome to Crikket',
  'This sample report confirms the database schema and starter data are ready.',
  'open',
  'medium',
  ARRAY['demo', 'seed']::text[],
  'http://localhost:3001',
  null,
  null,
  null,
  null,
  null,
  null,
  null,
  null,
  null,
  null,
  null,
  'completed',
  null,
  now(),
  'ready',
  'private',
  '{"source":"seed"}'::jsonb,
  '{"browser":"Seed data","os":"Supabase","viewport":{"width":1440,"height":900}}'::jsonb,
  now(),
  now()
)
ON CONFLICT ("id") DO UPDATE
SET
  "organization_id" = EXCLUDED."organization_id",
  "reporter_id" = EXCLUDED."reporter_id",
  "title" = EXCLUDED."title",
  "description" = EXCLUDED."description",
  "status" = EXCLUDED."status",
  "priority" = EXCLUDED."priority",
  "tags" = EXCLUDED."tags",
  "url" = EXCLUDED."url",
  "metadata" = EXCLUDED."metadata",
  "device_info" = EXCLUDED."device_info",
  "updated_at" = now();

INSERT INTO "bug_report_log" (
  "id",
  "bug_report_id",
  "level",
  "message",
  "timestamp",
  "offset",
  "metadata"
)
VALUES (
  'seed_bug_report_log',
  'seed_bug_report',
  'info',
  'Seed data created successfully.',
  now(),
  0,
  '{"source":"seed"}'::jsonb
)
ON CONFLICT ("id") DO UPDATE
SET
  "level" = EXCLUDED."level",
  "message" = EXCLUDED."message",
  "timestamp" = now(),
  "offset" = EXCLUDED."offset",
  "metadata" = EXCLUDED."metadata";

COMMIT;
