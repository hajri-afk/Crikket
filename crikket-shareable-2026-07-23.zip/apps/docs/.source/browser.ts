// @ts-nocheck
import { browser } from 'fumadocs-mdx/runtime/browser';
import type * as Config from '../source.config';

const create = browser<typeof Config, import("fumadocs-mdx/runtime/types").InternalTypeConfig & {
  DocData: {
  }
}>();
const browserCollections = {
  docs: create.doc("docs", {"comparison.mdx": () => import("../content/docs/comparison.mdx?collection=docs"), "index.mdx": () => import("../content/docs/index.mdx?collection=docs"), "deployment/caddy.mdx": () => import("../content/docs/deployment/caddy.mdx?collection=docs"), "deployment/vercel.mdx": () => import("../content/docs/deployment/vercel.mdx?collection=docs"), "extension/index.mdx": () => import("../content/docs/extension/index.mdx?collection=docs"), "self-hosting/index.mdx": () => import("../content/docs/self-hosting/index.mdx?collection=docs"), "self-hosting/operations.mdx": () => import("../content/docs/self-hosting/operations.mdx?collection=docs"), "self-hosting/production.mdx": () => import("../content/docs/self-hosting/production.mdx?collection=docs"), "self-hosting/quick-start.mdx": () => import("../content/docs/self-hosting/quick-start.mdx?collection=docs"), "self-hosting/storage.mdx": () => import("../content/docs/self-hosting/storage.mdx?collection=docs"), "self-hosting/troubleshooting.mdx": () => import("../content/docs/self-hosting/troubleshooting.mdx?collection=docs"), "usage/index.mdx": () => import("../content/docs/usage/index.mdx?collection=docs"), "usage/integration.mdx": () => import("../content/docs/usage/integration.mdx?collection=docs"), "usage/quick-start.mdx": () => import("../content/docs/usage/quick-start.mdx?collection=docs"), }),
};
export default browserCollections;