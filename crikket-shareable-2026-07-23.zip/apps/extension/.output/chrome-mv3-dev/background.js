var background = (function() {
  "use strict";
  function defineBackground(arg) {
    if (arg == null || typeof arg === "function") return { main: arg };
    return arg;
  }
  function reportNonFatalError(context, error, options) {
    console.warn(`[Non-fatal] ${context}`, error);
  }
  const MAX_EVENT_COUNT = 2e3;
  const MAX_TEXT_LENGTH = 2e3;
  const MAX_URL_LENGTH = 4096;
  const MAX_NETWORK_BODY_LENGTH = 4e3;
  const BACKGROUND_LISTENER_FLAG = "__crikketDebuggerBackgroundListenerRegistered";
  const DEBUGGER_SESSIONS_STORAGE_KEY = "crikketDebuggerSessions";
  const START_SESSION_MESSAGE = "CRIKKET_DEBUGGER_START_SESSION";
  const MARK_RECORDING_STARTED_MESSAGE = "CRIKKET_DEBUGGER_MARK_RECORDING_STARTED";
  const GET_SESSION_SNAPSHOT_MESSAGE = "CRIKKET_DEBUGGER_GET_SESSION_SNAPSHOT";
  const DISCARD_SESSION_MESSAGE = "CRIKKET_DEBUGGER_DISCARD_SESSION";
  const PAGE_EVENT_MESSAGE = "CRIKKET_DEBUGGER_PAGE_EVENT";
  const PAGE_EVENTS_MESSAGE = "CRIKKET_DEBUGGER_PAGE_EVENTS";
  const ENSURE_PAGE_RUNTIME_MESSAGE = "CRIKKET_DEBUGGER_ENSURE_PAGE_RUNTIME";
  function normalizeStoredSession(value) {
    if (!isRecord(value))
      return null;
    const sessionId = asOptionalString(value.sessionId);
    const captureTabId = asOptionalNumber(value.captureTabId);
    const captureType = value.captureType;
    const startedAt = asOptionalNumber(value.startedAt);
    const recordingStartedAt = value.recordingStartedAt === null ? null : asOptionalNumber(value.recordingStartedAt);
    if (!sessionId || captureTabId === void 0 || startedAt === void 0) {
      return null;
    }
    if (captureType !== "video" && captureType !== "screenshot") {
      return null;
    }
    const events = Array.isArray(value.events) ? value.events.map(normalizeDebuggerEvent).filter(isDefined) : [];
    return {
      sessionId,
      captureTabId,
      captureType,
      startedAt,
      recordingStartedAt: recordingStartedAt ?? null,
      events
    };
  }
  function normalizeDebuggerEvent(value) {
    if (!isRecord(value))
      return null;
    const kind = value.kind;
    if (kind !== "action" && kind !== "console" && kind !== "network") {
      return null;
    }
    const timestamp = asOptionalNumber(value.timestamp);
    if (timestamp === void 0)
      return null;
    if (kind === "action") {
      const actionType = asOptionalString(value.actionType);
      if (!actionType)
        return null;
      return {
        kind,
        timestamp,
        actionType,
        target: asOptionalString(value.target, MAX_TEXT_LENGTH),
        metadata: sanitizeRecord(value.metadata)
      };
    }
    if (kind === "console") {
      const level = value.level;
      if (level !== "log" && level !== "info" && level !== "warn" && level !== "error" && level !== "debug") {
        return null;
      }
      const message = asOptionalString(value.message, MAX_TEXT_LENGTH);
      if (!message)
        return null;
      return {
        kind,
        timestamp,
        level,
        message,
        metadata: sanitizeRecord(value.metadata)
      };
    }
    const method = asOptionalString(value.method, 20);
    const url = asOptionalString(value.url, MAX_URL_LENGTH);
    if (!(method && url))
      return null;
    return {
      kind,
      timestamp,
      method,
      url,
      status: asOptionalNumber(value.status),
      duration: asOptionalNumber(value.duration),
      requestHeaders: sanitizeHeaders(value.requestHeaders),
      responseHeaders: sanitizeHeaders(value.responseHeaders),
      requestBody: asOptionalString(value.requestBody, MAX_NETWORK_BODY_LENGTH),
      responseBody: asOptionalString(value.responseBody, MAX_NETWORK_BODY_LENGTH)
    };
  }
  function sanitizeHeaders(value) {
    if (!isRecord(value))
      return void 0;
    const result2 = {};
    for (const [key, headerValue] of Object.entries(value)) {
      if (typeof headerValue !== "string")
        continue;
      const normalizedKey = key.trim().toLowerCase();
      if (!normalizedKey || shouldHideHeader(normalizedKey)) {
        continue;
      }
      result2[normalizedKey.slice(0, 120)] = headerValue.slice(0, 500);
    }
    return Object.keys(result2).length > 0 ? result2 : void 0;
  }
  function shouldHideHeader(headerName) {
    return headerName.includes("debugger");
  }
  function sanitizeRecord(value) {
    if (!isRecord(value))
      return void 0;
    const result2 = {};
    for (const [key, entryValue] of Object.entries(value)) {
      const normalized = sanitizeJsonValue(entryValue);
      if (normalized === void 0)
        continue;
      result2[key.slice(0, 120)] = normalized;
    }
    return Object.keys(result2).length > 0 ? result2 : void 0;
  }
  function sanitizeJsonValue(value, depth = 0) {
    if (depth > 3)
      return void 0;
    if (value === null || typeof value === "boolean" || typeof value === "number") {
      return value;
    }
    if (typeof value === "string") {
      return value.slice(0, MAX_TEXT_LENGTH);
    }
    if (Array.isArray(value)) {
      return value.slice(0, 30).map((entry) => sanitizeJsonValue(entry, depth + 1)).filter(isDefined);
    }
    if (isRecord(value)) {
      const result2 = {};
      for (const [key, entryValue] of Object.entries(value).slice(0, 30)) {
        const normalized = sanitizeJsonValue(entryValue, depth + 1);
        if (normalized === void 0)
          continue;
        result2[key.slice(0, 120)] = normalized;
      }
      return result2;
    }
    return void 0;
  }
  function asOptionalString(value, maxLength = MAX_TEXT_LENGTH) {
    if (typeof value !== "string")
      return void 0;
    const trimmed = value.trim();
    if (!trimmed)
      return void 0;
    return trimmed.slice(0, maxLength);
  }
  function asOptionalNumber(value) {
    if (typeof value !== "number" || !Number.isFinite(value)) {
      return void 0;
    }
    return Math.floor(value);
  }
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function isDefined(value) {
    return value !== null && value !== void 0;
  }
  function isRecordLike(value) {
    return isRecord(value);
  }
  function isDebuggerRuntimeMessage(value) {
    if (!isRecordLike(value)) return false;
    const messageType = value.type;
    if (typeof messageType !== "string") return false;
    return messageType === START_SESSION_MESSAGE || messageType === MARK_RECORDING_STARTED_MESSAGE || messageType === GET_SESSION_SNAPSHOT_MESSAGE || messageType === DISCARD_SESSION_MESSAGE || messageType === PAGE_EVENT_MESSAGE || messageType === PAGE_EVENTS_MESSAGE || messageType === ENSURE_PAGE_RUNTIME_MESSAGE;
  }
  const MAX_ACTION_EVENT_COUNT = 400;
  const MAX_CONSOLE_EVENT_COUNT = 800;
  const MAX_NETWORK_EVENT_COUNT = 1200;
  function appendEventWithRetentionPolicy(events, event) {
    events.push(event);
    enforceKindCap(events, event.kind);
    while (events.length > MAX_EVENT_COUNT) {
      const dropIndex = findOldestEventIndexByPriority(events, [
        "console",
        "action",
        "network"
      ]);
      events.splice(dropIndex, 1);
    }
  }
  function appendNetworkEventWithDedup(events, event) {
    if (isLikelyDuplicateNetworkEvent(events, event)) {
      return;
    }
    appendEventWithRetentionPolicy(events, event);
  }
  function appendActionEventWithDedup(events, event) {
    if (isLikelyDuplicateNavigationEvent(events, event)) {
      return;
    }
    appendEventWithRetentionPolicy(events, event);
  }
  function isLikelyDuplicateNetworkEvent(events, candidate) {
    const DUPLICATE_WINDOW_MS = 350;
    for (let index = events.length - 1; index >= 0; index -= 1) {
      const event = events[index];
      if (!event || event.kind !== "network") {
        continue;
      }
      const isSameKey = event.method === candidate.method && event.url === candidate.url && (event.status ?? 0) === (candidate.status ?? 0);
      if (!isSameKey) {
        continue;
      }
      const delta = Math.abs(event.timestamp - candidate.timestamp);
      if (delta > DUPLICATE_WINDOW_MS) {
        return false;
      }
      return true;
    }
    return false;
  }
  function isLikelyDuplicateNavigationEvent(events, candidate) {
    if (candidate.actionType !== "navigation") {
      return false;
    }
    const DUPLICATE_WINDOW_MS = 500;
    const candidateUrl = getNavigationUrl(candidate);
    if (!candidateUrl) {
      return false;
    }
    for (let index = events.length - 1; index >= 0; index -= 1) {
      const event = events[index];
      if (!event || event.kind !== "action" || event.actionType !== "navigation") {
        continue;
      }
      const delta = Math.abs(event.timestamp - candidate.timestamp);
      if (delta > DUPLICATE_WINDOW_MS) {
        return false;
      }
      const previousUrl = getNavigationUrl(event);
      if (previousUrl === candidateUrl) {
        return true;
      }
    }
    return false;
  }
  function getNavigationUrl(event) {
    const metadata = event.metadata;
    if (!(metadata && typeof metadata === "object")) {
      return null;
    }
    const url = metadata.url;
    return typeof url === "string" && url.length > 0 ? url : null;
  }
  function enforceKindCap(events, kind) {
    const maxPerKind = getMaxPerKind(kind);
    let count = 0;
    for (const event of events) {
      if (event.kind === kind) {
        count += 1;
      }
    }
    const overflowCount = count - maxPerKind;
    if (overflowCount <= 0) {
      return;
    }
    let removed = 0;
    for (let index = 0; index < events.length && removed < overflowCount; index += 1) {
      if (events[index]?.kind !== kind) {
        continue;
      }
      events.splice(index, 1);
      index -= 1;
      removed += 1;
    }
  }
  function getMaxPerKind(kind) {
    if (kind === "action") {
      return MAX_ACTION_EVENT_COUNT;
    }
    if (kind === "console") {
      return MAX_CONSOLE_EVENT_COUNT;
    }
    return MAX_NETWORK_EVENT_COUNT;
  }
  function findOldestEventIndexByPriority(events, priority) {
    for (const kind of priority) {
      const index = events.findIndex((event) => event.kind === kind);
      if (index >= 0) {
        return index;
      }
    }
    return 0;
  }
  const DEBUGGER_CONTENT_BRIDGE_FILE = "debugger-content-bridge.js";
  const DEBUGGER_PAGE_RUNTIME_FILE = "debugger-page.js";
  function createSessionId() {
    if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
      return crypto.randomUUID();
    }
    const random = Math.random().toString(36).slice(2, 10);
    return `dbg_${Date.now()}_${random}`;
  }
  async function injectDebuggerScriptIntoTab(tabId) {
    if (!chrome.scripting?.executeScript) {
      return;
    }
    try {
      await chrome.scripting.executeScript({
        target: {
          tabId
        },
        files: [DEBUGGER_CONTENT_BRIDGE_FILE]
      });
      await chrome.scripting.executeScript({
        target: {
          tabId
        },
        world: "MAIN",
        files: [DEBUGGER_PAGE_RUNTIME_FILE]
      });
    } catch (error) {
      reportNonFatalError(
        `Failed to inject debugger instrumentation script into tab ${tabId}`,
        error
      );
    }
  }
  function isInjectablePageUrl(url) {
    return url.startsWith("http://") || url.startsWith("https://");
  }
  function createDebuggerSessionStore() {
    const sessionsById = /* @__PURE__ */ new Map();
    const tabToSession = /* @__PURE__ */ new Map();
    const recentEventsByTab = /* @__PURE__ */ new Map();
    let isLoaded = false;
    let loadPromise = null;
    let persistTimer = null;
    const schedulePersist = () => {
      if (persistTimer) {
        return;
      }
      persistTimer = setTimeout(() => {
        persistTimer = null;
        persistState().catch((error) => {
          reportNonFatalError("Failed to persist debugger state", error);
        });
      }, 250);
    };
    const persistState = async () => {
      const sessionsSnapshot = Array.from(sessionsById.values());
      await chrome.storage.local.set({
        [DEBUGGER_SESSIONS_STORAGE_KEY]: sessionsSnapshot
      });
    };
    const hydrateStoredState = async () => {
      const result2 = await chrome.storage.local.get([
        DEBUGGER_SESSIONS_STORAGE_KEY
      ]);
      const storedSessions = result2[DEBUGGER_SESSIONS_STORAGE_KEY];
      if (!Array.isArray(storedSessions)) {
        return;
      }
      for (const candidate of storedSessions) {
        const session = normalizeStoredSession(candidate);
        if (!session) {
          continue;
        }
        sessionsById.set(session.sessionId, session);
        tabToSession.set(session.captureTabId, session.sessionId);
      }
    };
    const ensureLoaded = async () => {
      if (isLoaded) {
        return;
      }
      if (loadPromise) {
        await loadPromise;
        return;
      }
      loadPromise = hydrateStoredState().catch((error) => {
        reportNonFatalError("Failed to load debugger state from storage", error);
      }).finally(() => {
        isLoaded = true;
        loadPromise = null;
      });
      await loadPromise;
    };
    const removeSession = (sessionId) => {
      const session = sessionsById.get(sessionId);
      if (!session) {
        return;
      }
      sessionsById.delete(sessionId);
      const activeSessionId = tabToSession.get(session.captureTabId);
      if (activeSessionId === sessionId) {
        tabToSession.delete(session.captureTabId);
      }
    };
    const appendEventsToSession = (tabId, events) => {
      if (events.length === 0) {
        return;
      }
      const sessionId = tabToSession.get(tabId);
      const session = sessionId ? sessionsById.get(sessionId) : void 0;
      if (!session) {
        return;
      }
      for (const event of events) {
        if (event.kind === "network") {
          appendNetworkEventWithDedup(session.events, event);
        } else if (event.kind === "action") {
          appendActionEventWithDedup(session.events, event);
        } else {
          appendEventWithRetentionPolicy(session.events, event);
        }
      }
      schedulePersist();
    };
    const appendEventsToRecentBuffer = (tabId, events) => {
      if (events.length === 0) {
        return;
      }
      const now = Date.now();
      const MAX_RECENT_EVENT_AGE_MS = 6e4;
      const MAX_RECENT_EVENT_COUNT = 250;
      const existing = recentEventsByTab.get(tabId) ?? [];
      const merged = [...existing, ...events].filter((event) => {
        return now - event.timestamp <= MAX_RECENT_EVENT_AGE_MS;
      });
      if (merged.length > MAX_RECENT_EVENT_COUNT) {
        recentEventsByTab.set(
          tabId,
          merged.slice(merged.length - MAX_RECENT_EVENT_COUNT)
        );
        return;
      }
      recentEventsByTab.set(tabId, merged);
    };
    const consumeInstantReplayEvents = (tabId, lookbackMs) => {
      const now = Date.now();
      const recentEvents = recentEventsByTab.get(tabId) ?? [];
      if (recentEvents.length === 0) {
        return [];
      }
      return recentEvents.filter((event) => {
        return now - event.timestamp <= lookbackMs;
      });
    };
    const startSession = async (payload) => {
      await ensureLoaded();
      const startedAt = Date.now();
      const sessionId = createSessionId();
      const instantReplayLookbackMs = typeof payload.instantReplayLookbackMs === "number" && Number.isFinite(payload.instantReplayLookbackMs) && payload.instantReplayLookbackMs > 0 ? Math.floor(payload.instantReplayLookbackMs) : 0;
      const instantReplayEvents = instantReplayLookbackMs > 0 ? consumeInstantReplayEvents(
        payload.captureTabId,
        instantReplayLookbackMs
      ) : [];
      const session = {
        sessionId,
        captureTabId: payload.captureTabId,
        captureType: payload.captureType,
        startedAt,
        recordingStartedAt: payload.captureType === "screenshot" ? startedAt : null,
        events: instantReplayEvents
      };
      sessionsById.set(sessionId, session);
      tabToSession.set(payload.captureTabId, sessionId);
      schedulePersist();
      await injectDebuggerScriptIntoTab(payload.captureTabId);
      return {
        sessionId,
        startedAt
      };
    };
    const injectDebuggerScriptForTab = async (tabId) => {
      await ensureLoaded();
      if (!tabToSession.has(tabId)) {
        return;
      }
      await injectDebuggerScriptIntoTab(tabId);
    };
    const appendPageEvents = async (tabId, rawEvents) => {
      await ensureLoaded();
      if (!Array.isArray(rawEvents) || rawEvents.length === 0) {
        return;
      }
      const normalizedEvents = [];
      for (const rawEvent of rawEvents) {
        const normalizedEvent = normalizeDebuggerEvent(rawEvent);
        if (!normalizedEvent) {
          continue;
        }
        normalizedEvents.push(normalizedEvent);
      }
      appendEventsToRecentBuffer(tabId, normalizedEvents);
      appendEventsToSession(tabId, normalizedEvents);
    };
    const getSessionSnapshot = async (sessionId) => {
      await ensureLoaded();
      const session = sessionsById.get(sessionId);
      if (!session) {
        return null;
      }
      return {
        sessionId: session.sessionId,
        captureTabId: session.captureTabId,
        captureType: session.captureType,
        startedAt: session.startedAt,
        recordingStartedAt: session.recordingStartedAt,
        events: session.events
      };
    };
    const markSessionRecordingStarted = async (payload) => {
      await ensureLoaded();
      const session = sessionsById.get(payload.sessionId);
      if (!session) {
        return;
      }
      session.recordingStartedAt = Math.floor(payload.recordingStartedAt);
      schedulePersist();
    };
    const discardSession = async (sessionId) => {
      await ensureLoaded();
      const session = sessionsById.get(sessionId);
      removeSession(sessionId);
      if (session) {
        recentEventsByTab.delete(session.captureTabId);
      }
      schedulePersist();
    };
    const ensureDebuggerScriptForTab = async (tabId, url) => {
      await ensureLoaded();
      if (!(url && isInjectablePageUrl(url))) {
        return;
      }
      if (!tabToSession.has(tabId)) {
        return;
      }
      await injectDebuggerScriptIntoTab(tabId);
    };
    const discardSessionByTabId = async (tabId) => {
      await ensureLoaded();
      const sessionId = tabToSession.get(tabId);
      if (!sessionId) {
        return;
      }
      removeSession(sessionId);
      recentEventsByTab.delete(tabId);
      schedulePersist();
    };
    return {
      injectDebuggerScriptForTab,
      startSession,
      appendPageEvents,
      getSessionSnapshot,
      markSessionRecordingStarted,
      discardSession,
      ensureDebuggerScriptForTab,
      discardSessionByTabId
    };
  }
  function registerDebuggerBackgroundListeners() {
    const scope = globalThis;
    if (scope[BACKGROUND_LISTENER_FLAG]) {
      return;
    }
    scope[BACKGROUND_LISTENER_FLAG] = true;
    const store = createDebuggerSessionStore();
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (!isDebuggerRuntimeMessage(message)) {
        return;
      }
      const safeSendResponse = (response) => {
        sendResponse(response);
      };
      const onError = (error) => {
        safeSendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Debugger handler failed"
        });
      };
      const handler = async () => {
        const tabId = sender.tab?.id;
        const appendEventsForSenderTab = async (events) => {
          if (typeof tabId !== "number") {
            return;
          }
          await store.appendPageEvents(tabId, events);
        };
        switch (message.type) {
          case START_SESSION_MESSAGE: {
            const data = await store.startSession(message.payload);
            safeSendResponse({ ok: true, data });
            return;
          }
          case MARK_RECORDING_STARTED_MESSAGE: {
            await store.markSessionRecordingStarted(message.payload);
            safeSendResponse({ ok: true, data: void 0 });
            return;
          }
          case PAGE_EVENT_MESSAGE: {
            await appendEventsForSenderTab([message.payload.event]);
            safeSendResponse({ ok: true, data: void 0 });
            return;
          }
          case PAGE_EVENTS_MESSAGE: {
            await appendEventsForSenderTab(message.payload.events);
            safeSendResponse({ ok: true, data: void 0 });
            return;
          }
          case ENSURE_PAGE_RUNTIME_MESSAGE: {
            if (typeof tabId === "number") {
              await store.injectDebuggerScriptForTab(tabId);
            }
            safeSendResponse({ ok: true, data: void 0 });
            return;
          }
          case GET_SESSION_SNAPSHOT_MESSAGE: {
            const data = await store.getSessionSnapshot(message.payload.sessionId);
            safeSendResponse({ ok: true, data });
            return;
          }
          case DISCARD_SESSION_MESSAGE: {
            await store.discardSession(message.payload.sessionId);
            safeSendResponse({ ok: true, data: void 0 });
            return;
          }
          default: {
            safeSendResponse({ ok: true, data: void 0 });
            return;
          }
        }
      };
      handler().catch(onError);
      return true;
    });
    chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
      const didTabNavigate = changeInfo.status === "loading" || typeof changeInfo.url === "string";
      if (!didTabNavigate) {
        return;
      }
      const url = typeof changeInfo.url === "string" ? changeInfo.url : tab.url ?? void 0;
      store.ensureDebuggerScriptForTab(tabId, url).catch((error) => {
        reportNonFatalError(
          `Failed to reinject debugger instrumentation after tab update for tab ${tabId}`,
          error
        );
      });
    });
    chrome.tabs.onRemoved.addListener((tabId) => {
      store.discardSessionByTabId(tabId).catch((error) => {
        reportNonFatalError(
          `Failed to discard debugger session for removed tab ${tabId}`,
          error
        );
      });
    });
  }
  const RECORDING_IN_PROGRESS_STORAGE_KEY = "recordingInProgress";
  const RECORDER_TAB_ID_STORAGE_KEY = "recorderTabId";
  const RECORDING_COUNTDOWN_ENDS_AT_STORAGE_KEY = "recordingCountdownEndsAt";
  const RECORDING_STARTED_AT_STORAGE_KEY = "recordingStartedAt";
  const HOTKEY_START_VIDEO_CAPTURE_STORAGE_KEY = "hotkeyStartVideoCapture";
  const HOTKEY_START_SCREENSHOT_CAPTURE_STORAGE_KEY = "hotkeyStartScreenshotCapture";
  const START_RECORDING_COMMAND = "start-video-recording";
  const START_SCREENSHOT_COMMAND = "start-screenshot-capture";
  const STOP_RECORDING_COMMAND = "stop-video-recording";
  async function handleStartRecordingFromHotkey() {
    await queueCaptureStartFromHotkey(HOTKEY_START_VIDEO_CAPTURE_STORAGE_KEY);
  }
  async function handleStartScreenshotFromHotkey() {
    await queueCaptureStartFromHotkey(HOTKEY_START_SCREENSHOT_CAPTURE_STORAGE_KEY);
  }
  async function queueCaptureStartFromHotkey(storageKey) {
    const state = await readRecordingState();
    if (state.isRecordingInProgress) {
      const recorderTabId = await resolveRecorderTabId();
      if (recorderTabId !== null) {
        await focusRecorderTab();
        return;
      }
      await clearStaleRecordingState();
    }
    await chrome.storage.local.set({
      [storageKey]: Date.now()
    });
    await chrome.action.openPopup();
  }
  async function handleStopRecordingFromHotkey() {
    try {
      await chrome.runtime.sendMessage({ type: "STOP_RECORDING_FROM_POPUP" });
    } catch (error) {
      reportNonFatalError(
        "Failed to send STOP_RECORDING_FROM_POPUP for hotkey stop",
        error
      );
    }
    await focusRecorderTab();
  }
  async function handleRecorderHotkeyCommand(command) {
    if (command === START_RECORDING_COMMAND) {
      await handleStartRecordingFromHotkey();
      return;
    }
    if (command === START_SCREENSHOT_COMMAND) {
      await handleStartScreenshotFromHotkey();
      return;
    }
    if (command === STOP_RECORDING_COMMAND) {
      await handleStopRecordingFromHotkey();
    }
  }
  async function readRecordingState() {
    const result2 = await chrome.storage.local.get([
      RECORDING_IN_PROGRESS_STORAGE_KEY
    ]);
    return {
      isRecordingInProgress: Boolean(result2[RECORDING_IN_PROGRESS_STORAGE_KEY])
    };
  }
  async function focusRecorderTab() {
    const recorderTabId = await resolveRecorderTabId();
    if (recorderTabId === null) {
      return;
    }
    const recorderTab = await chrome.tabs.get(recorderTabId);
    if (typeof recorderTab.windowId === "number") {
      await chrome.windows.update(recorderTab.windowId, { focused: true });
    }
    await chrome.tabs.update(recorderTabId, { active: true });
  }
  async function resolveRecorderTabId() {
    const stored = await chrome.storage.local.get([RECORDER_TAB_ID_STORAGE_KEY]);
    const storedTabId = stored[RECORDER_TAB_ID_STORAGE_KEY];
    if (typeof storedTabId === "number") {
      try {
        await chrome.tabs.get(storedTabId);
        return storedTabId;
      } catch (error) {
        reportNonFatalError(
          `Failed to resolve stored recorder tab ${storedTabId} from hotkey flow`,
          error
        );
      }
    }
    const recorderTabs = await chrome.tabs.query({
      url: [chrome.runtime.getURL("/recorder.html*")]
    });
    const mostRecentRecorderTab = recorderTabs.filter((tab) => typeof tab.id === "number").sort((a, b) => (b.id ?? 0) - (a.id ?? 0))[0];
    return mostRecentRecorderTab?.id ?? null;
  }
  async function clearStaleRecordingState() {
    await chrome.storage.local.set({
      [RECORDING_IN_PROGRESS_STORAGE_KEY]: false
    });
    await chrome.storage.local.remove([
      RECORDER_TAB_ID_STORAGE_KEY,
      RECORDING_COUNTDOWN_ENDS_AT_STORAGE_KEY,
      RECORDING_STARTED_AT_STORAGE_KEY
    ]);
  }
  const definition = defineBackground(() => {
    registerDebuggerBackgroundListeners();
    chrome.commands.onCommand.addListener((command) => {
      handleRecorderHotkeyCommand(command).catch(async (error) => {
        reportNonFatalError("Failed to execute recorder hotkey command", error);
        try {
          await chrome.action.openPopup();
        } catch (openPopupError) {
          reportNonFatalError(
            "Failed to open popup after hotkey failure",
            openPopupError
          );
        }
      });
    });
  });
  function initPlugins() {
  }
  const browser$1 = globalThis.browser?.runtime?.id ? globalThis.browser : globalThis.chrome;
  const browser = browser$1;
  var _MatchPattern = class {
    constructor(matchPattern) {
      if (matchPattern === "<all_urls>") {
        this.isAllUrls = true;
        this.protocolMatches = [..._MatchPattern.PROTOCOLS];
        this.hostnameMatch = "*";
        this.pathnameMatch = "*";
      } else {
        const groups = /(.*):\/\/(.*?)(\/.*)/.exec(matchPattern);
        if (groups == null)
          throw new InvalidMatchPattern(matchPattern, "Incorrect format");
        const [_, protocol, hostname, pathname] = groups;
        validateProtocol(matchPattern, protocol);
        validateHostname(matchPattern, hostname);
        this.protocolMatches = protocol === "*" ? ["http", "https"] : [protocol];
        this.hostnameMatch = hostname;
        this.pathnameMatch = pathname;
      }
    }
    includes(url) {
      if (this.isAllUrls)
        return true;
      const u = typeof url === "string" ? new URL(url) : url instanceof Location ? new URL(url.href) : url;
      return !!this.protocolMatches.find((protocol) => {
        if (protocol === "http")
          return this.isHttpMatch(u);
        if (protocol === "https")
          return this.isHttpsMatch(u);
        if (protocol === "file")
          return this.isFileMatch(u);
        if (protocol === "ftp")
          return this.isFtpMatch(u);
        if (protocol === "urn")
          return this.isUrnMatch(u);
      });
    }
    isHttpMatch(url) {
      return url.protocol === "http:" && this.isHostPathMatch(url);
    }
    isHttpsMatch(url) {
      return url.protocol === "https:" && this.isHostPathMatch(url);
    }
    isHostPathMatch(url) {
      if (!this.hostnameMatch || !this.pathnameMatch)
        return false;
      const hostnameMatchRegexs = [
        this.convertPatternToRegex(this.hostnameMatch),
        this.convertPatternToRegex(this.hostnameMatch.replace(/^\*\./, ""))
      ];
      const pathnameMatchRegex = this.convertPatternToRegex(this.pathnameMatch);
      return !!hostnameMatchRegexs.find((regex) => regex.test(url.hostname)) && pathnameMatchRegex.test(url.pathname);
    }
    isFileMatch(url) {
      throw Error("Not implemented: file:// pattern matching. Open a PR to add support");
    }
    isFtpMatch(url) {
      throw Error("Not implemented: ftp:// pattern matching. Open a PR to add support");
    }
    isUrnMatch(url) {
      throw Error("Not implemented: urn:// pattern matching. Open a PR to add support");
    }
    convertPatternToRegex(pattern) {
      const escaped = this.escapeForRegex(pattern);
      const starsReplaced = escaped.replace(/\\\*/g, ".*");
      return RegExp(`^${starsReplaced}$`);
    }
    escapeForRegex(string) {
      return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    }
  };
  var MatchPattern = _MatchPattern;
  MatchPattern.PROTOCOLS = ["http", "https", "file", "ftp", "urn"];
  var InvalidMatchPattern = class extends Error {
    constructor(matchPattern, reason) {
      super(`Invalid match pattern "${matchPattern}": ${reason}`);
    }
  };
  function validateProtocol(matchPattern, protocol) {
    if (!MatchPattern.PROTOCOLS.includes(protocol) && protocol !== "*")
      throw new InvalidMatchPattern(
        matchPattern,
        `${protocol} not a valid protocol (${MatchPattern.PROTOCOLS.join(", ")})`
      );
  }
  function validateHostname(matchPattern, hostname) {
    if (hostname.includes(":"))
      throw new InvalidMatchPattern(matchPattern, `Hostname cannot include a port`);
    if (hostname.includes("*") && hostname.length > 1 && !hostname.startsWith("*."))
      throw new InvalidMatchPattern(
        matchPattern,
        `If using a wildcard (*), it must go at the start of the hostname`
      );
  }
  function print(method, ...args) {
    if (typeof args[0] === "string") method(`[wxt] ${args.shift()}`, ...args);
    else method("[wxt]", ...args);
  }
  const logger = {
    debug: (...args) => print(console.debug, ...args),
    log: (...args) => print(console.log, ...args),
    warn: (...args) => print(console.warn, ...args),
    error: (...args) => print(console.error, ...args)
  };
  let ws;
  function getDevServerWebSocket() {
    if (ws == null) {
      const serverUrl = "ws://localhost:5555";
      logger.debug("Connecting to dev server @", serverUrl);
      ws = new WebSocket(serverUrl, "vite-hmr");
      ws.addWxtEventListener = ws.addEventListener.bind(ws);
      ws.sendCustom = (event, payload) => ws?.send(JSON.stringify({
        type: "custom",
        event,
        payload
      }));
      ws.addEventListener("open", () => {
        logger.debug("Connected to dev server");
      });
      ws.addEventListener("close", () => {
        logger.debug("Disconnected from dev server");
      });
      ws.addEventListener("error", (event) => {
        logger.error("Failed to connect to dev server", event);
      });
      ws.addEventListener("message", (e) => {
        try {
          const message = JSON.parse(e.data);
          if (message.type === "custom") ws?.dispatchEvent(new CustomEvent(message.event, { detail: message.data }));
        } catch (err) {
          logger.error("Failed to handle message", err);
        }
      });
    }
    return ws;
  }
  function keepServiceWorkerAlive() {
    setInterval(async () => {
      await browser.runtime.getPlatformInfo();
    }, 5e3);
  }
  function reloadContentScript(payload) {
    if (browser.runtime.getManifest().manifest_version == 2) reloadContentScriptMv2();
    else reloadContentScriptMv3(payload);
  }
  async function reloadContentScriptMv3({ registration, contentScript }) {
    if (registration === "runtime") await reloadRuntimeContentScriptMv3(contentScript);
    else await reloadManifestContentScriptMv3(contentScript);
  }
  async function reloadManifestContentScriptMv3(contentScript) {
    const id = `wxt:${contentScript.js[0]}`;
    logger.log("Reloading content script:", contentScript);
    const registered = await browser.scripting.getRegisteredContentScripts();
    logger.debug("Existing scripts:", registered);
    const existing = registered.find((cs) => cs.id === id);
    if (existing) {
      logger.debug("Updating content script", existing);
      await browser.scripting.updateContentScripts([{
        ...contentScript,
        id,
        css: contentScript.css ?? []
      }]);
    } else {
      logger.debug("Registering new content script...");
      await browser.scripting.registerContentScripts([{
        ...contentScript,
        id,
        css: contentScript.css ?? []
      }]);
    }
    await reloadTabsForContentScript(contentScript);
  }
  async function reloadRuntimeContentScriptMv3(contentScript) {
    logger.log("Reloading content script:", contentScript);
    const registered = await browser.scripting.getRegisteredContentScripts();
    logger.debug("Existing scripts:", registered);
    const matches = registered.filter((cs) => {
      const hasJs = contentScript.js?.find((js) => cs.js?.includes(js));
      const hasCss = contentScript.css?.find((css) => cs.css?.includes(css));
      return hasJs || hasCss;
    });
    if (matches.length === 0) {
      logger.log("Content script is not registered yet, nothing to reload", contentScript);
      return;
    }
    await browser.scripting.updateContentScripts(matches);
    await reloadTabsForContentScript(contentScript);
  }
  async function reloadTabsForContentScript(contentScript) {
    const allTabs = await browser.tabs.query({});
    const matchPatterns = contentScript.matches.map((match) => new MatchPattern(match));
    const matchingTabs = allTabs.filter((tab) => {
      const url = tab.url;
      if (!url) return false;
      return !!matchPatterns.find((pattern) => pattern.includes(url));
    });
    await Promise.all(matchingTabs.map(async (tab) => {
      try {
        await browser.tabs.reload(tab.id);
      } catch (err) {
        logger.warn("Failed to reload tab:", err);
      }
    }));
  }
  async function reloadContentScriptMv2(_payload) {
    throw Error("TODO: reloadContentScriptMv2");
  }
  {
    try {
      const ws2 = getDevServerWebSocket();
      ws2.addWxtEventListener("wxt:reload-extension", () => {
        browser.runtime.reload();
      });
      ws2.addWxtEventListener("wxt:reload-content-script", (event) => {
        reloadContentScript(event.detail);
      });
      if (true) {
        ws2.addEventListener("open", () => ws2.sendCustom("wxt:background-initialized"));
        keepServiceWorkerAlive();
      }
    } catch (err) {
      logger.error("Failed to setup web socket connection with dev server", err);
    }
    browser.commands.onCommand.addListener((command) => {
      if (command === "wxt:reload-extension") browser.runtime.reload();
    });
  }
  let result;
  try {
    initPlugins();
    result = definition.main();
    if (result instanceof Promise) console.warn("The background's main() function return a promise, but it must be synchronous");
  } catch (err) {
    logger.error("The background crashed on startup!");
    throw err;
  }
  var background_entrypoint_default = result;
  return background_entrypoint_default;
})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZC5qcyIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5idW4vd3h0QDAuMjAuMTcrNzQwNmFkZWI5YmZjZDU1My9ub2RlX21vZHVsZXMvd3h0L2Rpc3QvdXRpbHMvZGVmaW5lLWJhY2tncm91bmQubWpzIiwiLi4vLi4vLi4vLi4vcGFja2FnZXMvc2hhcmVkL3NyYy9saWIvZXJyb3JzLnRzIiwiLi4vLi4vLi4vLi4vcGFja2FnZXMvY2FwdHVyZS1jb3JlL2Rpc3QvZGVidWdnZXIvY29uc3RhbnRzLmpzIiwiLi4vLi4vLi4vLi4vcGFja2FnZXMvY2FwdHVyZS1jb3JlL2Rpc3QvZGVidWdnZXIvbm9ybWFsaXplLmpzIiwiLi4vLi4vbGliL2J1Zy1yZXBvcnQtZGVidWdnZXIvbWVzc2FnaW5nLnRzIiwiLi4vLi4vLi4vLi4vcGFja2FnZXMvY2FwdHVyZS1jb3JlL2Rpc3QvZGVidWdnZXIvZW5naW5lL2JhY2tncm91bmQvcmV0ZW50aW9uLmpzIiwiLi4vLi4vbGliL2J1Zy1yZXBvcnQtZGVidWdnZXIvZW5naW5lL2JhY2tncm91bmQvaW5qZWN0aW9uLnRzIiwiLi4vLi4vbGliL2J1Zy1yZXBvcnQtZGVidWdnZXIvZW5naW5lL2JhY2tncm91bmQvc2Vzc2lvbi1zdG9yZS50cyIsIi4uLy4uL2xpYi9idWctcmVwb3J0LWRlYnVnZ2VyL2VuZ2luZS9iYWNrZ3JvdW5kL2luZGV4LnRzIiwiLi4vLi4vbGliL2NhcHR1cmUtY29udGV4dC50cyIsIi4uLy4uL2xpYi9yZWNvcmRlci1ob3RrZXktY29tbWFuZHMudHMiLCIuLi8uLi9lbnRyeXBvaW50cy9iYWNrZ3JvdW5kLnRzIiwiLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5idW4vQHd4dC1kZXYrYnJvd3NlckAwLjEuMzcvbm9kZV9tb2R1bGVzL0B3eHQtZGV2L2Jyb3dzZXIvc3JjL2luZGV4Lm1qcyIsIi4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8uYnVuL3d4dEAwLjIwLjE3Kzc0MDZhZGViOWJmY2Q1NTMvbm9kZV9tb2R1bGVzL3d4dC9kaXN0L2Jyb3dzZXIubWpzIiwiLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5idW4vQHdlYmV4dC1jb3JlK21hdGNoLXBhdHRlcm5zQDEuMC4zL25vZGVfbW9kdWxlcy9Ad2ViZXh0LWNvcmUvbWF0Y2gtcGF0dGVybnMvbGliL2luZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vI3JlZ2lvbiBzcmMvdXRpbHMvZGVmaW5lLWJhY2tncm91bmQudHNcbmZ1bmN0aW9uIGRlZmluZUJhY2tncm91bmQoYXJnKSB7XG5cdGlmIChhcmcgPT0gbnVsbCB8fCB0eXBlb2YgYXJnID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiB7IG1haW46IGFyZyB9O1xuXHRyZXR1cm4gYXJnO1xufVxuXG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGRlZmluZUJhY2tncm91bmQgfTsiLCJpbnRlcmZhY2UgTm9uRmF0YWxFcnJvck9wdGlvbnMge1xuICBvbmNlPzogYm9vbGVhblxufVxuXG5jb25zdCByZXBvcnRlZENvbnRleHRzID0gbmV3IFNldDxzdHJpbmc+KClcblxuZXhwb3J0IGZ1bmN0aW9uIHJlcG9ydE5vbkZhdGFsRXJyb3IoXG4gIGNvbnRleHQ6IHN0cmluZyxcbiAgZXJyb3I6IHVua25vd24sXG4gIG9wdGlvbnM/OiBOb25GYXRhbEVycm9yT3B0aW9uc1xuKTogdm9pZCB7XG4gIGlmIChvcHRpb25zPy5vbmNlKSB7XG4gICAgaWYgKHJlcG9ydGVkQ29udGV4dHMuaGFzKGNvbnRleHQpKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICByZXBvcnRlZENvbnRleHRzLmFkZChjb250ZXh0KVxuICB9XG5cbiAgY29uc29sZS53YXJuKGBbTm9uLWZhdGFsXSAke2NvbnRleHR9YCwgZXJyb3IpXG59XG5cbmludGVyZmFjZSBFcnJvcldpdGhDb2RlIHtcbiAgY29kZT86IHVua25vd25cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzRXJyb3JXaXRoQ29kZShcbiAgZXJyb3I6IHVua25vd24sXG4gIGNvZGU6IHN0cmluZ1xuKTogZXJyb3IgaXMgRXJyb3IgJiBFcnJvcldpdGhDb2RlIHtcbiAgcmV0dXJuIChcbiAgICBlcnJvciBpbnN0YW5jZW9mIEVycm9yICYmXG4gICAgXCJjb2RlXCIgaW4gZXJyb3IgJiZcbiAgICAoZXJyb3IgYXMgRXJyb3JXaXRoQ29kZSkuY29kZSA9PT0gY29kZVxuICApXG59XG4iLCJleHBvcnQgY29uc3QgTUFYX0VWRU5UX0NPVU5UID0gMjAwMDtcbmV4cG9ydCBjb25zdCBNQVhfVEVYVF9MRU5HVEggPSAyMDAwO1xuZXhwb3J0IGNvbnN0IE1BWF9VUkxfTEVOR1RIID0gNDA5NjtcbmV4cG9ydCBjb25zdCBNQVhfTkVUV09SS19CT0RZX0xFTkdUSCA9IDQwMDA7XG5leHBvcnQgY29uc3QgUEFHRV9CUklER0VfU09VUkNFID0gXCJDUklLS0VUX0RFQlVHR0VSX1BBR0VfQlJJREdFXCI7XG5leHBvcnQgY29uc3QgQkFDS0dST1VORF9MSVNURU5FUl9GTEFHID0gXCJfX2NyaWtrZXREZWJ1Z2dlckJhY2tncm91bmRMaXN0ZW5lclJlZ2lzdGVyZWRcIjtcbmV4cG9ydCBjb25zdCBERUJVR0dFUl9TRVNTSU9OU19TVE9SQUdFX0tFWSA9IFwiY3Jpa2tldERlYnVnZ2VyU2Vzc2lvbnNcIjtcbmV4cG9ydCBjb25zdCBERUJVR0dFUl9SRVBMQVlfQlVGRkVSU19TVE9SQUdFX0tFWSA9IFwiY3Jpa2tldERlYnVnZ2VyUmVwbGF5QnVmZmVyc1wiO1xuZXhwb3J0IGNvbnN0IERFQlVHR0VSX1NFU1NJT05fSURfU1RPUkFHRV9LRVkgPSBcImRlYnVnZ2VyU2Vzc2lvbklkXCI7XG5leHBvcnQgY29uc3QgU1RBUlRfU0VTU0lPTl9NRVNTQUdFID0gXCJDUklLS0VUX0RFQlVHR0VSX1NUQVJUX1NFU1NJT05cIjtcbmV4cG9ydCBjb25zdCBNQVJLX1JFQ09SRElOR19TVEFSVEVEX01FU1NBR0UgPSBcIkNSSUtLRVRfREVCVUdHRVJfTUFSS19SRUNPUkRJTkdfU1RBUlRFRFwiO1xuZXhwb3J0IGNvbnN0IEdFVF9TRVNTSU9OX1NOQVBTSE9UX01FU1NBR0UgPSBcIkNSSUtLRVRfREVCVUdHRVJfR0VUX1NFU1NJT05fU05BUFNIT1RcIjtcbmV4cG9ydCBjb25zdCBESVNDQVJEX1NFU1NJT05fTUVTU0FHRSA9IFwiQ1JJS0tFVF9ERUJVR0dFUl9ESVNDQVJEX1NFU1NJT05cIjtcbmV4cG9ydCBjb25zdCBQQUdFX0VWRU5UX01FU1NBR0UgPSBcIkNSSUtLRVRfREVCVUdHRVJfUEFHRV9FVkVOVFwiO1xuZXhwb3J0IGNvbnN0IFBBR0VfRVZFTlRTX01FU1NBR0UgPSBcIkNSSUtLRVRfREVCVUdHRVJfUEFHRV9FVkVOVFNcIjtcbmV4cG9ydCBjb25zdCBFTlNVUkVfUEFHRV9SVU5USU1FX01FU1NBR0UgPSBcIkNSSUtLRVRfREVCVUdHRVJfRU5TVVJFX1BBR0VfUlVOVElNRVwiO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y29uc3RhbnRzLmpzLm1hcCIsImltcG9ydCB7IE1BWF9ORVRXT1JLX0JPRFlfTEVOR1RILCBNQVhfVEVYVF9MRU5HVEgsIE1BWF9VUkxfTEVOR1RILCB9IGZyb20gXCIuL2NvbnN0YW50c1wiO1xuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZVN0b3JlZFNlc3Npb24odmFsdWUpIHtcbiAgICBpZiAoIWlzUmVjb3JkKHZhbHVlKSlcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgY29uc3Qgc2Vzc2lvbklkID0gYXNPcHRpb25hbFN0cmluZyh2YWx1ZS5zZXNzaW9uSWQpO1xuICAgIGNvbnN0IGNhcHR1cmVUYWJJZCA9IGFzT3B0aW9uYWxOdW1iZXIodmFsdWUuY2FwdHVyZVRhYklkKTtcbiAgICBjb25zdCBjYXB0dXJlVHlwZSA9IHZhbHVlLmNhcHR1cmVUeXBlO1xuICAgIGNvbnN0IHN0YXJ0ZWRBdCA9IGFzT3B0aW9uYWxOdW1iZXIodmFsdWUuc3RhcnRlZEF0KTtcbiAgICBjb25zdCByZWNvcmRpbmdTdGFydGVkQXQgPSB2YWx1ZS5yZWNvcmRpbmdTdGFydGVkQXQgPT09IG51bGxcbiAgICAgICAgPyBudWxsXG4gICAgICAgIDogYXNPcHRpb25hbE51bWJlcih2YWx1ZS5yZWNvcmRpbmdTdGFydGVkQXQpO1xuICAgIGlmICghc2Vzc2lvbklkIHx8IGNhcHR1cmVUYWJJZCA9PT0gdW5kZWZpbmVkIHx8IHN0YXJ0ZWRBdCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBpZiAoY2FwdHVyZVR5cGUgIT09IFwidmlkZW9cIiAmJiBjYXB0dXJlVHlwZSAhPT0gXCJzY3JlZW5zaG90XCIpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGNvbnN0IGV2ZW50cyA9IEFycmF5LmlzQXJyYXkodmFsdWUuZXZlbnRzKVxuICAgICAgICA/IHZhbHVlLmV2ZW50cy5tYXAobm9ybWFsaXplRGVidWdnZXJFdmVudCkuZmlsdGVyKGlzRGVmaW5lZClcbiAgICAgICAgOiBbXTtcbiAgICByZXR1cm4ge1xuICAgICAgICBzZXNzaW9uSWQsXG4gICAgICAgIGNhcHR1cmVUYWJJZCxcbiAgICAgICAgY2FwdHVyZVR5cGUsXG4gICAgICAgIHN0YXJ0ZWRBdCxcbiAgICAgICAgcmVjb3JkaW5nU3RhcnRlZEF0OiByZWNvcmRpbmdTdGFydGVkQXQgPz8gbnVsbCxcbiAgICAgICAgZXZlbnRzLFxuICAgIH07XG59XG5leHBvcnQgZnVuY3Rpb24gbm9ybWFsaXplRGVidWdnZXJFdmVudCh2YWx1ZSkge1xuICAgIGlmICghaXNSZWNvcmQodmFsdWUpKVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICBjb25zdCBraW5kID0gdmFsdWUua2luZDtcbiAgICBpZiAoa2luZCAhPT0gXCJhY3Rpb25cIiAmJiBraW5kICE9PSBcImNvbnNvbGVcIiAmJiBraW5kICE9PSBcIm5ldHdvcmtcIikge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgdGltZXN0YW1wID0gYXNPcHRpb25hbE51bWJlcih2YWx1ZS50aW1lc3RhbXApO1xuICAgIGlmICh0aW1lc3RhbXAgPT09IHVuZGVmaW5lZClcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgaWYgKGtpbmQgPT09IFwiYWN0aW9uXCIpIHtcbiAgICAgICAgY29uc3QgYWN0aW9uVHlwZSA9IGFzT3B0aW9uYWxTdHJpbmcodmFsdWUuYWN0aW9uVHlwZSk7XG4gICAgICAgIGlmICghYWN0aW9uVHlwZSlcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAga2luZCxcbiAgICAgICAgICAgIHRpbWVzdGFtcCxcbiAgICAgICAgICAgIGFjdGlvblR5cGUsXG4gICAgICAgICAgICB0YXJnZXQ6IGFzT3B0aW9uYWxTdHJpbmcodmFsdWUudGFyZ2V0LCBNQVhfVEVYVF9MRU5HVEgpLFxuICAgICAgICAgICAgbWV0YWRhdGE6IHNhbml0aXplUmVjb3JkKHZhbHVlLm1ldGFkYXRhKSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgaWYgKGtpbmQgPT09IFwiY29uc29sZVwiKSB7XG4gICAgICAgIGNvbnN0IGxldmVsID0gdmFsdWUubGV2ZWw7XG4gICAgICAgIGlmIChsZXZlbCAhPT0gXCJsb2dcIiAmJlxuICAgICAgICAgICAgbGV2ZWwgIT09IFwiaW5mb1wiICYmXG4gICAgICAgICAgICBsZXZlbCAhPT0gXCJ3YXJuXCIgJiZcbiAgICAgICAgICAgIGxldmVsICE9PSBcImVycm9yXCIgJiZcbiAgICAgICAgICAgIGxldmVsICE9PSBcImRlYnVnXCIpIHtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBhc09wdGlvbmFsU3RyaW5nKHZhbHVlLm1lc3NhZ2UsIE1BWF9URVhUX0xFTkdUSCk7XG4gICAgICAgIGlmICghbWVzc2FnZSlcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAga2luZCxcbiAgICAgICAgICAgIHRpbWVzdGFtcCxcbiAgICAgICAgICAgIGxldmVsLFxuICAgICAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgICAgIG1ldGFkYXRhOiBzYW5pdGl6ZVJlY29yZCh2YWx1ZS5tZXRhZGF0YSksXG4gICAgICAgIH07XG4gICAgfVxuICAgIGNvbnN0IG1ldGhvZCA9IGFzT3B0aW9uYWxTdHJpbmcodmFsdWUubWV0aG9kLCAyMCk7XG4gICAgY29uc3QgdXJsID0gYXNPcHRpb25hbFN0cmluZyh2YWx1ZS51cmwsIE1BWF9VUkxfTEVOR1RIKTtcbiAgICBpZiAoIShtZXRob2QgJiYgdXJsKSlcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgcmV0dXJuIHtcbiAgICAgICAga2luZCxcbiAgICAgICAgdGltZXN0YW1wLFxuICAgICAgICBtZXRob2QsXG4gICAgICAgIHVybCxcbiAgICAgICAgc3RhdHVzOiBhc09wdGlvbmFsTnVtYmVyKHZhbHVlLnN0YXR1cyksXG4gICAgICAgIGR1cmF0aW9uOiBhc09wdGlvbmFsTnVtYmVyKHZhbHVlLmR1cmF0aW9uKSxcbiAgICAgICAgcmVxdWVzdEhlYWRlcnM6IHNhbml0aXplSGVhZGVycyh2YWx1ZS5yZXF1ZXN0SGVhZGVycyksXG4gICAgICAgIHJlc3BvbnNlSGVhZGVyczogc2FuaXRpemVIZWFkZXJzKHZhbHVlLnJlc3BvbnNlSGVhZGVycyksXG4gICAgICAgIHJlcXVlc3RCb2R5OiBhc09wdGlvbmFsU3RyaW5nKHZhbHVlLnJlcXVlc3RCb2R5LCBNQVhfTkVUV09SS19CT0RZX0xFTkdUSCksXG4gICAgICAgIHJlc3BvbnNlQm9keTogYXNPcHRpb25hbFN0cmluZyh2YWx1ZS5yZXNwb25zZUJvZHksIE1BWF9ORVRXT1JLX0JPRFlfTEVOR1RIKSxcbiAgICB9O1xufVxuZnVuY3Rpb24gc2FuaXRpemVIZWFkZXJzKHZhbHVlKSB7XG4gICAgaWYgKCFpc1JlY29yZCh2YWx1ZSkpXG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgY29uc3QgcmVzdWx0ID0ge307XG4gICAgZm9yIChjb25zdCBba2V5LCBoZWFkZXJWYWx1ZV0gb2YgT2JqZWN0LmVudHJpZXModmFsdWUpKSB7XG4gICAgICAgIGlmICh0eXBlb2YgaGVhZGVyVmFsdWUgIT09IFwic3RyaW5nXCIpXG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgY29uc3Qgbm9ybWFsaXplZEtleSA9IGtleS50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgaWYgKCFub3JtYWxpemVkS2V5IHx8IHNob3VsZEhpZGVIZWFkZXIobm9ybWFsaXplZEtleSkpIHtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIHJlc3VsdFtub3JtYWxpemVkS2V5LnNsaWNlKDAsIDEyMCldID0gaGVhZGVyVmFsdWUuc2xpY2UoMCwgNTAwKTtcbiAgICB9XG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKHJlc3VsdCkubGVuZ3RoID4gMCA/IHJlc3VsdCA6IHVuZGVmaW5lZDtcbn1cbmZ1bmN0aW9uIHNob3VsZEhpZGVIZWFkZXIoaGVhZGVyTmFtZSkge1xuICAgIHJldHVybiBoZWFkZXJOYW1lLmluY2x1ZGVzKFwiZGVidWdnZXJcIik7XG59XG5mdW5jdGlvbiBzYW5pdGl6ZVJlY29yZCh2YWx1ZSkge1xuICAgIGlmICghaXNSZWNvcmQodmFsdWUpKVxuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIGNvbnN0IHJlc3VsdCA9IHt9O1xuICAgIGZvciAoY29uc3QgW2tleSwgZW50cnlWYWx1ZV0gb2YgT2JqZWN0LmVudHJpZXModmFsdWUpKSB7XG4gICAgICAgIGNvbnN0IG5vcm1hbGl6ZWQgPSBzYW5pdGl6ZUpzb25WYWx1ZShlbnRyeVZhbHVlKTtcbiAgICAgICAgaWYgKG5vcm1hbGl6ZWQgPT09IHVuZGVmaW5lZClcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICByZXN1bHRba2V5LnNsaWNlKDAsIDEyMCldID0gbm9ybWFsaXplZDtcbiAgICB9XG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKHJlc3VsdCkubGVuZ3RoID4gMCA/IHJlc3VsdCA6IHVuZGVmaW5lZDtcbn1cbmZ1bmN0aW9uIHNhbml0aXplSnNvblZhbHVlKHZhbHVlLCBkZXB0aCA9IDApIHtcbiAgICBpZiAoZGVwdGggPiAzKVxuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIGlmICh2YWx1ZSA9PT0gbnVsbCB8fFxuICAgICAgICB0eXBlb2YgdmFsdWUgPT09IFwiYm9vbGVhblwiIHx8XG4gICAgICAgIHR5cGVvZiB2YWx1ZSA9PT0gXCJudW1iZXJcIikge1xuICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlLnNsaWNlKDAsIE1BWF9URVhUX0xFTkdUSCk7XG4gICAgfVxuICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgICByZXR1cm4gdmFsdWVcbiAgICAgICAgICAgIC5zbGljZSgwLCAzMClcbiAgICAgICAgICAgIC5tYXAoKGVudHJ5KSA9PiBzYW5pdGl6ZUpzb25WYWx1ZShlbnRyeSwgZGVwdGggKyAxKSlcbiAgICAgICAgICAgIC5maWx0ZXIoaXNEZWZpbmVkKTtcbiAgICB9XG4gICAgaWYgKGlzUmVjb3JkKHZhbHVlKSkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSB7fTtcbiAgICAgICAgZm9yIChjb25zdCBba2V5LCBlbnRyeVZhbHVlXSBvZiBPYmplY3QuZW50cmllcyh2YWx1ZSkuc2xpY2UoMCwgMzApKSB7XG4gICAgICAgICAgICBjb25zdCBub3JtYWxpemVkID0gc2FuaXRpemVKc29uVmFsdWUoZW50cnlWYWx1ZSwgZGVwdGggKyAxKTtcbiAgICAgICAgICAgIGlmIChub3JtYWxpemVkID09PSB1bmRlZmluZWQpXG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICByZXN1bHRba2V5LnNsaWNlKDAsIDEyMCldID0gbm9ybWFsaXplZDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICByZXR1cm4gdW5kZWZpbmVkO1xufVxuZnVuY3Rpb24gYXNPcHRpb25hbFN0cmluZyh2YWx1ZSwgbWF4TGVuZ3RoID0gTUFYX1RFWFRfTEVOR1RIKSB7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gXCJzdHJpbmdcIilcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICBjb25zdCB0cmltbWVkID0gdmFsdWUudHJpbSgpO1xuICAgIGlmICghdHJpbW1lZClcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICByZXR1cm4gdHJpbW1lZC5zbGljZSgwLCBtYXhMZW5ndGgpO1xufVxuZnVuY3Rpb24gYXNPcHRpb25hbE51bWJlcih2YWx1ZSkge1xuICAgIGlmICh0eXBlb2YgdmFsdWUgIT09IFwibnVtYmVyXCIgfHwgIU51bWJlci5pc0Zpbml0ZSh2YWx1ZSkpIHtcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgcmV0dXJuIE1hdGguZmxvb3IodmFsdWUpO1xufVxuZnVuY3Rpb24gaXNSZWNvcmQodmFsdWUpIHtcbiAgICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHZhbHVlICE9PSBudWxsICYmICFBcnJheS5pc0FycmF5KHZhbHVlKTtcbn1cbmZ1bmN0aW9uIGlzRGVmaW5lZCh2YWx1ZSkge1xuICAgIHJldHVybiB2YWx1ZSAhPT0gbnVsbCAmJiB2YWx1ZSAhPT0gdW5kZWZpbmVkO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGlzUmVjb3JkTGlrZSh2YWx1ZSkge1xuICAgIHJldHVybiBpc1JlY29yZCh2YWx1ZSk7XG59XG5leHBvcnQgZnVuY3Rpb24gbm9ybWFsaXplU3RvcmVkUmVwbGF5QnVmZmVyKHZhbHVlKSB7XG4gICAgaWYgKCFpc1JlY29yZCh2YWx1ZSkpXG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIGNvbnN0IHRhYklkID0gYXNPcHRpb25hbE51bWJlcih2YWx1ZS50YWJJZCk7XG4gICAgY29uc3QgbGFzdFRvdWNoZWRBdCA9IGFzT3B0aW9uYWxOdW1iZXIodmFsdWUubGFzdFRvdWNoZWRBdCk7XG4gICAgaWYgKHRhYklkID09PSB1bmRlZmluZWQgfHxcbiAgICAgICAgdGFiSWQgPCAwIHx8XG4gICAgICAgIGxhc3RUb3VjaGVkQXQgPT09IHVuZGVmaW5lZCB8fFxuICAgICAgICBsYXN0VG91Y2hlZEF0IDwgMCkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgZXZlbnRzID0gQXJyYXkuaXNBcnJheSh2YWx1ZS5ldmVudHMpXG4gICAgICAgID8gdmFsdWUuZXZlbnRzLm1hcChub3JtYWxpemVEZWJ1Z2dlckV2ZW50KS5maWx0ZXIoaXNEZWZpbmVkKVxuICAgICAgICA6IFtdO1xuICAgIHJldHVybiB7XG4gICAgICAgIHRhYklkLFxuICAgICAgICBsYXN0VG91Y2hlZEF0LFxuICAgICAgICBldmVudHMsXG4gICAgfTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW5vcm1hbGl6ZS5qcy5tYXAiLCJpbXBvcnQge1xuICBESVNDQVJEX1NFU1NJT05fTUVTU0FHRSxcbiAgRU5TVVJFX1BBR0VfUlVOVElNRV9NRVNTQUdFLFxuICBHRVRfU0VTU0lPTl9TTkFQU0hPVF9NRVNTQUdFLFxuICBNQVJLX1JFQ09SRElOR19TVEFSVEVEX01FU1NBR0UsXG4gIFBBR0VfQlJJREdFX1NPVVJDRSxcbiAgUEFHRV9FVkVOVF9NRVNTQUdFLFxuICBQQUdFX0VWRU5UU19NRVNTQUdFLFxuICBTVEFSVF9TRVNTSU9OX01FU1NBR0UsXG59IGZyb20gXCJAY3Jpa2tldC9jYXB0dXJlLWNvcmUvZGVidWdnZXIvY29uc3RhbnRzXCJcbmltcG9ydCB7IGlzUmVjb3JkTGlrZSB9IGZyb20gXCJAY3Jpa2tldC9jYXB0dXJlLWNvcmUvZGVidWdnZXIvbm9ybWFsaXplXCJcbmltcG9ydCB0eXBlIHtcbiAgRGVidWdnZXJDb250ZW50QnJpZGdlUGF5bG9hZCxcbiAgRGVidWdnZXJSdW50aW1lTWVzc2FnZSxcbiAgRGVidWdnZXJSdW50aW1lUmVzcG9uc2UsXG59IGZyb20gXCJAY3Jpa2tldC9jYXB0dXJlLWNvcmUvZGVidWdnZXIvdHlwZXNcIlxuaW1wb3J0IHsgcmVwb3J0Tm9uRmF0YWxFcnJvciB9IGZyb20gXCJAY3Jpa2tldC9zaGFyZWQvbGliL2Vycm9yc1wiXG5cbmV4cG9ydCBmdW5jdGlvbiBzZW5kRGVidWdnZXJNZXNzYWdlPFREYXRhPihcbiAgbWVzc2FnZTogRGVidWdnZXJSdW50aW1lTWVzc2FnZVxuKTogUHJvbWlzZTxURGF0YT4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKFxuICAgICAgbWVzc2FnZSxcbiAgICAgIChyZXNwb25zZTogRGVidWdnZXJSdW50aW1lUmVzcG9uc2U8VERhdGE+IHwgdW5kZWZpbmVkKSA9PiB7XG4gICAgICAgIGNvbnN0IHJ1bnRpbWVFcnJvciA9IGNocm9tZS5ydW50aW1lLmxhc3RFcnJvclxuICAgICAgICBpZiAocnVudGltZUVycm9yKSB7XG4gICAgICAgICAgcmVqZWN0KG5ldyBFcnJvcihydW50aW1lRXJyb3IubWVzc2FnZSkpXG4gICAgICAgICAgcmV0dXJuXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIXJlc3BvbnNlKSB7XG4gICAgICAgICAgcmVqZWN0KG5ldyBFcnJvcihcIkRlYnVnZ2VyIHNlcnZpY2UgZGlkIG5vdCByZXNwb25kXCIpKVxuICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IocmVzcG9uc2UuZXJyb3IpKVxuICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG5cbiAgICAgICAgcmVzb2x2ZShyZXNwb25zZS5kYXRhKVxuICAgICAgfVxuICAgIClcbiAgfSlcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNlbmREZWJ1Z2dlclBhZ2VFdmVudChyYXdFdmVudDogdW5rbm93bik6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBzZW5kRGVidWdnZXJQYWdlRXZlbnRzKFtyYXdFdmVudF0pXG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZW5kRGVidWdnZXJQYWdlRXZlbnRzKFxuICByYXdFdmVudHM6IHVua25vd25bXVxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmIChyYXdFdmVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuXG4gIH1cblxuICB0cnkge1xuICAgIGF3YWl0IHNlbmREZWJ1Z2dlck1lc3NhZ2U8dW5kZWZpbmVkPih7XG4gICAgICB0eXBlOiBQQUdFX0VWRU5UU19NRVNTQUdFLFxuICAgICAgcGF5bG9hZDoge1xuICAgICAgICBldmVudHM6IHJhd0V2ZW50cyxcbiAgICAgIH0sXG4gICAgfSlcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBpZiAoaXNFeHBlY3RlZFJ1bnRpbWVEaXNjb25uZWN0RXJyb3IoZXJyb3IpKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICByZXBvcnROb25GYXRhbEVycm9yKFwiRmFpbGVkIHRvIHNlbmQgZGVidWdnZXIgcGFnZSBldmVudHNcIiwgZXJyb3IpXG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVuc3VyZURlYnVnZ2VyUGFnZVJ1bnRpbWUoKTogUHJvbWlzZTx2b2lkPiB7XG4gIHRyeSB7XG4gICAgYXdhaXQgc2VuZERlYnVnZ2VyTWVzc2FnZTx1bmRlZmluZWQ+KHtcbiAgICAgIHR5cGU6IEVOU1VSRV9QQUdFX1JVTlRJTUVfTUVTU0FHRSxcbiAgICAgIHBheWxvYWQ6IHt9LFxuICAgIH0pXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgaWYgKGlzRXhwZWN0ZWRSdW50aW1lRGlzY29ubmVjdEVycm9yKGVycm9yKSkge1xuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgcmVwb3J0Tm9uRmF0YWxFcnJvcihcIkZhaWxlZCB0byBlbnN1cmUgZGVidWdnZXIgcGFnZSBydW50aW1lXCIsIGVycm9yKVxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc0RlYnVnZ2VyUnVudGltZU1lc3NhZ2UoXG4gIHZhbHVlOiB1bmtub3duXG4pOiB2YWx1ZSBpcyBEZWJ1Z2dlclJ1bnRpbWVNZXNzYWdlIHtcbiAgaWYgKCFpc1JlY29yZExpa2UodmFsdWUpKSByZXR1cm4gZmFsc2VcblxuICBjb25zdCBtZXNzYWdlVHlwZSA9IHZhbHVlLnR5cGVcbiAgaWYgKHR5cGVvZiBtZXNzYWdlVHlwZSAhPT0gXCJzdHJpbmdcIikgcmV0dXJuIGZhbHNlXG5cbiAgcmV0dXJuIChcbiAgICBtZXNzYWdlVHlwZSA9PT0gU1RBUlRfU0VTU0lPTl9NRVNTQUdFIHx8XG4gICAgbWVzc2FnZVR5cGUgPT09IE1BUktfUkVDT1JESU5HX1NUQVJURURfTUVTU0FHRSB8fFxuICAgIG1lc3NhZ2VUeXBlID09PSBHRVRfU0VTU0lPTl9TTkFQU0hPVF9NRVNTQUdFIHx8XG4gICAgbWVzc2FnZVR5cGUgPT09IERJU0NBUkRfU0VTU0lPTl9NRVNTQUdFIHx8XG4gICAgbWVzc2FnZVR5cGUgPT09IFBBR0VfRVZFTlRfTUVTU0FHRSB8fFxuICAgIG1lc3NhZ2VUeXBlID09PSBQQUdFX0VWRU5UU19NRVNTQUdFIHx8XG4gICAgbWVzc2FnZVR5cGUgPT09IEVOU1VSRV9QQUdFX1JVTlRJTUVfTUVTU0FHRVxuICApXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc0RlYnVnZ2VyQ29udGVudEJyaWRnZVBheWxvYWQoXG4gIHZhbHVlOiB1bmtub3duXG4pOiB2YWx1ZSBpcyBEZWJ1Z2dlckNvbnRlbnRCcmlkZ2VQYXlsb2FkIHtcbiAgaWYgKCFpc1JlY29yZExpa2UodmFsdWUpKSByZXR1cm4gZmFsc2VcblxuICBpZiAodmFsdWUuc291cmNlICE9PSBQQUdFX0JSSURHRV9TT1VSQ0UpIHtcbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIGNvbnN0IGhhc1NpbmdsZUV2ZW50ID0gT2JqZWN0Lmhhc093bih2YWx1ZSwgXCJldmVudFwiKVxuICBjb25zdCBoYXNFdmVudEJhdGNoID0gQXJyYXkuaXNBcnJheSh2YWx1ZS5ldmVudHMpXG5cbiAgcmV0dXJuIGhhc1NpbmdsZUV2ZW50IHx8IGhhc0V2ZW50QmF0Y2hcbn1cblxuZnVuY3Rpb24gaXNFeHBlY3RlZFJ1bnRpbWVEaXNjb25uZWN0RXJyb3IoZXJyb3I6IHVua25vd24pOiBib29sZWFuIHtcbiAgaWYgKCEoZXJyb3IgaW5zdGFuY2VvZiBFcnJvcikpIHtcbiAgICByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIGNvbnN0IG1lc3NhZ2UgPSBlcnJvci5tZXNzYWdlLnRvTG93ZXJDYXNlKClcbiAgcmV0dXJuIChcbiAgICBtZXNzYWdlLmluY2x1ZGVzKFwiZXh0ZW5zaW9uIGNvbnRleHQgaW52YWxpZGF0ZWRcIikgfHxcbiAgICBtZXNzYWdlLmluY2x1ZGVzKFwicmVjZWl2aW5nIGVuZCBkb2VzIG5vdCBleGlzdFwiKVxuICApXG59XG4iLCJpbXBvcnQgeyBNQVhfRVZFTlRfQ09VTlQgfSBmcm9tIFwiLi4vLi4vY29uc3RhbnRzXCI7XG5jb25zdCBNQVhfQUNUSU9OX0VWRU5UX0NPVU5UID0gNDAwO1xuY29uc3QgTUFYX0NPTlNPTEVfRVZFTlRfQ09VTlQgPSA4MDA7XG5jb25zdCBNQVhfTkVUV09SS19FVkVOVF9DT1VOVCA9IDEyMDA7XG5leHBvcnQgZnVuY3Rpb24gYXBwZW5kRXZlbnRXaXRoUmV0ZW50aW9uUG9saWN5KGV2ZW50cywgZXZlbnQpIHtcbiAgICBldmVudHMucHVzaChldmVudCk7XG4gICAgZW5mb3JjZUtpbmRDYXAoZXZlbnRzLCBldmVudC5raW5kKTtcbiAgICB3aGlsZSAoZXZlbnRzLmxlbmd0aCA+IE1BWF9FVkVOVF9DT1VOVCkge1xuICAgICAgICBjb25zdCBkcm9wSW5kZXggPSBmaW5kT2xkZXN0RXZlbnRJbmRleEJ5UHJpb3JpdHkoZXZlbnRzLCBbXG4gICAgICAgICAgICBcImNvbnNvbGVcIixcbiAgICAgICAgICAgIFwiYWN0aW9uXCIsXG4gICAgICAgICAgICBcIm5ldHdvcmtcIixcbiAgICAgICAgXSk7XG4gICAgICAgIGV2ZW50cy5zcGxpY2UoZHJvcEluZGV4LCAxKTtcbiAgICB9XG59XG5leHBvcnQgZnVuY3Rpb24gYXBwZW5kTmV0d29ya0V2ZW50V2l0aERlZHVwKGV2ZW50cywgZXZlbnQpIHtcbiAgICBpZiAoaXNMaWtlbHlEdXBsaWNhdGVOZXR3b3JrRXZlbnQoZXZlbnRzLCBldmVudCkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBhcHBlbmRFdmVudFdpdGhSZXRlbnRpb25Qb2xpY3koZXZlbnRzLCBldmVudCk7XG59XG5leHBvcnQgZnVuY3Rpb24gYXBwZW5kQWN0aW9uRXZlbnRXaXRoRGVkdXAoZXZlbnRzLCBldmVudCkge1xuICAgIGlmIChpc0xpa2VseUR1cGxpY2F0ZU5hdmlnYXRpb25FdmVudChldmVudHMsIGV2ZW50KSkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGFwcGVuZEV2ZW50V2l0aFJldGVudGlvblBvbGljeShldmVudHMsIGV2ZW50KTtcbn1cbmZ1bmN0aW9uIGlzTGlrZWx5RHVwbGljYXRlTmV0d29ya0V2ZW50KGV2ZW50cywgY2FuZGlkYXRlKSB7XG4gICAgY29uc3QgRFVQTElDQVRFX1dJTkRPV19NUyA9IDM1MDtcbiAgICBmb3IgKGxldCBpbmRleCA9IGV2ZW50cy5sZW5ndGggLSAxOyBpbmRleCA+PSAwOyBpbmRleCAtPSAxKSB7XG4gICAgICAgIGNvbnN0IGV2ZW50ID0gZXZlbnRzW2luZGV4XTtcbiAgICAgICAgaWYgKCFldmVudCB8fCBldmVudC5raW5kICE9PSBcIm5ldHdvcmtcIikge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgaXNTYW1lS2V5ID0gZXZlbnQubWV0aG9kID09PSBjYW5kaWRhdGUubWV0aG9kICYmXG4gICAgICAgICAgICBldmVudC51cmwgPT09IGNhbmRpZGF0ZS51cmwgJiZcbiAgICAgICAgICAgIChldmVudC5zdGF0dXMgPz8gMCkgPT09IChjYW5kaWRhdGUuc3RhdHVzID8/IDApO1xuICAgICAgICBpZiAoIWlzU2FtZUtleSkge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZGVsdGEgPSBNYXRoLmFicyhldmVudC50aW1lc3RhbXAgLSBjYW5kaWRhdGUudGltZXN0YW1wKTtcbiAgICAgICAgaWYgKGRlbHRhID4gRFVQTElDQVRFX1dJTkRPV19NUykge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG59XG5mdW5jdGlvbiBpc0xpa2VseUR1cGxpY2F0ZU5hdmlnYXRpb25FdmVudChldmVudHMsIGNhbmRpZGF0ZSkge1xuICAgIGlmIChjYW5kaWRhdGUuYWN0aW9uVHlwZSAhPT0gXCJuYXZpZ2F0aW9uXCIpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBEVVBMSUNBVEVfV0lORE9XX01TID0gNTAwO1xuICAgIGNvbnN0IGNhbmRpZGF0ZVVybCA9IGdldE5hdmlnYXRpb25VcmwoY2FuZGlkYXRlKTtcbiAgICBpZiAoIWNhbmRpZGF0ZVVybCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGZvciAobGV0IGluZGV4ID0gZXZlbnRzLmxlbmd0aCAtIDE7IGluZGV4ID49IDA7IGluZGV4IC09IDEpIHtcbiAgICAgICAgY29uc3QgZXZlbnQgPSBldmVudHNbaW5kZXhdO1xuICAgICAgICBpZiAoIWV2ZW50IHx8XG4gICAgICAgICAgICBldmVudC5raW5kICE9PSBcImFjdGlvblwiIHx8XG4gICAgICAgICAgICBldmVudC5hY3Rpb25UeXBlICE9PSBcIm5hdmlnYXRpb25cIikge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZGVsdGEgPSBNYXRoLmFicyhldmVudC50aW1lc3RhbXAgLSBjYW5kaWRhdGUudGltZXN0YW1wKTtcbiAgICAgICAgaWYgKGRlbHRhID4gRFVQTElDQVRFX1dJTkRPV19NUykge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHByZXZpb3VzVXJsID0gZ2V0TmF2aWdhdGlvblVybChldmVudCk7XG4gICAgICAgIGlmIChwcmV2aW91c1VybCA9PT0gY2FuZGlkYXRlVXJsKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG59XG5mdW5jdGlvbiBnZXROYXZpZ2F0aW9uVXJsKGV2ZW50KSB7XG4gICAgY29uc3QgbWV0YWRhdGEgPSBldmVudC5tZXRhZGF0YTtcbiAgICBpZiAoIShtZXRhZGF0YSAmJiB0eXBlb2YgbWV0YWRhdGEgPT09IFwib2JqZWN0XCIpKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjb25zdCB1cmwgPSBtZXRhZGF0YS51cmw7XG4gICAgcmV0dXJuIHR5cGVvZiB1cmwgPT09IFwic3RyaW5nXCIgJiYgdXJsLmxlbmd0aCA+IDAgPyB1cmwgOiBudWxsO1xufVxuZnVuY3Rpb24gZW5mb3JjZUtpbmRDYXAoZXZlbnRzLCBraW5kKSB7XG4gICAgY29uc3QgbWF4UGVyS2luZCA9IGdldE1heFBlcktpbmQoa2luZCk7XG4gICAgbGV0IGNvdW50ID0gMDtcbiAgICBmb3IgKGNvbnN0IGV2ZW50IG9mIGV2ZW50cykge1xuICAgICAgICBpZiAoZXZlbnQua2luZCA9PT0ga2luZCkge1xuICAgICAgICAgICAgY291bnQgKz0gMTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBvdmVyZmxvd0NvdW50ID0gY291bnQgLSBtYXhQZXJLaW5kO1xuICAgIGlmIChvdmVyZmxvd0NvdW50IDw9IDApIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBsZXQgcmVtb3ZlZCA9IDA7XG4gICAgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IGV2ZW50cy5sZW5ndGggJiYgcmVtb3ZlZCA8IG92ZXJmbG93Q291bnQ7IGluZGV4ICs9IDEpIHtcbiAgICAgICAgaWYgKGV2ZW50c1tpbmRleF0/LmtpbmQgIT09IGtpbmQpIHtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGV2ZW50cy5zcGxpY2UoaW5kZXgsIDEpO1xuICAgICAgICBpbmRleCAtPSAxO1xuICAgICAgICByZW1vdmVkICs9IDE7XG4gICAgfVxufVxuZnVuY3Rpb24gZ2V0TWF4UGVyS2luZChraW5kKSB7XG4gICAgaWYgKGtpbmQgPT09IFwiYWN0aW9uXCIpIHtcbiAgICAgICAgcmV0dXJuIE1BWF9BQ1RJT05fRVZFTlRfQ09VTlQ7XG4gICAgfVxuICAgIGlmIChraW5kID09PSBcImNvbnNvbGVcIikge1xuICAgICAgICByZXR1cm4gTUFYX0NPTlNPTEVfRVZFTlRfQ09VTlQ7XG4gICAgfVxuICAgIHJldHVybiBNQVhfTkVUV09SS19FVkVOVF9DT1VOVDtcbn1cbmZ1bmN0aW9uIGZpbmRPbGRlc3RFdmVudEluZGV4QnlQcmlvcml0eShldmVudHMsIHByaW9yaXR5KSB7XG4gICAgZm9yIChjb25zdCBraW5kIG9mIHByaW9yaXR5KSB7XG4gICAgICAgIGNvbnN0IGluZGV4ID0gZXZlbnRzLmZpbmRJbmRleCgoZXZlbnQpID0+IGV2ZW50LmtpbmQgPT09IGtpbmQpO1xuICAgICAgICBpZiAoaW5kZXggPj0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIGluZGV4O1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiAwO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmV0ZW50aW9uLmpzLm1hcCIsImltcG9ydCB7IHJlcG9ydE5vbkZhdGFsRXJyb3IgfSBmcm9tIFwiQGNyaWtrZXQvc2hhcmVkL2xpYi9lcnJvcnNcIlxuXG5jb25zdCBERUJVR0dFUl9DT05URU5UX0JSSURHRV9GSUxFID0gXCJkZWJ1Z2dlci1jb250ZW50LWJyaWRnZS5qc1wiXG5jb25zdCBERUJVR0dFUl9QQUdFX1JVTlRJTUVfRklMRSA9IFwiZGVidWdnZXItcGFnZS5qc1wiXG5cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVTZXNzaW9uSWQoKTogc3RyaW5nIHtcbiAgaWYgKFxuICAgIHR5cGVvZiBjcnlwdG8gIT09IFwidW5kZWZpbmVkXCIgJiZcbiAgICB0eXBlb2YgY3J5cHRvLnJhbmRvbVVVSUQgPT09IFwiZnVuY3Rpb25cIlxuICApIHtcbiAgICByZXR1cm4gY3J5cHRvLnJhbmRvbVVVSUQoKVxuICB9XG5cbiAgY29uc3QgcmFuZG9tID0gTWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc2xpY2UoMiwgMTApXG4gIHJldHVybiBgZGJnXyR7RGF0ZS5ub3coKX1fJHtyYW5kb219YFxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaW5qZWN0RGVidWdnZXJTY3JpcHRJbnRvVGFiKFxuICB0YWJJZDogbnVtYmVyXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKCFjaHJvbWUuc2NyaXB0aW5nPy5leGVjdXRlU2NyaXB0KSB7XG4gICAgcmV0dXJuXG4gIH1cblxuICB0cnkge1xuICAgIGF3YWl0IGNocm9tZS5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7XG4gICAgICB0YXJnZXQ6IHtcbiAgICAgICAgdGFiSWQsXG4gICAgICB9LFxuICAgICAgZmlsZXM6IFtERUJVR0dFUl9DT05URU5UX0JSSURHRV9GSUxFXSxcbiAgICB9KVxuXG4gICAgYXdhaXQgY2hyb21lLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHtcbiAgICAgIHRhcmdldDoge1xuICAgICAgICB0YWJJZCxcbiAgICAgIH0sXG4gICAgICB3b3JsZDogXCJNQUlOXCIsXG4gICAgICBmaWxlczogW0RFQlVHR0VSX1BBR0VfUlVOVElNRV9GSUxFXSxcbiAgICB9KVxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIHJlcG9ydE5vbkZhdGFsRXJyb3IoXG4gICAgICBgRmFpbGVkIHRvIGluamVjdCBkZWJ1Z2dlciBpbnN0cnVtZW50YXRpb24gc2NyaXB0IGludG8gdGFiICR7dGFiSWR9YCxcbiAgICAgIGVycm9yXG4gICAgKVxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc0luamVjdGFibGVQYWdlVXJsKHVybDogc3RyaW5nKTogYm9vbGVhbiB7XG4gIHJldHVybiB1cmwuc3RhcnRzV2l0aChcImh0dHA6Ly9cIikgfHwgdXJsLnN0YXJ0c1dpdGgoXCJodHRwczovL1wiKVxufVxuIiwiaW1wb3J0IHsgREVCVUdHRVJfU0VTU0lPTlNfU1RPUkFHRV9LRVkgfSBmcm9tIFwiQGNyaWtrZXQvY2FwdHVyZS1jb3JlL2RlYnVnZ2VyL2NvbnN0YW50c1wiXG5pbXBvcnQge1xuICBhcHBlbmRBY3Rpb25FdmVudFdpdGhEZWR1cCxcbiAgYXBwZW5kRXZlbnRXaXRoUmV0ZW50aW9uUG9saWN5LFxuICBhcHBlbmROZXR3b3JrRXZlbnRXaXRoRGVkdXAsXG59IGZyb20gXCJAY3Jpa2tldC9jYXB0dXJlLWNvcmUvZGVidWdnZXIvZW5naW5lL2JhY2tncm91bmQvcmV0ZW50aW9uXCJcbmltcG9ydCB7XG4gIG5vcm1hbGl6ZURlYnVnZ2VyRXZlbnQsXG4gIG5vcm1hbGl6ZVN0b3JlZFNlc3Npb24sXG59IGZyb20gXCJAY3Jpa2tldC9jYXB0dXJlLWNvcmUvZGVidWdnZXIvbm9ybWFsaXplXCJcbmltcG9ydCB0eXBlIHtcbiAgRGVidWdnZXJFdmVudCxcbiAgRGVidWdnZXJTZXNzaW9uU25hcHNob3QsXG4gIFN0b3JlZERlYnVnZ2VyU2Vzc2lvbixcbn0gZnJvbSBcIkBjcmlra2V0L2NhcHR1cmUtY29yZS9kZWJ1Z2dlci90eXBlc1wiXG5pbXBvcnQgeyByZXBvcnROb25GYXRhbEVycm9yIH0gZnJvbSBcIkBjcmlra2V0L3NoYXJlZC9saWIvZXJyb3JzXCJcbmltcG9ydCB7XG4gIGNyZWF0ZVNlc3Npb25JZCxcbiAgaW5qZWN0RGVidWdnZXJTY3JpcHRJbnRvVGFiLFxuICBpc0luamVjdGFibGVQYWdlVXJsLFxufSBmcm9tIFwiLi9pbmplY3Rpb25cIlxuXG5pbnRlcmZhY2UgU3RhcnRTZXNzaW9uUGF5bG9hZCB7XG4gIGNhcHR1cmVUYWJJZDogbnVtYmVyXG4gIGNhcHR1cmVUeXBlOiBcInZpZGVvXCIgfCBcInNjcmVlbnNob3RcIlxuICBpbnN0YW50UmVwbGF5TG9va2JhY2tNcz86IG51bWJlclxufVxuXG5pbnRlcmZhY2UgTWFya1JlY29yZGluZ1N0YXJ0ZWRQYXlsb2FkIHtcbiAgc2Vzc2lvbklkOiBzdHJpbmdcbiAgcmVjb3JkaW5nU3RhcnRlZEF0OiBudW1iZXJcbn1cblxuaW50ZXJmYWNlIERlYnVnZ2VyU2Vzc2lvblN0b3JlIHtcbiAgaW5qZWN0RGVidWdnZXJTY3JpcHRGb3JUYWI6ICh0YWJJZDogbnVtYmVyKSA9PiBQcm9taXNlPHZvaWQ+XG4gIHN0YXJ0U2Vzc2lvbjogKHBheWxvYWQ6IFN0YXJ0U2Vzc2lvblBheWxvYWQpID0+IFByb21pc2U8e1xuICAgIHNlc3Npb25JZDogc3RyaW5nXG4gICAgc3RhcnRlZEF0OiBudW1iZXJcbiAgfT5cbiAgYXBwZW5kUGFnZUV2ZW50czogKHRhYklkOiBudW1iZXIsIHJhd0V2ZW50czogdW5rbm93bltdKSA9PiBQcm9taXNlPHZvaWQ+XG4gIGdldFNlc3Npb25TbmFwc2hvdDogKFxuICAgIHNlc3Npb25JZDogc3RyaW5nXG4gICkgPT4gUHJvbWlzZTxEZWJ1Z2dlclNlc3Npb25TbmFwc2hvdCB8IG51bGw+XG4gIG1hcmtTZXNzaW9uUmVjb3JkaW5nU3RhcnRlZDogKFxuICAgIHBheWxvYWQ6IE1hcmtSZWNvcmRpbmdTdGFydGVkUGF5bG9hZFxuICApID0+IFByb21pc2U8dm9pZD5cbiAgZGlzY2FyZFNlc3Npb246IChzZXNzaW9uSWQ6IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPlxuICBlbnN1cmVEZWJ1Z2dlclNjcmlwdEZvclRhYjogKHRhYklkOiBudW1iZXIsIHVybD86IHN0cmluZykgPT4gUHJvbWlzZTx2b2lkPlxuICBkaXNjYXJkU2Vzc2lvbkJ5VGFiSWQ6ICh0YWJJZDogbnVtYmVyKSA9PiBQcm9taXNlPHZvaWQ+XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVEZWJ1Z2dlclNlc3Npb25TdG9yZSgpOiBEZWJ1Z2dlclNlc3Npb25TdG9yZSB7XG4gIGNvbnN0IHNlc3Npb25zQnlJZCA9IG5ldyBNYXA8c3RyaW5nLCBTdG9yZWREZWJ1Z2dlclNlc3Npb24+KClcbiAgY29uc3QgdGFiVG9TZXNzaW9uID0gbmV3IE1hcDxudW1iZXIsIHN0cmluZz4oKVxuICBjb25zdCByZWNlbnRFdmVudHNCeVRhYiA9IG5ldyBNYXA8bnVtYmVyLCBEZWJ1Z2dlckV2ZW50W10+KClcblxuICBsZXQgaXNMb2FkZWQgPSBmYWxzZVxuICBsZXQgbG9hZFByb21pc2U6IFByb21pc2U8dm9pZD4gfCBudWxsID0gbnVsbFxuICBsZXQgcGVyc2lzdFRpbWVyOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PiB8IG51bGwgPSBudWxsXG5cbiAgY29uc3Qgc2NoZWR1bGVQZXJzaXN0ID0gKCkgPT4ge1xuICAgIGlmIChwZXJzaXN0VGltZXIpIHtcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIHBlcnNpc3RUaW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgcGVyc2lzdFRpbWVyID0gbnVsbFxuICAgICAgcGVyc2lzdFN0YXRlKCkuY2F0Y2goKGVycm9yOiB1bmtub3duKSA9PiB7XG4gICAgICAgIHJlcG9ydE5vbkZhdGFsRXJyb3IoXCJGYWlsZWQgdG8gcGVyc2lzdCBkZWJ1Z2dlciBzdGF0ZVwiLCBlcnJvcilcbiAgICAgIH0pXG4gICAgfSwgMjUwKVxuICB9XG5cbiAgY29uc3QgcGVyc2lzdFN0YXRlID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHNlc3Npb25zU25hcHNob3QgPSBBcnJheS5mcm9tKHNlc3Npb25zQnlJZC52YWx1ZXMoKSlcblxuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7XG4gICAgICBbREVCVUdHRVJfU0VTU0lPTlNfU1RPUkFHRV9LRVldOiBzZXNzaW9uc1NuYXBzaG90LFxuICAgIH0pXG4gIH1cblxuICBjb25zdCBoeWRyYXRlU3RvcmVkU3RhdGUgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFtcbiAgICAgIERFQlVHR0VSX1NFU1NJT05TX1NUT1JBR0VfS0VZLFxuICAgIF0pXG4gICAgY29uc3Qgc3RvcmVkU2Vzc2lvbnMgPSByZXN1bHRbREVCVUdHRVJfU0VTU0lPTlNfU1RPUkFHRV9LRVldXG5cbiAgICBpZiAoIUFycmF5LmlzQXJyYXkoc3RvcmVkU2Vzc2lvbnMpKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBmb3IgKGNvbnN0IGNhbmRpZGF0ZSBvZiBzdG9yZWRTZXNzaW9ucykge1xuICAgICAgY29uc3Qgc2Vzc2lvbiA9IG5vcm1hbGl6ZVN0b3JlZFNlc3Npb24oY2FuZGlkYXRlKVxuICAgICAgaWYgKCFzZXNzaW9uKSB7XG4gICAgICAgIGNvbnRpbnVlXG4gICAgICB9XG5cbiAgICAgIHNlc3Npb25zQnlJZC5zZXQoc2Vzc2lvbi5zZXNzaW9uSWQsIHNlc3Npb24pXG4gICAgICB0YWJUb1Nlc3Npb24uc2V0KHNlc3Npb24uY2FwdHVyZVRhYklkLCBzZXNzaW9uLnNlc3Npb25JZClcbiAgICB9XG4gIH1cblxuICBjb25zdCBlbnN1cmVMb2FkZWQgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKGlzTG9hZGVkKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBpZiAobG9hZFByb21pc2UpIHtcbiAgICAgIGF3YWl0IGxvYWRQcm9taXNlXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBsb2FkUHJvbWlzZSA9IGh5ZHJhdGVTdG9yZWRTdGF0ZSgpXG4gICAgICAuY2F0Y2goKGVycm9yOiB1bmtub3duKSA9PiB7XG4gICAgICAgIHJlcG9ydE5vbkZhdGFsRXJyb3IoXCJGYWlsZWQgdG8gbG9hZCBkZWJ1Z2dlciBzdGF0ZSBmcm9tIHN0b3JhZ2VcIiwgZXJyb3IpXG4gICAgICB9KVxuICAgICAgLmZpbmFsbHkoKCkgPT4ge1xuICAgICAgICBpc0xvYWRlZCA9IHRydWVcbiAgICAgICAgbG9hZFByb21pc2UgPSBudWxsXG4gICAgICB9KVxuXG4gICAgYXdhaXQgbG9hZFByb21pc2VcbiAgfVxuXG4gIGNvbnN0IHJlbW92ZVNlc3Npb24gPSAoc2Vzc2lvbklkOiBzdHJpbmcpID0+IHtcbiAgICBjb25zdCBzZXNzaW9uID0gc2Vzc2lvbnNCeUlkLmdldChzZXNzaW9uSWQpXG4gICAgaWYgKCFzZXNzaW9uKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBzZXNzaW9uc0J5SWQuZGVsZXRlKHNlc3Npb25JZClcblxuICAgIGNvbnN0IGFjdGl2ZVNlc3Npb25JZCA9IHRhYlRvU2Vzc2lvbi5nZXQoc2Vzc2lvbi5jYXB0dXJlVGFiSWQpXG4gICAgaWYgKGFjdGl2ZVNlc3Npb25JZCA9PT0gc2Vzc2lvbklkKSB7XG4gICAgICB0YWJUb1Nlc3Npb24uZGVsZXRlKHNlc3Npb24uY2FwdHVyZVRhYklkKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGFwcGVuZEV2ZW50c1RvU2Vzc2lvbiA9IChcbiAgICB0YWJJZDogbnVtYmVyLFxuICAgIGV2ZW50czogRGVidWdnZXJFdmVudFtdXG4gICk6IHZvaWQgPT4ge1xuICAgIGlmIChldmVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBjb25zdCBzZXNzaW9uSWQgPSB0YWJUb1Nlc3Npb24uZ2V0KHRhYklkKVxuICAgIGNvbnN0IHNlc3Npb24gPSBzZXNzaW9uSWQgPyBzZXNzaW9uc0J5SWQuZ2V0KHNlc3Npb25JZCkgOiB1bmRlZmluZWRcbiAgICBpZiAoIXNlc3Npb24pIHtcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIGZvciAoY29uc3QgZXZlbnQgb2YgZXZlbnRzKSB7XG4gICAgICBpZiAoZXZlbnQua2luZCA9PT0gXCJuZXR3b3JrXCIpIHtcbiAgICAgICAgYXBwZW5kTmV0d29ya0V2ZW50V2l0aERlZHVwKHNlc3Npb24uZXZlbnRzLCBldmVudClcbiAgICAgIH0gZWxzZSBpZiAoZXZlbnQua2luZCA9PT0gXCJhY3Rpb25cIikge1xuICAgICAgICBhcHBlbmRBY3Rpb25FdmVudFdpdGhEZWR1cChzZXNzaW9uLmV2ZW50cywgZXZlbnQpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhcHBlbmRFdmVudFdpdGhSZXRlbnRpb25Qb2xpY3koc2Vzc2lvbi5ldmVudHMsIGV2ZW50KVxuICAgICAgfVxuICAgIH1cblxuICAgIHNjaGVkdWxlUGVyc2lzdCgpXG4gIH1cblxuICBjb25zdCBhcHBlbmRFdmVudHNUb1JlY2VudEJ1ZmZlciA9IChcbiAgICB0YWJJZDogbnVtYmVyLFxuICAgIGV2ZW50czogRGVidWdnZXJFdmVudFtdXG4gICk6IHZvaWQgPT4ge1xuICAgIGlmIChldmVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpXG4gICAgY29uc3QgTUFYX1JFQ0VOVF9FVkVOVF9BR0VfTVMgPSA2MF8wMDBcbiAgICBjb25zdCBNQVhfUkVDRU5UX0VWRU5UX0NPVU5UID0gMjUwXG4gICAgY29uc3QgZXhpc3RpbmcgPSByZWNlbnRFdmVudHNCeVRhYi5nZXQodGFiSWQpID8/IFtdXG5cbiAgICBjb25zdCBtZXJnZWQgPSBbLi4uZXhpc3RpbmcsIC4uLmV2ZW50c10uZmlsdGVyKChldmVudCkgPT4ge1xuICAgICAgcmV0dXJuIG5vdyAtIGV2ZW50LnRpbWVzdGFtcCA8PSBNQVhfUkVDRU5UX0VWRU5UX0FHRV9NU1xuICAgIH0pXG5cbiAgICBpZiAobWVyZ2VkLmxlbmd0aCA+IE1BWF9SRUNFTlRfRVZFTlRfQ09VTlQpIHtcbiAgICAgIHJlY2VudEV2ZW50c0J5VGFiLnNldChcbiAgICAgICAgdGFiSWQsXG4gICAgICAgIG1lcmdlZC5zbGljZShtZXJnZWQubGVuZ3RoIC0gTUFYX1JFQ0VOVF9FVkVOVF9DT1VOVClcbiAgICAgIClcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIHJlY2VudEV2ZW50c0J5VGFiLnNldCh0YWJJZCwgbWVyZ2VkKVxuICB9XG5cbiAgY29uc3QgY29uc3VtZUluc3RhbnRSZXBsYXlFdmVudHMgPSAoXG4gICAgdGFiSWQ6IG51bWJlcixcbiAgICBsb29rYmFja01zOiBudW1iZXJcbiAgKTogRGVidWdnZXJFdmVudFtdID0+IHtcbiAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpXG4gICAgY29uc3QgcmVjZW50RXZlbnRzID0gcmVjZW50RXZlbnRzQnlUYWIuZ2V0KHRhYklkKSA/PyBbXVxuICAgIGlmIChyZWNlbnRFdmVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gW11cbiAgICB9XG5cbiAgICByZXR1cm4gcmVjZW50RXZlbnRzLmZpbHRlcigoZXZlbnQpID0+IHtcbiAgICAgIHJldHVybiBub3cgLSBldmVudC50aW1lc3RhbXAgPD0gbG9va2JhY2tNc1xuICAgIH0pXG4gIH1cblxuICBjb25zdCBzdGFydFNlc3Npb24gPSBhc3luYyAocGF5bG9hZDogU3RhcnRTZXNzaW9uUGF5bG9hZCkgPT4ge1xuICAgIGF3YWl0IGVuc3VyZUxvYWRlZCgpXG5cbiAgICBjb25zdCBzdGFydGVkQXQgPSBEYXRlLm5vdygpXG4gICAgY29uc3Qgc2Vzc2lvbklkID0gY3JlYXRlU2Vzc2lvbklkKClcbiAgICBjb25zdCBpbnN0YW50UmVwbGF5TG9va2JhY2tNcyA9XG4gICAgICB0eXBlb2YgcGF5bG9hZC5pbnN0YW50UmVwbGF5TG9va2JhY2tNcyA9PT0gXCJudW1iZXJcIiAmJlxuICAgICAgTnVtYmVyLmlzRmluaXRlKHBheWxvYWQuaW5zdGFudFJlcGxheUxvb2tiYWNrTXMpICYmXG4gICAgICBwYXlsb2FkLmluc3RhbnRSZXBsYXlMb29rYmFja01zID4gMFxuICAgICAgICA/IE1hdGguZmxvb3IocGF5bG9hZC5pbnN0YW50UmVwbGF5TG9va2JhY2tNcylcbiAgICAgICAgOiAwXG4gICAgY29uc3QgaW5zdGFudFJlcGxheUV2ZW50cyA9XG4gICAgICBpbnN0YW50UmVwbGF5TG9va2JhY2tNcyA+IDBcbiAgICAgICAgPyBjb25zdW1lSW5zdGFudFJlcGxheUV2ZW50cyhcbiAgICAgICAgICAgIHBheWxvYWQuY2FwdHVyZVRhYklkLFxuICAgICAgICAgICAgaW5zdGFudFJlcGxheUxvb2tiYWNrTXNcbiAgICAgICAgICApXG4gICAgICAgIDogW11cblxuICAgIGNvbnN0IHNlc3Npb246IFN0b3JlZERlYnVnZ2VyU2Vzc2lvbiA9IHtcbiAgICAgIHNlc3Npb25JZCxcbiAgICAgIGNhcHR1cmVUYWJJZDogcGF5bG9hZC5jYXB0dXJlVGFiSWQsXG4gICAgICBjYXB0dXJlVHlwZTogcGF5bG9hZC5jYXB0dXJlVHlwZSxcbiAgICAgIHN0YXJ0ZWRBdCxcbiAgICAgIHJlY29yZGluZ1N0YXJ0ZWRBdDpcbiAgICAgICAgcGF5bG9hZC5jYXB0dXJlVHlwZSA9PT0gXCJzY3JlZW5zaG90XCIgPyBzdGFydGVkQXQgOiBudWxsLFxuICAgICAgZXZlbnRzOiBpbnN0YW50UmVwbGF5RXZlbnRzLFxuICAgIH1cblxuICAgIHNlc3Npb25zQnlJZC5zZXQoc2Vzc2lvbklkLCBzZXNzaW9uKVxuICAgIHRhYlRvU2Vzc2lvbi5zZXQocGF5bG9hZC5jYXB0dXJlVGFiSWQsIHNlc3Npb25JZClcbiAgICBzY2hlZHVsZVBlcnNpc3QoKVxuICAgIGF3YWl0IGluamVjdERlYnVnZ2VyU2NyaXB0SW50b1RhYihwYXlsb2FkLmNhcHR1cmVUYWJJZClcblxuICAgIHJldHVybiB7XG4gICAgICBzZXNzaW9uSWQsXG4gICAgICBzdGFydGVkQXQsXG4gICAgfVxuICB9XG5cbiAgY29uc3QgaW5qZWN0RGVidWdnZXJTY3JpcHRGb3JUYWIgPSBhc3luYyAodGFiSWQ6IG51bWJlcik6IFByb21pc2U8dm9pZD4gPT4ge1xuICAgIGF3YWl0IGVuc3VyZUxvYWRlZCgpXG5cbiAgICBpZiAoIXRhYlRvU2Vzc2lvbi5oYXModGFiSWQpKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBhd2FpdCBpbmplY3REZWJ1Z2dlclNjcmlwdEludG9UYWIodGFiSWQpXG4gIH1cblxuICBjb25zdCBhcHBlbmRQYWdlRXZlbnRzID0gYXN5bmMgKHRhYklkOiBudW1iZXIsIHJhd0V2ZW50czogdW5rbm93bltdKSA9PiB7XG4gICAgYXdhaXQgZW5zdXJlTG9hZGVkKClcblxuICAgIGlmICghQXJyYXkuaXNBcnJheShyYXdFdmVudHMpIHx8IHJhd0V2ZW50cy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIGNvbnN0IG5vcm1hbGl6ZWRFdmVudHM6IERlYnVnZ2VyRXZlbnRbXSA9IFtdXG4gICAgZm9yIChjb25zdCByYXdFdmVudCBvZiByYXdFdmVudHMpIHtcbiAgICAgIGNvbnN0IG5vcm1hbGl6ZWRFdmVudCA9IG5vcm1hbGl6ZURlYnVnZ2VyRXZlbnQocmF3RXZlbnQpXG4gICAgICBpZiAoIW5vcm1hbGl6ZWRFdmVudCkge1xuICAgICAgICBjb250aW51ZVxuICAgICAgfVxuXG4gICAgICBub3JtYWxpemVkRXZlbnRzLnB1c2gobm9ybWFsaXplZEV2ZW50KVxuICAgIH1cblxuICAgIGFwcGVuZEV2ZW50c1RvUmVjZW50QnVmZmVyKHRhYklkLCBub3JtYWxpemVkRXZlbnRzKVxuICAgIGFwcGVuZEV2ZW50c1RvU2Vzc2lvbih0YWJJZCwgbm9ybWFsaXplZEV2ZW50cylcbiAgfVxuXG4gIGNvbnN0IGdldFNlc3Npb25TbmFwc2hvdCA9IGFzeW5jIChcbiAgICBzZXNzaW9uSWQ6IHN0cmluZ1xuICApOiBQcm9taXNlPERlYnVnZ2VyU2Vzc2lvblNuYXBzaG90IHwgbnVsbD4gPT4ge1xuICAgIGF3YWl0IGVuc3VyZUxvYWRlZCgpXG5cbiAgICBjb25zdCBzZXNzaW9uID0gc2Vzc2lvbnNCeUlkLmdldChzZXNzaW9uSWQpXG4gICAgaWYgKCFzZXNzaW9uKSB7XG4gICAgICByZXR1cm4gbnVsbFxuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICBzZXNzaW9uSWQ6IHNlc3Npb24uc2Vzc2lvbklkLFxuICAgICAgY2FwdHVyZVRhYklkOiBzZXNzaW9uLmNhcHR1cmVUYWJJZCxcbiAgICAgIGNhcHR1cmVUeXBlOiBzZXNzaW9uLmNhcHR1cmVUeXBlLFxuICAgICAgc3RhcnRlZEF0OiBzZXNzaW9uLnN0YXJ0ZWRBdCxcbiAgICAgIHJlY29yZGluZ1N0YXJ0ZWRBdDogc2Vzc2lvbi5yZWNvcmRpbmdTdGFydGVkQXQsXG4gICAgICBldmVudHM6IHNlc3Npb24uZXZlbnRzLFxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IG1hcmtTZXNzaW9uUmVjb3JkaW5nU3RhcnRlZCA9IGFzeW5jIChcbiAgICBwYXlsb2FkOiBNYXJrUmVjb3JkaW5nU3RhcnRlZFBheWxvYWRcbiAgKSA9PiB7XG4gICAgYXdhaXQgZW5zdXJlTG9hZGVkKClcblxuICAgIGNvbnN0IHNlc3Npb24gPSBzZXNzaW9uc0J5SWQuZ2V0KHBheWxvYWQuc2Vzc2lvbklkKVxuICAgIGlmICghc2Vzc2lvbikge1xuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgc2Vzc2lvbi5yZWNvcmRpbmdTdGFydGVkQXQgPSBNYXRoLmZsb29yKHBheWxvYWQucmVjb3JkaW5nU3RhcnRlZEF0KVxuICAgIHNjaGVkdWxlUGVyc2lzdCgpXG4gIH1cblxuICBjb25zdCBkaXNjYXJkU2Vzc2lvbiA9IGFzeW5jIChzZXNzaW9uSWQ6IHN0cmluZykgPT4ge1xuICAgIGF3YWl0IGVuc3VyZUxvYWRlZCgpXG5cbiAgICBjb25zdCBzZXNzaW9uID0gc2Vzc2lvbnNCeUlkLmdldChzZXNzaW9uSWQpXG4gICAgcmVtb3ZlU2Vzc2lvbihzZXNzaW9uSWQpXG4gICAgaWYgKHNlc3Npb24pIHtcbiAgICAgIHJlY2VudEV2ZW50c0J5VGFiLmRlbGV0ZShzZXNzaW9uLmNhcHR1cmVUYWJJZClcbiAgICB9XG4gICAgc2NoZWR1bGVQZXJzaXN0KClcbiAgfVxuXG4gIGNvbnN0IGVuc3VyZURlYnVnZ2VyU2NyaXB0Rm9yVGFiID0gYXN5bmMgKFxuICAgIHRhYklkOiBudW1iZXIsXG4gICAgdXJsPzogc3RyaW5nXG4gICk6IFByb21pc2U8dm9pZD4gPT4ge1xuICAgIGF3YWl0IGVuc3VyZUxvYWRlZCgpXG5cbiAgICBpZiAoISh1cmwgJiYgaXNJbmplY3RhYmxlUGFnZVVybCh1cmwpKSkge1xuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgaWYgKCF0YWJUb1Nlc3Npb24uaGFzKHRhYklkKSkge1xuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgYXdhaXQgaW5qZWN0RGVidWdnZXJTY3JpcHRJbnRvVGFiKHRhYklkKVxuICB9XG5cbiAgY29uc3QgZGlzY2FyZFNlc3Npb25CeVRhYklkID0gYXN5bmMgKHRhYklkOiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+ID0+IHtcbiAgICBhd2FpdCBlbnN1cmVMb2FkZWQoKVxuXG4gICAgY29uc3Qgc2Vzc2lvbklkID0gdGFiVG9TZXNzaW9uLmdldCh0YWJJZClcbiAgICBpZiAoIXNlc3Npb25JZCkge1xuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgcmVtb3ZlU2Vzc2lvbihzZXNzaW9uSWQpXG4gICAgcmVjZW50RXZlbnRzQnlUYWIuZGVsZXRlKHRhYklkKVxuICAgIHNjaGVkdWxlUGVyc2lzdCgpXG4gIH1cblxuICByZXR1cm4ge1xuICAgIGluamVjdERlYnVnZ2VyU2NyaXB0Rm9yVGFiLFxuICAgIHN0YXJ0U2Vzc2lvbixcbiAgICBhcHBlbmRQYWdlRXZlbnRzLFxuICAgIGdldFNlc3Npb25TbmFwc2hvdCxcbiAgICBtYXJrU2Vzc2lvblJlY29yZGluZ1N0YXJ0ZWQsXG4gICAgZGlzY2FyZFNlc3Npb24sXG4gICAgZW5zdXJlRGVidWdnZXJTY3JpcHRGb3JUYWIsXG4gICAgZGlzY2FyZFNlc3Npb25CeVRhYklkLFxuICB9XG59XG4iLCJpbXBvcnQge1xuICBCQUNLR1JPVU5EX0xJU1RFTkVSX0ZMQUcsXG4gIERJU0NBUkRfU0VTU0lPTl9NRVNTQUdFLFxuICBFTlNVUkVfUEFHRV9SVU5USU1FX01FU1NBR0UsXG4gIEdFVF9TRVNTSU9OX1NOQVBTSE9UX01FU1NBR0UsXG4gIE1BUktfUkVDT1JESU5HX1NUQVJURURfTUVTU0FHRSxcbiAgUEFHRV9FVkVOVF9NRVNTQUdFLFxuICBQQUdFX0VWRU5UU19NRVNTQUdFLFxuICBTVEFSVF9TRVNTSU9OX01FU1NBR0UsXG59IGZyb20gXCJAY3Jpa2tldC9jYXB0dXJlLWNvcmUvZGVidWdnZXIvY29uc3RhbnRzXCJcbmltcG9ydCB0eXBlIHsgRGVidWdnZXJSdW50aW1lUmVzcG9uc2UgfSBmcm9tIFwiQGNyaWtrZXQvY2FwdHVyZS1jb3JlL2RlYnVnZ2VyL3R5cGVzXCJcbmltcG9ydCB7IHJlcG9ydE5vbkZhdGFsRXJyb3IgfSBmcm9tIFwiQGNyaWtrZXQvc2hhcmVkL2xpYi9lcnJvcnNcIlxuaW1wb3J0IHsgaXNEZWJ1Z2dlclJ1bnRpbWVNZXNzYWdlIH0gZnJvbSBcIi4uLy4uL21lc3NhZ2luZ1wiXG5pbXBvcnQgeyBjcmVhdGVEZWJ1Z2dlclNlc3Npb25TdG9yZSB9IGZyb20gXCIuL3Nlc3Npb24tc3RvcmVcIlxuXG5leHBvcnQgZnVuY3Rpb24gcmVnaXN0ZXJEZWJ1Z2dlckJhY2tncm91bmRMaXN0ZW5lcnMoKTogdm9pZCB7XG4gIGNvbnN0IHNjb3BlID0gZ2xvYmFsVGhpcyBhcyB0eXBlb2YgZ2xvYmFsVGhpcyAmIHtcbiAgICBbQkFDS0dST1VORF9MSVNURU5FUl9GTEFHXT86IGJvb2xlYW5cbiAgfVxuXG4gIGlmIChzY29wZVtCQUNLR1JPVU5EX0xJU1RFTkVSX0ZMQUddKSB7XG4gICAgcmV0dXJuXG4gIH1cblxuICBzY29wZVtCQUNLR1JPVU5EX0xJU1RFTkVSX0ZMQUddID0gdHJ1ZVxuXG4gIGNvbnN0IHN0b3JlID0gY3JlYXRlRGVidWdnZXJTZXNzaW9uU3RvcmUoKVxuXG4gIGNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobWVzc2FnZSwgc2VuZGVyLCBzZW5kUmVzcG9uc2UpID0+IHtcbiAgICBpZiAoIWlzRGVidWdnZXJSdW50aW1lTWVzc2FnZShtZXNzYWdlKSkge1xuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgY29uc3Qgc2FmZVNlbmRSZXNwb25zZSA9IDxURGF0YT4oXG4gICAgICByZXNwb25zZTogRGVidWdnZXJSdW50aW1lUmVzcG9uc2U8VERhdGE+XG4gICAgKSA9PiB7XG4gICAgICBzZW5kUmVzcG9uc2UocmVzcG9uc2UpXG4gICAgfVxuXG4gICAgY29uc3Qgb25FcnJvciA9IChlcnJvcjogdW5rbm93bikgPT4ge1xuICAgICAgc2FmZVNlbmRSZXNwb25zZSh7XG4gICAgICAgIG9rOiBmYWxzZSxcbiAgICAgICAgZXJyb3I6XG4gICAgICAgICAgZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIkRlYnVnZ2VyIGhhbmRsZXIgZmFpbGVkXCIsXG4gICAgICB9KVxuICAgIH1cblxuICAgIGNvbnN0IGhhbmRsZXIgPSBhc3luYyAoKSA9PiB7XG4gICAgICBjb25zdCB0YWJJZCA9IHNlbmRlci50YWI/LmlkXG4gICAgICBjb25zdCBhcHBlbmRFdmVudHNGb3JTZW5kZXJUYWIgPSBhc3luYyAoZXZlbnRzOiB1bmtub3duW10pID0+IHtcbiAgICAgICAgaWYgKHR5cGVvZiB0YWJJZCAhPT0gXCJudW1iZXJcIikge1xuICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG5cbiAgICAgICAgYXdhaXQgc3RvcmUuYXBwZW5kUGFnZUV2ZW50cyh0YWJJZCwgZXZlbnRzKVxuICAgICAgfVxuXG4gICAgICBzd2l0Y2ggKG1lc3NhZ2UudHlwZSkge1xuICAgICAgICBjYXNlIFNUQVJUX1NFU1NJT05fTUVTU0FHRToge1xuICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBzdG9yZS5zdGFydFNlc3Npb24obWVzc2FnZS5wYXlsb2FkKVxuICAgICAgICAgIHNhZmVTZW5kUmVzcG9uc2UoeyBvazogdHJ1ZSwgZGF0YSB9KVxuICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG4gICAgICAgIGNhc2UgTUFSS19SRUNPUkRJTkdfU1RBUlRFRF9NRVNTQUdFOiB7XG4gICAgICAgICAgYXdhaXQgc3RvcmUubWFya1Nlc3Npb25SZWNvcmRpbmdTdGFydGVkKG1lc3NhZ2UucGF5bG9hZClcbiAgICAgICAgICBzYWZlU2VuZFJlc3BvbnNlKHsgb2s6IHRydWUsIGRhdGE6IHVuZGVmaW5lZCB9KVxuICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG4gICAgICAgIGNhc2UgUEFHRV9FVkVOVF9NRVNTQUdFOiB7XG4gICAgICAgICAgYXdhaXQgYXBwZW5kRXZlbnRzRm9yU2VuZGVyVGFiKFttZXNzYWdlLnBheWxvYWQuZXZlbnRdKVxuICAgICAgICAgIHNhZmVTZW5kUmVzcG9uc2UoeyBvazogdHJ1ZSwgZGF0YTogdW5kZWZpbmVkIH0pXG4gICAgICAgICAgcmV0dXJuXG4gICAgICAgIH1cbiAgICAgICAgY2FzZSBQQUdFX0VWRU5UU19NRVNTQUdFOiB7XG4gICAgICAgICAgYXdhaXQgYXBwZW5kRXZlbnRzRm9yU2VuZGVyVGFiKG1lc3NhZ2UucGF5bG9hZC5ldmVudHMpXG4gICAgICAgICAgc2FmZVNlbmRSZXNwb25zZSh7IG9rOiB0cnVlLCBkYXRhOiB1bmRlZmluZWQgfSlcbiAgICAgICAgICByZXR1cm5cbiAgICAgICAgfVxuICAgICAgICBjYXNlIEVOU1VSRV9QQUdFX1JVTlRJTUVfTUVTU0FHRToge1xuICAgICAgICAgIGlmICh0eXBlb2YgdGFiSWQgPT09IFwibnVtYmVyXCIpIHtcbiAgICAgICAgICAgIGF3YWl0IHN0b3JlLmluamVjdERlYnVnZ2VyU2NyaXB0Rm9yVGFiKHRhYklkKVxuICAgICAgICAgIH1cbiAgICAgICAgICBzYWZlU2VuZFJlc3BvbnNlKHsgb2s6IHRydWUsIGRhdGE6IHVuZGVmaW5lZCB9KVxuICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG4gICAgICAgIGNhc2UgR0VUX1NFU1NJT05fU05BUFNIT1RfTUVTU0FHRToge1xuICAgICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBzdG9yZS5nZXRTZXNzaW9uU25hcHNob3QobWVzc2FnZS5wYXlsb2FkLnNlc3Npb25JZClcbiAgICAgICAgICBzYWZlU2VuZFJlc3BvbnNlKHsgb2s6IHRydWUsIGRhdGEgfSlcbiAgICAgICAgICByZXR1cm5cbiAgICAgICAgfVxuICAgICAgICBjYXNlIERJU0NBUkRfU0VTU0lPTl9NRVNTQUdFOiB7XG4gICAgICAgICAgYXdhaXQgc3RvcmUuZGlzY2FyZFNlc3Npb24obWVzc2FnZS5wYXlsb2FkLnNlc3Npb25JZClcbiAgICAgICAgICBzYWZlU2VuZFJlc3BvbnNlKHsgb2s6IHRydWUsIGRhdGE6IHVuZGVmaW5lZCB9KVxuICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG4gICAgICAgIGRlZmF1bHQ6IHtcbiAgICAgICAgICBzYWZlU2VuZFJlc3BvbnNlKHsgb2s6IHRydWUsIGRhdGE6IHVuZGVmaW5lZCB9KVxuICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgaGFuZGxlcigpLmNhdGNoKG9uRXJyb3IpXG4gICAgcmV0dXJuIHRydWVcbiAgfSlcblxuICBjaHJvbWUudGFicy5vblVwZGF0ZWQuYWRkTGlzdGVuZXIoKHRhYklkLCBjaGFuZ2VJbmZvLCB0YWIpID0+IHtcbiAgICBjb25zdCBkaWRUYWJOYXZpZ2F0ZSA9XG4gICAgICBjaGFuZ2VJbmZvLnN0YXR1cyA9PT0gXCJsb2FkaW5nXCIgfHwgdHlwZW9mIGNoYW5nZUluZm8udXJsID09PSBcInN0cmluZ1wiXG5cbiAgICBpZiAoIWRpZFRhYk5hdmlnYXRlKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBjb25zdCB1cmwgPVxuICAgICAgdHlwZW9mIGNoYW5nZUluZm8udXJsID09PSBcInN0cmluZ1wiXG4gICAgICAgID8gY2hhbmdlSW5mby51cmxcbiAgICAgICAgOiAodGFiLnVybCA/PyB1bmRlZmluZWQpXG5cbiAgICBzdG9yZS5lbnN1cmVEZWJ1Z2dlclNjcmlwdEZvclRhYih0YWJJZCwgdXJsKS5jYXRjaCgoZXJyb3I6IHVua25vd24pID0+IHtcbiAgICAgIHJlcG9ydE5vbkZhdGFsRXJyb3IoXG4gICAgICAgIGBGYWlsZWQgdG8gcmVpbmplY3QgZGVidWdnZXIgaW5zdHJ1bWVudGF0aW9uIGFmdGVyIHRhYiB1cGRhdGUgZm9yIHRhYiAke3RhYklkfWAsXG4gICAgICAgIGVycm9yXG4gICAgICApXG4gICAgfSlcbiAgfSlcblxuICBjaHJvbWUudGFicy5vblJlbW92ZWQuYWRkTGlzdGVuZXIoKHRhYklkKSA9PiB7XG4gICAgc3RvcmUuZGlzY2FyZFNlc3Npb25CeVRhYklkKHRhYklkKS5jYXRjaCgoZXJyb3I6IHVua25vd24pID0+IHtcbiAgICAgIHJlcG9ydE5vbkZhdGFsRXJyb3IoXG4gICAgICAgIGBGYWlsZWQgdG8gZGlzY2FyZCBkZWJ1Z2dlciBzZXNzaW9uIGZvciByZW1vdmVkIHRhYiAke3RhYklkfWAsXG4gICAgICAgIGVycm9yXG4gICAgICApXG4gICAgfSlcbiAgfSlcbn1cbiIsImV4cG9ydCB0eXBlIENhcHR1cmVDb250ZXh0ID0geyB0aXRsZT86IHN0cmluZzsgdXJsPzogc3RyaW5nIH1cblxuZXhwb3J0IGNvbnN0IENBUFRVUkVfQ09OVEVYVF9TVE9SQUdFX0tFWSA9IFwiY2FwdHVyZUNvbnRleHRcIlxuZXhwb3J0IGNvbnN0IENBUFRVUkVfVEFCX0lEX1NUT1JBR0VfS0VZID0gXCJjYXB0dXJlVGFiSWRcIlxuZXhwb3J0IGNvbnN0IFJFQ09SRElOR19JTl9QUk9HUkVTU19TVE9SQUdFX0tFWSA9IFwicmVjb3JkaW5nSW5Qcm9ncmVzc1wiXG5leHBvcnQgY29uc3QgUkVDT1JERVJfVEFCX0lEX1NUT1JBR0VfS0VZID0gXCJyZWNvcmRlclRhYklkXCJcbmV4cG9ydCBjb25zdCBSRUNPUkRJTkdfQ09VTlRET1dOX0VORFNfQVRfU1RPUkFHRV9LRVkgPVxuICBcInJlY29yZGluZ0NvdW50ZG93bkVuZHNBdFwiXG5leHBvcnQgY29uc3QgUkVDT1JESU5HX1NUQVJURURfQVRfU1RPUkFHRV9LRVkgPSBcInJlY29yZGluZ1N0YXJ0ZWRBdFwiXG5leHBvcnQgY29uc3QgSE9US0VZX1NUQVJUX1ZJREVPX0NBUFRVUkVfU1RPUkFHRV9LRVkgPSBcImhvdGtleVN0YXJ0VmlkZW9DYXB0dXJlXCJcbmV4cG9ydCBjb25zdCBIT1RLRVlfU1RBUlRfU0NSRUVOU0hPVF9DQVBUVVJFX1NUT1JBR0VfS0VZID1cbiAgXCJob3RrZXlTdGFydFNjcmVlbnNob3RDYXB0dXJlXCJcblxuY29uc3QgaXNFeHRlbnNpb25VcmwgPSAodXJsPzogc3RyaW5nKTogYm9vbGVhbiA9PlxuICB0eXBlb2YgdXJsID09PSBcInN0cmluZ1wiICYmXG4gICh1cmwuc3RhcnRzV2l0aChcImNocm9tZS1leHRlbnNpb246Ly9cIikgfHwgdXJsLnN0YXJ0c1dpdGgoXCJtb3otZXh0ZW5zaW9uOi8vXCIpKVxuXG5leHBvcnQgY29uc3Qgc2FuaXRpemVDYXB0dXJlQ29udGV4dCA9IChcbiAgY29udGV4dD86IENhcHR1cmVDb250ZXh0XG4pOiBDYXB0dXJlQ29udGV4dCA9PiB7XG4gIGlmICghY29udGV4dCkgcmV0dXJuIHt9XG4gIGlmIChpc0V4dGVuc2lvblVybChjb250ZXh0LnVybCkpIHJldHVybiB7fVxuXG4gIHJldHVybiB7XG4gICAgdGl0bGU6IGNvbnRleHQudGl0bGUgPz8gdW5kZWZpbmVkLFxuICAgIHVybDogY29udGV4dC51cmwgPz8gdW5kZWZpbmVkLFxuICB9XG59XG5cbmV4cG9ydCBjb25zdCBoYXNDYXB0dXJlQ29udGV4dCA9IChjb250ZXh0OiBDYXB0dXJlQ29udGV4dCk6IGJvb2xlYW4gPT5cbiAgQm9vbGVhbihjb250ZXh0LnRpdGxlIHx8IGNvbnRleHQudXJsKVxuXG5leHBvcnQgY29uc3QgZ2V0QWN0aXZlVGFiQ29udGV4dCA9IGFzeW5jICgpOiBQcm9taXNlPENhcHR1cmVDb250ZXh0PiA9PiB7XG4gIGNvbnN0IHRhYnMgPSBhd2FpdCBjaHJvbWUudGFicy5xdWVyeSh7XG4gICAgYWN0aXZlOiB0cnVlLFxuICAgIGN1cnJlbnRXaW5kb3c6IHRydWUsXG4gIH0pXG4gIGNvbnN0IGFjdGl2ZVRhYiA9IHRhYnNbMF1cblxuICByZXR1cm4gc2FuaXRpemVDYXB0dXJlQ29udGV4dCh7XG4gICAgdGl0bGU6IGFjdGl2ZVRhYj8udGl0bGUgPz8gdW5kZWZpbmVkLFxuICAgIHVybDogYWN0aXZlVGFiPy51cmwgPz8gdW5kZWZpbmVkLFxuICB9KVxufVxuXG5leHBvcnQgY29uc3QgcmVhZEFuZENsZWFyU3RvcmVkQ2FwdHVyZUNvbnRleHQgPVxuICBhc3luYyAoKTogUHJvbWlzZTxDYXB0dXJlQ29udGV4dD4gPT4ge1xuICAgIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChbQ0FQVFVSRV9DT05URVhUX1NUT1JBR0VfS0VZXSlcbiAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5yZW1vdmUoW0NBUFRVUkVfQ09OVEVYVF9TVE9SQUdFX0tFWV0pXG5cbiAgICByZXR1cm4gc2FuaXRpemVDYXB0dXJlQ29udGV4dChcbiAgICAgIHN0b3JlZFtDQVBUVVJFX0NPTlRFWFRfU1RPUkFHRV9LRVldIGFzIENhcHR1cmVDb250ZXh0IHwgdW5kZWZpbmVkXG4gICAgKVxuICB9XG5cbmV4cG9ydCBjb25zdCByZWFkQW5kQ2xlYXJDYXB0dXJlVGFiSWQgPSBhc3luYyAoKTogUHJvbWlzZTxudW1iZXIgfCBudWxsPiA9PiB7XG4gIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChbQ0FQVFVSRV9UQUJfSURfU1RPUkFHRV9LRVldKVxuICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5yZW1vdmUoW0NBUFRVUkVfVEFCX0lEX1NUT1JBR0VfS0VZXSlcblxuICBjb25zdCB0YWJJZCA9IHN0b3JlZFtDQVBUVVJFX1RBQl9JRF9TVE9SQUdFX0tFWV1cbiAgcmV0dXJuIHR5cGVvZiB0YWJJZCA9PT0gXCJudW1iZXJcIiA/IHRhYklkIDogbnVsbFxufVxuIiwiaW1wb3J0IHsgcmVwb3J0Tm9uRmF0YWxFcnJvciB9IGZyb20gXCJAY3Jpa2tldC9zaGFyZWQvbGliL2Vycm9yc1wiXG5pbXBvcnQge1xuICBIT1RLRVlfU1RBUlRfU0NSRUVOU0hPVF9DQVBUVVJFX1NUT1JBR0VfS0VZLFxuICBIT1RLRVlfU1RBUlRfVklERU9fQ0FQVFVSRV9TVE9SQUdFX0tFWSxcbiAgUkVDT1JERVJfVEFCX0lEX1NUT1JBR0VfS0VZLFxuICBSRUNPUkRJTkdfQ09VTlRET1dOX0VORFNfQVRfU1RPUkFHRV9LRVksXG4gIFJFQ09SRElOR19JTl9QUk9HUkVTU19TVE9SQUdFX0tFWSxcbiAgUkVDT1JESU5HX1NUQVJURURfQVRfU1RPUkFHRV9LRVksXG59IGZyb20gXCJAL2xpYi9jYXB0dXJlLWNvbnRleHRcIlxuXG5leHBvcnQgY29uc3QgU1RBUlRfUkVDT1JESU5HX0NPTU1BTkQgPSBcInN0YXJ0LXZpZGVvLXJlY29yZGluZ1wiXG5leHBvcnQgY29uc3QgU1RBUlRfU0NSRUVOU0hPVF9DT01NQU5EID0gXCJzdGFydC1zY3JlZW5zaG90LWNhcHR1cmVcIlxuZXhwb3J0IGNvbnN0IFNUT1BfUkVDT1JESU5HX0NPTU1BTkQgPSBcInN0b3AtdmlkZW8tcmVjb3JkaW5nXCJcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN0YXJ0UmVjb3JkaW5nRnJvbUhvdGtleSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgcXVldWVDYXB0dXJlU3RhcnRGcm9tSG90a2V5KEhPVEtFWV9TVEFSVF9WSURFT19DQVBUVVJFX1NUT1JBR0VfS0VZKVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaGFuZGxlU3RhcnRTY3JlZW5zaG90RnJvbUhvdGtleSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgYXdhaXQgcXVldWVDYXB0dXJlU3RhcnRGcm9tSG90a2V5KEhPVEtFWV9TVEFSVF9TQ1JFRU5TSE9UX0NBUFRVUkVfU1RPUkFHRV9LRVkpXG59XG5cbmFzeW5jIGZ1bmN0aW9uIHF1ZXVlQ2FwdHVyZVN0YXJ0RnJvbUhvdGtleShzdG9yYWdlS2V5OiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3Qgc3RhdGUgPSBhd2FpdCByZWFkUmVjb3JkaW5nU3RhdGUoKVxuICBpZiAoc3RhdGUuaXNSZWNvcmRpbmdJblByb2dyZXNzKSB7XG4gICAgY29uc3QgcmVjb3JkZXJUYWJJZCA9IGF3YWl0IHJlc29sdmVSZWNvcmRlclRhYklkKClcbiAgICBpZiAocmVjb3JkZXJUYWJJZCAhPT0gbnVsbCkge1xuICAgICAgYXdhaXQgZm9jdXNSZWNvcmRlclRhYigpXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBhd2FpdCBjbGVhclN0YWxlUmVjb3JkaW5nU3RhdGUoKVxuICB9XG5cbiAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHtcbiAgICBbc3RvcmFnZUtleV06IERhdGUubm93KCksXG4gIH0pXG4gIGF3YWl0IGNocm9tZS5hY3Rpb24ub3BlblBvcHVwKClcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN0b3BSZWNvcmRpbmdGcm9tSG90a2V5KCk6IFByb21pc2U8dm9pZD4ge1xuICB0cnkge1xuICAgIGF3YWl0IGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKHsgdHlwZTogXCJTVE9QX1JFQ09SRElOR19GUk9NX1BPUFVQXCIgfSlcbiAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcbiAgICByZXBvcnROb25GYXRhbEVycm9yKFxuICAgICAgXCJGYWlsZWQgdG8gc2VuZCBTVE9QX1JFQ09SRElOR19GUk9NX1BPUFVQIGZvciBob3RrZXkgc3RvcFwiLFxuICAgICAgZXJyb3JcbiAgICApXG4gIH1cblxuICBhd2FpdCBmb2N1c1JlY29yZGVyVGFiKClcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVJlY29yZGVySG90a2V5Q29tbWFuZChcbiAgY29tbWFuZDogc3RyaW5nXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKGNvbW1hbmQgPT09IFNUQVJUX1JFQ09SRElOR19DT01NQU5EKSB7XG4gICAgYXdhaXQgaGFuZGxlU3RhcnRSZWNvcmRpbmdGcm9tSG90a2V5KClcbiAgICByZXR1cm5cbiAgfVxuXG4gIGlmIChjb21tYW5kID09PSBTVEFSVF9TQ1JFRU5TSE9UX0NPTU1BTkQpIHtcbiAgICBhd2FpdCBoYW5kbGVTdGFydFNjcmVlbnNob3RGcm9tSG90a2V5KClcbiAgICByZXR1cm5cbiAgfVxuXG4gIGlmIChjb21tYW5kID09PSBTVE9QX1JFQ09SRElOR19DT01NQU5EKSB7XG4gICAgYXdhaXQgaGFuZGxlU3RvcFJlY29yZGluZ0Zyb21Ib3RrZXkoKVxuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlYWRSZWNvcmRpbmdTdGF0ZSgpOiBQcm9taXNlPHtcbiAgaXNSZWNvcmRpbmdJblByb2dyZXNzOiBib29sZWFuXG59PiB7XG4gIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChbXG4gICAgUkVDT1JESU5HX0lOX1BST0dSRVNTX1NUT1JBR0VfS0VZLFxuICBdKVxuICByZXR1cm4ge1xuICAgIGlzUmVjb3JkaW5nSW5Qcm9ncmVzczogQm9vbGVhbihyZXN1bHRbUkVDT1JESU5HX0lOX1BST0dSRVNTX1NUT1JBR0VfS0VZXSksXG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gZm9jdXNSZWNvcmRlclRhYigpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgcmVjb3JkZXJUYWJJZCA9IGF3YWl0IHJlc29sdmVSZWNvcmRlclRhYklkKClcbiAgaWYgKHJlY29yZGVyVGFiSWQgPT09IG51bGwpIHtcbiAgICByZXR1cm5cbiAgfVxuXG4gIGNvbnN0IHJlY29yZGVyVGFiID0gYXdhaXQgY2hyb21lLnRhYnMuZ2V0KHJlY29yZGVyVGFiSWQpXG4gIGlmICh0eXBlb2YgcmVjb3JkZXJUYWIud2luZG93SWQgPT09IFwibnVtYmVyXCIpIHtcbiAgICBhd2FpdCBjaHJvbWUud2luZG93cy51cGRhdGUocmVjb3JkZXJUYWIud2luZG93SWQsIHsgZm9jdXNlZDogdHJ1ZSB9KVxuICB9XG4gIGF3YWl0IGNocm9tZS50YWJzLnVwZGF0ZShyZWNvcmRlclRhYklkLCB7IGFjdGl2ZTogdHJ1ZSB9KVxufVxuXG5hc3luYyBmdW5jdGlvbiByZXNvbHZlUmVjb3JkZXJUYWJJZCgpOiBQcm9taXNlPG51bWJlciB8IG51bGw+IHtcbiAgY29uc3Qgc3RvcmVkID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFtSRUNPUkRFUl9UQUJfSURfU1RPUkFHRV9LRVldKVxuICBjb25zdCBzdG9yZWRUYWJJZCA9IHN0b3JlZFtSRUNPUkRFUl9UQUJfSURfU1RPUkFHRV9LRVldXG4gIGlmICh0eXBlb2Ygc3RvcmVkVGFiSWQgPT09IFwibnVtYmVyXCIpIHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgY2hyb21lLnRhYnMuZ2V0KHN0b3JlZFRhYklkKVxuICAgICAgcmV0dXJuIHN0b3JlZFRhYklkXG4gICAgfSBjYXRjaCAoZXJyb3I6IHVua25vd24pIHtcbiAgICAgIHJlcG9ydE5vbkZhdGFsRXJyb3IoXG4gICAgICAgIGBGYWlsZWQgdG8gcmVzb2x2ZSBzdG9yZWQgcmVjb3JkZXIgdGFiICR7c3RvcmVkVGFiSWR9IGZyb20gaG90a2V5IGZsb3dgLFxuICAgICAgICBlcnJvclxuICAgICAgKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHJlY29yZGVyVGFicyA9IGF3YWl0IGNocm9tZS50YWJzLnF1ZXJ5KHtcbiAgICB1cmw6IFtjaHJvbWUucnVudGltZS5nZXRVUkwoXCIvcmVjb3JkZXIuaHRtbCpcIildLFxuICB9KVxuICBjb25zdCBtb3N0UmVjZW50UmVjb3JkZXJUYWIgPSByZWNvcmRlclRhYnNcbiAgICAuZmlsdGVyKCh0YWIpID0+IHR5cGVvZiB0YWIuaWQgPT09IFwibnVtYmVyXCIpXG4gICAgLnNvcnQoKGEsIGIpID0+IChiLmlkID8/IDApIC0gKGEuaWQgPz8gMCkpWzBdXG4gIHJldHVybiBtb3N0UmVjZW50UmVjb3JkZXJUYWI/LmlkID8/IG51bGxcbn1cblxuYXN5bmMgZnVuY3Rpb24gY2xlYXJTdGFsZVJlY29yZGluZ1N0YXRlKCk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoe1xuICAgIFtSRUNPUkRJTkdfSU5fUFJPR1JFU1NfU1RPUkFHRV9LRVldOiBmYWxzZSxcbiAgfSlcbiAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFtcbiAgICBSRUNPUkRFUl9UQUJfSURfU1RPUkFHRV9LRVksXG4gICAgUkVDT1JESU5HX0NPVU5URE9XTl9FTkRTX0FUX1NUT1JBR0VfS0VZLFxuICAgIFJFQ09SRElOR19TVEFSVEVEX0FUX1NUT1JBR0VfS0VZLFxuICBdKVxufVxuIiwiaW1wb3J0IHsgcmVwb3J0Tm9uRmF0YWxFcnJvciB9IGZyb20gXCJAY3Jpa2tldC9zaGFyZWQvbGliL2Vycm9yc1wiXG5pbXBvcnQgeyByZWdpc3RlckRlYnVnZ2VyQmFja2dyb3VuZExpc3RlbmVycyB9IGZyb20gXCJAL2xpYi9idWctcmVwb3J0LWRlYnVnZ2VyL2VuZ2luZS9iYWNrZ3JvdW5kXCJcbmltcG9ydCB7IGhhbmRsZVJlY29yZGVySG90a2V5Q29tbWFuZCB9IGZyb20gXCJAL2xpYi9yZWNvcmRlci1ob3RrZXktY29tbWFuZHNcIlxuXG5leHBvcnQgZGVmYXVsdCBkZWZpbmVCYWNrZ3JvdW5kKCgpID0+IHtcbiAgcmVnaXN0ZXJEZWJ1Z2dlckJhY2tncm91bmRMaXN0ZW5lcnMoKVxuXG4gIGNocm9tZS5jb21tYW5kcy5vbkNvbW1hbmQuYWRkTGlzdGVuZXIoKGNvbW1hbmQpID0+IHtcbiAgICBoYW5kbGVSZWNvcmRlckhvdGtleUNvbW1hbmQoY29tbWFuZCkuY2F0Y2goYXN5bmMgKGVycm9yOiB1bmtub3duKSA9PiB7XG4gICAgICByZXBvcnROb25GYXRhbEVycm9yKFwiRmFpbGVkIHRvIGV4ZWN1dGUgcmVjb3JkZXIgaG90a2V5IGNvbW1hbmRcIiwgZXJyb3IpXG4gICAgICB0cnkge1xuICAgICAgICBhd2FpdCBjaHJvbWUuYWN0aW9uLm9wZW5Qb3B1cCgpXG4gICAgICB9IGNhdGNoIChvcGVuUG9wdXBFcnJvcikge1xuICAgICAgICByZXBvcnROb25GYXRhbEVycm9yKFxuICAgICAgICAgIFwiRmFpbGVkIHRvIG9wZW4gcG9wdXAgYWZ0ZXIgaG90a2V5IGZhaWx1cmVcIixcbiAgICAgICAgICBvcGVuUG9wdXBFcnJvclxuICAgICAgICApXG4gICAgICB9XG4gICAgfSlcbiAgfSlcbn0pXG4iLCIvLyAjcmVnaW9uIHNuaXBwZXRcbmV4cG9ydCBjb25zdCBicm93c2VyID0gZ2xvYmFsVGhpcy5icm93c2VyPy5ydW50aW1lPy5pZFxuICA/IGdsb2JhbFRoaXMuYnJvd3NlclxuICA6IGdsb2JhbFRoaXMuY2hyb21lO1xuLy8gI2VuZHJlZ2lvbiBzbmlwcGV0XG4iLCJpbXBvcnQgeyBicm93c2VyIGFzIGJyb3dzZXIkMSB9IGZyb20gXCJAd3h0LWRldi9icm93c2VyXCI7XG5cbi8vI3JlZ2lvbiBzcmMvYnJvd3Nlci50c1xuLyoqXG4qIENvbnRhaW5zIHRoZSBgYnJvd3NlcmAgZXhwb3J0IHdoaWNoIHlvdSBzaG91bGQgdXNlIHRvIGFjY2VzcyB0aGUgZXh0ZW5zaW9uIEFQSXMgaW4geW91ciBwcm9qZWN0OlxuKiBgYGB0c1xuKiBpbXBvcnQgeyBicm93c2VyIH0gZnJvbSAnd3h0L2Jyb3dzZXInO1xuKlxuKiBicm93c2VyLnJ1bnRpbWUub25JbnN0YWxsZWQuYWRkTGlzdGVuZXIoKCkgPT4ge1xuKiAgIC8vIC4uLlxuKiB9KVxuKiBgYGBcbiogQG1vZHVsZSB3eHQvYnJvd3NlclxuKi9cbmNvbnN0IGJyb3dzZXIgPSBicm93c2VyJDE7XG5cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgYnJvd3NlciB9OyIsIi8vIHNyYy9pbmRleC50c1xudmFyIF9NYXRjaFBhdHRlcm4gPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKG1hdGNoUGF0dGVybikge1xuICAgIGlmIChtYXRjaFBhdHRlcm4gPT09IFwiPGFsbF91cmxzPlwiKSB7XG4gICAgICB0aGlzLmlzQWxsVXJscyA9IHRydWU7XG4gICAgICB0aGlzLnByb3RvY29sTWF0Y2hlcyA9IFsuLi5fTWF0Y2hQYXR0ZXJuLlBST1RPQ09MU107XG4gICAgICB0aGlzLmhvc3RuYW1lTWF0Y2ggPSBcIipcIjtcbiAgICAgIHRoaXMucGF0aG5hbWVNYXRjaCA9IFwiKlwiO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBncm91cHMgPSAvKC4qKTpcXC9cXC8oLio/KShcXC8uKikvLmV4ZWMobWF0Y2hQYXR0ZXJuKTtcbiAgICAgIGlmIChncm91cHMgPT0gbnVsbClcbiAgICAgICAgdGhyb3cgbmV3IEludmFsaWRNYXRjaFBhdHRlcm4obWF0Y2hQYXR0ZXJuLCBcIkluY29ycmVjdCBmb3JtYXRcIik7XG4gICAgICBjb25zdCBbXywgcHJvdG9jb2wsIGhvc3RuYW1lLCBwYXRobmFtZV0gPSBncm91cHM7XG4gICAgICB2YWxpZGF0ZVByb3RvY29sKG1hdGNoUGF0dGVybiwgcHJvdG9jb2wpO1xuICAgICAgdmFsaWRhdGVIb3N0bmFtZShtYXRjaFBhdHRlcm4sIGhvc3RuYW1lKTtcbiAgICAgIHZhbGlkYXRlUGF0aG5hbWUobWF0Y2hQYXR0ZXJuLCBwYXRobmFtZSk7XG4gICAgICB0aGlzLnByb3RvY29sTWF0Y2hlcyA9IHByb3RvY29sID09PSBcIipcIiA/IFtcImh0dHBcIiwgXCJodHRwc1wiXSA6IFtwcm90b2NvbF07XG4gICAgICB0aGlzLmhvc3RuYW1lTWF0Y2ggPSBob3N0bmFtZTtcbiAgICAgIHRoaXMucGF0aG5hbWVNYXRjaCA9IHBhdGhuYW1lO1xuICAgIH1cbiAgfVxuICBpbmNsdWRlcyh1cmwpIHtcbiAgICBpZiAodGhpcy5pc0FsbFVybHMpXG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICBjb25zdCB1ID0gdHlwZW9mIHVybCA9PT0gXCJzdHJpbmdcIiA/IG5ldyBVUkwodXJsKSA6IHVybCBpbnN0YW5jZW9mIExvY2F0aW9uID8gbmV3IFVSTCh1cmwuaHJlZikgOiB1cmw7XG4gICAgcmV0dXJuICEhdGhpcy5wcm90b2NvbE1hdGNoZXMuZmluZCgocHJvdG9jb2wpID0+IHtcbiAgICAgIGlmIChwcm90b2NvbCA9PT0gXCJodHRwXCIpXG4gICAgICAgIHJldHVybiB0aGlzLmlzSHR0cE1hdGNoKHUpO1xuICAgICAgaWYgKHByb3RvY29sID09PSBcImh0dHBzXCIpXG4gICAgICAgIHJldHVybiB0aGlzLmlzSHR0cHNNYXRjaCh1KTtcbiAgICAgIGlmIChwcm90b2NvbCA9PT0gXCJmaWxlXCIpXG4gICAgICAgIHJldHVybiB0aGlzLmlzRmlsZU1hdGNoKHUpO1xuICAgICAgaWYgKHByb3RvY29sID09PSBcImZ0cFwiKVxuICAgICAgICByZXR1cm4gdGhpcy5pc0Z0cE1hdGNoKHUpO1xuICAgICAgaWYgKHByb3RvY29sID09PSBcInVyblwiKVxuICAgICAgICByZXR1cm4gdGhpcy5pc1Vybk1hdGNoKHUpO1xuICAgIH0pO1xuICB9XG4gIGlzSHR0cE1hdGNoKHVybCkge1xuICAgIHJldHVybiB1cmwucHJvdG9jb2wgPT09IFwiaHR0cDpcIiAmJiB0aGlzLmlzSG9zdFBhdGhNYXRjaCh1cmwpO1xuICB9XG4gIGlzSHR0cHNNYXRjaCh1cmwpIHtcbiAgICByZXR1cm4gdXJsLnByb3RvY29sID09PSBcImh0dHBzOlwiICYmIHRoaXMuaXNIb3N0UGF0aE1hdGNoKHVybCk7XG4gIH1cbiAgaXNIb3N0UGF0aE1hdGNoKHVybCkge1xuICAgIGlmICghdGhpcy5ob3N0bmFtZU1hdGNoIHx8ICF0aGlzLnBhdGhuYW1lTWF0Y2gpXG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgY29uc3QgaG9zdG5hbWVNYXRjaFJlZ2V4cyA9IFtcbiAgICAgIHRoaXMuY29udmVydFBhdHRlcm5Ub1JlZ2V4KHRoaXMuaG9zdG5hbWVNYXRjaCksXG4gICAgICB0aGlzLmNvbnZlcnRQYXR0ZXJuVG9SZWdleCh0aGlzLmhvc3RuYW1lTWF0Y2gucmVwbGFjZSgvXlxcKlxcLi8sIFwiXCIpKVxuICAgIF07XG4gICAgY29uc3QgcGF0aG5hbWVNYXRjaFJlZ2V4ID0gdGhpcy5jb252ZXJ0UGF0dGVyblRvUmVnZXgodGhpcy5wYXRobmFtZU1hdGNoKTtcbiAgICByZXR1cm4gISFob3N0bmFtZU1hdGNoUmVnZXhzLmZpbmQoKHJlZ2V4KSA9PiByZWdleC50ZXN0KHVybC5ob3N0bmFtZSkpICYmIHBhdGhuYW1lTWF0Y2hSZWdleC50ZXN0KHVybC5wYXRobmFtZSk7XG4gIH1cbiAgaXNGaWxlTWF0Y2godXJsKSB7XG4gICAgdGhyb3cgRXJyb3IoXCJOb3QgaW1wbGVtZW50ZWQ6IGZpbGU6Ly8gcGF0dGVybiBtYXRjaGluZy4gT3BlbiBhIFBSIHRvIGFkZCBzdXBwb3J0XCIpO1xuICB9XG4gIGlzRnRwTWF0Y2godXJsKSB7XG4gICAgdGhyb3cgRXJyb3IoXCJOb3QgaW1wbGVtZW50ZWQ6IGZ0cDovLyBwYXR0ZXJuIG1hdGNoaW5nLiBPcGVuIGEgUFIgdG8gYWRkIHN1cHBvcnRcIik7XG4gIH1cbiAgaXNVcm5NYXRjaCh1cmwpIHtcbiAgICB0aHJvdyBFcnJvcihcIk5vdCBpbXBsZW1lbnRlZDogdXJuOi8vIHBhdHRlcm4gbWF0Y2hpbmcuIE9wZW4gYSBQUiB0byBhZGQgc3VwcG9ydFwiKTtcbiAgfVxuICBjb252ZXJ0UGF0dGVyblRvUmVnZXgocGF0dGVybikge1xuICAgIGNvbnN0IGVzY2FwZWQgPSB0aGlzLmVzY2FwZUZvclJlZ2V4KHBhdHRlcm4pO1xuICAgIGNvbnN0IHN0YXJzUmVwbGFjZWQgPSBlc2NhcGVkLnJlcGxhY2UoL1xcXFxcXCovZywgXCIuKlwiKTtcbiAgICByZXR1cm4gUmVnRXhwKGBeJHtzdGFyc1JlcGxhY2VkfSRgKTtcbiAgfVxuICBlc2NhcGVGb3JSZWdleChzdHJpbmcpIHtcbiAgICByZXR1cm4gc3RyaW5nLnJlcGxhY2UoL1suKis/XiR7fSgpfFtcXF1cXFxcXS9nLCBcIlxcXFwkJlwiKTtcbiAgfVxufTtcbnZhciBNYXRjaFBhdHRlcm4gPSBfTWF0Y2hQYXR0ZXJuO1xuTWF0Y2hQYXR0ZXJuLlBST1RPQ09MUyA9IFtcImh0dHBcIiwgXCJodHRwc1wiLCBcImZpbGVcIiwgXCJmdHBcIiwgXCJ1cm5cIl07XG52YXIgSW52YWxpZE1hdGNoUGF0dGVybiA9IGNsYXNzIGV4dGVuZHMgRXJyb3Ige1xuICBjb25zdHJ1Y3RvcihtYXRjaFBhdHRlcm4sIHJlYXNvbikge1xuICAgIHN1cGVyKGBJbnZhbGlkIG1hdGNoIHBhdHRlcm4gXCIke21hdGNoUGF0dGVybn1cIjogJHtyZWFzb259YCk7XG4gIH1cbn07XG5mdW5jdGlvbiB2YWxpZGF0ZVByb3RvY29sKG1hdGNoUGF0dGVybiwgcHJvdG9jb2wpIHtcbiAgaWYgKCFNYXRjaFBhdHRlcm4uUFJPVE9DT0xTLmluY2x1ZGVzKHByb3RvY29sKSAmJiBwcm90b2NvbCAhPT0gXCIqXCIpXG4gICAgdGhyb3cgbmV3IEludmFsaWRNYXRjaFBhdHRlcm4oXG4gICAgICBtYXRjaFBhdHRlcm4sXG4gICAgICBgJHtwcm90b2NvbH0gbm90IGEgdmFsaWQgcHJvdG9jb2wgKCR7TWF0Y2hQYXR0ZXJuLlBST1RPQ09MUy5qb2luKFwiLCBcIil9KWBcbiAgICApO1xufVxuZnVuY3Rpb24gdmFsaWRhdGVIb3N0bmFtZShtYXRjaFBhdHRlcm4sIGhvc3RuYW1lKSB7XG4gIGlmIChob3N0bmFtZS5pbmNsdWRlcyhcIjpcIikpXG4gICAgdGhyb3cgbmV3IEludmFsaWRNYXRjaFBhdHRlcm4obWF0Y2hQYXR0ZXJuLCBgSG9zdG5hbWUgY2Fubm90IGluY2x1ZGUgYSBwb3J0YCk7XG4gIGlmIChob3N0bmFtZS5pbmNsdWRlcyhcIipcIikgJiYgaG9zdG5hbWUubGVuZ3RoID4gMSAmJiAhaG9zdG5hbWUuc3RhcnRzV2l0aChcIiouXCIpKVxuICAgIHRocm93IG5ldyBJbnZhbGlkTWF0Y2hQYXR0ZXJuKFxuICAgICAgbWF0Y2hQYXR0ZXJuLFxuICAgICAgYElmIHVzaW5nIGEgd2lsZGNhcmQgKCopLCBpdCBtdXN0IGdvIGF0IHRoZSBzdGFydCBvZiB0aGUgaG9zdG5hbWVgXG4gICAgKTtcbn1cbmZ1bmN0aW9uIHZhbGlkYXRlUGF0aG5hbWUobWF0Y2hQYXR0ZXJuLCBwYXRobmFtZSkge1xuICByZXR1cm47XG59XG5leHBvcnQge1xuICBJbnZhbGlkTWF0Y2hQYXR0ZXJuLFxuICBNYXRjaFBhdHRlcm5cbn07XG4iXSwibmFtZXMiOlsicmVzdWx0IiwiYnJvd3NlciJdLCJtYXBwaW5ncyI6Ijs7QUFDQSxXQUFTLGlCQUFpQixLQUFLO0FBQzlCLFFBQUksT0FBTyxRQUFRLE9BQU8sUUFBUSxXQUFZLFFBQU8sRUFBRSxNQUFNLElBQUc7QUFDaEUsV0FBTztBQUFBLEVBQ1I7QUNFTyxXQUFTLG9CQUNkLFNBQ0EsT0FDQSxTQUNNO0FBU04sWUFBUSxLQUFLLGVBQWUsT0FBTyxJQUFJLEtBQUs7QUFBQSxFQUM5QztBQ3BCTyxRQUFNLGtCQUFrQjtBQUN4QixRQUFNLGtCQUFrQjtBQUN4QixRQUFNLGlCQUFpQjtBQUN2QixRQUFNLDBCQUEwQjtBQUVoQyxRQUFNLDJCQUEyQjtBQUNqQyxRQUFNLGdDQUFnQztBQUd0QyxRQUFNLHdCQUF3QjtBQUM5QixRQUFNLGlDQUFpQztBQUN2QyxRQUFNLCtCQUErQjtBQUNyQyxRQUFNLDBCQUEwQjtBQUNoQyxRQUFNLHFCQUFxQjtBQUMzQixRQUFNLHNCQUFzQjtBQUM1QixRQUFNLDhCQUE4QjtBQ2RwQyxXQUFTLHVCQUF1QixPQUFPO0FBQzFDLFFBQUksQ0FBQyxTQUFTLEtBQUs7QUFDZixhQUFPO0FBQ1gsVUFBTSxZQUFZLGlCQUFpQixNQUFNLFNBQVM7QUFDbEQsVUFBTSxlQUFlLGlCQUFpQixNQUFNLFlBQVk7QUFDeEQsVUFBTSxjQUFjLE1BQU07QUFDMUIsVUFBTSxZQUFZLGlCQUFpQixNQUFNLFNBQVM7QUFDbEQsVUFBTSxxQkFBcUIsTUFBTSx1QkFBdUIsT0FDbEQsT0FDQSxpQkFBaUIsTUFBTSxrQkFBa0I7QUFDL0MsUUFBSSxDQUFDLGFBQWEsaUJBQWlCLFVBQWEsY0FBYyxRQUFXO0FBQ3JFLGFBQU87QUFBQSxJQUNYO0FBQ0EsUUFBSSxnQkFBZ0IsV0FBVyxnQkFBZ0IsY0FBYztBQUN6RCxhQUFPO0FBQUEsSUFDWDtBQUNBLFVBQU0sU0FBUyxNQUFNLFFBQVEsTUFBTSxNQUFNLElBQ25DLE1BQU0sT0FBTyxJQUFJLHNCQUFzQixFQUFFLE9BQU8sU0FBUyxJQUN6RCxDQUFBO0FBQ04sV0FBTztBQUFBLE1BQ0g7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBLG9CQUFvQixzQkFBc0I7QUFBQSxNQUMxQztBQUFBLElBQ1I7QUFBQSxFQUNBO0FBQ08sV0FBUyx1QkFBdUIsT0FBTztBQUMxQyxRQUFJLENBQUMsU0FBUyxLQUFLO0FBQ2YsYUFBTztBQUNYLFVBQU0sT0FBTyxNQUFNO0FBQ25CLFFBQUksU0FBUyxZQUFZLFNBQVMsYUFBYSxTQUFTLFdBQVc7QUFDL0QsYUFBTztBQUFBLElBQ1g7QUFDQSxVQUFNLFlBQVksaUJBQWlCLE1BQU0sU0FBUztBQUNsRCxRQUFJLGNBQWM7QUFDZCxhQUFPO0FBQ1gsUUFBSSxTQUFTLFVBQVU7QUFDbkIsWUFBTSxhQUFhLGlCQUFpQixNQUFNLFVBQVU7QUFDcEQsVUFBSSxDQUFDO0FBQ0QsZUFBTztBQUNYLGFBQU87QUFBQSxRQUNIO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBLFFBQVEsaUJBQWlCLE1BQU0sUUFBUSxlQUFlO0FBQUEsUUFDdEQsVUFBVSxlQUFlLE1BQU0sUUFBUTtBQUFBLE1BQ25EO0FBQUEsSUFDSTtBQUNBLFFBQUksU0FBUyxXQUFXO0FBQ3BCLFlBQU0sUUFBUSxNQUFNO0FBQ3BCLFVBQUksVUFBVSxTQUNWLFVBQVUsVUFDVixVQUFVLFVBQ1YsVUFBVSxXQUNWLFVBQVUsU0FBUztBQUNuQixlQUFPO0FBQUEsTUFDWDtBQUNBLFlBQU0sVUFBVSxpQkFBaUIsTUFBTSxTQUFTLGVBQWU7QUFDL0QsVUFBSSxDQUFDO0FBQ0QsZUFBTztBQUNYLGFBQU87QUFBQSxRQUNIO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxVQUFVLGVBQWUsTUFBTSxRQUFRO0FBQUEsTUFDbkQ7QUFBQSxJQUNJO0FBQ0EsVUFBTSxTQUFTLGlCQUFpQixNQUFNLFFBQVEsRUFBRTtBQUNoRCxVQUFNLE1BQU0saUJBQWlCLE1BQU0sS0FBSyxjQUFjO0FBQ3RELFFBQUksRUFBRSxVQUFVO0FBQ1osYUFBTztBQUNYLFdBQU87QUFBQSxNQUNIO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQSxRQUFRLGlCQUFpQixNQUFNLE1BQU07QUFBQSxNQUNyQyxVQUFVLGlCQUFpQixNQUFNLFFBQVE7QUFBQSxNQUN6QyxnQkFBZ0IsZ0JBQWdCLE1BQU0sY0FBYztBQUFBLE1BQ3BELGlCQUFpQixnQkFBZ0IsTUFBTSxlQUFlO0FBQUEsTUFDdEQsYUFBYSxpQkFBaUIsTUFBTSxhQUFhLHVCQUF1QjtBQUFBLE1BQ3hFLGNBQWMsaUJBQWlCLE1BQU0sY0FBYyx1QkFBdUI7QUFBQSxJQUNsRjtBQUFBLEVBQ0E7QUFDQSxXQUFTLGdCQUFnQixPQUFPO0FBQzVCLFFBQUksQ0FBQyxTQUFTLEtBQUs7QUFDZixhQUFPO0FBQ1gsVUFBTUEsVUFBUyxDQUFBO0FBQ2YsZUFBVyxDQUFDLEtBQUssV0FBVyxLQUFLLE9BQU8sUUFBUSxLQUFLLEdBQUc7QUFDcEQsVUFBSSxPQUFPLGdCQUFnQjtBQUN2QjtBQUNKLFlBQU0sZ0JBQWdCLElBQUksS0FBSSxFQUFHLFlBQVc7QUFDNUMsVUFBSSxDQUFDLGlCQUFpQixpQkFBaUIsYUFBYSxHQUFHO0FBQ25EO0FBQUEsTUFDSjtBQUNBLE1BQUFBLFFBQU8sY0FBYyxNQUFNLEdBQUcsR0FBRyxDQUFDLElBQUksWUFBWSxNQUFNLEdBQUcsR0FBRztBQUFBLElBQ2xFO0FBQ0EsV0FBTyxPQUFPLEtBQUtBLE9BQU0sRUFBRSxTQUFTLElBQUlBLFVBQVM7QUFBQSxFQUNyRDtBQUNBLFdBQVMsaUJBQWlCLFlBQVk7QUFDbEMsV0FBTyxXQUFXLFNBQVMsVUFBVTtBQUFBLEVBQ3pDO0FBQ0EsV0FBUyxlQUFlLE9BQU87QUFDM0IsUUFBSSxDQUFDLFNBQVMsS0FBSztBQUNmLGFBQU87QUFDWCxVQUFNQSxVQUFTLENBQUE7QUFDZixlQUFXLENBQUMsS0FBSyxVQUFVLEtBQUssT0FBTyxRQUFRLEtBQUssR0FBRztBQUNuRCxZQUFNLGFBQWEsa0JBQWtCLFVBQVU7QUFDL0MsVUFBSSxlQUFlO0FBQ2Y7QUFDSixNQUFBQSxRQUFPLElBQUksTUFBTSxHQUFHLEdBQUcsQ0FBQyxJQUFJO0FBQUEsSUFDaEM7QUFDQSxXQUFPLE9BQU8sS0FBS0EsT0FBTSxFQUFFLFNBQVMsSUFBSUEsVUFBUztBQUFBLEVBQ3JEO0FBQ0EsV0FBUyxrQkFBa0IsT0FBTyxRQUFRLEdBQUc7QUFDekMsUUFBSSxRQUFRO0FBQ1IsYUFBTztBQUNYLFFBQUksVUFBVSxRQUNWLE9BQU8sVUFBVSxhQUNqQixPQUFPLFVBQVUsVUFBVTtBQUMzQixhQUFPO0FBQUEsSUFDWDtBQUNBLFFBQUksT0FBTyxVQUFVLFVBQVU7QUFDM0IsYUFBTyxNQUFNLE1BQU0sR0FBRyxlQUFlO0FBQUEsSUFDekM7QUFDQSxRQUFJLE1BQU0sUUFBUSxLQUFLLEdBQUc7QUFDdEIsYUFBTyxNQUNGLE1BQU0sR0FBRyxFQUFFLEVBQ1gsSUFBSSxDQUFDLFVBQVUsa0JBQWtCLE9BQU8sUUFBUSxDQUFDLENBQUMsRUFDbEQsT0FBTyxTQUFTO0FBQUEsSUFDekI7QUFDQSxRQUFJLFNBQVMsS0FBSyxHQUFHO0FBQ2pCLFlBQU1BLFVBQVMsQ0FBQTtBQUNmLGlCQUFXLENBQUMsS0FBSyxVQUFVLEtBQUssT0FBTyxRQUFRLEtBQUssRUFBRSxNQUFNLEdBQUcsRUFBRSxHQUFHO0FBQ2hFLGNBQU0sYUFBYSxrQkFBa0IsWUFBWSxRQUFRLENBQUM7QUFDMUQsWUFBSSxlQUFlO0FBQ2Y7QUFDSixRQUFBQSxRQUFPLElBQUksTUFBTSxHQUFHLEdBQUcsQ0FBQyxJQUFJO0FBQUEsTUFDaEM7QUFDQSxhQUFPQTtBQUFBLElBQ1g7QUFDQSxXQUFPO0FBQUEsRUFDWDtBQUNBLFdBQVMsaUJBQWlCLE9BQU8sWUFBWSxpQkFBaUI7QUFDMUQsUUFBSSxPQUFPLFVBQVU7QUFDakIsYUFBTztBQUNYLFVBQU0sVUFBVSxNQUFNLEtBQUk7QUFDMUIsUUFBSSxDQUFDO0FBQ0QsYUFBTztBQUNYLFdBQU8sUUFBUSxNQUFNLEdBQUcsU0FBUztBQUFBLEVBQ3JDO0FBQ0EsV0FBUyxpQkFBaUIsT0FBTztBQUM3QixRQUFJLE9BQU8sVUFBVSxZQUFZLENBQUMsT0FBTyxTQUFTLEtBQUssR0FBRztBQUN0RCxhQUFPO0FBQUEsSUFDWDtBQUNBLFdBQU8sS0FBSyxNQUFNLEtBQUs7QUFBQSxFQUMzQjtBQUNBLFdBQVMsU0FBUyxPQUFPO0FBQ3JCLFdBQU8sT0FBTyxVQUFVLFlBQVksVUFBVSxRQUFRLENBQUMsTUFBTSxRQUFRLEtBQUs7QUFBQSxFQUM5RTtBQUNBLFdBQVMsVUFBVSxPQUFPO0FBQ3RCLFdBQU8sVUFBVSxRQUFRLFVBQVU7QUFBQSxFQUN2QztBQUNPLFdBQVMsYUFBYSxPQUFPO0FBQ2hDLFdBQU8sU0FBUyxLQUFLO0FBQUEsRUFDekI7QUNoRk8sV0FBUyx5QkFDZCxPQUNpQztBQUNqQyxRQUFJLENBQUMsYUFBYSxLQUFLLEVBQUcsUUFBTztBQUVqQyxVQUFNLGNBQWMsTUFBTTtBQUMxQixRQUFJLE9BQU8sZ0JBQWdCLFNBQVUsUUFBTztBQUU1QyxXQUNFLGdCQUFnQix5QkFDaEIsZ0JBQWdCLGtDQUNoQixnQkFBZ0IsZ0NBQ2hCLGdCQUFnQiwyQkFDaEIsZ0JBQWdCLHNCQUNoQixnQkFBZ0IsdUJBQ2hCLGdCQUFnQjtBQUFBLEVBRXBCO0FDekdBLFFBQU0seUJBQXlCO0FBQy9CLFFBQU0sMEJBQTBCO0FBQ2hDLFFBQU0sMEJBQTBCO0FBQ3pCLFdBQVMsK0JBQStCLFFBQVEsT0FBTztBQUMxRCxXQUFPLEtBQUssS0FBSztBQUNqQixtQkFBZSxRQUFRLE1BQU0sSUFBSTtBQUNqQyxXQUFPLE9BQU8sU0FBUyxpQkFBaUI7QUFDcEMsWUFBTSxZQUFZLCtCQUErQixRQUFRO0FBQUEsUUFDckQ7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ1osQ0FBUztBQUNELGFBQU8sT0FBTyxXQUFXLENBQUM7QUFBQSxJQUM5QjtBQUFBLEVBQ0o7QUFDTyxXQUFTLDRCQUE0QixRQUFRLE9BQU87QUFDdkQsUUFBSSw4QkFBOEIsUUFBUSxLQUFLLEdBQUc7QUFDOUM7QUFBQSxJQUNKO0FBQ0EsbUNBQStCLFFBQVEsS0FBSztBQUFBLEVBQ2hEO0FBQ08sV0FBUywyQkFBMkIsUUFBUSxPQUFPO0FBQ3RELFFBQUksaUNBQWlDLFFBQVEsS0FBSyxHQUFHO0FBQ2pEO0FBQUEsSUFDSjtBQUNBLG1DQUErQixRQUFRLEtBQUs7QUFBQSxFQUNoRDtBQUNBLFdBQVMsOEJBQThCLFFBQVEsV0FBVztBQUN0RCxVQUFNLHNCQUFzQjtBQUM1QixhQUFTLFFBQVEsT0FBTyxTQUFTLEdBQUcsU0FBUyxHQUFHLFNBQVMsR0FBRztBQUN4RCxZQUFNLFFBQVEsT0FBTyxLQUFLO0FBQzFCLFVBQUksQ0FBQyxTQUFTLE1BQU0sU0FBUyxXQUFXO0FBQ3BDO0FBQUEsTUFDSjtBQUNBLFlBQU0sWUFBWSxNQUFNLFdBQVcsVUFBVSxVQUN6QyxNQUFNLFFBQVEsVUFBVSxRQUN2QixNQUFNLFVBQVUsUUFBUSxVQUFVLFVBQVU7QUFDakQsVUFBSSxDQUFDLFdBQVc7QUFDWjtBQUFBLE1BQ0o7QUFDQSxZQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0sWUFBWSxVQUFVLFNBQVM7QUFDNUQsVUFBSSxRQUFRLHFCQUFxQjtBQUM3QixlQUFPO0FBQUEsTUFDWDtBQUNBLGFBQU87QUFBQSxJQUNYO0FBQ0EsV0FBTztBQUFBLEVBQ1g7QUFDQSxXQUFTLGlDQUFpQyxRQUFRLFdBQVc7QUFDekQsUUFBSSxVQUFVLGVBQWUsY0FBYztBQUN2QyxhQUFPO0FBQUEsSUFDWDtBQUNBLFVBQU0sc0JBQXNCO0FBQzVCLFVBQU0sZUFBZSxpQkFBaUIsU0FBUztBQUMvQyxRQUFJLENBQUMsY0FBYztBQUNmLGFBQU87QUFBQSxJQUNYO0FBQ0EsYUFBUyxRQUFRLE9BQU8sU0FBUyxHQUFHLFNBQVMsR0FBRyxTQUFTLEdBQUc7QUFDeEQsWUFBTSxRQUFRLE9BQU8sS0FBSztBQUMxQixVQUFJLENBQUMsU0FDRCxNQUFNLFNBQVMsWUFDZixNQUFNLGVBQWUsY0FBYztBQUNuQztBQUFBLE1BQ0o7QUFDQSxZQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0sWUFBWSxVQUFVLFNBQVM7QUFDNUQsVUFBSSxRQUFRLHFCQUFxQjtBQUM3QixlQUFPO0FBQUEsTUFDWDtBQUNBLFlBQU0sY0FBYyxpQkFBaUIsS0FBSztBQUMxQyxVQUFJLGdCQUFnQixjQUFjO0FBQzlCLGVBQU87QUFBQSxNQUNYO0FBQUEsSUFDSjtBQUNBLFdBQU87QUFBQSxFQUNYO0FBQ0EsV0FBUyxpQkFBaUIsT0FBTztBQUM3QixVQUFNLFdBQVcsTUFBTTtBQUN2QixRQUFJLEVBQUUsWUFBWSxPQUFPLGFBQWEsV0FBVztBQUM3QyxhQUFPO0FBQUEsSUFDWDtBQUNBLFVBQU0sTUFBTSxTQUFTO0FBQ3JCLFdBQU8sT0FBTyxRQUFRLFlBQVksSUFBSSxTQUFTLElBQUksTUFBTTtBQUFBLEVBQzdEO0FBQ0EsV0FBUyxlQUFlLFFBQVEsTUFBTTtBQUNsQyxVQUFNLGFBQWEsY0FBYyxJQUFJO0FBQ3JDLFFBQUksUUFBUTtBQUNaLGVBQVcsU0FBUyxRQUFRO0FBQ3hCLFVBQUksTUFBTSxTQUFTLE1BQU07QUFDckIsaUJBQVM7QUFBQSxNQUNiO0FBQUEsSUFDSjtBQUNBLFVBQU0sZ0JBQWdCLFFBQVE7QUFDOUIsUUFBSSxpQkFBaUIsR0FBRztBQUNwQjtBQUFBLElBQ0o7QUFDQSxRQUFJLFVBQVU7QUFDZCxhQUFTLFFBQVEsR0FBRyxRQUFRLE9BQU8sVUFBVSxVQUFVLGVBQWUsU0FBUyxHQUFHO0FBQzlFLFVBQUksT0FBTyxLQUFLLEdBQUcsU0FBUyxNQUFNO0FBQzlCO0FBQUEsTUFDSjtBQUNBLGFBQU8sT0FBTyxPQUFPLENBQUM7QUFDdEIsZUFBUztBQUNULGlCQUFXO0FBQUEsSUFDZjtBQUFBLEVBQ0o7QUFDQSxXQUFTLGNBQWMsTUFBTTtBQUN6QixRQUFJLFNBQVMsVUFBVTtBQUNuQixhQUFPO0FBQUEsSUFDWDtBQUNBLFFBQUksU0FBUyxXQUFXO0FBQ3BCLGFBQU87QUFBQSxJQUNYO0FBQ0EsV0FBTztBQUFBLEVBQ1g7QUFDQSxXQUFTLCtCQUErQixRQUFRLFVBQVU7QUFDdEQsZUFBVyxRQUFRLFVBQVU7QUFDekIsWUFBTSxRQUFRLE9BQU8sVUFBVSxDQUFDLFVBQVUsTUFBTSxTQUFTLElBQUk7QUFDN0QsVUFBSSxTQUFTLEdBQUc7QUFDWixlQUFPO0FBQUEsTUFDWDtBQUFBLElBQ0o7QUFDQSxXQUFPO0FBQUEsRUFDWDtBQ3pIQSxRQUFNLCtCQUErQjtBQUNyQyxRQUFNLDZCQUE2QjtBQUU1QixXQUFTLGtCQUEwQjtBQUN4QyxRQUNFLE9BQU8sV0FBVyxlQUNsQixPQUFPLE9BQU8sZUFBZSxZQUM3QjtBQUNBLGFBQU8sT0FBTyxXQUFBO0FBQUEsSUFDaEI7QUFFQSxVQUFNLFNBQVMsS0FBSyxTQUFTLFNBQVMsRUFBRSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQ3JELFdBQU8sT0FBTyxLQUFLLElBQUEsQ0FBSyxJQUFJLE1BQU07QUFBQSxFQUNwQztBQUVBLGlCQUFzQiw0QkFDcEIsT0FDZTtBQUNmLFFBQUksQ0FBQyxPQUFPLFdBQVcsZUFBZTtBQUNwQztBQUFBLElBQ0Y7QUFFQSxRQUFJO0FBQ0YsWUFBTSxPQUFPLFVBQVUsY0FBYztBQUFBLFFBQ25DLFFBQVE7QUFBQSxVQUNOO0FBQUEsUUFBQTtBQUFBLFFBRUYsT0FBTyxDQUFDLDRCQUE0QjtBQUFBLE1BQUEsQ0FDckM7QUFFRCxZQUFNLE9BQU8sVUFBVSxjQUFjO0FBQUEsUUFDbkMsUUFBUTtBQUFBLFVBQ047QUFBQSxRQUFBO0FBQUEsUUFFRixPQUFPO0FBQUEsUUFDUCxPQUFPLENBQUMsMEJBQTBCO0FBQUEsTUFBQSxDQUNuQztBQUFBLElBQ0gsU0FBUyxPQUFPO0FBQ2Q7QUFBQSxRQUNFLDZEQUE2RCxLQUFLO0FBQUEsUUFDbEU7QUFBQSxNQUFBO0FBQUEsSUFFSjtBQUFBLEVBQ0Y7QUFFTyxXQUFTLG9CQUFvQixLQUFzQjtBQUN4RCxXQUFPLElBQUksV0FBVyxTQUFTLEtBQUssSUFBSSxXQUFXLFVBQVU7QUFBQSxFQUMvRDtBQ0VPLFdBQVMsNkJBQW1EO0FBQ2pFLFVBQU0sbUNBQW1CLElBQUE7QUFDekIsVUFBTSxtQ0FBbUIsSUFBQTtBQUN6QixVQUFNLHdDQUF3QixJQUFBO0FBRTlCLFFBQUksV0FBVztBQUNmLFFBQUksY0FBb0M7QUFDeEMsUUFBSSxlQUFxRDtBQUV6RCxVQUFNLGtCQUFrQixNQUFNO0FBQzVCLFVBQUksY0FBYztBQUNoQjtBQUFBLE1BQ0Y7QUFFQSxxQkFBZSxXQUFXLE1BQU07QUFDOUIsdUJBQWU7QUFDZixxQkFBQSxFQUFlLE1BQU0sQ0FBQyxVQUFtQjtBQUN2Qyw4QkFBb0Isb0NBQW9DLEtBQUs7QUFBQSxRQUMvRCxDQUFDO0FBQUEsTUFDSCxHQUFHLEdBQUc7QUFBQSxJQUNSO0FBRUEsVUFBTSxlQUFlLFlBQVk7QUFDL0IsWUFBTSxtQkFBbUIsTUFBTSxLQUFLLGFBQWEsUUFBUTtBQUV6RCxZQUFNLE9BQU8sUUFBUSxNQUFNLElBQUk7QUFBQSxRQUM3QixDQUFDLDZCQUE2QixHQUFHO0FBQUEsTUFBQSxDQUNsQztBQUFBLElBQ0g7QUFFQSxVQUFNLHFCQUFxQixZQUFZO0FBQ3JDLFlBQU1BLFVBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJO0FBQUEsUUFDNUM7QUFBQSxNQUFBLENBQ0Q7QUFDRCxZQUFNLGlCQUFpQkEsUUFBTyw2QkFBNkI7QUFFM0QsVUFBSSxDQUFDLE1BQU0sUUFBUSxjQUFjLEdBQUc7QUFDbEM7QUFBQSxNQUNGO0FBRUEsaUJBQVcsYUFBYSxnQkFBZ0I7QUFDdEMsY0FBTSxVQUFVLHVCQUF1QixTQUFTO0FBQ2hELFlBQUksQ0FBQyxTQUFTO0FBQ1o7QUFBQSxRQUNGO0FBRUEscUJBQWEsSUFBSSxRQUFRLFdBQVcsT0FBTztBQUMzQyxxQkFBYSxJQUFJLFFBQVEsY0FBYyxRQUFRLFNBQVM7QUFBQSxNQUMxRDtBQUFBLElBQ0Y7QUFFQSxVQUFNLGVBQWUsWUFBWTtBQUMvQixVQUFJLFVBQVU7QUFDWjtBQUFBLE1BQ0Y7QUFFQSxVQUFJLGFBQWE7QUFDZixjQUFNO0FBQ047QUFBQSxNQUNGO0FBRUEsb0JBQWMsbUJBQUEsRUFDWCxNQUFNLENBQUMsVUFBbUI7QUFDekIsNEJBQW9CLDhDQUE4QyxLQUFLO0FBQUEsTUFDekUsQ0FBQyxFQUNBLFFBQVEsTUFBTTtBQUNiLG1CQUFXO0FBQ1gsc0JBQWM7QUFBQSxNQUNoQixDQUFDO0FBRUgsWUFBTTtBQUFBLElBQ1I7QUFFQSxVQUFNLGdCQUFnQixDQUFDLGNBQXNCO0FBQzNDLFlBQU0sVUFBVSxhQUFhLElBQUksU0FBUztBQUMxQyxVQUFJLENBQUMsU0FBUztBQUNaO0FBQUEsTUFDRjtBQUVBLG1CQUFhLE9BQU8sU0FBUztBQUU3QixZQUFNLGtCQUFrQixhQUFhLElBQUksUUFBUSxZQUFZO0FBQzdELFVBQUksb0JBQW9CLFdBQVc7QUFDakMscUJBQWEsT0FBTyxRQUFRLFlBQVk7QUFBQSxNQUMxQztBQUFBLElBQ0Y7QUFFQSxVQUFNLHdCQUF3QixDQUM1QixPQUNBLFdBQ1M7QUFDVCxVQUFJLE9BQU8sV0FBVyxHQUFHO0FBQ3ZCO0FBQUEsTUFDRjtBQUVBLFlBQU0sWUFBWSxhQUFhLElBQUksS0FBSztBQUN4QyxZQUFNLFVBQVUsWUFBWSxhQUFhLElBQUksU0FBUyxJQUFJO0FBQzFELFVBQUksQ0FBQyxTQUFTO0FBQ1o7QUFBQSxNQUNGO0FBRUEsaUJBQVcsU0FBUyxRQUFRO0FBQzFCLFlBQUksTUFBTSxTQUFTLFdBQVc7QUFDNUIsc0NBQTRCLFFBQVEsUUFBUSxLQUFLO0FBQUEsUUFDbkQsV0FBVyxNQUFNLFNBQVMsVUFBVTtBQUNsQyxxQ0FBMkIsUUFBUSxRQUFRLEtBQUs7QUFBQSxRQUNsRCxPQUFPO0FBQ0wseUNBQStCLFFBQVEsUUFBUSxLQUFLO0FBQUEsUUFDdEQ7QUFBQSxNQUNGO0FBRUEsc0JBQUE7QUFBQSxJQUNGO0FBRUEsVUFBTSw2QkFBNkIsQ0FDakMsT0FDQSxXQUNTO0FBQ1QsVUFBSSxPQUFPLFdBQVcsR0FBRztBQUN2QjtBQUFBLE1BQ0Y7QUFFQSxZQUFNLE1BQU0sS0FBSyxJQUFBO0FBQ2pCLFlBQU0sMEJBQTBCO0FBQ2hDLFlBQU0seUJBQXlCO0FBQy9CLFlBQU0sV0FBVyxrQkFBa0IsSUFBSSxLQUFLLEtBQUssQ0FBQTtBQUVqRCxZQUFNLFNBQVMsQ0FBQyxHQUFHLFVBQVUsR0FBRyxNQUFNLEVBQUUsT0FBTyxDQUFDLFVBQVU7QUFDeEQsZUFBTyxNQUFNLE1BQU0sYUFBYTtBQUFBLE1BQ2xDLENBQUM7QUFFRCxVQUFJLE9BQU8sU0FBUyx3QkFBd0I7QUFDMUMsMEJBQWtCO0FBQUEsVUFDaEI7QUFBQSxVQUNBLE9BQU8sTUFBTSxPQUFPLFNBQVMsc0JBQXNCO0FBQUEsUUFBQTtBQUVyRDtBQUFBLE1BQ0Y7QUFFQSx3QkFBa0IsSUFBSSxPQUFPLE1BQU07QUFBQSxJQUNyQztBQUVBLFVBQU0sNkJBQTZCLENBQ2pDLE9BQ0EsZUFDb0I7QUFDcEIsWUFBTSxNQUFNLEtBQUssSUFBQTtBQUNqQixZQUFNLGVBQWUsa0JBQWtCLElBQUksS0FBSyxLQUFLLENBQUE7QUFDckQsVUFBSSxhQUFhLFdBQVcsR0FBRztBQUM3QixlQUFPLENBQUE7QUFBQSxNQUNUO0FBRUEsYUFBTyxhQUFhLE9BQU8sQ0FBQyxVQUFVO0FBQ3BDLGVBQU8sTUFBTSxNQUFNLGFBQWE7QUFBQSxNQUNsQyxDQUFDO0FBQUEsSUFDSDtBQUVBLFVBQU0sZUFBZSxPQUFPLFlBQWlDO0FBQzNELFlBQU0sYUFBQTtBQUVOLFlBQU0sWUFBWSxLQUFLLElBQUE7QUFDdkIsWUFBTSxZQUFZLGdCQUFBO0FBQ2xCLFlBQU0sMEJBQ0osT0FBTyxRQUFRLDRCQUE0QixZQUMzQyxPQUFPLFNBQVMsUUFBUSx1QkFBdUIsS0FDL0MsUUFBUSwwQkFBMEIsSUFDOUIsS0FBSyxNQUFNLFFBQVEsdUJBQXVCLElBQzFDO0FBQ04sWUFBTSxzQkFDSiwwQkFBMEIsSUFDdEI7QUFBQSxRQUNFLFFBQVE7QUFBQSxRQUNSO0FBQUEsTUFBQSxJQUVGLENBQUE7QUFFTixZQUFNLFVBQWlDO0FBQUEsUUFDckM7QUFBQSxRQUNBLGNBQWMsUUFBUTtBQUFBLFFBQ3RCLGFBQWEsUUFBUTtBQUFBLFFBQ3JCO0FBQUEsUUFDQSxvQkFDRSxRQUFRLGdCQUFnQixlQUFlLFlBQVk7QUFBQSxRQUNyRCxRQUFRO0FBQUEsTUFBQTtBQUdWLG1CQUFhLElBQUksV0FBVyxPQUFPO0FBQ25DLG1CQUFhLElBQUksUUFBUSxjQUFjLFNBQVM7QUFDaEQsc0JBQUE7QUFDQSxZQUFNLDRCQUE0QixRQUFRLFlBQVk7QUFFdEQsYUFBTztBQUFBLFFBQ0w7QUFBQSxRQUNBO0FBQUEsTUFBQTtBQUFBLElBRUo7QUFFQSxVQUFNLDZCQUE2QixPQUFPLFVBQWlDO0FBQ3pFLFlBQU0sYUFBQTtBQUVOLFVBQUksQ0FBQyxhQUFhLElBQUksS0FBSyxHQUFHO0FBQzVCO0FBQUEsTUFDRjtBQUVBLFlBQU0sNEJBQTRCLEtBQUs7QUFBQSxJQUN6QztBQUVBLFVBQU0sbUJBQW1CLE9BQU8sT0FBZSxjQUF5QjtBQUN0RSxZQUFNLGFBQUE7QUFFTixVQUFJLENBQUMsTUFBTSxRQUFRLFNBQVMsS0FBSyxVQUFVLFdBQVcsR0FBRztBQUN2RDtBQUFBLE1BQ0Y7QUFFQSxZQUFNLG1CQUFvQyxDQUFBO0FBQzFDLGlCQUFXLFlBQVksV0FBVztBQUNoQyxjQUFNLGtCQUFrQix1QkFBdUIsUUFBUTtBQUN2RCxZQUFJLENBQUMsaUJBQWlCO0FBQ3BCO0FBQUEsUUFDRjtBQUVBLHlCQUFpQixLQUFLLGVBQWU7QUFBQSxNQUN2QztBQUVBLGlDQUEyQixPQUFPLGdCQUFnQjtBQUNsRCw0QkFBc0IsT0FBTyxnQkFBZ0I7QUFBQSxJQUMvQztBQUVBLFVBQU0scUJBQXFCLE9BQ3pCLGNBQzRDO0FBQzVDLFlBQU0sYUFBQTtBQUVOLFlBQU0sVUFBVSxhQUFhLElBQUksU0FBUztBQUMxQyxVQUFJLENBQUMsU0FBUztBQUNaLGVBQU87QUFBQSxNQUNUO0FBRUEsYUFBTztBQUFBLFFBQ0wsV0FBVyxRQUFRO0FBQUEsUUFDbkIsY0FBYyxRQUFRO0FBQUEsUUFDdEIsYUFBYSxRQUFRO0FBQUEsUUFDckIsV0FBVyxRQUFRO0FBQUEsUUFDbkIsb0JBQW9CLFFBQVE7QUFBQSxRQUM1QixRQUFRLFFBQVE7QUFBQSxNQUFBO0FBQUEsSUFFcEI7QUFFQSxVQUFNLDhCQUE4QixPQUNsQyxZQUNHO0FBQ0gsWUFBTSxhQUFBO0FBRU4sWUFBTSxVQUFVLGFBQWEsSUFBSSxRQUFRLFNBQVM7QUFDbEQsVUFBSSxDQUFDLFNBQVM7QUFDWjtBQUFBLE1BQ0Y7QUFFQSxjQUFRLHFCQUFxQixLQUFLLE1BQU0sUUFBUSxrQkFBa0I7QUFDbEUsc0JBQUE7QUFBQSxJQUNGO0FBRUEsVUFBTSxpQkFBaUIsT0FBTyxjQUFzQjtBQUNsRCxZQUFNLGFBQUE7QUFFTixZQUFNLFVBQVUsYUFBYSxJQUFJLFNBQVM7QUFDMUMsb0JBQWMsU0FBUztBQUN2QixVQUFJLFNBQVM7QUFDWCwwQkFBa0IsT0FBTyxRQUFRLFlBQVk7QUFBQSxNQUMvQztBQUNBLHNCQUFBO0FBQUEsSUFDRjtBQUVBLFVBQU0sNkJBQTZCLE9BQ2pDLE9BQ0EsUUFDa0I7QUFDbEIsWUFBTSxhQUFBO0FBRU4sVUFBSSxFQUFFLE9BQU8sb0JBQW9CLEdBQUcsSUFBSTtBQUN0QztBQUFBLE1BQ0Y7QUFFQSxVQUFJLENBQUMsYUFBYSxJQUFJLEtBQUssR0FBRztBQUM1QjtBQUFBLE1BQ0Y7QUFFQSxZQUFNLDRCQUE0QixLQUFLO0FBQUEsSUFDekM7QUFFQSxVQUFNLHdCQUF3QixPQUFPLFVBQWlDO0FBQ3BFLFlBQU0sYUFBQTtBQUVOLFlBQU0sWUFBWSxhQUFhLElBQUksS0FBSztBQUN4QyxVQUFJLENBQUMsV0FBVztBQUNkO0FBQUEsTUFDRjtBQUVBLG9CQUFjLFNBQVM7QUFDdkIsd0JBQWtCLE9BQU8sS0FBSztBQUM5QixzQkFBQTtBQUFBLElBQ0Y7QUFFQSxXQUFPO0FBQUEsTUFDTDtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUFBO0FBQUEsRUFFSjtBQzdWTyxXQUFTLHNDQUE0QztBQUMxRCxVQUFNLFFBQVE7QUFJZCxRQUFJLE1BQU0sd0JBQXdCLEdBQUc7QUFDbkM7QUFBQSxJQUNGO0FBRUEsVUFBTSx3QkFBd0IsSUFBSTtBQUVsQyxVQUFNLFFBQVEsMkJBQUE7QUFFZCxXQUFPLFFBQVEsVUFBVSxZQUFZLENBQUMsU0FBUyxRQUFRLGlCQUFpQjtBQUN0RSxVQUFJLENBQUMseUJBQXlCLE9BQU8sR0FBRztBQUN0QztBQUFBLE1BQ0Y7QUFFQSxZQUFNLG1CQUFtQixDQUN2QixhQUNHO0FBQ0gscUJBQWEsUUFBUTtBQUFBLE1BQ3ZCO0FBRUEsWUFBTSxVQUFVLENBQUMsVUFBbUI7QUFDbEMseUJBQWlCO0FBQUEsVUFDZixJQUFJO0FBQUEsVUFDSixPQUNFLGlCQUFpQixRQUFRLE1BQU0sVUFBVTtBQUFBLFFBQUEsQ0FDNUM7QUFBQSxNQUNIO0FBRUEsWUFBTSxVQUFVLFlBQVk7QUFDMUIsY0FBTSxRQUFRLE9BQU8sS0FBSztBQUMxQixjQUFNLDJCQUEyQixPQUFPLFdBQXNCO0FBQzVELGNBQUksT0FBTyxVQUFVLFVBQVU7QUFDN0I7QUFBQSxVQUNGO0FBRUEsZ0JBQU0sTUFBTSxpQkFBaUIsT0FBTyxNQUFNO0FBQUEsUUFDNUM7QUFFQSxnQkFBUSxRQUFRLE1BQUE7QUFBQSxVQUNkLEtBQUssdUJBQXVCO0FBQzFCLGtCQUFNLE9BQU8sTUFBTSxNQUFNLGFBQWEsUUFBUSxPQUFPO0FBQ3JELDZCQUFpQixFQUFFLElBQUksTUFBTSxLQUFBLENBQU07QUFDbkM7QUFBQSxVQUNGO0FBQUEsVUFDQSxLQUFLLGdDQUFnQztBQUNuQyxrQkFBTSxNQUFNLDRCQUE0QixRQUFRLE9BQU87QUFDdkQsNkJBQWlCLEVBQUUsSUFBSSxNQUFNLE1BQU0sUUFBVztBQUM5QztBQUFBLFVBQ0Y7QUFBQSxVQUNBLEtBQUssb0JBQW9CO0FBQ3ZCLGtCQUFNLHlCQUF5QixDQUFDLFFBQVEsUUFBUSxLQUFLLENBQUM7QUFDdEQsNkJBQWlCLEVBQUUsSUFBSSxNQUFNLE1BQU0sUUFBVztBQUM5QztBQUFBLFVBQ0Y7QUFBQSxVQUNBLEtBQUsscUJBQXFCO0FBQ3hCLGtCQUFNLHlCQUF5QixRQUFRLFFBQVEsTUFBTTtBQUNyRCw2QkFBaUIsRUFBRSxJQUFJLE1BQU0sTUFBTSxRQUFXO0FBQzlDO0FBQUEsVUFDRjtBQUFBLFVBQ0EsS0FBSyw2QkFBNkI7QUFDaEMsZ0JBQUksT0FBTyxVQUFVLFVBQVU7QUFDN0Isb0JBQU0sTUFBTSwyQkFBMkIsS0FBSztBQUFBLFlBQzlDO0FBQ0EsNkJBQWlCLEVBQUUsSUFBSSxNQUFNLE1BQU0sUUFBVztBQUM5QztBQUFBLFVBQ0Y7QUFBQSxVQUNBLEtBQUssOEJBQThCO0FBQ2pDLGtCQUFNLE9BQU8sTUFBTSxNQUFNLG1CQUFtQixRQUFRLFFBQVEsU0FBUztBQUNyRSw2QkFBaUIsRUFBRSxJQUFJLE1BQU0sS0FBQSxDQUFNO0FBQ25DO0FBQUEsVUFDRjtBQUFBLFVBQ0EsS0FBSyx5QkFBeUI7QUFDNUIsa0JBQU0sTUFBTSxlQUFlLFFBQVEsUUFBUSxTQUFTO0FBQ3BELDZCQUFpQixFQUFFLElBQUksTUFBTSxNQUFNLFFBQVc7QUFDOUM7QUFBQSxVQUNGO0FBQUEsVUFDQSxTQUFTO0FBQ1AsNkJBQWlCLEVBQUUsSUFBSSxNQUFNLE1BQU0sUUFBVztBQUM5QztBQUFBLFVBQ0Y7QUFBQSxRQUFBO0FBQUEsTUFFSjtBQUVBLGNBQUEsRUFBVSxNQUFNLE9BQU87QUFDdkIsYUFBTztBQUFBLElBQ1QsQ0FBQztBQUVELFdBQU8sS0FBSyxVQUFVLFlBQVksQ0FBQyxPQUFPLFlBQVksUUFBUTtBQUM1RCxZQUFNLGlCQUNKLFdBQVcsV0FBVyxhQUFhLE9BQU8sV0FBVyxRQUFRO0FBRS9ELFVBQUksQ0FBQyxnQkFBZ0I7QUFDbkI7QUFBQSxNQUNGO0FBRUEsWUFBTSxNQUNKLE9BQU8sV0FBVyxRQUFRLFdBQ3RCLFdBQVcsTUFDVixJQUFJLE9BQU87QUFFbEIsWUFBTSwyQkFBMkIsT0FBTyxHQUFHLEVBQUUsTUFBTSxDQUFDLFVBQW1CO0FBQ3JFO0FBQUEsVUFDRSx3RUFBd0UsS0FBSztBQUFBLFVBQzdFO0FBQUEsUUFBQTtBQUFBLE1BRUosQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUVELFdBQU8sS0FBSyxVQUFVLFlBQVksQ0FBQyxVQUFVO0FBQzNDLFlBQU0sc0JBQXNCLEtBQUssRUFBRSxNQUFNLENBQUMsVUFBbUI7QUFDM0Q7QUFBQSxVQUNFLHNEQUFzRCxLQUFLO0FBQUEsVUFDM0Q7QUFBQSxRQUFBO0FBQUEsTUFFSixDQUFDO0FBQUEsSUFDSCxDQUFDO0FBQUEsRUFDSDtBQ25JTyxRQUFNLG9DQUFvQztBQUMxQyxRQUFNLDhCQUE4QjtBQUNwQyxRQUFNLDBDQUNYO0FBQ0ssUUFBTSxtQ0FBbUM7QUFDekMsUUFBTSx5Q0FBeUM7QUFDL0MsUUFBTSw4Q0FDWDtBQ0RLLFFBQU0sMEJBQTBCO0FBQ2hDLFFBQU0sMkJBQTJCO0FBQ2pDLFFBQU0seUJBQXlCO0FBRXRDLGlCQUFzQixpQ0FBZ0Q7QUFDcEUsVUFBTSw0QkFBNEIsc0NBQXNDO0FBQUEsRUFDMUU7QUFFQSxpQkFBc0Isa0NBQWlEO0FBQ3JFLFVBQU0sNEJBQTRCLDJDQUEyQztBQUFBLEVBQy9FO0FBRUEsaUJBQWUsNEJBQTRCLFlBQW1DO0FBQzVFLFVBQU0sUUFBUSxNQUFNLG1CQUFBO0FBQ3BCLFFBQUksTUFBTSx1QkFBdUI7QUFDL0IsWUFBTSxnQkFBZ0IsTUFBTSxxQkFBQTtBQUM1QixVQUFJLGtCQUFrQixNQUFNO0FBQzFCLGNBQU0saUJBQUE7QUFDTjtBQUFBLE1BQ0Y7QUFFQSxZQUFNLHlCQUFBO0FBQUEsSUFDUjtBQUVBLFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSTtBQUFBLE1BQzdCLENBQUMsVUFBVSxHQUFHLEtBQUssSUFBQTtBQUFBLElBQUksQ0FDeEI7QUFDRCxVQUFNLE9BQU8sT0FBTyxVQUFBO0FBQUEsRUFDdEI7QUFFQSxpQkFBc0IsZ0NBQStDO0FBQ25FLFFBQUk7QUFDRixZQUFNLE9BQU8sUUFBUSxZQUFZLEVBQUUsTUFBTSw2QkFBNkI7QUFBQSxJQUN4RSxTQUFTLE9BQWdCO0FBQ3ZCO0FBQUEsUUFDRTtBQUFBLFFBQ0E7QUFBQSxNQUFBO0FBQUEsSUFFSjtBQUVBLFVBQU0saUJBQUE7QUFBQSxFQUNSO0FBRUEsaUJBQXNCLDRCQUNwQixTQUNlO0FBQ2YsUUFBSSxZQUFZLHlCQUF5QjtBQUN2QyxZQUFNLCtCQUFBO0FBQ047QUFBQSxJQUNGO0FBRUEsUUFBSSxZQUFZLDBCQUEwQjtBQUN4QyxZQUFNLGdDQUFBO0FBQ047QUFBQSxJQUNGO0FBRUEsUUFBSSxZQUFZLHdCQUF3QjtBQUN0QyxZQUFNLDhCQUFBO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFFQSxpQkFBZSxxQkFFWjtBQUNELFVBQU1BLFVBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJO0FBQUEsTUFDNUM7QUFBQSxJQUFBLENBQ0Q7QUFDRCxXQUFPO0FBQUEsTUFDTCx1QkFBdUIsUUFBUUEsUUFBTyxpQ0FBaUMsQ0FBQztBQUFBLElBQUE7QUFBQSxFQUU1RTtBQUVBLGlCQUFlLG1CQUFrQztBQUMvQyxVQUFNLGdCQUFnQixNQUFNLHFCQUFBO0FBQzVCLFFBQUksa0JBQWtCLE1BQU07QUFDMUI7QUFBQSxJQUNGO0FBRUEsVUFBTSxjQUFjLE1BQU0sT0FBTyxLQUFLLElBQUksYUFBYTtBQUN2RCxRQUFJLE9BQU8sWUFBWSxhQUFhLFVBQVU7QUFDNUMsWUFBTSxPQUFPLFFBQVEsT0FBTyxZQUFZLFVBQVUsRUFBRSxTQUFTLE1BQU07QUFBQSxJQUNyRTtBQUNBLFVBQU0sT0FBTyxLQUFLLE9BQU8sZUFBZSxFQUFFLFFBQVEsTUFBTTtBQUFBLEVBQzFEO0FBRUEsaUJBQWUsdUJBQStDO0FBQzVELFVBQU0sU0FBUyxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksQ0FBQywyQkFBMkIsQ0FBQztBQUMzRSxVQUFNLGNBQWMsT0FBTywyQkFBMkI7QUFDdEQsUUFBSSxPQUFPLGdCQUFnQixVQUFVO0FBQ25DLFVBQUk7QUFDRixjQUFNLE9BQU8sS0FBSyxJQUFJLFdBQVc7QUFDakMsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFnQjtBQUN2QjtBQUFBLFVBQ0UseUNBQXlDLFdBQVc7QUFBQSxVQUNwRDtBQUFBLFFBQUE7QUFBQSxNQUVKO0FBQUEsSUFDRjtBQUVBLFVBQU0sZUFBZSxNQUFNLE9BQU8sS0FBSyxNQUFNO0FBQUEsTUFDM0MsS0FBSyxDQUFDLE9BQU8sUUFBUSxPQUFPLGlCQUFpQixDQUFDO0FBQUEsSUFBQSxDQUMvQztBQUNELFVBQU0sd0JBQXdCLGFBQzNCLE9BQU8sQ0FBQyxRQUFRLE9BQU8sSUFBSSxPQUFPLFFBQVEsRUFDMUMsS0FBSyxDQUFDLEdBQUcsT0FBTyxFQUFFLE1BQU0sTUFBTSxFQUFFLE1BQU0sRUFBRSxFQUFFLENBQUM7QUFDOUMsV0FBTyx1QkFBdUIsTUFBTTtBQUFBLEVBQ3RDO0FBRUEsaUJBQWUsMkJBQTBDO0FBQ3ZELFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSTtBQUFBLE1BQzdCLENBQUMsaUNBQWlDLEdBQUc7QUFBQSxJQUFBLENBQ3RDO0FBQ0QsVUFBTSxPQUFPLFFBQVEsTUFBTSxPQUFPO0FBQUEsTUFDaEM7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQUEsQ0FDRDtBQUFBLEVBQ0g7QUM1SEEsUUFBQSxhQUFBLGlCQUFBLE1BQUE7QUFDRSx3Q0FBQTtBQUVBLFdBQUEsU0FBQSxVQUFBLFlBQUEsQ0FBQSxZQUFBO0FBQ0Usa0NBQUEsT0FBQSxFQUFBLE1BQUEsT0FBQSxVQUFBO0FBQ0UsNEJBQUEsNkNBQUEsS0FBQTtBQUNBLFlBQUE7QUFDRSxnQkFBQSxPQUFBLE9BQUEsVUFBQTtBQUFBLFFBQThCLFNBQUEsZ0JBQUE7QUFFOUI7QUFBQSxZQUFBO0FBQUEsWUFDRTtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFBO0FBQUEsSUFDRCxDQUFBO0FBQUEsRUFFTCxDQUFBOzs7QUNuQk8sUUFBTUMsWUFBVSxXQUFXLFNBQVMsU0FBUyxLQUNoRCxXQUFXLFVBQ1gsV0FBVztBQ1dmLFFBQU0sVUFBVTtBQ2JoQixNQUFJLGdCQUFnQixNQUFNO0FBQUEsSUFDeEIsWUFBWSxjQUFjO0FBQ3hCLFVBQUksaUJBQWlCLGNBQWM7QUFDakMsYUFBSyxZQUFZO0FBQ2pCLGFBQUssa0JBQWtCLENBQUMsR0FBRyxjQUFjLFNBQVM7QUFDbEQsYUFBSyxnQkFBZ0I7QUFDckIsYUFBSyxnQkFBZ0I7QUFBQSxNQUN2QixPQUFPO0FBQ0wsY0FBTSxTQUFTLHVCQUF1QixLQUFLLFlBQVk7QUFDdkQsWUFBSSxVQUFVO0FBQ1osZ0JBQU0sSUFBSSxvQkFBb0IsY0FBYyxrQkFBa0I7QUFDaEUsY0FBTSxDQUFDLEdBQUcsVUFBVSxVQUFVLFFBQVEsSUFBSTtBQUMxQyx5QkFBaUIsY0FBYyxRQUFRO0FBQ3ZDLHlCQUFpQixjQUFjLFFBQVE7QUFFdkMsYUFBSyxrQkFBa0IsYUFBYSxNQUFNLENBQUMsUUFBUSxPQUFPLElBQUksQ0FBQyxRQUFRO0FBQ3ZFLGFBQUssZ0JBQWdCO0FBQ3JCLGFBQUssZ0JBQWdCO0FBQUEsTUFDdkI7QUFBQSxJQUNGO0FBQUEsSUFDQSxTQUFTLEtBQUs7QUFDWixVQUFJLEtBQUs7QUFDUCxlQUFPO0FBQ1QsWUFBTSxJQUFJLE9BQU8sUUFBUSxXQUFXLElBQUksSUFBSSxHQUFHLElBQUksZUFBZSxXQUFXLElBQUksSUFBSSxJQUFJLElBQUksSUFBSTtBQUNqRyxhQUFPLENBQUMsQ0FBQyxLQUFLLGdCQUFnQixLQUFLLENBQUMsYUFBYTtBQUMvQyxZQUFJLGFBQWE7QUFDZixpQkFBTyxLQUFLLFlBQVksQ0FBQztBQUMzQixZQUFJLGFBQWE7QUFDZixpQkFBTyxLQUFLLGFBQWEsQ0FBQztBQUM1QixZQUFJLGFBQWE7QUFDZixpQkFBTyxLQUFLLFlBQVksQ0FBQztBQUMzQixZQUFJLGFBQWE7QUFDZixpQkFBTyxLQUFLLFdBQVcsQ0FBQztBQUMxQixZQUFJLGFBQWE7QUFDZixpQkFBTyxLQUFLLFdBQVcsQ0FBQztBQUFBLE1BQzVCLENBQUM7QUFBQSxJQUNIO0FBQUEsSUFDQSxZQUFZLEtBQUs7QUFDZixhQUFPLElBQUksYUFBYSxXQUFXLEtBQUssZ0JBQWdCLEdBQUc7QUFBQSxJQUM3RDtBQUFBLElBQ0EsYUFBYSxLQUFLO0FBQ2hCLGFBQU8sSUFBSSxhQUFhLFlBQVksS0FBSyxnQkFBZ0IsR0FBRztBQUFBLElBQzlEO0FBQUEsSUFDQSxnQkFBZ0IsS0FBSztBQUNuQixVQUFJLENBQUMsS0FBSyxpQkFBaUIsQ0FBQyxLQUFLO0FBQy9CLGVBQU87QUFDVCxZQUFNLHNCQUFzQjtBQUFBLFFBQzFCLEtBQUssc0JBQXNCLEtBQUssYUFBYTtBQUFBLFFBQzdDLEtBQUssc0JBQXNCLEtBQUssY0FBYyxRQUFRLFNBQVMsRUFBRSxDQUFDO0FBQUEsTUFDeEU7QUFDSSxZQUFNLHFCQUFxQixLQUFLLHNCQUFzQixLQUFLLGFBQWE7QUFDeEUsYUFBTyxDQUFDLENBQUMsb0JBQW9CLEtBQUssQ0FBQyxVQUFVLE1BQU0sS0FBSyxJQUFJLFFBQVEsQ0FBQyxLQUFLLG1CQUFtQixLQUFLLElBQUksUUFBUTtBQUFBLElBQ2hIO0FBQUEsSUFDQSxZQUFZLEtBQUs7QUFDZixZQUFNLE1BQU0scUVBQXFFO0FBQUEsSUFDbkY7QUFBQSxJQUNBLFdBQVcsS0FBSztBQUNkLFlBQU0sTUFBTSxvRUFBb0U7QUFBQSxJQUNsRjtBQUFBLElBQ0EsV0FBVyxLQUFLO0FBQ2QsWUFBTSxNQUFNLG9FQUFvRTtBQUFBLElBQ2xGO0FBQUEsSUFDQSxzQkFBc0IsU0FBUztBQUM3QixZQUFNLFVBQVUsS0FBSyxlQUFlLE9BQU87QUFDM0MsWUFBTSxnQkFBZ0IsUUFBUSxRQUFRLFNBQVMsSUFBSTtBQUNuRCxhQUFPLE9BQU8sSUFBSSxhQUFhLEdBQUc7QUFBQSxJQUNwQztBQUFBLElBQ0EsZUFBZSxRQUFRO0FBQ3JCLGFBQU8sT0FBTyxRQUFRLHVCQUF1QixNQUFNO0FBQUEsSUFDckQ7QUFBQSxFQUNGO0FBQ0EsTUFBSSxlQUFlO0FBQ25CLGVBQWEsWUFBWSxDQUFDLFFBQVEsU0FBUyxRQUFRLE9BQU8sS0FBSztBQUMvRCxNQUFJLHNCQUFzQixjQUFjLE1BQU07QUFBQSxJQUM1QyxZQUFZLGNBQWMsUUFBUTtBQUNoQyxZQUFNLDBCQUEwQixZQUFZLE1BQU0sTUFBTSxFQUFFO0FBQUEsSUFDNUQ7QUFBQSxFQUNGO0FBQ0EsV0FBUyxpQkFBaUIsY0FBYyxVQUFVO0FBQ2hELFFBQUksQ0FBQyxhQUFhLFVBQVUsU0FBUyxRQUFRLEtBQUssYUFBYTtBQUM3RCxZQUFNLElBQUk7QUFBQSxRQUNSO0FBQUEsUUFDQSxHQUFHLFFBQVEsMEJBQTBCLGFBQWEsVUFBVSxLQUFLLElBQUksQ0FBQztBQUFBLE1BQzVFO0FBQUEsRUFDQTtBQUNBLFdBQVMsaUJBQWlCLGNBQWMsVUFBVTtBQUNoRCxRQUFJLFNBQVMsU0FBUyxHQUFHO0FBQ3ZCLFlBQU0sSUFBSSxvQkFBb0IsY0FBYyxnQ0FBZ0M7QUFDOUUsUUFBSSxTQUFTLFNBQVMsR0FBRyxLQUFLLFNBQVMsU0FBUyxLQUFLLENBQUMsU0FBUyxXQUFXLElBQUk7QUFDNUUsWUFBTSxJQUFJO0FBQUEsUUFDUjtBQUFBLFFBQ0E7QUFBQSxNQUNOO0FBQUEsRUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7IiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMTIsMTMsMTRdfQ==
