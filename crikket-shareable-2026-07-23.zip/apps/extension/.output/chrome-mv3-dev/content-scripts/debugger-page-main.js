var debuggerPageMain = (function() {
  "use strict";
  const PAGE_SOURCE = "CRIKKET_DEBUGGER_PAGE_BRIDGE";
  const INSTALL_FLAG = "__crikketDebuggerPageScriptInstalled";
  const MAX_TEXT_LENGTH = 2e3;
  const MAX_BODY_LENGTH = 4e3;
  const MAX_HEADER_NAME_LENGTH = 120;
  const MAX_HEADER_VALUE_LENGTH = 500;
  const MAX_BATCH_SIZE = 40;
  const FLUSH_INTERVAL_MS = 120;
  const MAX_SERIALIZE_DEPTH = 4;
  const MAX_SERIALIZE_KEYS = 30;
  const MAX_SERIALIZE_ARRAY_ITEMS = 30;
  const REDACTED_VALUE = "[REDACTED]";
  const SENSITIVE_NAME_PATTERNS = [
    "authorization",
    "cookie",
    "set-cookie",
    "token",
    "secret",
    "password",
    "passwd",
    "pwd",
    "session",
    "api-key",
    "apikey",
    "x-api-key",
    "refresh-token",
    "refresh_token",
    "access-token",
    "access_token",
    "id-token",
    "id_token",
    "client-secret",
    "client_secret"
  ];
  const REDACTABLE_FIELD_PATTERN = /((?:access[_-]?token|refresh[_-]?token|id[_-]?token|api[_-]?key|client[_-]?secret|password|passwd|pwd|authorization|cookie|session[_-]?id)\s*[:=]\s*)([^&\s",;]+)/gi;
  const truncate = (value, maxLength = MAX_TEXT_LENGTH) => {
    if (value.length <= maxLength) {
      return value;
    }
    return `${value.slice(0, maxLength)}...`;
  };
  const isSensitiveName = (value) => {
    const normalizedValue = value.trim().toLowerCase();
    if (!normalizedValue) {
      return false;
    }
    return SENSITIVE_NAME_PATTERNS.some((pattern) => {
      return normalizedValue.includes(pattern);
    });
  };
  const shouldHideHeader = (headerName) => {
    return headerName.includes("debugger") || isSensitiveName(headerName);
  };
  const getElementTarget = (target) => {
    if (!(target instanceof Element)) {
      return void 0;
    }
    if (target.id) {
      return `#${target.id}`;
    }
    const classNames = typeof target.className === "string" ? target.className : "";
    const firstClass = classNames.split(" ").map((entry) => entry.trim()).find((entry) => entry.length > 0);
    if (firstClass) {
      return `${target.tagName.toLowerCase()}.${firstClass}`;
    }
    return target.tagName.toLowerCase();
  };
  const toAbsoluteUrl = (value, reporter) => {
    try {
      return new URL(value, location.href).toString();
    } catch (error) {
      reporter.reportNonFatalError("Failed to normalize network URL in debugger instrumentation", {
        error,
        value
      });
      return null;
    }
  };
  const redactSensitiveQueryParams = (absoluteUrl) => {
    try {
      const parsedUrl = new URL(absoluteUrl);
      for (const [key] of parsedUrl.searchParams.entries()) {
        if (!isSensitiveName(key)) {
          continue;
        }
        parsedUrl.searchParams.set(key, REDACTED_VALUE);
      }
      return parsedUrl.toString();
    } catch {
      return absoluteUrl;
    }
  };
  const sanitizeStructuredValue = (value, depth = 0) => {
    if (depth >= 6) {
      return "[MaxDepth]";
    }
    if (Array.isArray(value)) {
      return value.map((item) => sanitizeStructuredValue(item, depth + 1));
    }
    if (value && typeof value === "object") {
      const result2 = {};
      for (const [key, nestedValue] of Object.entries(value)) {
        if (isSensitiveName(key)) {
          result2[key] = REDACTED_VALUE;
          continue;
        }
        result2[key] = sanitizeStructuredValue(nestedValue, depth + 1);
      }
      return result2;
    }
    if (typeof value === "string") {
      return value.replace(REDACTABLE_FIELD_PATTERN, `$1${REDACTED_VALUE}`);
    }
    return value;
  };
  const sanitizeUrlEncodedBody = (body) => {
    const params = new URLSearchParams(body);
    for (const [key] of params.entries()) {
      if (!isSensitiveName(key)) {
        continue;
      }
      params.set(key, REDACTED_VALUE);
    }
    return params.toString();
  };
  const sanitizeCapturedBody = (body, contentType) => {
    if (typeof body !== "string" || body.length === 0) {
      return body;
    }
    const normalizedContentType = contentType.toLowerCase();
    if (normalizedContentType.includes("application/json")) {
      try {
        const parsed = JSON.parse(body);
        return truncate(JSON.stringify(sanitizeStructuredValue(parsed)), MAX_TEXT_LENGTH * 2);
      } catch {
        return truncate(body.replace(REDACTABLE_FIELD_PATTERN, `$1${REDACTED_VALUE}`), MAX_TEXT_LENGTH * 2);
      }
    }
    if (normalizedContentType.includes("x-www-form-urlencoded")) {
      return truncate(sanitizeUrlEncodedBody(body), MAX_TEXT_LENGTH * 2);
    }
    return truncate(body.replace(REDACTABLE_FIELD_PATTERN, `$1${REDACTED_VALUE}`), MAX_TEXT_LENGTH * 2);
  };
  function createNonFatalReporter() {
    const originalConsoleWarn = console.warn.bind(console);
    const reportedContexts = /* @__PURE__ */ new Set();
    return {
      reportNonFatalError(context, error) {
        if (reportedContexts.has(context)) {
          return;
        }
        reportedContexts.add(context);
        originalConsoleWarn(`[Non-fatal] ${context}`, error);
      }
    };
  }
  function installActionAndNavigationCapture(input) {
    const { postAction } = input;
    const postNavigationBreadcrumb = (mode) => {
      postAction("navigation", "window", {
        mode,
        url: location.href,
        path: location.pathname,
        search: location.search,
        hash: location.hash,
        title: document.title
      });
    };
    const delegatedHandlers = {
      click: (event) => {
        postAction("click", getElementTarget(event.target));
      },
      input: (event) => {
        const target = getElementTarget(event.target);
        let valueLength;
        const inputTarget = event.target;
        if (inputTarget instanceof HTMLInputElement || inputTarget instanceof HTMLTextAreaElement) {
          valueLength = inputTarget.value.length;
        }
        postAction("input", target, {
          valueLength
        });
      },
      change: (event) => {
        postAction("change", getElementTarget(event.target));
      }
    };
    const delegatedListener = (event) => {
      if (event.type !== "click" && event.type !== "input" && event.type !== "change") {
        return;
      }
      delegatedHandlers[event.type](event);
    };
    for (const eventType of ["click", "input", "change"]) {
      document.addEventListener(eventType, delegatedListener, {
        capture: true,
        passive: true
      });
    }
    const originalPushState = history.pushState;
    history.pushState = function(...args) {
      originalPushState.apply(this, args);
      postNavigationBreadcrumb("pushState");
    };
    const originalReplaceState = history.replaceState;
    history.replaceState = function(...args) {
      originalReplaceState.apply(this, args);
      postNavigationBreadcrumb("replaceState");
    };
    window.addEventListener("popstate", () => {
      postNavigationBreadcrumb("popstate");
    }, {
      capture: true,
      passive: true
    });
    window.addEventListener("hashchange", () => {
      postNavigationBreadcrumb("hashchange");
    }, {
      capture: true,
      passive: true
    });
    postNavigationBreadcrumb("initial");
  }
  function installConsoleCapture(input) {
    const { reporter, postConsole } = input;
    const consoleLevels = [
      "log",
      "info",
      "warn",
      "error",
      "debug"
    ];
    for (const level of consoleLevels) {
      const original = console[level].bind(console);
      console[level] = (...args) => {
        try {
          postConsole(level, args);
        } catch (error) {
          reporter.reportNonFatalError("Failed to post console event in debugger instrumentation", error);
        }
        original(...args);
      };
    }
  }
  const DIAGNOSTICS_KEY = "__crikketDebuggerDiagnostics";
  const DIAGNOSTICS_VERSION = 1;
  const MAX_ERROR_ENTRIES = 25;
  const MAX_ERROR_LENGTH = 300;
  const createDefaultDiagnosticsState = () => {
    return {
      version: DIAGNOSTICS_VERSION,
      installedAt: Date.now(),
      url: location.href,
      hooks: {
        fetch: "pending",
        xhr: false
      },
      counters: {
        actionEvents: 0,
        consoleEvents: 0,
        networkEvents: 0,
        fetchCalls: 0,
        fetchFailures: 0,
        xhrCalls: 0,
        queuedEvents: 0,
        flushedBatches: 0
      },
      last: {},
      errors: []
    };
  };
  const toErrorMessage = (context, error) => {
    if (error instanceof Error) {
      return `${context}: ${error.message}`;
    }
    return `${context}: ${String(error)}`;
  };
  function createPageDiagnostics(scope) {
    const runtimeScope = scope;
    const state = runtimeScope[DIAGNOSTICS_KEY] ?? createDefaultDiagnosticsState();
    runtimeScope[DIAGNOSTICS_KEY] = state;
    state.installedAt = Date.now();
    state.url = location.href;
    state.hooks.fetch = "pending";
    state.hooks.xhr = false;
    return {
      state,
      createReporter(reporter) {
        const originalReport = reporter.reportNonFatalError.bind(reporter);
        return {
          reportNonFatalError(context, error) {
            state.errors.push(truncate(toErrorMessage(context, error), MAX_ERROR_LENGTH));
            if (state.errors.length > MAX_ERROR_ENTRIES) {
              state.errors.shift();
            }
            originalReport(context, error);
          }
        };
      },
      recordActionEvent() {
        state.counters.actionEvents += 1;
      },
      recordConsoleEvent() {
        state.counters.consoleEvents += 1;
      },
      recordNetworkEvent(url) {
        state.counters.networkEvents += 1;
        state.last.networkUrl = url;
      },
      recordFetchCall() {
        state.counters.fetchCalls += 1;
      },
      recordFetchFailure(message) {
        state.counters.fetchFailures += 1;
        state.last.fetchError = message;
      },
      setFetchHookState(nextState) {
        state.hooks.fetch = nextState;
      },
      recordXhrCall() {
        state.counters.xhrCalls += 1;
      },
      setXhrHookInstalled() {
        state.hooks.xhr = true;
      },
      recordQueuedEvent() {
        state.counters.queuedEvents += 1;
      },
      recordFlushedBatch() {
        state.counters.flushedBatches += 1;
      }
    };
  }
  function createEventQueue(input = {}) {
    const { recordFlushedBatch, recordQueuedEvent } = input;
    const eventQueue = [];
    let flushTimer = null;
    const flushEventQueue = () => {
      flushTimer = null;
      if (eventQueue.length === 0) {
        return;
      }
      const batchedEvents = eventQueue.splice(0, MAX_BATCH_SIZE);
      recordFlushedBatch?.();
      window.postMessage({
        source: PAGE_SOURCE,
        events: batchedEvents
      }, "*");
      if (eventQueue.length > 0) {
        flushTimer = setTimeout(flushEventQueue, 0);
        return;
      }
    };
    const scheduleEventFlush = () => {
      if (flushTimer) {
        return;
      }
      flushTimer = setTimeout(flushEventQueue, FLUSH_INTERVAL_MS);
    };
    const enqueueEvent = (event) => {
      eventQueue.push(event);
      recordQueuedEvent?.();
      if (eventQueue.length >= MAX_BATCH_SIZE) {
        if (flushTimer) {
          clearTimeout(flushTimer);
        }
        flushTimer = setTimeout(flushEventQueue, 0);
        return;
      }
      scheduleEventFlush();
    };
    return {
      enqueueEvent,
      flushEventQueue
    };
  }
  const serializePrimitive = (value) => {
    if (value === null || typeof value === "boolean" || typeof value === "number") {
      return {
        handled: true,
        value
      };
    }
    if (typeof value === "string") {
      return {
        handled: true,
        value: truncate(value)
      };
    }
    if (typeof value === "undefined") {
      return {
        handled: true,
        value: "[undefined]"
      };
    }
    if (typeof value === "bigint") {
      return {
        handled: true,
        value: `${value.toString()}n`
      };
    }
    if (typeof value === "symbol") {
      return {
        handled: true,
        value: value.toString()
      };
    }
    if (typeof value === "function") {
      return {
        handled: true,
        value: `[Function ${value.name || "anonymous"}]`
      };
    }
    return {
      handled: false
    };
  };
  const serializeError = (value) => {
    return {
      name: value.name,
      message: truncate(value.message),
      stack: typeof value.stack === "string" ? truncate(value.stack) : void 0
    };
  };
  const isArrayBufferValue = (value) => {
    return typeof ArrayBuffer !== "undefined" && value instanceof ArrayBuffer;
  };
  const isArrayBufferViewValue = (value) => {
    return typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView(value);
  };
  const serializeArray = (value, state, depth, path, serializeValue) => {
    const serialized = [];
    const limit = Math.min(value.length, MAX_SERIALIZE_ARRAY_ITEMS);
    for (let index = 0; index < limit; index += 1) {
      serialized.push(serializeValue(value[index], state, depth + 1, `${path}[${index}]`));
    }
    if (value.length > limit) {
      serialized.push(`[+${value.length - limit} more]`);
    }
    return serialized;
  };
  const serializeMap = (value, state, depth, path, serializeValue) => {
    const entries = [];
    let index = 0;
    for (const [entryKey, entryValue] of value.entries()) {
      if (index >= MAX_SERIALIZE_KEYS) {
        entries.push(`[+${value.size - index} more]`);
        break;
      }
      entries.push([
        serializeValue(entryKey, state, depth + 1, `${path}.mapKey${index}`),
        serializeValue(entryValue, state, depth + 1, `${path}.mapVal${index}`)
      ]);
      index += 1;
    }
    return {
      type: "Map",
      entries
    };
  };
  const serializeSet = (value, state, depth, path, serializeValue) => {
    const entries = [];
    let index = 0;
    for (const entry of value.values()) {
      if (index >= MAX_SERIALIZE_KEYS) {
        entries.push(`[+${value.size - index} more]`);
        break;
      }
      entries.push(serializeValue(entry, state, depth + 1, `${path}.setVal${index}`));
      index += 1;
    }
    return {
      type: "Set",
      values: entries
    };
  };
  const serializeRecordObject = (value, state, depth, path, serializeValue) => {
    const result2 = {};
    const entries = Object.entries(value);
    const limit = Math.min(entries.length, MAX_SERIALIZE_KEYS);
    for (let index = 0; index < limit; index += 1) {
      const [entryKey, entryValue] = entries[index] ?? [];
      if (typeof entryKey !== "string") {
        continue;
      }
      result2[entryKey] = serializeValue(entryValue, state, depth + 1, `${path}.${entryKey}`);
    }
    if (entries.length > limit) {
      result2.__truncatedKeys = entries.length - limit;
    }
    return result2;
  };
  const objectSerializers = [
    {
      canHandle: (value) => value instanceof Error,
      serialize: (value) => serializeError(value)
    },
    {
      canHandle: (value) => value instanceof Date,
      serialize: (value) => value.toISOString()
    },
    {
      canHandle: (value) => value instanceof RegExp,
      serialize: (value) => value.toString()
    },
    {
      canHandle: (value) => typeof URL !== "undefined" && value instanceof URL,
      serialize: (value) => value.toString()
    },
    {
      canHandle: (value) => typeof Element !== "undefined" && value instanceof Element,
      serialize: (value) => {
        const element = value;
        return getElementTarget(element) ?? element.tagName.toLowerCase();
      }
    },
    {
      canHandle: (value) => typeof Event !== "undefined" && value instanceof Event,
      serialize: (value) => {
        const event = value;
        return {
          type: event.type,
          target: getElementTarget(event.target)
        };
      }
    },
    {
      canHandle: (value) => Array.isArray(value),
      serialize: (value, state, depth, path, serializeValue) => serializeArray(value, state, depth, path, serializeValue)
    },
    {
      canHandle: (value) => value instanceof Map,
      serialize: (value, state, depth, path, serializeValue) => serializeMap(value, state, depth, path, serializeValue)
    },
    {
      canHandle: (value) => value instanceof Set,
      serialize: (value, state, depth, path, serializeValue) => serializeSet(value, state, depth, path, serializeValue)
    },
    {
      canHandle: (value) => isArrayBufferValue(value),
      serialize: (value) => `[ArrayBuffer ${value.byteLength}]`
    },
    {
      canHandle: (value) => isArrayBufferViewValue(value),
      serialize: (value) => {
        const bufferView = value;
        return `[${bufferView.constructor.name} ${bufferView.byteLength}]`;
      }
    }
  ];
  const serializeKnownObject = (value, state, depth, path, serializeValue) => {
    for (const serializer of objectSerializers) {
      if (!serializer.canHandle(value)) {
        continue;
      }
      return serializer.serialize(value, state, depth, path, serializeValue);
    }
    return serializeRecordObject(value, state, depth, path, serializeValue);
  };
  const toSerializableValue = (value, state, depth, path) => {
    const primitive = serializePrimitive(value);
    if (primitive.handled) {
      return primitive.value;
    }
    if (depth >= MAX_SERIALIZE_DEPTH) {
      return "[MaxDepth]";
    }
    if (typeof value !== "object" || value === null) {
      return Object.prototype.toString.call(value);
    }
    const existingPath = state.seen.get(value);
    if (existingPath) {
      return `[Circular ~${existingPath}]`;
    }
    state.seen.set(value, path);
    return serializeKnownObject(value, state, depth, path, toSerializableValue);
  };
  function createStringifyValue(reporter) {
    return (value) => {
      if (typeof value === "string") {
        return truncate(value);
      }
      if (typeof value === "number" || typeof value === "boolean" || value === null || typeof value === "undefined") {
        return String(value);
      }
      try {
        const serialized = toSerializableValue(value, {
          seen: /* @__PURE__ */ new WeakMap()
        }, 0, "$");
        if (typeof serialized === "string") {
          return truncate(serialized);
        }
        return truncate(JSON.stringify(serialized));
      } catch (error) {
        reporter.reportNonFatalError("Failed to stringify console value in debugger instrumentation", error);
        return truncate(Object.prototype.toString.call(value));
      }
    };
  }
  const getRequestBodyPreview = (body, stringifyValue) => {
    if (!body) {
      return void 0;
    }
    if (typeof body === "string") {
      return truncate(body, MAX_BODY_LENGTH);
    }
    if (body instanceof URLSearchParams) {
      return truncate(body.toString(), MAX_BODY_LENGTH);
    }
    if (typeof FormData !== "undefined" && body instanceof FormData) {
      const keys = [];
      for (const key of body.keys()) {
        keys.push(key);
      }
      return truncate(`[form-data] ${keys.join(",")}`, MAX_BODY_LENGTH);
    }
    if (typeof Blob !== "undefined" && body instanceof Blob) {
      return `[blob:${body.type || "unknown"}:${body.size}]`;
    }
    if (typeof ArrayBuffer !== "undefined") {
      if (body instanceof ArrayBuffer) {
        return `[arraybuffer:${body.byteLength}]`;
      }
      if (ArrayBuffer.isView(body)) {
        return `[${body.constructor.name.toLowerCase()}:${body.byteLength}]`;
      }
    }
    return truncate(stringifyValue(body), MAX_BODY_LENGTH);
  };
  const shouldCaptureTextContent = (contentType) => {
    const normalized = contentType.toLowerCase();
    return normalized.includes("json") || normalized.includes("text") || normalized.includes("xml") || normalized.includes("x-www-form-urlencoded");
  };
  const toHeaderRecord = (input) => {
    if (!input) {
      return {};
    }
    const result2 = {};
    for (const [key, value] of input.entries()) {
      const normalizedKey = key.trim().toLowerCase();
      if (!normalizedKey || shouldHideHeader(normalizedKey)) {
        continue;
      }
      result2[normalizedKey.slice(0, MAX_HEADER_NAME_LENGTH)] = value.slice(0, MAX_HEADER_VALUE_LENGTH);
    }
    return result2;
  };
  const parseRawHeaders = (rawHeaders) => {
    const result2 = {};
    const lines = rawHeaders.split("\n");
    for (const line of lines) {
      const normalizedLine = line.replace("\r", "");
      const separatorIndex = normalizedLine.indexOf(":");
      if (separatorIndex <= 0) {
        continue;
      }
      const key = normalizedLine.slice(0, separatorIndex).trim().toLowerCase();
      if (!key || shouldHideHeader(key)) {
        continue;
      }
      const value = normalizedLine.slice(separatorIndex + 1).trim();
      if (!value) {
        continue;
      }
      result2[key.slice(0, MAX_HEADER_NAME_LENGTH)] = value.slice(0, MAX_HEADER_VALUE_LENGTH);
    }
    return result2;
  };
  const scheduleBackgroundTask = (reporter, task) => {
    const executeTask = () => {
      Promise.resolve(task()).catch((error) => {
        reporter.reportNonFatalError("Background debugger instrumentation task failed", error);
      });
    };
    if (typeof window.requestIdleCallback === "function") {
      window.requestIdleCallback(() => {
        executeTask();
      });
      return;
    }
    window.setTimeout(executeTask, 0);
  };
  const getRequestBodyPreviewAsync = (reporter, body, stringifyValue, contentType = "") => {
    return new Promise((resolve) => {
      scheduleBackgroundTask(reporter, () => {
        resolve(sanitizeCapturedBody(getRequestBodyPreview(body, stringifyValue), contentType));
      });
    });
  };
  const getTextBodyPreviewAsync = (reporter, contentType, errorContext, readBody) => {
    return new Promise((resolve) => {
      scheduleBackgroundTask(reporter, async () => {
        if (!shouldCaptureTextContent(contentType)) {
          resolve(void 0);
          return;
        }
        try {
          resolve(sanitizeCapturedBody(truncate(await readBody(), MAX_BODY_LENGTH), contentType));
        } catch (error) {
          reporter.reportNonFatalError(errorContext, error);
          resolve(void 0);
        }
      });
    });
  };
  const resolveFetchMethod = (input, init) => {
    if (typeof init?.method === "string" && init.method) {
      return init.method.toUpperCase();
    }
    if (input instanceof Request) {
      return input.method.toUpperCase();
    }
    return "GET";
  };
  const resolveFetchUrl = (input) => {
    if (typeof input === "string") {
      return input;
    }
    if (input instanceof URL) {
      return input.toString();
    }
    return input.url;
  };
  const getFetchRequestBodyPreview = async (input, init, requestHeaders, stringifyValue, reporter) => {
    const initBodyPreview = getRequestBodyPreview(init?.body, stringifyValue);
    if (initBodyPreview) {
      return initBodyPreview;
    }
    if (!(input instanceof Request)) {
      return void 0;
    }
    const method = (init?.method ?? input.method ?? "GET").toUpperCase();
    if (method === "GET" || method === "HEAD" || input.bodyUsed) {
      return void 0;
    }
    const contentType = requestHeaders?.get("content-type") ?? input.headers.get("content-type") ?? "";
    if (!shouldCaptureTextContent(contentType)) {
      return void 0;
    }
    try {
      return sanitizeCapturedBody(truncate(await input.clone().text(), MAX_BODY_LENGTH), contentType);
    } catch (error) {
      reporter.reportNonFatalError("Failed to capture fetch request body in debugger instrumentation", error);
      return void 0;
    }
  };
  const resolveFetchRequestBodyPromise = (requestInput, requestInit, requestHeaderSource, stringifyValue, reporter, requestBodyByRequest) => {
    if (requestInput instanceof Request) {
      return requestBodyByRequest.get(requestInput) ?? getFetchRequestBodyPreview(requestInput, requestInit, requestHeaderSource, stringifyValue, reporter);
    }
    return getFetchRequestBodyPreview(requestInput, requestInit, requestHeaderSource, stringifyValue, reporter);
  };
  const resolveFetchContext = (args, reporter, stringifyValue, requestBodyByRequest) => {
    const [requestInput, requestInit] = args;
    const method = resolveFetchMethod(requestInput, requestInit);
    const url = resolveFetchUrl(requestInput);
    const absoluteUrl = toAbsoluteUrl(url, reporter);
    if (!absoluteUrl) {
      return null;
    }
    let requestHeaderSource = null;
    if (requestInit?.headers) {
      try {
        requestHeaderSource = new Headers(requestInit.headers);
      } catch (error) {
        reporter.reportNonFatalError("Failed to normalize fetch headers in debugger instrumentation", error);
      }
    } else if (requestInput instanceof Request) {
      requestHeaderSource = requestInput.headers;
    }
    const requestHeaders = requestHeaderSource ? toHeaderRecord(requestHeaderSource) : requestInput instanceof Request ? toHeaderRecord(requestInput.headers) : {};
    const requestContentType = requestHeaderSource?.get("content-type") ?? (requestInput instanceof Request ? requestInput.headers.get("content-type") ?? "" : "");
    const requestBodyPromise = resolveFetchRequestBodyPromise(requestInput, requestInit, requestHeaderSource, stringifyValue, reporter, requestBodyByRequest);
    return {
      method,
      normalizedUrl: redactSensitiveQueryParams(absoluteUrl),
      requestHeaders,
      requestContentType,
      requestBodyPromise
    };
  };
  const installRequestConstructorCapture = (reporter, stringifyValue, requestBodyByRequest) => {
    if (typeof window.Request !== "function") {
      return;
    }
    const OriginalRequest = window.Request;
    const patchedRequest = new Proxy(OriginalRequest, {
      construct(target, argArray, newTarget) {
        const [, requestInit] = argArray;
        const requestInstance = Reflect.construct(target, argArray, newTarget);
        let requestHeaderSource;
        if (requestInit?.headers !== void 0) {
          try {
            requestHeaderSource = new Headers(requestInit.headers);
          } catch (error) {
            reporter.reportNonFatalError("Failed to normalize Request headers in debugger instrumentation", error);
            requestHeaderSource = requestInstance.headers;
          }
        } else {
          requestHeaderSource = requestInstance.headers;
        }
        const contentType = requestHeaderSource.get("content-type") ?? "";
        const requestBodyPromise = requestInit?.body !== void 0 ? getRequestBodyPreviewAsync(reporter, requestInit.body, stringifyValue, contentType) : getTextBodyPreviewAsync(reporter, contentType, "Failed to capture Request body text in debugger instrumentation", () => {
          if (requestInstance.bodyUsed) {
            return Promise.resolve("");
          }
          return requestInstance.clone().text();
        });
        requestBodyByRequest.set(requestInstance, requestBodyPromise);
        return requestInstance;
      }
    });
    try {
      Object.assign(patchedRequest, OriginalRequest);
    } catch (error) {
      reporter.reportNonFatalError("Failed to mirror Request constructor properties in debugger instrumentation", error);
    }
    try {
      window.Request = patchedRequest;
    } catch (error) {
      reporter.reportNonFatalError("Failed to patch Request constructor in debugger instrumentation", error);
    }
  };
  const cloneFetchResponseForCapture = (response, reporter) => {
    const contentType = response.headers.get("content-type") ?? "";
    if (!shouldCaptureTextContent(contentType) || response.bodyUsed) {
      return {
        contentType,
        responseClone: null
      };
    }
    try {
      return {
        contentType,
        responseClone: response.clone()
      };
    } catch (error) {
      reporter.reportNonFatalError("Failed to clone fetch response body in debugger instrumentation", error);
      return {
        contentType,
        responseClone: null
      };
    }
  };
  const scheduleFetchSuccessPost = (reporter, postNetwork, context, response, duration) => {
    const responseHeaders = toHeaderRecord(response.headers);
    const { contentType, responseClone } = cloneFetchResponseForCapture(response, reporter);
    scheduleBackgroundTask(reporter, async () => {
      let requestBody;
      let responseBody;
      try {
        requestBody = await context.requestBodyPromise;
      } catch (error) {
        reporter.reportNonFatalError("Failed to resolve fetch request body in debugger instrumentation", error);
      }
      try {
        responseBody = await getTextBodyPreviewAsync(reporter, contentType, "Failed to capture fetch response body text in debugger instrumentation", () => {
          if (!responseClone) {
            return Promise.resolve("");
          }
          return responseClone.text();
        });
      } catch (error) {
        reporter.reportNonFatalError("Failed to capture fetch response body in debugger instrumentation", error);
      }
      postNetwork({
        method: context.method,
        url: context.normalizedUrl,
        status: response.status,
        duration,
        requestHeaders: context.requestHeaders,
        responseHeaders,
        requestBody: sanitizeCapturedBody(requestBody, context.requestContentType),
        responseBody: sanitizeCapturedBody(responseBody, contentType)
      });
    });
  };
  const scheduleFetchFailurePost = (reporter, postNetwork, context, error, startedAt, stringifyValue) => {
    scheduleBackgroundTask(reporter, async () => {
      let requestBody;
      try {
        requestBody = await context.requestBodyPromise;
      } catch (_requestBodyError) {
        requestBody = void 0;
      }
      postNetwork({
        method: context.method,
        url: context.normalizedUrl,
        status: 0,
        duration: Date.now() - startedAt,
        requestHeaders: context.requestHeaders,
        requestBody: sanitizeCapturedBody(requestBody, context.requestContentType),
        responseBody: sanitizeCapturedBody(truncate(stringifyValue(error), MAX_BODY_LENGTH), "")
      });
    });
  };
  const installFetchCapture = (input) => {
    const { diagnostics, postNetwork, reporter } = input;
    const stringifyValue = createStringifyValue(reporter);
    const requestBodyByRequest = /* @__PURE__ */ new WeakMap();
    const bindFetch = (candidate) => {
      return candidate.bind(window);
    };
    installRequestConstructorCapture(reporter, stringifyValue, requestBodyByRequest);
    if (typeof window.fetch !== "function") {
      diagnostics.setFetchHookState("failed");
      return;
    }
    const baseFetch = bindFetch(window.fetch);
    let delegateFetch = baseFetch;
    let isInsidePatchedFetch = false;
    const patchedFetch = (async (...args) => {
      if (isInsidePatchedFetch) {
        return baseFetch(...args);
      }
      isInsidePatchedFetch = true;
      diagnostics.recordFetchCall();
      const startedAt = Date.now();
      const context = resolveFetchContext(args, reporter, stringifyValue, requestBodyByRequest);
      if (!context) {
        try {
          return delegateFetch(...args);
        } finally {
          isInsidePatchedFetch = false;
        }
      }
      try {
        const response = await delegateFetch(...args);
        const duration = Date.now() - startedAt;
        scheduleFetchSuccessPost(reporter, postNetwork, context, response, duration);
        return response;
      } catch (error) {
        diagnostics.recordFetchFailure(truncate(stringifyValue(error), 300));
        scheduleFetchFailurePost(reporter, postNetwork, context, error, startedAt, stringifyValue);
        throw error;
      } finally {
        isInsidePatchedFetch = false;
      }
    });
    try {
      Object.assign(patchedFetch, window.fetch);
    } catch (error) {
      reporter.reportNonFatalError("Failed to mirror fetch properties in debugger instrumentation", error);
    }
    const fetchDescriptor = Object.getOwnPropertyDescriptor(window, "fetch");
    const canRedefineFetch = !fetchDescriptor || fetchDescriptor.configurable;
    if (canRedefineFetch) {
      try {
        Object.defineProperty(window, "fetch", {
          configurable: true,
          enumerable: fetchDescriptor?.enumerable ?? true,
          get() {
            return patchedFetch;
          },
          set(nextFetch) {
            if (typeof nextFetch !== "function") {
              return;
            }
            if (nextFetch === patchedFetch) {
              return;
            }
            delegateFetch = bindFetch(nextFetch);
          }
        });
        diagnostics.setFetchHookState("accessor");
        return;
      } catch (error) {
        reporter.reportNonFatalError("Failed to install fetch accessor in debugger instrumentation", error);
      }
    }
    try {
      window.fetch = patchedFetch;
      diagnostics.setFetchHookState("assignment");
    } catch (error) {
      diagnostics.setFetchHookState("failed");
      reporter.reportNonFatalError("Failed to patch fetch in debugger instrumentation", error);
    }
  };
  const installXhrCapture = (input) => {
    const { diagnostics, postNetwork, reporter } = input;
    const stringifyValue = createStringifyValue(reporter);
    const xhrMetaMap = /* @__PURE__ */ new WeakMap();
    const buildXhrPostPayload = async (xhr) => {
      const state = xhrMetaMap.get(xhr);
      if (!state) {
        return null;
      }
      const normalizedUrl = toAbsoluteUrl(state.url, reporter);
      if (!normalizedUrl) {
        return null;
      }
      const redactedUrl = redactSensitiveQueryParams(normalizedUrl);
      let requestBody;
      let responseBody;
      const responseHeaders = parseRawHeaders(xhr.getAllResponseHeaders());
      const responseContentType = responseHeaders["content-type"] ?? "";
      try {
        requestBody = await state.requestBodyPromise;
      } catch (_requestBodyError) {
        requestBody = void 0;
      }
      try {
        if (xhr.responseType === "" || xhr.responseType === "text") {
          responseBody = truncate(xhr.responseText || "", MAX_BODY_LENGTH);
        } else if (xhr.responseType === "json") {
          responseBody = truncate(stringifyValue(xhr.response), MAX_BODY_LENGTH);
        }
      } catch (error) {
        reporter.reportNonFatalError("Failed to capture XHR response body in debugger instrumentation", error);
      }
      return {
        method: state.method,
        url: redactedUrl,
        status: xhr.status,
        duration: Date.now() - state.startedAt,
        requestHeaders: state.requestHeaders,
        responseHeaders,
        requestBody: sanitizeCapturedBody(requestBody, state.requestHeaders["content-type"] ?? ""),
        responseBody: sanitizeCapturedBody(responseBody, responseContentType)
      };
    };
    const postXhrLoadEndEvent = (xhr) => {
      scheduleBackgroundTask(reporter, async () => {
        const payload = await buildXhrPostPayload(xhr);
        if (!payload) {
          return;
        }
        postNetwork(payload);
      });
    };
    const originalOpen = XMLHttpRequest.prototype.open;
    const openWithOptionalArgs = originalOpen;
    XMLHttpRequest.prototype.open = function(method, url, async, username, password) {
      const normalizedMethod = typeof method === "string" ? method : "GET";
      const normalizedUrl = typeof url === "string" ? url : String(url ?? "");
      xhrMetaMap.set(this, {
        method: normalizedMethod,
        url: normalizedUrl,
        startedAt: Date.now(),
        requestBodyPromise: Promise.resolve(void 0),
        requestHeaders: {}
      });
      if (typeof async === "boolean" || typeof username === "string" || username === null || typeof password === "string" || password === null) {
        return openWithOptionalArgs.call(this, method, url, async ?? true, username, password);
      }
      return openWithOptionalArgs.call(this, method, url);
    };
    const originalSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
    XMLHttpRequest.prototype.setRequestHeader = function(...args) {
      const [key, value] = args;
      const meta = xhrMetaMap.get(this);
      if (meta) {
        const normalizedKey = key.trim().toLowerCase();
        if (!shouldHideHeader(normalizedKey)) {
          meta.requestHeaders[normalizedKey.slice(0, MAX_HEADER_NAME_LENGTH)] = value.slice(0, MAX_HEADER_VALUE_LENGTH);
        }
      }
      return originalSetRequestHeader.apply(this, args);
    };
    const originalSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function(...args) {
      diagnostics.recordXhrCall();
      const meta = xhrMetaMap.get(this);
      if (meta) {
        meta.startedAt = Date.now();
        meta.requestBodyPromise = getRequestBodyPreviewAsync(reporter, args[0], stringifyValue, meta.requestHeaders["content-type"] ?? "");
      }
      this.addEventListener("loadend", () => {
        postXhrLoadEndEvent(this);
      }, {
        once: true
      });
      return originalSend.apply(this, args);
    };
    diagnostics.setXhrHookInstalled();
  };
  function installNetworkCapture(input) {
    installFetchCapture(input);
    installXhrCapture(input);
  }
  function installDebuggerPageRuntime() {
    const scope = window;
    if (scope[INSTALL_FLAG]) {
      return;
    }
    scope[INSTALL_FLAG] = true;
    const diagnostics = createPageDiagnostics(window);
    const reporter = diagnostics.createReporter(createNonFatalReporter());
    const { enqueueEvent, flushEventQueue } = createEventQueue({
      recordQueuedEvent: diagnostics.recordQueuedEvent,
      recordFlushedBatch: diagnostics.recordFlushedBatch
    });
    const stringifyValue = createStringifyValue(reporter);
    const postAction = (actionType, target, metadata) => {
      diagnostics.recordActionEvent();
      enqueueEvent({
        kind: "action",
        timestamp: Date.now(),
        actionType,
        target,
        metadata
      });
    };
    const postConsole = (level, args) => {
      diagnostics.recordConsoleEvent();
      const serializedArgs = [];
      for (const arg of args) {
        serializedArgs.push(stringifyValue(arg));
      }
      enqueueEvent({
        kind: "console",
        timestamp: Date.now(),
        level,
        message: truncate(serializedArgs.join(" ")),
        metadata: {
          argumentCount: args.length
        }
      });
    };
    const postNetwork = (payload) => {
      diagnostics.recordNetworkEvent(payload.url);
      enqueueEvent({
        kind: "network",
        timestamp: Date.now(),
        ...payload
      });
    };
    installActionAndNavigationCapture({
      postAction
    });
    installConsoleCapture({
      reporter,
      postConsole
    });
    try {
      installNetworkCapture({
        diagnostics,
        reporter,
        postNetwork
      });
    } catch (error) {
      reporter.reportNonFatalError("Failed to install network capture in debugger runtime", error);
    }
    const flushOnPageHide = () => {
      flushEventQueue();
    };
    window.addEventListener("pagehide", flushOnPageHide, {
      capture: true
    });
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden") {
        flushEventQueue();
      }
    }, {
      capture: true,
      passive: true
    });
  }
  function defineContentScript(definition2) {
    return definition2;
  }
  const definition = defineContentScript({
    matches: ["<all_urls>"],
    runAt: "document_start",
    world: "MAIN",
    main() {
      installDebuggerPageRuntime();
    }
  });
  function initPlugins() {
  }
  function print(method, ...args) {
    if (typeof args[0] === "string") method(`[wxt] ${args.shift()}`, ...args);
    else method("[wxt]", ...args);
  }
  const logger = {
    debug: (...args) => print(console.debug, ...args),
    log: (...args) => print(console.log, ...args),
    warn: (...args) => print(console.warn, ...args),
    error: (...args) => print(console.error, ...args)
  };
  const result = (async () => {
    try {
      initPlugins();
      return await definition.main();
    } catch (err) {
      logger.error(`The content script "${"debugger-page-main"}" crashed on startup!`, err);
      throw err;
    }
  })();
  return result;
})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVidWdnZXItcGFnZS1tYWluLmpzIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9wYWNrYWdlcy9jYXB0dXJlLWNvcmUvZGlzdC9kZWJ1Z2dlci9lbmdpbmUvcGFnZS9jb25zdGFudHMuanMiLCIuLi8uLi8uLi8uLi8uLi9wYWNrYWdlcy9jYXB0dXJlLWNvcmUvZGlzdC9kZWJ1Z2dlci9lbmdpbmUvcGFnZS91dGlscy5qcyIsIi4uLy4uLy4uLy4uLy4uL3BhY2thZ2VzL2NhcHR1cmUtY29yZS9kaXN0L2RlYnVnZ2VyL2VuZ2luZS9wYWdlL2FjdGlvbnMuanMiLCIuLi8uLi8uLi8uLi8uLi9wYWNrYWdlcy9jYXB0dXJlLWNvcmUvZGlzdC9kZWJ1Z2dlci9lbmdpbmUvcGFnZS9jb25zb2xlLmpzIiwiLi4vLi4vLi4vLi4vLi4vcGFja2FnZXMvY2FwdHVyZS1jb3JlL2Rpc3QvZGVidWdnZXIvZW5naW5lL3BhZ2UvZGlhZ25vc3RpY3MuanMiLCIuLi8uLi8uLi8uLi8uLi9wYWNrYWdlcy9jYXB0dXJlLWNvcmUvZGlzdC9kZWJ1Z2dlci9lbmdpbmUvcGFnZS9ldmVudC1xdWV1ZS5qcyIsIi4uLy4uLy4uLy4uLy4uL3BhY2thZ2VzL2NhcHR1cmUtY29yZS9kaXN0L2RlYnVnZ2VyL2VuZ2luZS9wYWdlL3NlcmlhbGl6ZXIuanMiLCIuLi8uLi8uLi8uLi8uLi9wYWNrYWdlcy9jYXB0dXJlLWNvcmUvZGlzdC9kZWJ1Z2dlci9lbmdpbmUvcGFnZS9oZWFkZXJzLmpzIiwiLi4vLi4vLi4vLi4vLi4vcGFja2FnZXMvY2FwdHVyZS1jb3JlL2Rpc3QvZGVidWdnZXIvZW5naW5lL3BhZ2UvbmV0d29yay9zaGFyZWQuanMiLCIuLi8uLi8uLi8uLi8uLi9wYWNrYWdlcy9jYXB0dXJlLWNvcmUvZGlzdC9kZWJ1Z2dlci9lbmdpbmUvcGFnZS9uZXR3b3JrL2ZldGNoL2NvbnRleHQuanMiLCIuLi8uLi8uLi8uLi8uLi9wYWNrYWdlcy9jYXB0dXJlLWNvcmUvZGlzdC9kZWJ1Z2dlci9lbmdpbmUvcGFnZS9uZXR3b3JrL2ZldGNoL3Bvc3QuanMiLCIuLi8uLi8uLi8uLi8uLi9wYWNrYWdlcy9jYXB0dXJlLWNvcmUvZGlzdC9kZWJ1Z2dlci9lbmdpbmUvcGFnZS9uZXR3b3JrL2ZldGNoL2luc3RhbGwuanMiLCIuLi8uLi8uLi8uLi8uLi9wYWNrYWdlcy9jYXB0dXJlLWNvcmUvZGlzdC9kZWJ1Z2dlci9lbmdpbmUvcGFnZS9uZXR3b3JrL3hoci5qcyIsIi4uLy4uLy4uLy4uLy4uL3BhY2thZ2VzL2NhcHR1cmUtY29yZS9kaXN0L2RlYnVnZ2VyL2VuZ2luZS9wYWdlL25ldHdvcmsvaW5kZXguanMiLCIuLi8uLi8uLi8uLi8uLi9wYWNrYWdlcy9jYXB0dXJlLWNvcmUvZGlzdC9kZWJ1Z2dlci9lbmdpbmUvcGFnZS9pbmRleC5qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8uYnVuL3d4dEAwLjIwLjE3Kzc0MDZhZGViOWJmY2Q1NTMvbm9kZV9tb2R1bGVzL3d4dC9kaXN0L3V0aWxzL2RlZmluZS1jb250ZW50LXNjcmlwdC5tanMiLCIuLi8uLi8uLi9lbnRyeXBvaW50cy9kZWJ1Z2dlci1wYWdlLW1haW4uY29udGVudC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgUEFHRV9TT1VSQ0UgPSBcIkNSSUtLRVRfREVCVUdHRVJfUEFHRV9CUklER0VcIjtcbmV4cG9ydCBjb25zdCBJTlNUQUxMX0ZMQUcgPSBcIl9fY3Jpa2tldERlYnVnZ2VyUGFnZVNjcmlwdEluc3RhbGxlZFwiO1xuZXhwb3J0IGNvbnN0IE1BWF9URVhUX0xFTkdUSCA9IDIwMDA7XG5leHBvcnQgY29uc3QgTUFYX0JPRFlfTEVOR1RIID0gNDAwMDtcbmV4cG9ydCBjb25zdCBNQVhfSEVBREVSX05BTUVfTEVOR1RIID0gMTIwO1xuZXhwb3J0IGNvbnN0IE1BWF9IRUFERVJfVkFMVUVfTEVOR1RIID0gNTAwO1xuZXhwb3J0IGNvbnN0IE1BWF9CQVRDSF9TSVpFID0gNDA7XG5leHBvcnQgY29uc3QgRkxVU0hfSU5URVJWQUxfTVMgPSAxMjA7XG5leHBvcnQgY29uc3QgTUFYX1NFUklBTElaRV9ERVBUSCA9IDQ7XG5leHBvcnQgY29uc3QgTUFYX1NFUklBTElaRV9LRVlTID0gMzA7XG5leHBvcnQgY29uc3QgTUFYX1NFUklBTElaRV9BUlJBWV9JVEVNUyA9IDMwO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y29uc3RhbnRzLmpzLm1hcCIsImltcG9ydCB7IE1BWF9URVhUX0xFTkdUSCB9IGZyb20gXCIuL2NvbnN0YW50c1wiO1xuY29uc3QgUkVEQUNURURfVkFMVUUgPSBcIltSRURBQ1RFRF1cIjtcbmNvbnN0IFNFTlNJVElWRV9OQU1FX1BBVFRFUk5TID0gW1xuICAgIFwiYXV0aG9yaXphdGlvblwiLFxuICAgIFwiY29va2llXCIsXG4gICAgXCJzZXQtY29va2llXCIsXG4gICAgXCJ0b2tlblwiLFxuICAgIFwic2VjcmV0XCIsXG4gICAgXCJwYXNzd29yZFwiLFxuICAgIFwicGFzc3dkXCIsXG4gICAgXCJwd2RcIixcbiAgICBcInNlc3Npb25cIixcbiAgICBcImFwaS1rZXlcIixcbiAgICBcImFwaWtleVwiLFxuICAgIFwieC1hcGkta2V5XCIsXG4gICAgXCJyZWZyZXNoLXRva2VuXCIsXG4gICAgXCJyZWZyZXNoX3Rva2VuXCIsXG4gICAgXCJhY2Nlc3MtdG9rZW5cIixcbiAgICBcImFjY2Vzc190b2tlblwiLFxuICAgIFwiaWQtdG9rZW5cIixcbiAgICBcImlkX3Rva2VuXCIsXG4gICAgXCJjbGllbnQtc2VjcmV0XCIsXG4gICAgXCJjbGllbnRfc2VjcmV0XCIsXG5dO1xuY29uc3QgUkVEQUNUQUJMRV9GSUVMRF9QQVRURVJOID0gLygoPzphY2Nlc3NbXy1dP3Rva2VufHJlZnJlc2hbXy1dP3Rva2VufGlkW18tXT90b2tlbnxhcGlbXy1dP2tleXxjbGllbnRbXy1dP3NlY3JldHxwYXNzd29yZHxwYXNzd2R8cHdkfGF1dGhvcml6YXRpb258Y29va2llfHNlc3Npb25bXy1dP2lkKVxccypbOj1dXFxzKikoW14mXFxzXCIsO10rKS9naTtcbmV4cG9ydCBjb25zdCB0cnVuY2F0ZSA9ICh2YWx1ZSwgbWF4TGVuZ3RoID0gTUFYX1RFWFRfTEVOR1RIKSA9PiB7XG4gICAgaWYgKHZhbHVlLmxlbmd0aCA8PSBtYXhMZW5ndGgpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH1cbiAgICByZXR1cm4gYCR7dmFsdWUuc2xpY2UoMCwgbWF4TGVuZ3RoKX0uLi5gO1xufTtcbmV4cG9ydCBjb25zdCBpc1NlbnNpdGl2ZU5hbWUgPSAodmFsdWUpID0+IHtcbiAgICBjb25zdCBub3JtYWxpemVkVmFsdWUgPSB2YWx1ZS50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgICBpZiAoIW5vcm1hbGl6ZWRWYWx1ZSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiBTRU5TSVRJVkVfTkFNRV9QQVRURVJOUy5zb21lKChwYXR0ZXJuKSA9PiB7XG4gICAgICAgIHJldHVybiBub3JtYWxpemVkVmFsdWUuaW5jbHVkZXMocGF0dGVybik7XG4gICAgfSk7XG59O1xuZXhwb3J0IGNvbnN0IHNob3VsZEhpZGVIZWFkZXIgPSAoaGVhZGVyTmFtZSkgPT4ge1xuICAgIHJldHVybiBoZWFkZXJOYW1lLmluY2x1ZGVzKFwiZGVidWdnZXJcIikgfHwgaXNTZW5zaXRpdmVOYW1lKGhlYWRlck5hbWUpO1xufTtcbmV4cG9ydCBjb25zdCBnZXRFbGVtZW50VGFyZ2V0ID0gKHRhcmdldCkgPT4ge1xuICAgIGlmICghKHRhcmdldCBpbnN0YW5jZW9mIEVsZW1lbnQpKSB7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGlmICh0YXJnZXQuaWQpIHtcbiAgICAgICAgcmV0dXJuIGAjJHt0YXJnZXQuaWR9YDtcbiAgICB9XG4gICAgY29uc3QgY2xhc3NOYW1lcyA9IHR5cGVvZiB0YXJnZXQuY2xhc3NOYW1lID09PSBcInN0cmluZ1wiID8gdGFyZ2V0LmNsYXNzTmFtZSA6IFwiXCI7XG4gICAgY29uc3QgZmlyc3RDbGFzcyA9IGNsYXNzTmFtZXNcbiAgICAgICAgLnNwbGl0KFwiIFwiKVxuICAgICAgICAubWFwKChlbnRyeSkgPT4gZW50cnkudHJpbSgpKVxuICAgICAgICAuZmluZCgoZW50cnkpID0+IGVudHJ5Lmxlbmd0aCA+IDApO1xuICAgIGlmIChmaXJzdENsYXNzKSB7XG4gICAgICAgIHJldHVybiBgJHt0YXJnZXQudGFnTmFtZS50b0xvd2VyQ2FzZSgpfS4ke2ZpcnN0Q2xhc3N9YDtcbiAgICB9XG4gICAgcmV0dXJuIHRhcmdldC50YWdOYW1lLnRvTG93ZXJDYXNlKCk7XG59O1xuZXhwb3J0IGNvbnN0IHRvQWJzb2x1dGVVcmwgPSAodmFsdWUsIHJlcG9ydGVyKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIG5ldyBVUkwodmFsdWUsIGxvY2F0aW9uLmhyZWYpLnRvU3RyaW5nKCk7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXBvcnRlci5yZXBvcnROb25GYXRhbEVycm9yKFwiRmFpbGVkIHRvIG5vcm1hbGl6ZSBuZXR3b3JrIFVSTCBpbiBkZWJ1Z2dlciBpbnN0cnVtZW50YXRpb25cIiwge1xuICAgICAgICAgICAgZXJyb3IsXG4gICAgICAgICAgICB2YWx1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbn07XG5leHBvcnQgY29uc3QgcmVkYWN0U2Vuc2l0aXZlUXVlcnlQYXJhbXMgPSAoYWJzb2x1dGVVcmwpID0+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBwYXJzZWRVcmwgPSBuZXcgVVJMKGFic29sdXRlVXJsKTtcbiAgICAgICAgZm9yIChjb25zdCBba2V5XSBvZiBwYXJzZWRVcmwuc2VhcmNoUGFyYW1zLmVudHJpZXMoKSkge1xuICAgICAgICAgICAgaWYgKCFpc1NlbnNpdGl2ZU5hbWUoa2V5KSkge1xuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcGFyc2VkVXJsLnNlYXJjaFBhcmFtcy5zZXQoa2V5LCBSRURBQ1RFRF9WQUxVRSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHBhcnNlZFVybC50b1N0cmluZygpO1xuICAgIH1cbiAgICBjYXRjaCB7XG4gICAgICAgIHJldHVybiBhYnNvbHV0ZVVybDtcbiAgICB9XG59O1xuY29uc3Qgc2FuaXRpemVTdHJ1Y3R1cmVkVmFsdWUgPSAodmFsdWUsIGRlcHRoID0gMCkgPT4ge1xuICAgIGlmIChkZXB0aCA+PSA2KSB7XG4gICAgICAgIHJldHVybiBcIltNYXhEZXB0aF1cIjtcbiAgICB9XG4gICAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZS5tYXAoKGl0ZW0pID0+IHNhbml0aXplU3RydWN0dXJlZFZhbHVlKGl0ZW0sIGRlcHRoICsgMSkpO1xuICAgIH1cbiAgICBpZiAodmFsdWUgJiYgdHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IHt9O1xuICAgICAgICBmb3IgKGNvbnN0IFtrZXksIG5lc3RlZFZhbHVlXSBvZiBPYmplY3QuZW50cmllcyh2YWx1ZSkpIHtcbiAgICAgICAgICAgIGlmIChpc1NlbnNpdGl2ZU5hbWUoa2V5KSkge1xuICAgICAgICAgICAgICAgIHJlc3VsdFtrZXldID0gUkVEQUNURURfVkFMVUU7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXN1bHRba2V5XSA9IHNhbml0aXplU3RydWN0dXJlZFZhbHVlKG5lc3RlZFZhbHVlLCBkZXB0aCArIDEpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlLnJlcGxhY2UoUkVEQUNUQUJMRV9GSUVMRF9QQVRURVJOLCBgJDEke1JFREFDVEVEX1ZBTFVFfWApO1xuICAgIH1cbiAgICByZXR1cm4gdmFsdWU7XG59O1xuY29uc3Qgc2FuaXRpemVVcmxFbmNvZGVkQm9keSA9IChib2R5KSA9PiB7XG4gICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhib2R5KTtcbiAgICBmb3IgKGNvbnN0IFtrZXldIG9mIHBhcmFtcy5lbnRyaWVzKCkpIHtcbiAgICAgICAgaWYgKCFpc1NlbnNpdGl2ZU5hbWUoa2V5KSkge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgcGFyYW1zLnNldChrZXksIFJFREFDVEVEX1ZBTFVFKTtcbiAgICB9XG4gICAgcmV0dXJuIHBhcmFtcy50b1N0cmluZygpO1xufTtcbmV4cG9ydCBjb25zdCBzYW5pdGl6ZUNhcHR1cmVkQm9keSA9IChib2R5LCBjb250ZW50VHlwZSkgPT4ge1xuICAgIGlmICh0eXBlb2YgYm9keSAhPT0gXCJzdHJpbmdcIiB8fCBib2R5Lmxlbmd0aCA9PT0gMCkge1xuICAgICAgICByZXR1cm4gYm9keTtcbiAgICB9XG4gICAgY29uc3Qgbm9ybWFsaXplZENvbnRlbnRUeXBlID0gY29udGVudFR5cGUudG9Mb3dlckNhc2UoKTtcbiAgICBpZiAobm9ybWFsaXplZENvbnRlbnRUeXBlLmluY2x1ZGVzKFwiYXBwbGljYXRpb24vanNvblwiKSkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcGFyc2VkID0gSlNPTi5wYXJzZShib2R5KTtcbiAgICAgICAgICAgIHJldHVybiB0cnVuY2F0ZShKU09OLnN0cmluZ2lmeShzYW5pdGl6ZVN0cnVjdHVyZWRWYWx1ZShwYXJzZWQpKSwgTUFYX1RFWFRfTEVOR1RIICogMik7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2gge1xuICAgICAgICAgICAgcmV0dXJuIHRydW5jYXRlKGJvZHkucmVwbGFjZShSRURBQ1RBQkxFX0ZJRUxEX1BBVFRFUk4sIGAkMSR7UkVEQUNURURfVkFMVUV9YCksIE1BWF9URVhUX0xFTkdUSCAqIDIpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGlmIChub3JtYWxpemVkQ29udGVudFR5cGUuaW5jbHVkZXMoXCJ4LXd3dy1mb3JtLXVybGVuY29kZWRcIikpIHtcbiAgICAgICAgcmV0dXJuIHRydW5jYXRlKHNhbml0aXplVXJsRW5jb2RlZEJvZHkoYm9keSksIE1BWF9URVhUX0xFTkdUSCAqIDIpO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1bmNhdGUoYm9keS5yZXBsYWNlKFJFREFDVEFCTEVfRklFTERfUEFUVEVSTiwgYCQxJHtSRURBQ1RFRF9WQUxVRX1gKSwgTUFYX1RFWFRfTEVOR1RIICogMik7XG59O1xuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZU5vbkZhdGFsUmVwb3J0ZXIoKSB7XG4gICAgY29uc3Qgb3JpZ2luYWxDb25zb2xlV2FybiA9IGNvbnNvbGUud2Fybi5iaW5kKGNvbnNvbGUpO1xuICAgIGNvbnN0IHJlcG9ydGVkQ29udGV4dHMgPSBuZXcgU2V0KCk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgcmVwb3J0Tm9uRmF0YWxFcnJvcihjb250ZXh0LCBlcnJvcikge1xuICAgICAgICAgICAgaWYgKHJlcG9ydGVkQ29udGV4dHMuaGFzKGNvbnRleHQpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmVwb3J0ZWRDb250ZXh0cy5hZGQoY29udGV4dCk7XG4gICAgICAgICAgICBvcmlnaW5hbENvbnNvbGVXYXJuKGBbTm9uLWZhdGFsXSAke2NvbnRleHR9YCwgZXJyb3IpO1xuICAgICAgICB9LFxuICAgIH07XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD11dGlscy5qcy5tYXAiLCJpbXBvcnQgeyBnZXRFbGVtZW50VGFyZ2V0IH0gZnJvbSBcIi4vdXRpbHNcIjtcbmV4cG9ydCBmdW5jdGlvbiBpbnN0YWxsQWN0aW9uQW5kTmF2aWdhdGlvbkNhcHR1cmUoaW5wdXQpIHtcbiAgICBjb25zdCB7IHBvc3RBY3Rpb24gfSA9IGlucHV0O1xuICAgIGNvbnN0IHBvc3ROYXZpZ2F0aW9uQnJlYWRjcnVtYiA9IChtb2RlKSA9PiB7XG4gICAgICAgIHBvc3RBY3Rpb24oXCJuYXZpZ2F0aW9uXCIsIFwid2luZG93XCIsIHtcbiAgICAgICAgICAgIG1vZGUsXG4gICAgICAgICAgICB1cmw6IGxvY2F0aW9uLmhyZWYsXG4gICAgICAgICAgICBwYXRoOiBsb2NhdGlvbi5wYXRobmFtZSxcbiAgICAgICAgICAgIHNlYXJjaDogbG9jYXRpb24uc2VhcmNoLFxuICAgICAgICAgICAgaGFzaDogbG9jYXRpb24uaGFzaCxcbiAgICAgICAgICAgIHRpdGxlOiBkb2N1bWVudC50aXRsZSxcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCBkZWxlZ2F0ZWRIYW5kbGVycyA9IHtcbiAgICAgICAgY2xpY2s6IChldmVudCkgPT4ge1xuICAgICAgICAgICAgcG9zdEFjdGlvbihcImNsaWNrXCIsIGdldEVsZW1lbnRUYXJnZXQoZXZlbnQudGFyZ2V0KSk7XG4gICAgICAgIH0sXG4gICAgICAgIGlucHV0OiAoZXZlbnQpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHRhcmdldCA9IGdldEVsZW1lbnRUYXJnZXQoZXZlbnQudGFyZ2V0KTtcbiAgICAgICAgICAgIGxldCB2YWx1ZUxlbmd0aDtcbiAgICAgICAgICAgIGNvbnN0IGlucHV0VGFyZ2V0ID0gZXZlbnQudGFyZ2V0O1xuICAgICAgICAgICAgaWYgKGlucHV0VGFyZ2V0IGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudCB8fFxuICAgICAgICAgICAgICAgIGlucHV0VGFyZ2V0IGluc3RhbmNlb2YgSFRNTFRleHRBcmVhRWxlbWVudCkge1xuICAgICAgICAgICAgICAgIHZhbHVlTGVuZ3RoID0gaW5wdXRUYXJnZXQudmFsdWUubGVuZ3RoO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcG9zdEFjdGlvbihcImlucHV0XCIsIHRhcmdldCwge1xuICAgICAgICAgICAgICAgIHZhbHVlTGVuZ3RoLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgICAgIGNoYW5nZTogKGV2ZW50KSA9PiB7XG4gICAgICAgICAgICBwb3N0QWN0aW9uKFwiY2hhbmdlXCIsIGdldEVsZW1lbnRUYXJnZXQoZXZlbnQudGFyZ2V0KSk7XG4gICAgICAgIH0sXG4gICAgfTtcbiAgICBjb25zdCBkZWxlZ2F0ZWRMaXN0ZW5lciA9IChldmVudCkgPT4ge1xuICAgICAgICBpZiAoZXZlbnQudHlwZSAhPT0gXCJjbGlja1wiICYmXG4gICAgICAgICAgICBldmVudC50eXBlICE9PSBcImlucHV0XCIgJiZcbiAgICAgICAgICAgIGV2ZW50LnR5cGUgIT09IFwiY2hhbmdlXCIpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBkZWxlZ2F0ZWRIYW5kbGVyc1tldmVudC50eXBlXShldmVudCk7XG4gICAgfTtcbiAgICBmb3IgKGNvbnN0IGV2ZW50VHlwZSBvZiBbXCJjbGlja1wiLCBcImlucHV0XCIsIFwiY2hhbmdlXCJdKSB7XG4gICAgICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoZXZlbnRUeXBlLCBkZWxlZ2F0ZWRMaXN0ZW5lciwge1xuICAgICAgICAgICAgY2FwdHVyZTogdHJ1ZSxcbiAgICAgICAgICAgIHBhc3NpdmU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBjb25zdCBvcmlnaW5hbFB1c2hTdGF0ZSA9IGhpc3RvcnkucHVzaFN0YXRlO1xuICAgIGhpc3RvcnkucHVzaFN0YXRlID0gZnVuY3Rpb24gKC4uLmFyZ3MpIHtcbiAgICAgICAgb3JpZ2luYWxQdXNoU3RhdGUuYXBwbHkodGhpcywgYXJncyk7XG4gICAgICAgIHBvc3ROYXZpZ2F0aW9uQnJlYWRjcnVtYihcInB1c2hTdGF0ZVwiKTtcbiAgICB9O1xuICAgIGNvbnN0IG9yaWdpbmFsUmVwbGFjZVN0YXRlID0gaGlzdG9yeS5yZXBsYWNlU3RhdGU7XG4gICAgaGlzdG9yeS5yZXBsYWNlU3RhdGUgPSBmdW5jdGlvbiAoLi4uYXJncykge1xuICAgICAgICBvcmlnaW5hbFJlcGxhY2VTdGF0ZS5hcHBseSh0aGlzLCBhcmdzKTtcbiAgICAgICAgcG9zdE5hdmlnYXRpb25CcmVhZGNydW1iKFwicmVwbGFjZVN0YXRlXCIpO1xuICAgIH07XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJwb3BzdGF0ZVwiLCAoKSA9PiB7XG4gICAgICAgIHBvc3ROYXZpZ2F0aW9uQnJlYWRjcnVtYihcInBvcHN0YXRlXCIpO1xuICAgIH0sIHtcbiAgICAgICAgY2FwdHVyZTogdHJ1ZSxcbiAgICAgICAgcGFzc2l2ZTogdHJ1ZSxcbiAgICB9KTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImhhc2hjaGFuZ2VcIiwgKCkgPT4ge1xuICAgICAgICBwb3N0TmF2aWdhdGlvbkJyZWFkY3J1bWIoXCJoYXNoY2hhbmdlXCIpO1xuICAgIH0sIHtcbiAgICAgICAgY2FwdHVyZTogdHJ1ZSxcbiAgICAgICAgcGFzc2l2ZTogdHJ1ZSxcbiAgICB9KTtcbiAgICBwb3N0TmF2aWdhdGlvbkJyZWFkY3J1bWIoXCJpbml0aWFsXCIpO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YWN0aW9ucy5qcy5tYXAiLCJleHBvcnQgZnVuY3Rpb24gaW5zdGFsbENvbnNvbGVDYXB0dXJlKGlucHV0KSB7XG4gICAgY29uc3QgeyByZXBvcnRlciwgcG9zdENvbnNvbGUgfSA9IGlucHV0O1xuICAgIGNvbnN0IGNvbnNvbGVMZXZlbHMgPSBbXG4gICAgICAgIFwibG9nXCIsXG4gICAgICAgIFwiaW5mb1wiLFxuICAgICAgICBcIndhcm5cIixcbiAgICAgICAgXCJlcnJvclwiLFxuICAgICAgICBcImRlYnVnXCIsXG4gICAgXTtcbiAgICBmb3IgKGNvbnN0IGxldmVsIG9mIGNvbnNvbGVMZXZlbHMpIHtcbiAgICAgICAgY29uc3Qgb3JpZ2luYWwgPSBjb25zb2xlW2xldmVsXS5iaW5kKGNvbnNvbGUpO1xuICAgICAgICBjb25zb2xlW2xldmVsXSA9ICguLi5hcmdzKSA9PiB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHBvc3RDb25zb2xlKGxldmVsLCBhcmdzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgIHJlcG9ydGVyLnJlcG9ydE5vbkZhdGFsRXJyb3IoXCJGYWlsZWQgdG8gcG9zdCBjb25zb2xlIGV2ZW50IGluIGRlYnVnZ2VyIGluc3RydW1lbnRhdGlvblwiLCBlcnJvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvcmlnaW5hbCguLi5hcmdzKTtcbiAgICAgICAgfTtcbiAgICB9XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb25zb2xlLmpzLm1hcCIsImltcG9ydCB7IHRydW5jYXRlIH0gZnJvbSBcIi4vdXRpbHNcIjtcbmNvbnN0IERJQUdOT1NUSUNTX0tFWSA9IFwiX19jcmlra2V0RGVidWdnZXJEaWFnbm9zdGljc1wiO1xuY29uc3QgRElBR05PU1RJQ1NfVkVSU0lPTiA9IDE7XG5jb25zdCBNQVhfRVJST1JfRU5UUklFUyA9IDI1O1xuY29uc3QgTUFYX0VSUk9SX0xFTkdUSCA9IDMwMDtcbmNvbnN0IGNyZWF0ZURlZmF1bHREaWFnbm9zdGljc1N0YXRlID0gKCkgPT4ge1xuICAgIHJldHVybiB7XG4gICAgICAgIHZlcnNpb246IERJQUdOT1NUSUNTX1ZFUlNJT04sXG4gICAgICAgIGluc3RhbGxlZEF0OiBEYXRlLm5vdygpLFxuICAgICAgICB1cmw6IGxvY2F0aW9uLmhyZWYsXG4gICAgICAgIGhvb2tzOiB7XG4gICAgICAgICAgICBmZXRjaDogXCJwZW5kaW5nXCIsXG4gICAgICAgICAgICB4aHI6IGZhbHNlLFxuICAgICAgICB9LFxuICAgICAgICBjb3VudGVyczoge1xuICAgICAgICAgICAgYWN0aW9uRXZlbnRzOiAwLFxuICAgICAgICAgICAgY29uc29sZUV2ZW50czogMCxcbiAgICAgICAgICAgIG5ldHdvcmtFdmVudHM6IDAsXG4gICAgICAgICAgICBmZXRjaENhbGxzOiAwLFxuICAgICAgICAgICAgZmV0Y2hGYWlsdXJlczogMCxcbiAgICAgICAgICAgIHhockNhbGxzOiAwLFxuICAgICAgICAgICAgcXVldWVkRXZlbnRzOiAwLFxuICAgICAgICAgICAgZmx1c2hlZEJhdGNoZXM6IDAsXG4gICAgICAgIH0sXG4gICAgICAgIGxhc3Q6IHt9LFxuICAgICAgICBlcnJvcnM6IFtdLFxuICAgIH07XG59O1xuY29uc3QgdG9FcnJvck1lc3NhZ2UgPSAoY29udGV4dCwgZXJyb3IpID0+IHtcbiAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICByZXR1cm4gYCR7Y29udGV4dH06ICR7ZXJyb3IubWVzc2FnZX1gO1xuICAgIH1cbiAgICByZXR1cm4gYCR7Y29udGV4dH06ICR7U3RyaW5nKGVycm9yKX1gO1xufTtcbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVQYWdlRGlhZ25vc3RpY3Moc2NvcGUpIHtcbiAgICBjb25zdCBydW50aW1lU2NvcGUgPSBzY29wZTtcbiAgICBjb25zdCBzdGF0ZSA9IHJ1bnRpbWVTY29wZVtESUFHTk9TVElDU19LRVldID8/IGNyZWF0ZURlZmF1bHREaWFnbm9zdGljc1N0YXRlKCk7XG4gICAgcnVudGltZVNjb3BlW0RJQUdOT1NUSUNTX0tFWV0gPSBzdGF0ZTtcbiAgICBzdGF0ZS5pbnN0YWxsZWRBdCA9IERhdGUubm93KCk7XG4gICAgc3RhdGUudXJsID0gbG9jYXRpb24uaHJlZjtcbiAgICBzdGF0ZS5ob29rcy5mZXRjaCA9IFwicGVuZGluZ1wiO1xuICAgIHN0YXRlLmhvb2tzLnhociA9IGZhbHNlO1xuICAgIHJldHVybiB7XG4gICAgICAgIHN0YXRlLFxuICAgICAgICBjcmVhdGVSZXBvcnRlcihyZXBvcnRlcikge1xuICAgICAgICAgICAgY29uc3Qgb3JpZ2luYWxSZXBvcnQgPSByZXBvcnRlci5yZXBvcnROb25GYXRhbEVycm9yLmJpbmQocmVwb3J0ZXIpO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICByZXBvcnROb25GYXRhbEVycm9yKGNvbnRleHQsIGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIHN0YXRlLmVycm9ycy5wdXNoKHRydW5jYXRlKHRvRXJyb3JNZXNzYWdlKGNvbnRleHQsIGVycm9yKSwgTUFYX0VSUk9SX0xFTkdUSCkpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoc3RhdGUuZXJyb3JzLmxlbmd0aCA+IE1BWF9FUlJPUl9FTlRSSUVTKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzdGF0ZS5lcnJvcnMuc2hpZnQoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBvcmlnaW5hbFJlcG9ydChjb250ZXh0LCBlcnJvcik7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH0sXG4gICAgICAgIHJlY29yZEFjdGlvbkV2ZW50KCkge1xuICAgICAgICAgICAgc3RhdGUuY291bnRlcnMuYWN0aW9uRXZlbnRzICs9IDE7XG4gICAgICAgIH0sXG4gICAgICAgIHJlY29yZENvbnNvbGVFdmVudCgpIHtcbiAgICAgICAgICAgIHN0YXRlLmNvdW50ZXJzLmNvbnNvbGVFdmVudHMgKz0gMTtcbiAgICAgICAgfSxcbiAgICAgICAgcmVjb3JkTmV0d29ya0V2ZW50KHVybCkge1xuICAgICAgICAgICAgc3RhdGUuY291bnRlcnMubmV0d29ya0V2ZW50cyArPSAxO1xuICAgICAgICAgICAgc3RhdGUubGFzdC5uZXR3b3JrVXJsID0gdXJsO1xuICAgICAgICB9LFxuICAgICAgICByZWNvcmRGZXRjaENhbGwoKSB7XG4gICAgICAgICAgICBzdGF0ZS5jb3VudGVycy5mZXRjaENhbGxzICs9IDE7XG4gICAgICAgIH0sXG4gICAgICAgIHJlY29yZEZldGNoRmFpbHVyZShtZXNzYWdlKSB7XG4gICAgICAgICAgICBzdGF0ZS5jb3VudGVycy5mZXRjaEZhaWx1cmVzICs9IDE7XG4gICAgICAgICAgICBzdGF0ZS5sYXN0LmZldGNoRXJyb3IgPSBtZXNzYWdlO1xuICAgICAgICB9LFxuICAgICAgICBzZXRGZXRjaEhvb2tTdGF0ZShuZXh0U3RhdGUpIHtcbiAgICAgICAgICAgIHN0YXRlLmhvb2tzLmZldGNoID0gbmV4dFN0YXRlO1xuICAgICAgICB9LFxuICAgICAgICByZWNvcmRYaHJDYWxsKCkge1xuICAgICAgICAgICAgc3RhdGUuY291bnRlcnMueGhyQ2FsbHMgKz0gMTtcbiAgICAgICAgfSxcbiAgICAgICAgc2V0WGhySG9va0luc3RhbGxlZCgpIHtcbiAgICAgICAgICAgIHN0YXRlLmhvb2tzLnhociA9IHRydWU7XG4gICAgICAgIH0sXG4gICAgICAgIHJlY29yZFF1ZXVlZEV2ZW50KCkge1xuICAgICAgICAgICAgc3RhdGUuY291bnRlcnMucXVldWVkRXZlbnRzICs9IDE7XG4gICAgICAgIH0sXG4gICAgICAgIHJlY29yZEZsdXNoZWRCYXRjaCgpIHtcbiAgICAgICAgICAgIHN0YXRlLmNvdW50ZXJzLmZsdXNoZWRCYXRjaGVzICs9IDE7XG4gICAgICAgIH0sXG4gICAgfTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWRpYWdub3N0aWNzLmpzLm1hcCIsImltcG9ydCB7IEZMVVNIX0lOVEVSVkFMX01TLCBNQVhfQkFUQ0hfU0laRSwgUEFHRV9TT1VSQ0UgfSBmcm9tIFwiLi9jb25zdGFudHNcIjtcbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVFdmVudFF1ZXVlKGlucHV0ID0ge30pIHtcbiAgICBjb25zdCB7IHJlY29yZEZsdXNoZWRCYXRjaCwgcmVjb3JkUXVldWVkRXZlbnQgfSA9IGlucHV0O1xuICAgIGNvbnN0IGV2ZW50UXVldWUgPSBbXTtcbiAgICBsZXQgZmx1c2hUaW1lciA9IG51bGw7XG4gICAgY29uc3QgZmx1c2hFdmVudFF1ZXVlID0gKCkgPT4ge1xuICAgICAgICBmbHVzaFRpbWVyID0gbnVsbDtcbiAgICAgICAgaWYgKGV2ZW50UXVldWUubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgYmF0Y2hlZEV2ZW50cyA9IGV2ZW50UXVldWUuc3BsaWNlKDAsIE1BWF9CQVRDSF9TSVpFKTtcbiAgICAgICAgcmVjb3JkRmx1c2hlZEJhdGNoPy4oKTtcbiAgICAgICAgd2luZG93LnBvc3RNZXNzYWdlKHtcbiAgICAgICAgICAgIHNvdXJjZTogUEFHRV9TT1VSQ0UsXG4gICAgICAgICAgICBldmVudHM6IGJhdGNoZWRFdmVudHMsXG4gICAgICAgIH0sIFwiKlwiKTtcbiAgICAgICAgaWYgKGV2ZW50UXVldWUubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgZmx1c2hUaW1lciA9IHNldFRpbWVvdXQoZmx1c2hFdmVudFF1ZXVlLCAwKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3Qgc2NoZWR1bGVFdmVudEZsdXNoID0gKCkgPT4ge1xuICAgICAgICBpZiAoZmx1c2hUaW1lcikge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGZsdXNoVGltZXIgPSBzZXRUaW1lb3V0KGZsdXNoRXZlbnRRdWV1ZSwgRkxVU0hfSU5URVJWQUxfTVMpO1xuICAgIH07XG4gICAgY29uc3QgZW5xdWV1ZUV2ZW50ID0gKGV2ZW50KSA9PiB7XG4gICAgICAgIGV2ZW50UXVldWUucHVzaChldmVudCk7XG4gICAgICAgIHJlY29yZFF1ZXVlZEV2ZW50Py4oKTtcbiAgICAgICAgaWYgKGV2ZW50UXVldWUubGVuZ3RoID49IE1BWF9CQVRDSF9TSVpFKSB7XG4gICAgICAgICAgICBpZiAoZmx1c2hUaW1lcikge1xuICAgICAgICAgICAgICAgIGNsZWFyVGltZW91dChmbHVzaFRpbWVyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZsdXNoVGltZXIgPSBzZXRUaW1lb3V0KGZsdXNoRXZlbnRRdWV1ZSwgMCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgc2NoZWR1bGVFdmVudEZsdXNoKCk7XG4gICAgfTtcbiAgICByZXR1cm4ge1xuICAgICAgICBlbnF1ZXVlRXZlbnQsXG4gICAgICAgIGZsdXNoRXZlbnRRdWV1ZSxcbiAgICB9O1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXZlbnQtcXVldWUuanMubWFwIiwiaW1wb3J0IHsgTUFYX0JPRFlfTEVOR1RILCBNQVhfU0VSSUFMSVpFX0FSUkFZX0lURU1TLCBNQVhfU0VSSUFMSVpFX0RFUFRILCBNQVhfU0VSSUFMSVpFX0tFWVMsIH0gZnJvbSBcIi4vY29uc3RhbnRzXCI7XG5pbXBvcnQgeyBnZXRFbGVtZW50VGFyZ2V0LCB0cnVuY2F0ZSB9IGZyb20gXCIuL3V0aWxzXCI7XG5jb25zdCBzZXJpYWxpemVQcmltaXRpdmUgPSAodmFsdWUpID0+IHtcbiAgICBpZiAodmFsdWUgPT09IG51bGwgfHxcbiAgICAgICAgdHlwZW9mIHZhbHVlID09PSBcImJvb2xlYW5cIiB8fFxuICAgICAgICB0eXBlb2YgdmFsdWUgPT09IFwibnVtYmVyXCIpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGhhbmRsZWQ6IHRydWUsXG4gICAgICAgICAgICB2YWx1ZSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgaGFuZGxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHZhbHVlOiB0cnVuY2F0ZSh2YWx1ZSksXG4gICAgICAgIH07XG4gICAgfVxuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGhhbmRsZWQ6IHRydWUsXG4gICAgICAgICAgICB2YWx1ZTogXCJbdW5kZWZpbmVkXVwiLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSBcImJpZ2ludFwiKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBoYW5kbGVkOiB0cnVlLFxuICAgICAgICAgICAgdmFsdWU6IGAke3ZhbHVlLnRvU3RyaW5nKCl9bmAsXG4gICAgICAgIH07XG4gICAgfVxuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09IFwic3ltYm9sXCIpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGhhbmRsZWQ6IHRydWUsXG4gICAgICAgICAgICB2YWx1ZTogdmFsdWUudG9TdHJpbmcoKSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBoYW5kbGVkOiB0cnVlLFxuICAgICAgICAgICAgdmFsdWU6IGBbRnVuY3Rpb24gJHt2YWx1ZS5uYW1lIHx8IFwiYW5vbnltb3VzXCJ9XWAsXG4gICAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIGhhbmRsZWQ6IGZhbHNlLFxuICAgIH07XG59O1xuY29uc3Qgc2VyaWFsaXplRXJyb3IgPSAodmFsdWUpID0+IHtcbiAgICByZXR1cm4ge1xuICAgICAgICBuYW1lOiB2YWx1ZS5uYW1lLFxuICAgICAgICBtZXNzYWdlOiB0cnVuY2F0ZSh2YWx1ZS5tZXNzYWdlKSxcbiAgICAgICAgc3RhY2s6IHR5cGVvZiB2YWx1ZS5zdGFjayA9PT0gXCJzdHJpbmdcIiA/IHRydW5jYXRlKHZhbHVlLnN0YWNrKSA6IHVuZGVmaW5lZCxcbiAgICB9O1xufTtcbmNvbnN0IGlzQXJyYXlCdWZmZXJWYWx1ZSA9ICh2YWx1ZSkgPT4ge1xuICAgIHJldHVybiB0eXBlb2YgQXJyYXlCdWZmZXIgIT09IFwidW5kZWZpbmVkXCIgJiYgdmFsdWUgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlcjtcbn07XG5jb25zdCBpc0FycmF5QnVmZmVyVmlld1ZhbHVlID0gKHZhbHVlKSA9PiB7XG4gICAgcmV0dXJuIHR5cGVvZiBBcnJheUJ1ZmZlciAhPT0gXCJ1bmRlZmluZWRcIiAmJiBBcnJheUJ1ZmZlci5pc1ZpZXcodmFsdWUpO1xufTtcbmNvbnN0IHNlcmlhbGl6ZUFycmF5ID0gKHZhbHVlLCBzdGF0ZSwgZGVwdGgsIHBhdGgsIHNlcmlhbGl6ZVZhbHVlKSA9PiB7XG4gICAgY29uc3Qgc2VyaWFsaXplZCA9IFtdO1xuICAgIGNvbnN0IGxpbWl0ID0gTWF0aC5taW4odmFsdWUubGVuZ3RoLCBNQVhfU0VSSUFMSVpFX0FSUkFZX0lURU1TKTtcbiAgICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgbGltaXQ7IGluZGV4ICs9IDEpIHtcbiAgICAgICAgc2VyaWFsaXplZC5wdXNoKHNlcmlhbGl6ZVZhbHVlKHZhbHVlW2luZGV4XSwgc3RhdGUsIGRlcHRoICsgMSwgYCR7cGF0aH1bJHtpbmRleH1dYCkpO1xuICAgIH1cbiAgICBpZiAodmFsdWUubGVuZ3RoID4gbGltaXQpIHtcbiAgICAgICAgc2VyaWFsaXplZC5wdXNoKGBbKyR7dmFsdWUubGVuZ3RoIC0gbGltaXR9IG1vcmVdYCk7XG4gICAgfVxuICAgIHJldHVybiBzZXJpYWxpemVkO1xufTtcbmNvbnN0IHNlcmlhbGl6ZU1hcCA9ICh2YWx1ZSwgc3RhdGUsIGRlcHRoLCBwYXRoLCBzZXJpYWxpemVWYWx1ZSkgPT4ge1xuICAgIGNvbnN0IGVudHJpZXMgPSBbXTtcbiAgICBsZXQgaW5kZXggPSAwO1xuICAgIGZvciAoY29uc3QgW2VudHJ5S2V5LCBlbnRyeVZhbHVlXSBvZiB2YWx1ZS5lbnRyaWVzKCkpIHtcbiAgICAgICAgaWYgKGluZGV4ID49IE1BWF9TRVJJQUxJWkVfS0VZUykge1xuICAgICAgICAgICAgZW50cmllcy5wdXNoKGBbKyR7dmFsdWUuc2l6ZSAtIGluZGV4fSBtb3JlXWApO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgZW50cmllcy5wdXNoKFtcbiAgICAgICAgICAgIHNlcmlhbGl6ZVZhbHVlKGVudHJ5S2V5LCBzdGF0ZSwgZGVwdGggKyAxLCBgJHtwYXRofS5tYXBLZXkke2luZGV4fWApLFxuICAgICAgICAgICAgc2VyaWFsaXplVmFsdWUoZW50cnlWYWx1ZSwgc3RhdGUsIGRlcHRoICsgMSwgYCR7cGF0aH0ubWFwVmFsJHtpbmRleH1gKSxcbiAgICAgICAgXSk7XG4gICAgICAgIGluZGV4ICs9IDE7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIHR5cGU6IFwiTWFwXCIsXG4gICAgICAgIGVudHJpZXMsXG4gICAgfTtcbn07XG5jb25zdCBzZXJpYWxpemVTZXQgPSAodmFsdWUsIHN0YXRlLCBkZXB0aCwgcGF0aCwgc2VyaWFsaXplVmFsdWUpID0+IHtcbiAgICBjb25zdCBlbnRyaWVzID0gW107XG4gICAgbGV0IGluZGV4ID0gMDtcbiAgICBmb3IgKGNvbnN0IGVudHJ5IG9mIHZhbHVlLnZhbHVlcygpKSB7XG4gICAgICAgIGlmIChpbmRleCA+PSBNQVhfU0VSSUFMSVpFX0tFWVMpIHtcbiAgICAgICAgICAgIGVudHJpZXMucHVzaChgWyske3ZhbHVlLnNpemUgLSBpbmRleH0gbW9yZV1gKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGVudHJpZXMucHVzaChzZXJpYWxpemVWYWx1ZShlbnRyeSwgc3RhdGUsIGRlcHRoICsgMSwgYCR7cGF0aH0uc2V0VmFsJHtpbmRleH1gKSk7XG4gICAgICAgIGluZGV4ICs9IDE7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIHR5cGU6IFwiU2V0XCIsXG4gICAgICAgIHZhbHVlczogZW50cmllcyxcbiAgICB9O1xufTtcbmNvbnN0IHNlcmlhbGl6ZVJlY29yZE9iamVjdCA9ICh2YWx1ZSwgc3RhdGUsIGRlcHRoLCBwYXRoLCBzZXJpYWxpemVWYWx1ZSkgPT4ge1xuICAgIGNvbnN0IHJlc3VsdCA9IHt9O1xuICAgIGNvbnN0IGVudHJpZXMgPSBPYmplY3QuZW50cmllcyh2YWx1ZSk7XG4gICAgY29uc3QgbGltaXQgPSBNYXRoLm1pbihlbnRyaWVzLmxlbmd0aCwgTUFYX1NFUklBTElaRV9LRVlTKTtcbiAgICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgbGltaXQ7IGluZGV4ICs9IDEpIHtcbiAgICAgICAgY29uc3QgW2VudHJ5S2V5LCBlbnRyeVZhbHVlXSA9IGVudHJpZXNbaW5kZXhdID8/IFtdO1xuICAgICAgICBpZiAodHlwZW9mIGVudHJ5S2V5ICE9PSBcInN0cmluZ1wiKSB7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICByZXN1bHRbZW50cnlLZXldID0gc2VyaWFsaXplVmFsdWUoZW50cnlWYWx1ZSwgc3RhdGUsIGRlcHRoICsgMSwgYCR7cGF0aH0uJHtlbnRyeUtleX1gKTtcbiAgICB9XG4gICAgaWYgKGVudHJpZXMubGVuZ3RoID4gbGltaXQpIHtcbiAgICAgICAgcmVzdWx0Ll9fdHJ1bmNhdGVkS2V5cyA9IGVudHJpZXMubGVuZ3RoIC0gbGltaXQ7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59O1xuY29uc3Qgb2JqZWN0U2VyaWFsaXplcnMgPSBbXG4gICAge1xuICAgICAgICBjYW5IYW5kbGU6ICh2YWx1ZSkgPT4gdmFsdWUgaW5zdGFuY2VvZiBFcnJvcixcbiAgICAgICAgc2VyaWFsaXplOiAodmFsdWUpID0+IHNlcmlhbGl6ZUVycm9yKHZhbHVlKSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgY2FuSGFuZGxlOiAodmFsdWUpID0+IHZhbHVlIGluc3RhbmNlb2YgRGF0ZSxcbiAgICAgICAgc2VyaWFsaXplOiAodmFsdWUpID0+IHZhbHVlLnRvSVNPU3RyaW5nKCksXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGNhbkhhbmRsZTogKHZhbHVlKSA9PiB2YWx1ZSBpbnN0YW5jZW9mIFJlZ0V4cCxcbiAgICAgICAgc2VyaWFsaXplOiAodmFsdWUpID0+IHZhbHVlLnRvU3RyaW5nKCksXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGNhbkhhbmRsZTogKHZhbHVlKSA9PiB0eXBlb2YgVVJMICE9PSBcInVuZGVmaW5lZFwiICYmIHZhbHVlIGluc3RhbmNlb2YgVVJMLFxuICAgICAgICBzZXJpYWxpemU6ICh2YWx1ZSkgPT4gdmFsdWUudG9TdHJpbmcoKSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgY2FuSGFuZGxlOiAodmFsdWUpID0+IHR5cGVvZiBFbGVtZW50ICE9PSBcInVuZGVmaW5lZFwiICYmIHZhbHVlIGluc3RhbmNlb2YgRWxlbWVudCxcbiAgICAgICAgc2VyaWFsaXplOiAodmFsdWUpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGVsZW1lbnQgPSB2YWx1ZTtcbiAgICAgICAgICAgIHJldHVybiBnZXRFbGVtZW50VGFyZ2V0KGVsZW1lbnQpID8/IGVsZW1lbnQudGFnTmFtZS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICB9LFxuICAgIH0sXG4gICAge1xuICAgICAgICBjYW5IYW5kbGU6ICh2YWx1ZSkgPT4gdHlwZW9mIEV2ZW50ICE9PSBcInVuZGVmaW5lZFwiICYmIHZhbHVlIGluc3RhbmNlb2YgRXZlbnQsXG4gICAgICAgIHNlcmlhbGl6ZTogKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBldmVudCA9IHZhbHVlO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICB0eXBlOiBldmVudC50eXBlLFxuICAgICAgICAgICAgICAgIHRhcmdldDogZ2V0RWxlbWVudFRhcmdldChldmVudC50YXJnZXQpLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgY2FuSGFuZGxlOiAodmFsdWUpID0+IEFycmF5LmlzQXJyYXkodmFsdWUpLFxuICAgICAgICBzZXJpYWxpemU6ICh2YWx1ZSwgc3RhdGUsIGRlcHRoLCBwYXRoLCBzZXJpYWxpemVWYWx1ZSkgPT4gc2VyaWFsaXplQXJyYXkodmFsdWUsIHN0YXRlLCBkZXB0aCwgcGF0aCwgc2VyaWFsaXplVmFsdWUpLFxuICAgIH0sXG4gICAge1xuICAgICAgICBjYW5IYW5kbGU6ICh2YWx1ZSkgPT4gdmFsdWUgaW5zdGFuY2VvZiBNYXAsXG4gICAgICAgIHNlcmlhbGl6ZTogKHZhbHVlLCBzdGF0ZSwgZGVwdGgsIHBhdGgsIHNlcmlhbGl6ZVZhbHVlKSA9PiBzZXJpYWxpemVNYXAodmFsdWUsIHN0YXRlLCBkZXB0aCwgcGF0aCwgc2VyaWFsaXplVmFsdWUpLFxuICAgIH0sXG4gICAge1xuICAgICAgICBjYW5IYW5kbGU6ICh2YWx1ZSkgPT4gdmFsdWUgaW5zdGFuY2VvZiBTZXQsXG4gICAgICAgIHNlcmlhbGl6ZTogKHZhbHVlLCBzdGF0ZSwgZGVwdGgsIHBhdGgsIHNlcmlhbGl6ZVZhbHVlKSA9PiBzZXJpYWxpemVTZXQodmFsdWUsIHN0YXRlLCBkZXB0aCwgcGF0aCwgc2VyaWFsaXplVmFsdWUpLFxuICAgIH0sXG4gICAge1xuICAgICAgICBjYW5IYW5kbGU6ICh2YWx1ZSkgPT4gaXNBcnJheUJ1ZmZlclZhbHVlKHZhbHVlKSxcbiAgICAgICAgc2VyaWFsaXplOiAodmFsdWUpID0+IGBbQXJyYXlCdWZmZXIgJHt2YWx1ZS5ieXRlTGVuZ3RofV1gLFxuICAgIH0sXG4gICAge1xuICAgICAgICBjYW5IYW5kbGU6ICh2YWx1ZSkgPT4gaXNBcnJheUJ1ZmZlclZpZXdWYWx1ZSh2YWx1ZSksXG4gICAgICAgIHNlcmlhbGl6ZTogKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBidWZmZXJWaWV3ID0gdmFsdWU7XG4gICAgICAgICAgICByZXR1cm4gYFske2J1ZmZlclZpZXcuY29uc3RydWN0b3IubmFtZX0gJHtidWZmZXJWaWV3LmJ5dGVMZW5ndGh9XWA7XG4gICAgICAgIH0sXG4gICAgfSxcbl07XG5jb25zdCBzZXJpYWxpemVLbm93bk9iamVjdCA9ICh2YWx1ZSwgc3RhdGUsIGRlcHRoLCBwYXRoLCBzZXJpYWxpemVWYWx1ZSkgPT4ge1xuICAgIGZvciAoY29uc3Qgc2VyaWFsaXplciBvZiBvYmplY3RTZXJpYWxpemVycykge1xuICAgICAgICBpZiAoIXNlcmlhbGl6ZXIuY2FuSGFuZGxlKHZhbHVlKSkge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHNlcmlhbGl6ZXIuc2VyaWFsaXplKHZhbHVlLCBzdGF0ZSwgZGVwdGgsIHBhdGgsIHNlcmlhbGl6ZVZhbHVlKTtcbiAgICB9XG4gICAgcmV0dXJuIHNlcmlhbGl6ZVJlY29yZE9iamVjdCh2YWx1ZSwgc3RhdGUsIGRlcHRoLCBwYXRoLCBzZXJpYWxpemVWYWx1ZSk7XG59O1xuY29uc3QgdG9TZXJpYWxpemFibGVWYWx1ZSA9ICh2YWx1ZSwgc3RhdGUsIGRlcHRoLCBwYXRoKSA9PiB7XG4gICAgY29uc3QgcHJpbWl0aXZlID0gc2VyaWFsaXplUHJpbWl0aXZlKHZhbHVlKTtcbiAgICBpZiAocHJpbWl0aXZlLmhhbmRsZWQpIHtcbiAgICAgICAgcmV0dXJuIHByaW1pdGl2ZS52YWx1ZTtcbiAgICB9XG4gICAgaWYgKGRlcHRoID49IE1BWF9TRVJJQUxJWkVfREVQVEgpIHtcbiAgICAgICAgcmV0dXJuIFwiW01heERlcHRoXVwiO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHZhbHVlICE9PSBcIm9iamVjdFwiIHx8IHZhbHVlID09PSBudWxsKSB7XG4gICAgICAgIHJldHVybiBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodmFsdWUpO1xuICAgIH1cbiAgICBjb25zdCBleGlzdGluZ1BhdGggPSBzdGF0ZS5zZWVuLmdldCh2YWx1ZSk7XG4gICAgaWYgKGV4aXN0aW5nUGF0aCkge1xuICAgICAgICByZXR1cm4gYFtDaXJjdWxhciB+JHtleGlzdGluZ1BhdGh9XWA7XG4gICAgfVxuICAgIHN0YXRlLnNlZW4uc2V0KHZhbHVlLCBwYXRoKTtcbiAgICByZXR1cm4gc2VyaWFsaXplS25vd25PYmplY3QodmFsdWUsIHN0YXRlLCBkZXB0aCwgcGF0aCwgdG9TZXJpYWxpemFibGVWYWx1ZSk7XG59O1xuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZVN0cmluZ2lmeVZhbHVlKHJlcG9ydGVyKSB7XG4gICAgcmV0dXJuICh2YWx1ZSkgPT4ge1xuICAgICAgICBpZiAodHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1bmNhdGUodmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT09IFwibnVtYmVyXCIgfHxcbiAgICAgICAgICAgIHR5cGVvZiB2YWx1ZSA9PT0gXCJib29sZWFuXCIgfHxcbiAgICAgICAgICAgIHZhbHVlID09PSBudWxsIHx8XG4gICAgICAgICAgICB0eXBlb2YgdmFsdWUgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICAgIHJldHVybiBTdHJpbmcodmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBzZXJpYWxpemVkID0gdG9TZXJpYWxpemFibGVWYWx1ZSh2YWx1ZSwge1xuICAgICAgICAgICAgICAgIHNlZW46IG5ldyBXZWFrTWFwKCksXG4gICAgICAgICAgICB9LCAwLCBcIiRcIik7XG4gICAgICAgICAgICBpZiAodHlwZW9mIHNlcmlhbGl6ZWQgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1bmNhdGUoc2VyaWFsaXplZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gdHJ1bmNhdGUoSlNPTi5zdHJpbmdpZnkoc2VyaWFsaXplZCkpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgcmVwb3J0ZXIucmVwb3J0Tm9uRmF0YWxFcnJvcihcIkZhaWxlZCB0byBzdHJpbmdpZnkgY29uc29sZSB2YWx1ZSBpbiBkZWJ1Z2dlciBpbnN0cnVtZW50YXRpb25cIiwgZXJyb3IpO1xuICAgICAgICAgICAgcmV0dXJuIHRydW5jYXRlKE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh2YWx1ZSkpO1xuICAgICAgICB9XG4gICAgfTtcbn1cbmV4cG9ydCBjb25zdCBnZXRSZXF1ZXN0Qm9keVByZXZpZXcgPSAoYm9keSwgc3RyaW5naWZ5VmFsdWUpID0+IHtcbiAgICBpZiAoIWJvZHkpIHtcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBib2R5ID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHJldHVybiB0cnVuY2F0ZShib2R5LCBNQVhfQk9EWV9MRU5HVEgpO1xuICAgIH1cbiAgICBpZiAoYm9keSBpbnN0YW5jZW9mIFVSTFNlYXJjaFBhcmFtcykge1xuICAgICAgICByZXR1cm4gdHJ1bmNhdGUoYm9keS50b1N0cmluZygpLCBNQVhfQk9EWV9MRU5HVEgpO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIEZvcm1EYXRhICE9PSBcInVuZGVmaW5lZFwiICYmIGJvZHkgaW5zdGFuY2VvZiBGb3JtRGF0YSkge1xuICAgICAgICBjb25zdCBrZXlzID0gW107XG4gICAgICAgIGZvciAoY29uc3Qga2V5IG9mIGJvZHkua2V5cygpKSB7XG4gICAgICAgICAgICBrZXlzLnB1c2goa2V5KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1bmNhdGUoYFtmb3JtLWRhdGFdICR7a2V5cy5qb2luKFwiLFwiKX1gLCBNQVhfQk9EWV9MRU5HVEgpO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIEJsb2IgIT09IFwidW5kZWZpbmVkXCIgJiYgYm9keSBpbnN0YW5jZW9mIEJsb2IpIHtcbiAgICAgICAgcmV0dXJuIGBbYmxvYjoke2JvZHkudHlwZSB8fCBcInVua25vd25cIn06JHtib2R5LnNpemV9XWA7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgQXJyYXlCdWZmZXIgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgaWYgKGJvZHkgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlcikge1xuICAgICAgICAgICAgcmV0dXJuIGBbYXJyYXlidWZmZXI6JHtib2R5LmJ5dGVMZW5ndGh9XWA7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKEFycmF5QnVmZmVyLmlzVmlldyhib2R5KSkge1xuICAgICAgICAgICAgcmV0dXJuIGBbJHtib2R5LmNvbnN0cnVjdG9yLm5hbWUudG9Mb3dlckNhc2UoKX06JHtib2R5LmJ5dGVMZW5ndGh9XWA7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRydW5jYXRlKHN0cmluZ2lmeVZhbHVlKGJvZHkpLCBNQVhfQk9EWV9MRU5HVEgpO1xufTtcbmV4cG9ydCBjb25zdCBzaG91bGRDYXB0dXJlVGV4dENvbnRlbnQgPSAoY29udGVudFR5cGUpID0+IHtcbiAgICBjb25zdCBub3JtYWxpemVkID0gY29udGVudFR5cGUudG9Mb3dlckNhc2UoKTtcbiAgICByZXR1cm4gKG5vcm1hbGl6ZWQuaW5jbHVkZXMoXCJqc29uXCIpIHx8XG4gICAgICAgIG5vcm1hbGl6ZWQuaW5jbHVkZXMoXCJ0ZXh0XCIpIHx8XG4gICAgICAgIG5vcm1hbGl6ZWQuaW5jbHVkZXMoXCJ4bWxcIikgfHxcbiAgICAgICAgbm9ybWFsaXplZC5pbmNsdWRlcyhcIngtd3d3LWZvcm0tdXJsZW5jb2RlZFwiKSk7XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c2VyaWFsaXplci5qcy5tYXAiLCJpbXBvcnQgeyBNQVhfSEVBREVSX05BTUVfTEVOR1RILCBNQVhfSEVBREVSX1ZBTFVFX0xFTkdUSCB9IGZyb20gXCIuL2NvbnN0YW50c1wiO1xuaW1wb3J0IHsgc2hvdWxkSGlkZUhlYWRlciB9IGZyb20gXCIuL3V0aWxzXCI7XG5leHBvcnQgY29uc3QgdG9IZWFkZXJSZWNvcmQgPSAoaW5wdXQpID0+IHtcbiAgICBpZiAoIWlucHV0KSB7XG4gICAgICAgIHJldHVybiB7fTtcbiAgICB9XG4gICAgY29uc3QgcmVzdWx0ID0ge307XG4gICAgZm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2YgaW5wdXQuZW50cmllcygpKSB7XG4gICAgICAgIGNvbnN0IG5vcm1hbGl6ZWRLZXkgPSBrZXkudHJpbSgpLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIGlmICghbm9ybWFsaXplZEtleSB8fCBzaG91bGRIaWRlSGVhZGVyKG5vcm1hbGl6ZWRLZXkpKSB7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICByZXN1bHRbbm9ybWFsaXplZEtleS5zbGljZSgwLCBNQVhfSEVBREVSX05BTUVfTEVOR1RIKV0gPSB2YWx1ZS5zbGljZSgwLCBNQVhfSEVBREVSX1ZBTFVFX0xFTkdUSCk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59O1xuZXhwb3J0IGNvbnN0IHBhcnNlUmF3SGVhZGVycyA9IChyYXdIZWFkZXJzKSA9PiB7XG4gICAgY29uc3QgcmVzdWx0ID0ge307XG4gICAgY29uc3QgbGluZXMgPSByYXdIZWFkZXJzLnNwbGl0KFwiXFxuXCIpO1xuICAgIGZvciAoY29uc3QgbGluZSBvZiBsaW5lcykge1xuICAgICAgICBjb25zdCBub3JtYWxpemVkTGluZSA9IGxpbmUucmVwbGFjZShcIlxcclwiLCBcIlwiKTtcbiAgICAgICAgY29uc3Qgc2VwYXJhdG9ySW5kZXggPSBub3JtYWxpemVkTGluZS5pbmRleE9mKFwiOlwiKTtcbiAgICAgICAgaWYgKHNlcGFyYXRvckluZGV4IDw9IDApIHtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGtleSA9IG5vcm1hbGl6ZWRMaW5lLnNsaWNlKDAsIHNlcGFyYXRvckluZGV4KS50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgaWYgKCFrZXkgfHwgc2hvdWxkSGlkZUhlYWRlcihrZXkpKSB7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB2YWx1ZSA9IG5vcm1hbGl6ZWRMaW5lLnNsaWNlKHNlcGFyYXRvckluZGV4ICsgMSkudHJpbSgpO1xuICAgICAgICBpZiAoIXZhbHVlKSB7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICByZXN1bHRba2V5LnNsaWNlKDAsIE1BWF9IRUFERVJfTkFNRV9MRU5HVEgpXSA9IHZhbHVlLnNsaWNlKDAsIE1BWF9IRUFERVJfVkFMVUVfTEVOR1RIKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1oZWFkZXJzLmpzLm1hcCIsImltcG9ydCB7IE1BWF9CT0RZX0xFTkdUSCB9IGZyb20gXCIuLi9jb25zdGFudHNcIjtcbmltcG9ydCB7IGdldFJlcXVlc3RCb2R5UHJldmlldywgc2hvdWxkQ2FwdHVyZVRleHRDb250ZW50IH0gZnJvbSBcIi4uL3NlcmlhbGl6ZXJcIjtcbmltcG9ydCB7IHNhbml0aXplQ2FwdHVyZWRCb2R5LCB0cnVuY2F0ZSB9IGZyb20gXCIuLi91dGlsc1wiO1xuZXhwb3J0IGNvbnN0IHNjaGVkdWxlQmFja2dyb3VuZFRhc2sgPSAocmVwb3J0ZXIsIHRhc2spID0+IHtcbiAgICBjb25zdCBleGVjdXRlVGFzayA9ICgpID0+IHtcbiAgICAgICAgUHJvbWlzZS5yZXNvbHZlKHRhc2soKSkuY2F0Y2goKGVycm9yKSA9PiB7XG4gICAgICAgICAgICByZXBvcnRlci5yZXBvcnROb25GYXRhbEVycm9yKFwiQmFja2dyb3VuZCBkZWJ1Z2dlciBpbnN0cnVtZW50YXRpb24gdGFzayBmYWlsZWRcIiwgZXJyb3IpO1xuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGlmICh0eXBlb2Ygd2luZG93LnJlcXVlc3RJZGxlQ2FsbGJhY2sgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICB3aW5kb3cucmVxdWVzdElkbGVDYWxsYmFjaygoKSA9PiB7XG4gICAgICAgICAgICBleGVjdXRlVGFzaygpO1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB3aW5kb3cuc2V0VGltZW91dChleGVjdXRlVGFzaywgMCk7XG59O1xuZXhwb3J0IGNvbnN0IGdldFJlcXVlc3RCb2R5UHJldmlld0FzeW5jID0gKHJlcG9ydGVyLCBib2R5LCBzdHJpbmdpZnlWYWx1ZSwgY29udGVudFR5cGUgPSBcIlwiKSA9PiB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICAgIHNjaGVkdWxlQmFja2dyb3VuZFRhc2socmVwb3J0ZXIsICgpID0+IHtcbiAgICAgICAgICAgIHJlc29sdmUoc2FuaXRpemVDYXB0dXJlZEJvZHkoZ2V0UmVxdWVzdEJvZHlQcmV2aWV3KGJvZHksIHN0cmluZ2lmeVZhbHVlKSwgY29udGVudFR5cGUpKTtcbiAgICAgICAgfSk7XG4gICAgfSk7XG59O1xuZXhwb3J0IGNvbnN0IGdldFRleHRCb2R5UHJldmlld0FzeW5jID0gKHJlcG9ydGVyLCBjb250ZW50VHlwZSwgZXJyb3JDb250ZXh0LCByZWFkQm9keSkgPT4ge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICBzY2hlZHVsZUJhY2tncm91bmRUYXNrKHJlcG9ydGVyLCBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICBpZiAoIXNob3VsZENhcHR1cmVUZXh0Q29udGVudChjb250ZW50VHlwZSkpIHtcbiAgICAgICAgICAgICAgICByZXNvbHZlKHVuZGVmaW5lZCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICByZXNvbHZlKHNhbml0aXplQ2FwdHVyZWRCb2R5KHRydW5jYXRlKGF3YWl0IHJlYWRCb2R5KCksIE1BWF9CT0RZX0xFTkdUSCksIGNvbnRlbnRUeXBlKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICByZXBvcnRlci5yZXBvcnROb25GYXRhbEVycm9yKGVycm9yQ29udGV4dCwgZXJyb3IpO1xuICAgICAgICAgICAgICAgIHJlc29sdmUodW5kZWZpbmVkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfSk7XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c2hhcmVkLmpzLm1hcCIsImltcG9ydCB7IE1BWF9CT0RZX0xFTkdUSCB9IGZyb20gXCIuLi8uLi9jb25zdGFudHNcIjtcbmltcG9ydCB7IHRvSGVhZGVyUmVjb3JkIH0gZnJvbSBcIi4uLy4uL2hlYWRlcnNcIjtcbmltcG9ydCB7IGdldFJlcXVlc3RCb2R5UHJldmlldywgc2hvdWxkQ2FwdHVyZVRleHRDb250ZW50LCB9IGZyb20gXCIuLi8uLi9zZXJpYWxpemVyXCI7XG5pbXBvcnQgeyByZWRhY3RTZW5zaXRpdmVRdWVyeVBhcmFtcywgc2FuaXRpemVDYXB0dXJlZEJvZHksIHRvQWJzb2x1dGVVcmwsIHRydW5jYXRlLCB9IGZyb20gXCIuLi8uLi91dGlsc1wiO1xuaW1wb3J0IHsgZ2V0UmVxdWVzdEJvZHlQcmV2aWV3QXN5bmMsIGdldFRleHRCb2R5UHJldmlld0FzeW5jIH0gZnJvbSBcIi4uL3NoYXJlZFwiO1xuY29uc3QgcmVzb2x2ZUZldGNoTWV0aG9kID0gKGlucHV0LCBpbml0KSA9PiB7XG4gICAgaWYgKHR5cGVvZiBpbml0Py5tZXRob2QgPT09IFwic3RyaW5nXCIgJiYgaW5pdC5tZXRob2QpIHtcbiAgICAgICAgcmV0dXJuIGluaXQubWV0aG9kLnRvVXBwZXJDYXNlKCk7XG4gICAgfVxuICAgIGlmIChpbnB1dCBpbnN0YW5jZW9mIFJlcXVlc3QpIHtcbiAgICAgICAgcmV0dXJuIGlucHV0Lm1ldGhvZC50b1VwcGVyQ2FzZSgpO1xuICAgIH1cbiAgICByZXR1cm4gXCJHRVRcIjtcbn07XG5jb25zdCByZXNvbHZlRmV0Y2hVcmwgPSAoaW5wdXQpID0+IHtcbiAgICBpZiAodHlwZW9mIGlucHV0ID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHJldHVybiBpbnB1dDtcbiAgICB9XG4gICAgaWYgKGlucHV0IGluc3RhbmNlb2YgVVJMKSB7XG4gICAgICAgIHJldHVybiBpbnB1dC50b1N0cmluZygpO1xuICAgIH1cbiAgICByZXR1cm4gaW5wdXQudXJsO1xufTtcbmNvbnN0IGdldEZldGNoUmVxdWVzdEJvZHlQcmV2aWV3ID0gYXN5bmMgKGlucHV0LCBpbml0LCByZXF1ZXN0SGVhZGVycywgc3RyaW5naWZ5VmFsdWUsIHJlcG9ydGVyKSA9PiB7XG4gICAgY29uc3QgaW5pdEJvZHlQcmV2aWV3ID0gZ2V0UmVxdWVzdEJvZHlQcmV2aWV3KGluaXQ/LmJvZHksIHN0cmluZ2lmeVZhbHVlKTtcbiAgICBpZiAoaW5pdEJvZHlQcmV2aWV3KSB7XG4gICAgICAgIHJldHVybiBpbml0Qm9keVByZXZpZXc7XG4gICAgfVxuICAgIGlmICghKGlucHV0IGluc3RhbmNlb2YgUmVxdWVzdCkpIHtcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgY29uc3QgbWV0aG9kID0gKGluaXQ/Lm1ldGhvZCA/PyBpbnB1dC5tZXRob2QgPz8gXCJHRVRcIikudG9VcHBlckNhc2UoKTtcbiAgICBpZiAobWV0aG9kID09PSBcIkdFVFwiIHx8IG1ldGhvZCA9PT0gXCJIRUFEXCIgfHwgaW5wdXQuYm9keVVzZWQpIHtcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgY29uc3QgY29udGVudFR5cGUgPSByZXF1ZXN0SGVhZGVycz8uZ2V0KFwiY29udGVudC10eXBlXCIpID8/XG4gICAgICAgIGlucHV0LmhlYWRlcnMuZ2V0KFwiY29udGVudC10eXBlXCIpID8/XG4gICAgICAgIFwiXCI7XG4gICAgaWYgKCFzaG91bGRDYXB0dXJlVGV4dENvbnRlbnQoY29udGVudFR5cGUpKSB7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBzYW5pdGl6ZUNhcHR1cmVkQm9keSh0cnVuY2F0ZShhd2FpdCBpbnB1dC5jbG9uZSgpLnRleHQoKSwgTUFYX0JPRFlfTEVOR1RIKSwgY29udGVudFR5cGUpO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmVwb3J0ZXIucmVwb3J0Tm9uRmF0YWxFcnJvcihcIkZhaWxlZCB0byBjYXB0dXJlIGZldGNoIHJlcXVlc3QgYm9keSBpbiBkZWJ1Z2dlciBpbnN0cnVtZW50YXRpb25cIiwgZXJyb3IpO1xuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbn07XG5jb25zdCByZXNvbHZlRmV0Y2hSZXF1ZXN0Qm9keVByb21pc2UgPSAocmVxdWVzdElucHV0LCByZXF1ZXN0SW5pdCwgcmVxdWVzdEhlYWRlclNvdXJjZSwgc3RyaW5naWZ5VmFsdWUsIHJlcG9ydGVyLCByZXF1ZXN0Qm9keUJ5UmVxdWVzdCkgPT4ge1xuICAgIGlmIChyZXF1ZXN0SW5wdXQgaW5zdGFuY2VvZiBSZXF1ZXN0KSB7XG4gICAgICAgIHJldHVybiAocmVxdWVzdEJvZHlCeVJlcXVlc3QuZ2V0KHJlcXVlc3RJbnB1dCkgPz9cbiAgICAgICAgICAgIGdldEZldGNoUmVxdWVzdEJvZHlQcmV2aWV3KHJlcXVlc3RJbnB1dCwgcmVxdWVzdEluaXQsIHJlcXVlc3RIZWFkZXJTb3VyY2UsIHN0cmluZ2lmeVZhbHVlLCByZXBvcnRlcikpO1xuICAgIH1cbiAgICByZXR1cm4gZ2V0RmV0Y2hSZXF1ZXN0Qm9keVByZXZpZXcocmVxdWVzdElucHV0LCByZXF1ZXN0SW5pdCwgcmVxdWVzdEhlYWRlclNvdXJjZSwgc3RyaW5naWZ5VmFsdWUsIHJlcG9ydGVyKTtcbn07XG5leHBvcnQgY29uc3QgcmVzb2x2ZUZldGNoQ29udGV4dCA9IChhcmdzLCByZXBvcnRlciwgc3RyaW5naWZ5VmFsdWUsIHJlcXVlc3RCb2R5QnlSZXF1ZXN0KSA9PiB7XG4gICAgY29uc3QgW3JlcXVlc3RJbnB1dCwgcmVxdWVzdEluaXRdID0gYXJncztcbiAgICBjb25zdCBtZXRob2QgPSByZXNvbHZlRmV0Y2hNZXRob2QocmVxdWVzdElucHV0LCByZXF1ZXN0SW5pdCk7XG4gICAgY29uc3QgdXJsID0gcmVzb2x2ZUZldGNoVXJsKHJlcXVlc3RJbnB1dCk7XG4gICAgY29uc3QgYWJzb2x1dGVVcmwgPSB0b0Fic29sdXRlVXJsKHVybCwgcmVwb3J0ZXIpO1xuICAgIGlmICghYWJzb2x1dGVVcmwpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGxldCByZXF1ZXN0SGVhZGVyU291cmNlID0gbnVsbDtcbiAgICBpZiAocmVxdWVzdEluaXQ/LmhlYWRlcnMpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJlcXVlc3RIZWFkZXJTb3VyY2UgPSBuZXcgSGVhZGVycyhyZXF1ZXN0SW5pdC5oZWFkZXJzKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHJlcG9ydGVyLnJlcG9ydE5vbkZhdGFsRXJyb3IoXCJGYWlsZWQgdG8gbm9ybWFsaXplIGZldGNoIGhlYWRlcnMgaW4gZGVidWdnZXIgaW5zdHJ1bWVudGF0aW9uXCIsIGVycm9yKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBlbHNlIGlmIChyZXF1ZXN0SW5wdXQgaW5zdGFuY2VvZiBSZXF1ZXN0KSB7XG4gICAgICAgIHJlcXVlc3RIZWFkZXJTb3VyY2UgPSByZXF1ZXN0SW5wdXQuaGVhZGVycztcbiAgICB9XG4gICAgY29uc3QgcmVxdWVzdEhlYWRlcnMgPSByZXF1ZXN0SGVhZGVyU291cmNlXG4gICAgICAgID8gdG9IZWFkZXJSZWNvcmQocmVxdWVzdEhlYWRlclNvdXJjZSlcbiAgICAgICAgOiByZXF1ZXN0SW5wdXQgaW5zdGFuY2VvZiBSZXF1ZXN0XG4gICAgICAgICAgICA/IHRvSGVhZGVyUmVjb3JkKHJlcXVlc3RJbnB1dC5oZWFkZXJzKVxuICAgICAgICAgICAgOiB7fTtcbiAgICBjb25zdCByZXF1ZXN0Q29udGVudFR5cGUgPSByZXF1ZXN0SGVhZGVyU291cmNlPy5nZXQoXCJjb250ZW50LXR5cGVcIikgPz9cbiAgICAgICAgKHJlcXVlc3RJbnB1dCBpbnN0YW5jZW9mIFJlcXVlc3RcbiAgICAgICAgICAgID8gKHJlcXVlc3RJbnB1dC5oZWFkZXJzLmdldChcImNvbnRlbnQtdHlwZVwiKSA/PyBcIlwiKVxuICAgICAgICAgICAgOiBcIlwiKTtcbiAgICBjb25zdCByZXF1ZXN0Qm9keVByb21pc2UgPSByZXNvbHZlRmV0Y2hSZXF1ZXN0Qm9keVByb21pc2UocmVxdWVzdElucHV0LCByZXF1ZXN0SW5pdCwgcmVxdWVzdEhlYWRlclNvdXJjZSwgc3RyaW5naWZ5VmFsdWUsIHJlcG9ydGVyLCByZXF1ZXN0Qm9keUJ5UmVxdWVzdCk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgbWV0aG9kLFxuICAgICAgICBub3JtYWxpemVkVXJsOiByZWRhY3RTZW5zaXRpdmVRdWVyeVBhcmFtcyhhYnNvbHV0ZVVybCksXG4gICAgICAgIHJlcXVlc3RIZWFkZXJzLFxuICAgICAgICByZXF1ZXN0Q29udGVudFR5cGUsXG4gICAgICAgIHJlcXVlc3RCb2R5UHJvbWlzZSxcbiAgICB9O1xufTtcbmV4cG9ydCBjb25zdCBpbnN0YWxsUmVxdWVzdENvbnN0cnVjdG9yQ2FwdHVyZSA9IChyZXBvcnRlciwgc3RyaW5naWZ5VmFsdWUsIHJlcXVlc3RCb2R5QnlSZXF1ZXN0KSA9PiB7XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cuUmVxdWVzdCAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgT3JpZ2luYWxSZXF1ZXN0ID0gd2luZG93LlJlcXVlc3Q7XG4gICAgY29uc3QgcGF0Y2hlZFJlcXVlc3QgPSBuZXcgUHJveHkoT3JpZ2luYWxSZXF1ZXN0LCB7XG4gICAgICAgIGNvbnN0cnVjdCh0YXJnZXQsIGFyZ0FycmF5LCBuZXdUYXJnZXQpIHtcbiAgICAgICAgICAgIGNvbnN0IFssIHJlcXVlc3RJbml0XSA9IGFyZ0FycmF5O1xuICAgICAgICAgICAgY29uc3QgcmVxdWVzdEluc3RhbmNlID0gUmVmbGVjdC5jb25zdHJ1Y3QodGFyZ2V0LCBhcmdBcnJheSwgbmV3VGFyZ2V0KTtcbiAgICAgICAgICAgIGxldCByZXF1ZXN0SGVhZGVyU291cmNlO1xuICAgICAgICAgICAgaWYgKHJlcXVlc3RJbml0Py5oZWFkZXJzICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICByZXF1ZXN0SGVhZGVyU291cmNlID0gbmV3IEhlYWRlcnMocmVxdWVzdEluaXQuaGVhZGVycyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICByZXBvcnRlci5yZXBvcnROb25GYXRhbEVycm9yKFwiRmFpbGVkIHRvIG5vcm1hbGl6ZSBSZXF1ZXN0IGhlYWRlcnMgaW4gZGVidWdnZXIgaW5zdHJ1bWVudGF0aW9uXCIsIGVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgcmVxdWVzdEhlYWRlclNvdXJjZSA9IHJlcXVlc3RJbnN0YW5jZS5oZWFkZXJzO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHJlcXVlc3RIZWFkZXJTb3VyY2UgPSByZXF1ZXN0SW5zdGFuY2UuaGVhZGVycztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGNvbnRlbnRUeXBlID0gcmVxdWVzdEhlYWRlclNvdXJjZS5nZXQoXCJjb250ZW50LXR5cGVcIikgPz8gXCJcIjtcbiAgICAgICAgICAgIGNvbnN0IHJlcXVlc3RCb2R5UHJvbWlzZSA9IHJlcXVlc3RJbml0Py5ib2R5ICE9PSB1bmRlZmluZWRcbiAgICAgICAgICAgICAgICA/IGdldFJlcXVlc3RCb2R5UHJldmlld0FzeW5jKHJlcG9ydGVyLCByZXF1ZXN0SW5pdC5ib2R5LCBzdHJpbmdpZnlWYWx1ZSwgY29udGVudFR5cGUpXG4gICAgICAgICAgICAgICAgOiBnZXRUZXh0Qm9keVByZXZpZXdBc3luYyhyZXBvcnRlciwgY29udGVudFR5cGUsIFwiRmFpbGVkIHRvIGNhcHR1cmUgUmVxdWVzdCBib2R5IHRleHQgaW4gZGVidWdnZXIgaW5zdHJ1bWVudGF0aW9uXCIsICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJlcXVlc3RJbnN0YW5jZS5ib2R5VXNlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShcIlwiKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVxdWVzdEluc3RhbmNlLmNsb25lKCkudGV4dCgpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmVxdWVzdEJvZHlCeVJlcXVlc3Quc2V0KHJlcXVlc3RJbnN0YW5jZSwgcmVxdWVzdEJvZHlQcm9taXNlKTtcbiAgICAgICAgICAgIHJldHVybiByZXF1ZXN0SW5zdGFuY2U7XG4gICAgICAgIH0sXG4gICAgfSk7XG4gICAgdHJ5IHtcbiAgICAgICAgT2JqZWN0LmFzc2lnbihwYXRjaGVkUmVxdWVzdCwgT3JpZ2luYWxSZXF1ZXN0KTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJlcG9ydGVyLnJlcG9ydE5vbkZhdGFsRXJyb3IoXCJGYWlsZWQgdG8gbWlycm9yIFJlcXVlc3QgY29uc3RydWN0b3IgcHJvcGVydGllcyBpbiBkZWJ1Z2dlciBpbnN0cnVtZW50YXRpb25cIiwgZXJyb3IpO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgICB3aW5kb3cuUmVxdWVzdCA9IHBhdGNoZWRSZXF1ZXN0O1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmVwb3J0ZXIucmVwb3J0Tm9uRmF0YWxFcnJvcihcIkZhaWxlZCB0byBwYXRjaCBSZXF1ZXN0IGNvbnN0cnVjdG9yIGluIGRlYnVnZ2VyIGluc3RydW1lbnRhdGlvblwiLCBlcnJvcik7XG4gICAgfVxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNvbnRleHQuanMubWFwIiwiaW1wb3J0IHsgTUFYX0JPRFlfTEVOR1RIIH0gZnJvbSBcIi4uLy4uL2NvbnN0YW50c1wiO1xuaW1wb3J0IHsgdG9IZWFkZXJSZWNvcmQgfSBmcm9tIFwiLi4vLi4vaGVhZGVyc1wiO1xuaW1wb3J0IHsgc2hvdWxkQ2FwdHVyZVRleHRDb250ZW50IH0gZnJvbSBcIi4uLy4uL3NlcmlhbGl6ZXJcIjtcbmltcG9ydCB7IHNhbml0aXplQ2FwdHVyZWRCb2R5LCB0cnVuY2F0ZSB9IGZyb20gXCIuLi8uLi91dGlsc1wiO1xuaW1wb3J0IHsgZ2V0VGV4dEJvZHlQcmV2aWV3QXN5bmMsIHNjaGVkdWxlQmFja2dyb3VuZFRhc2sgfSBmcm9tIFwiLi4vc2hhcmVkXCI7XG5jb25zdCBjbG9uZUZldGNoUmVzcG9uc2VGb3JDYXB0dXJlID0gKHJlc3BvbnNlLCByZXBvcnRlcikgPT4ge1xuICAgIGNvbnN0IGNvbnRlbnRUeXBlID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoXCJjb250ZW50LXR5cGVcIikgPz8gXCJcIjtcbiAgICBpZiAoIXNob3VsZENhcHR1cmVUZXh0Q29udGVudChjb250ZW50VHlwZSkgfHwgcmVzcG9uc2UuYm9keVVzZWQpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGNvbnRlbnRUeXBlLFxuICAgICAgICAgICAgcmVzcG9uc2VDbG9uZTogbnVsbCxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGNvbnRlbnRUeXBlLFxuICAgICAgICAgICAgcmVzcG9uc2VDbG9uZTogcmVzcG9uc2UuY2xvbmUoKSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJlcG9ydGVyLnJlcG9ydE5vbkZhdGFsRXJyb3IoXCJGYWlsZWQgdG8gY2xvbmUgZmV0Y2ggcmVzcG9uc2UgYm9keSBpbiBkZWJ1Z2dlciBpbnN0cnVtZW50YXRpb25cIiwgZXJyb3IpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgY29udGVudFR5cGUsXG4gICAgICAgICAgICByZXNwb25zZUNsb25lOiBudWxsLFxuICAgICAgICB9O1xuICAgIH1cbn07XG5leHBvcnQgY29uc3Qgc2NoZWR1bGVGZXRjaFN1Y2Nlc3NQb3N0ID0gKHJlcG9ydGVyLCBwb3N0TmV0d29yaywgY29udGV4dCwgcmVzcG9uc2UsIGR1cmF0aW9uKSA9PiB7XG4gICAgY29uc3QgcmVzcG9uc2VIZWFkZXJzID0gdG9IZWFkZXJSZWNvcmQocmVzcG9uc2UuaGVhZGVycyk7XG4gICAgY29uc3QgeyBjb250ZW50VHlwZSwgcmVzcG9uc2VDbG9uZSB9ID0gY2xvbmVGZXRjaFJlc3BvbnNlRm9yQ2FwdHVyZShyZXNwb25zZSwgcmVwb3J0ZXIpO1xuICAgIHNjaGVkdWxlQmFja2dyb3VuZFRhc2socmVwb3J0ZXIsIGFzeW5jICgpID0+IHtcbiAgICAgICAgbGV0IHJlcXVlc3RCb2R5O1xuICAgICAgICBsZXQgcmVzcG9uc2VCb2R5O1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgcmVxdWVzdEJvZHkgPSBhd2FpdCBjb250ZXh0LnJlcXVlc3RCb2R5UHJvbWlzZTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHJlcG9ydGVyLnJlcG9ydE5vbkZhdGFsRXJyb3IoXCJGYWlsZWQgdG8gcmVzb2x2ZSBmZXRjaCByZXF1ZXN0IGJvZHkgaW4gZGVidWdnZXIgaW5zdHJ1bWVudGF0aW9uXCIsIGVycm9yKTtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgcmVzcG9uc2VCb2R5ID0gYXdhaXQgZ2V0VGV4dEJvZHlQcmV2aWV3QXN5bmMocmVwb3J0ZXIsIGNvbnRlbnRUeXBlLCBcIkZhaWxlZCB0byBjYXB0dXJlIGZldGNoIHJlc3BvbnNlIGJvZHkgdGV4dCBpbiBkZWJ1Z2dlciBpbnN0cnVtZW50YXRpb25cIiwgKCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmICghcmVzcG9uc2VDbG9uZSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKFwiXCIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2VDbG9uZS50ZXh0KCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHJlcG9ydGVyLnJlcG9ydE5vbkZhdGFsRXJyb3IoXCJGYWlsZWQgdG8gY2FwdHVyZSBmZXRjaCByZXNwb25zZSBib2R5IGluIGRlYnVnZ2VyIGluc3RydW1lbnRhdGlvblwiLCBlcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgcG9zdE5ldHdvcmsoe1xuICAgICAgICAgICAgbWV0aG9kOiBjb250ZXh0Lm1ldGhvZCxcbiAgICAgICAgICAgIHVybDogY29udGV4dC5ub3JtYWxpemVkVXJsLFxuICAgICAgICAgICAgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMsXG4gICAgICAgICAgICBkdXJhdGlvbixcbiAgICAgICAgICAgIHJlcXVlc3RIZWFkZXJzOiBjb250ZXh0LnJlcXVlc3RIZWFkZXJzLFxuICAgICAgICAgICAgcmVzcG9uc2VIZWFkZXJzLFxuICAgICAgICAgICAgcmVxdWVzdEJvZHk6IHNhbml0aXplQ2FwdHVyZWRCb2R5KHJlcXVlc3RCb2R5LCBjb250ZXh0LnJlcXVlc3RDb250ZW50VHlwZSksXG4gICAgICAgICAgICByZXNwb25zZUJvZHk6IHNhbml0aXplQ2FwdHVyZWRCb2R5KHJlc3BvbnNlQm9keSwgY29udGVudFR5cGUpLFxuICAgICAgICB9KTtcbiAgICB9KTtcbn07XG5leHBvcnQgY29uc3Qgc2NoZWR1bGVGZXRjaEZhaWx1cmVQb3N0ID0gKHJlcG9ydGVyLCBwb3N0TmV0d29yaywgY29udGV4dCwgZXJyb3IsIHN0YXJ0ZWRBdCwgc3RyaW5naWZ5VmFsdWUpID0+IHtcbiAgICBzY2hlZHVsZUJhY2tncm91bmRUYXNrKHJlcG9ydGVyLCBhc3luYyAoKSA9PiB7XG4gICAgICAgIGxldCByZXF1ZXN0Qm9keTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJlcXVlc3RCb2R5ID0gYXdhaXQgY29udGV4dC5yZXF1ZXN0Qm9keVByb21pc2U7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKF9yZXF1ZXN0Qm9keUVycm9yKSB7XG4gICAgICAgICAgICByZXF1ZXN0Qm9keSA9IHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgICBwb3N0TmV0d29yayh7XG4gICAgICAgICAgICBtZXRob2Q6IGNvbnRleHQubWV0aG9kLFxuICAgICAgICAgICAgdXJsOiBjb250ZXh0Lm5vcm1hbGl6ZWRVcmwsXG4gICAgICAgICAgICBzdGF0dXM6IDAsXG4gICAgICAgICAgICBkdXJhdGlvbjogRGF0ZS5ub3coKSAtIHN0YXJ0ZWRBdCxcbiAgICAgICAgICAgIHJlcXVlc3RIZWFkZXJzOiBjb250ZXh0LnJlcXVlc3RIZWFkZXJzLFxuICAgICAgICAgICAgcmVxdWVzdEJvZHk6IHNhbml0aXplQ2FwdHVyZWRCb2R5KHJlcXVlc3RCb2R5LCBjb250ZXh0LnJlcXVlc3RDb250ZW50VHlwZSksXG4gICAgICAgICAgICByZXNwb25zZUJvZHk6IHNhbml0aXplQ2FwdHVyZWRCb2R5KHRydW5jYXRlKHN0cmluZ2lmeVZhbHVlKGVycm9yKSwgTUFYX0JPRFlfTEVOR1RIKSwgXCJcIiksXG4gICAgICAgIH0pO1xuICAgIH0pO1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBvc3QuanMubWFwIiwiaW1wb3J0IHsgY3JlYXRlU3RyaW5naWZ5VmFsdWUgfSBmcm9tIFwiLi4vLi4vc2VyaWFsaXplclwiO1xuaW1wb3J0IHsgdHJ1bmNhdGUgfSBmcm9tIFwiLi4vLi4vdXRpbHNcIjtcbmltcG9ydCB7IGluc3RhbGxSZXF1ZXN0Q29uc3RydWN0b3JDYXB0dXJlLCByZXNvbHZlRmV0Y2hDb250ZXh0LCB9IGZyb20gXCIuL2NvbnRleHRcIjtcbmltcG9ydCB7IHNjaGVkdWxlRmV0Y2hGYWlsdXJlUG9zdCwgc2NoZWR1bGVGZXRjaFN1Y2Nlc3NQb3N0IH0gZnJvbSBcIi4vcG9zdFwiO1xuZXhwb3J0IGNvbnN0IGluc3RhbGxGZXRjaENhcHR1cmUgPSAoaW5wdXQpID0+IHtcbiAgICBjb25zdCB7IGRpYWdub3N0aWNzLCBwb3N0TmV0d29yaywgcmVwb3J0ZXIgfSA9IGlucHV0O1xuICAgIGNvbnN0IHN0cmluZ2lmeVZhbHVlID0gY3JlYXRlU3RyaW5naWZ5VmFsdWUocmVwb3J0ZXIpO1xuICAgIGNvbnN0IHJlcXVlc3RCb2R5QnlSZXF1ZXN0ID0gbmV3IFdlYWtNYXAoKTtcbiAgICBjb25zdCBiaW5kRmV0Y2ggPSAoY2FuZGlkYXRlKSA9PiB7XG4gICAgICAgIHJldHVybiBjYW5kaWRhdGUuYmluZCh3aW5kb3cpO1xuICAgIH07XG4gICAgaW5zdGFsbFJlcXVlc3RDb25zdHJ1Y3RvckNhcHR1cmUocmVwb3J0ZXIsIHN0cmluZ2lmeVZhbHVlLCByZXF1ZXN0Qm9keUJ5UmVxdWVzdCk7XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cuZmV0Y2ggIT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICBkaWFnbm9zdGljcy5zZXRGZXRjaEhvb2tTdGF0ZShcImZhaWxlZFwiKTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBiYXNlRmV0Y2ggPSBiaW5kRmV0Y2god2luZG93LmZldGNoKTtcbiAgICBsZXQgZGVsZWdhdGVGZXRjaCA9IGJhc2VGZXRjaDtcbiAgICBsZXQgaXNJbnNpZGVQYXRjaGVkRmV0Y2ggPSBmYWxzZTtcbiAgICBjb25zdCBwYXRjaGVkRmV0Y2ggPSAoYXN5bmMgKC4uLmFyZ3MpID0+IHtcbiAgICAgICAgaWYgKGlzSW5zaWRlUGF0Y2hlZEZldGNoKSB7XG4gICAgICAgICAgICAvLyBQcmV2ZW50IHJlY3Vyc2lvbiB3aGVuIHRoaXJkLXBhcnR5IGZldGNoIHdyYXBwZXJzIGNhbGwgd2luZG93LmZldGNoKCkuXG4gICAgICAgICAgICByZXR1cm4gYmFzZUZldGNoKC4uLmFyZ3MpO1xuICAgICAgICB9XG4gICAgICAgIGlzSW5zaWRlUGF0Y2hlZEZldGNoID0gdHJ1ZTtcbiAgICAgICAgZGlhZ25vc3RpY3MucmVjb3JkRmV0Y2hDYWxsKCk7XG4gICAgICAgIGNvbnN0IHN0YXJ0ZWRBdCA9IERhdGUubm93KCk7XG4gICAgICAgIGNvbnN0IGNvbnRleHQgPSByZXNvbHZlRmV0Y2hDb250ZXh0KGFyZ3MsIHJlcG9ydGVyLCBzdHJpbmdpZnlWYWx1ZSwgcmVxdWVzdEJvZHlCeVJlcXVlc3QpO1xuICAgICAgICBpZiAoIWNvbnRleHQpIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGRlbGVnYXRlRmV0Y2goLi4uYXJncyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICBpc0luc2lkZVBhdGNoZWRGZXRjaCA9IGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGRlbGVnYXRlRmV0Y2goLi4uYXJncyk7XG4gICAgICAgICAgICBjb25zdCBkdXJhdGlvbiA9IERhdGUubm93KCkgLSBzdGFydGVkQXQ7XG4gICAgICAgICAgICBzY2hlZHVsZUZldGNoU3VjY2Vzc1Bvc3QocmVwb3J0ZXIsIHBvc3ROZXR3b3JrLCBjb250ZXh0LCByZXNwb25zZSwgZHVyYXRpb24pO1xuICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgZGlhZ25vc3RpY3MucmVjb3JkRmV0Y2hGYWlsdXJlKHRydW5jYXRlKHN0cmluZ2lmeVZhbHVlKGVycm9yKSwgMzAwKSk7XG4gICAgICAgICAgICBzY2hlZHVsZUZldGNoRmFpbHVyZVBvc3QocmVwb3J0ZXIsIHBvc3ROZXR3b3JrLCBjb250ZXh0LCBlcnJvciwgc3RhcnRlZEF0LCBzdHJpbmdpZnlWYWx1ZSk7XG4gICAgICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICAgICAgfVxuICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgIGlzSW5zaWRlUGF0Y2hlZEZldGNoID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICB0cnkge1xuICAgICAgICBPYmplY3QuYXNzaWduKHBhdGNoZWRGZXRjaCwgd2luZG93LmZldGNoKTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJlcG9ydGVyLnJlcG9ydE5vbkZhdGFsRXJyb3IoXCJGYWlsZWQgdG8gbWlycm9yIGZldGNoIHByb3BlcnRpZXMgaW4gZGVidWdnZXIgaW5zdHJ1bWVudGF0aW9uXCIsIGVycm9yKTtcbiAgICB9XG4gICAgY29uc3QgZmV0Y2hEZXNjcmlwdG9yID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih3aW5kb3csIFwiZmV0Y2hcIik7XG4gICAgY29uc3QgY2FuUmVkZWZpbmVGZXRjaCA9ICFmZXRjaERlc2NyaXB0b3IgfHwgZmV0Y2hEZXNjcmlwdG9yLmNvbmZpZ3VyYWJsZTtcbiAgICBpZiAoY2FuUmVkZWZpbmVGZXRjaCkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHdpbmRvdywgXCJmZXRjaFwiLCB7XG4gICAgICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgICAgIGVudW1lcmFibGU6IGZldGNoRGVzY3JpcHRvcj8uZW51bWVyYWJsZSA/PyB0cnVlLFxuICAgICAgICAgICAgICAgIGdldCgpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHBhdGNoZWRGZXRjaDtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHNldChuZXh0RmV0Y2gpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBuZXh0RmV0Y2ggIT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmIChuZXh0RmV0Y2ggPT09IHBhdGNoZWRGZXRjaCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGRlbGVnYXRlRmV0Y2ggPSBiaW5kRmV0Y2gobmV4dEZldGNoKTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBkaWFnbm9zdGljcy5zZXRGZXRjaEhvb2tTdGF0ZShcImFjY2Vzc29yXCIpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgcmVwb3J0ZXIucmVwb3J0Tm9uRmF0YWxFcnJvcihcIkZhaWxlZCB0byBpbnN0YWxsIGZldGNoIGFjY2Vzc29yIGluIGRlYnVnZ2VyIGluc3RydW1lbnRhdGlvblwiLCBlcnJvcik7XG4gICAgICAgIH1cbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgICAgd2luZG93LmZldGNoID0gcGF0Y2hlZEZldGNoO1xuICAgICAgICBkaWFnbm9zdGljcy5zZXRGZXRjaEhvb2tTdGF0ZShcImFzc2lnbm1lbnRcIik7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICBkaWFnbm9zdGljcy5zZXRGZXRjaEhvb2tTdGF0ZShcImZhaWxlZFwiKTtcbiAgICAgICAgcmVwb3J0ZXIucmVwb3J0Tm9uRmF0YWxFcnJvcihcIkZhaWxlZCB0byBwYXRjaCBmZXRjaCBpbiBkZWJ1Z2dlciBpbnN0cnVtZW50YXRpb25cIiwgZXJyb3IpO1xuICAgIH1cbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbnN0YWxsLmpzLm1hcCIsImltcG9ydCB7IE1BWF9CT0RZX0xFTkdUSCwgTUFYX0hFQURFUl9OQU1FX0xFTkdUSCwgTUFYX0hFQURFUl9WQUxVRV9MRU5HVEgsIH0gZnJvbSBcIi4uL2NvbnN0YW50c1wiO1xuaW1wb3J0IHsgcGFyc2VSYXdIZWFkZXJzIH0gZnJvbSBcIi4uL2hlYWRlcnNcIjtcbmltcG9ydCB7IGNyZWF0ZVN0cmluZ2lmeVZhbHVlIH0gZnJvbSBcIi4uL3NlcmlhbGl6ZXJcIjtcbmltcG9ydCB7IHJlZGFjdFNlbnNpdGl2ZVF1ZXJ5UGFyYW1zLCBzYW5pdGl6ZUNhcHR1cmVkQm9keSwgc2hvdWxkSGlkZUhlYWRlciwgdG9BYnNvbHV0ZVVybCwgdHJ1bmNhdGUsIH0gZnJvbSBcIi4uL3V0aWxzXCI7XG5pbXBvcnQgeyBnZXRSZXF1ZXN0Qm9keVByZXZpZXdBc3luYywgc2NoZWR1bGVCYWNrZ3JvdW5kVGFzayB9IGZyb20gXCIuL3NoYXJlZFwiO1xuZXhwb3J0IGNvbnN0IGluc3RhbGxYaHJDYXB0dXJlID0gKGlucHV0KSA9PiB7XG4gICAgY29uc3QgeyBkaWFnbm9zdGljcywgcG9zdE5ldHdvcmssIHJlcG9ydGVyIH0gPSBpbnB1dDtcbiAgICBjb25zdCBzdHJpbmdpZnlWYWx1ZSA9IGNyZWF0ZVN0cmluZ2lmeVZhbHVlKHJlcG9ydGVyKTtcbiAgICBjb25zdCB4aHJNZXRhTWFwID0gbmV3IFdlYWtNYXAoKTtcbiAgICBjb25zdCBidWlsZFhoclBvc3RQYXlsb2FkID0gYXN5bmMgKHhocikgPT4ge1xuICAgICAgICBjb25zdCBzdGF0ZSA9IHhock1ldGFNYXAuZ2V0KHhocik7XG4gICAgICAgIGlmICghc3RhdGUpIHtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG5vcm1hbGl6ZWRVcmwgPSB0b0Fic29sdXRlVXJsKHN0YXRlLnVybCwgcmVwb3J0ZXIpO1xuICAgICAgICBpZiAoIW5vcm1hbGl6ZWRVcmwpIHtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJlZGFjdGVkVXJsID0gcmVkYWN0U2Vuc2l0aXZlUXVlcnlQYXJhbXMobm9ybWFsaXplZFVybCk7XG4gICAgICAgIGxldCByZXF1ZXN0Qm9keTtcbiAgICAgICAgbGV0IHJlc3BvbnNlQm9keTtcbiAgICAgICAgY29uc3QgcmVzcG9uc2VIZWFkZXJzID0gcGFyc2VSYXdIZWFkZXJzKHhoci5nZXRBbGxSZXNwb25zZUhlYWRlcnMoKSk7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlQ29udGVudFR5cGUgPSByZXNwb25zZUhlYWRlcnNbXCJjb250ZW50LXR5cGVcIl0gPz8gXCJcIjtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJlcXVlc3RCb2R5ID0gYXdhaXQgc3RhdGUucmVxdWVzdEJvZHlQcm9taXNlO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChfcmVxdWVzdEJvZHlFcnJvcikge1xuICAgICAgICAgICAgcmVxdWVzdEJvZHkgPSB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGlmICh4aHIucmVzcG9uc2VUeXBlID09PSBcIlwiIHx8IHhoci5yZXNwb25zZVR5cGUgPT09IFwidGV4dFwiKSB7XG4gICAgICAgICAgICAgICAgcmVzcG9uc2VCb2R5ID0gdHJ1bmNhdGUoeGhyLnJlc3BvbnNlVGV4dCB8fCBcIlwiLCBNQVhfQk9EWV9MRU5HVEgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoeGhyLnJlc3BvbnNlVHlwZSA9PT0gXCJqc29uXCIpIHtcbiAgICAgICAgICAgICAgICByZXNwb25zZUJvZHkgPSB0cnVuY2F0ZShzdHJpbmdpZnlWYWx1ZSh4aHIucmVzcG9uc2UpLCBNQVhfQk9EWV9MRU5HVEgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgcmVwb3J0ZXIucmVwb3J0Tm9uRmF0YWxFcnJvcihcIkZhaWxlZCB0byBjYXB0dXJlIFhIUiByZXNwb25zZSBib2R5IGluIGRlYnVnZ2VyIGluc3RydW1lbnRhdGlvblwiLCBlcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIG1ldGhvZDogc3RhdGUubWV0aG9kLFxuICAgICAgICAgICAgdXJsOiByZWRhY3RlZFVybCxcbiAgICAgICAgICAgIHN0YXR1czogeGhyLnN0YXR1cyxcbiAgICAgICAgICAgIGR1cmF0aW9uOiBEYXRlLm5vdygpIC0gc3RhdGUuc3RhcnRlZEF0LFxuICAgICAgICAgICAgcmVxdWVzdEhlYWRlcnM6IHN0YXRlLnJlcXVlc3RIZWFkZXJzLFxuICAgICAgICAgICAgcmVzcG9uc2VIZWFkZXJzLFxuICAgICAgICAgICAgcmVxdWVzdEJvZHk6IHNhbml0aXplQ2FwdHVyZWRCb2R5KHJlcXVlc3RCb2R5LCBzdGF0ZS5yZXF1ZXN0SGVhZGVyc1tcImNvbnRlbnQtdHlwZVwiXSA/PyBcIlwiKSxcbiAgICAgICAgICAgIHJlc3BvbnNlQm9keTogc2FuaXRpemVDYXB0dXJlZEJvZHkocmVzcG9uc2VCb2R5LCByZXNwb25zZUNvbnRlbnRUeXBlKSxcbiAgICAgICAgfTtcbiAgICB9O1xuICAgIGNvbnN0IHBvc3RYaHJMb2FkRW5kRXZlbnQgPSAoeGhyKSA9PiB7XG4gICAgICAgIHNjaGVkdWxlQmFja2dyb3VuZFRhc2socmVwb3J0ZXIsIGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHBheWxvYWQgPSBhd2FpdCBidWlsZFhoclBvc3RQYXlsb2FkKHhocik7XG4gICAgICAgICAgICBpZiAoIXBheWxvYWQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBwb3N0TmV0d29yayhwYXlsb2FkKTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCBvcmlnaW5hbE9wZW4gPSBYTUxIdHRwUmVxdWVzdC5wcm90b3R5cGUub3BlbjtcbiAgICBjb25zdCBvcGVuV2l0aE9wdGlvbmFsQXJncyA9IG9yaWdpbmFsT3BlbjtcbiAgICBYTUxIdHRwUmVxdWVzdC5wcm90b3R5cGUub3BlbiA9IGZ1bmN0aW9uIChtZXRob2QsIHVybCwgYXN5bmMsIHVzZXJuYW1lLCBwYXNzd29yZCkge1xuICAgICAgICBjb25zdCBub3JtYWxpemVkTWV0aG9kID0gdHlwZW9mIG1ldGhvZCA9PT0gXCJzdHJpbmdcIiA/IG1ldGhvZCA6IFwiR0VUXCI7XG4gICAgICAgIGNvbnN0IG5vcm1hbGl6ZWRVcmwgPSB0eXBlb2YgdXJsID09PSBcInN0cmluZ1wiID8gdXJsIDogU3RyaW5nKHVybCA/PyBcIlwiKTtcbiAgICAgICAgeGhyTWV0YU1hcC5zZXQodGhpcywge1xuICAgICAgICAgICAgbWV0aG9kOiBub3JtYWxpemVkTWV0aG9kLFxuICAgICAgICAgICAgdXJsOiBub3JtYWxpemVkVXJsLFxuICAgICAgICAgICAgc3RhcnRlZEF0OiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgcmVxdWVzdEJvZHlQcm9taXNlOiBQcm9taXNlLnJlc29sdmUodW5kZWZpbmVkKSxcbiAgICAgICAgICAgIHJlcXVlc3RIZWFkZXJzOiB7fSxcbiAgICAgICAgfSk7XG4gICAgICAgIGlmICh0eXBlb2YgYXN5bmMgPT09IFwiYm9vbGVhblwiIHx8XG4gICAgICAgICAgICB0eXBlb2YgdXNlcm5hbWUgPT09IFwic3RyaW5nXCIgfHxcbiAgICAgICAgICAgIHVzZXJuYW1lID09PSBudWxsIHx8XG4gICAgICAgICAgICB0eXBlb2YgcGFzc3dvcmQgPT09IFwic3RyaW5nXCIgfHxcbiAgICAgICAgICAgIHBhc3N3b3JkID09PSBudWxsKSB7XG4gICAgICAgICAgICByZXR1cm4gb3BlbldpdGhPcHRpb25hbEFyZ3MuY2FsbCh0aGlzLCBtZXRob2QsIHVybCwgYXN5bmMgPz8gdHJ1ZSwgdXNlcm5hbWUsIHBhc3N3b3JkKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gb3BlbldpdGhPcHRpb25hbEFyZ3MuY2FsbCh0aGlzLCBtZXRob2QsIHVybCk7XG4gICAgfTtcbiAgICBjb25zdCBvcmlnaW5hbFNldFJlcXVlc3RIZWFkZXIgPSBYTUxIdHRwUmVxdWVzdC5wcm90b3R5cGUuc2V0UmVxdWVzdEhlYWRlcjtcbiAgICBYTUxIdHRwUmVxdWVzdC5wcm90b3R5cGUuc2V0UmVxdWVzdEhlYWRlciA9IGZ1bmN0aW9uICguLi5hcmdzKSB7XG4gICAgICAgIGNvbnN0IFtrZXksIHZhbHVlXSA9IGFyZ3M7XG4gICAgICAgIGNvbnN0IG1ldGEgPSB4aHJNZXRhTWFwLmdldCh0aGlzKTtcbiAgICAgICAgaWYgKG1ldGEpIHtcbiAgICAgICAgICAgIGNvbnN0IG5vcm1hbGl6ZWRLZXkgPSBrZXkudHJpbSgpLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgICAgICBpZiAoIXNob3VsZEhpZGVIZWFkZXIobm9ybWFsaXplZEtleSkpIHtcbiAgICAgICAgICAgICAgICBtZXRhLnJlcXVlc3RIZWFkZXJzW25vcm1hbGl6ZWRLZXkuc2xpY2UoMCwgTUFYX0hFQURFUl9OQU1FX0xFTkdUSCldID1cbiAgICAgICAgICAgICAgICAgICAgdmFsdWUuc2xpY2UoMCwgTUFYX0hFQURFUl9WQUxVRV9MRU5HVEgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBvcmlnaW5hbFNldFJlcXVlc3RIZWFkZXIuYXBwbHkodGhpcywgYXJncyk7XG4gICAgfTtcbiAgICBjb25zdCBvcmlnaW5hbFNlbmQgPSBYTUxIdHRwUmVxdWVzdC5wcm90b3R5cGUuc2VuZDtcbiAgICBYTUxIdHRwUmVxdWVzdC5wcm90b3R5cGUuc2VuZCA9IGZ1bmN0aW9uICguLi5hcmdzKSB7XG4gICAgICAgIGRpYWdub3N0aWNzLnJlY29yZFhockNhbGwoKTtcbiAgICAgICAgY29uc3QgbWV0YSA9IHhock1ldGFNYXAuZ2V0KHRoaXMpO1xuICAgICAgICBpZiAobWV0YSkge1xuICAgICAgICAgICAgbWV0YS5zdGFydGVkQXQgPSBEYXRlLm5vdygpO1xuICAgICAgICAgICAgbWV0YS5yZXF1ZXN0Qm9keVByb21pc2UgPSBnZXRSZXF1ZXN0Qm9keVByZXZpZXdBc3luYyhyZXBvcnRlciwgYXJnc1swXSwgc3RyaW5naWZ5VmFsdWUsIG1ldGEucmVxdWVzdEhlYWRlcnNbXCJjb250ZW50LXR5cGVcIl0gPz8gXCJcIik7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5hZGRFdmVudExpc3RlbmVyKFwibG9hZGVuZFwiLCAoKSA9PiB7XG4gICAgICAgICAgICBwb3N0WGhyTG9hZEVuZEV2ZW50KHRoaXMpO1xuICAgICAgICB9LCB7XG4gICAgICAgICAgICBvbmNlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIG9yaWdpbmFsU2VuZC5hcHBseSh0aGlzLCBhcmdzKTtcbiAgICB9O1xuICAgIGRpYWdub3N0aWNzLnNldFhockhvb2tJbnN0YWxsZWQoKTtcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD14aHIuanMubWFwIiwiaW1wb3J0IHsgaW5zdGFsbEZldGNoQ2FwdHVyZSB9IGZyb20gXCIuL2ZldGNoL2luc3RhbGxcIjtcbmltcG9ydCB7IGluc3RhbGxYaHJDYXB0dXJlIH0gZnJvbSBcIi4veGhyXCI7XG5leHBvcnQgZnVuY3Rpb24gaW5zdGFsbE5ldHdvcmtDYXB0dXJlKGlucHV0KSB7XG4gICAgaW5zdGFsbEZldGNoQ2FwdHVyZShpbnB1dCk7XG4gICAgaW5zdGFsbFhockNhcHR1cmUoaW5wdXQpO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIiwiaW1wb3J0IHsgaW5zdGFsbEFjdGlvbkFuZE5hdmlnYXRpb25DYXB0dXJlIH0gZnJvbSBcIi4vYWN0aW9uc1wiO1xuaW1wb3J0IHsgaW5zdGFsbENvbnNvbGVDYXB0dXJlIH0gZnJvbSBcIi4vY29uc29sZVwiO1xuaW1wb3J0IHsgSU5TVEFMTF9GTEFHIH0gZnJvbSBcIi4vY29uc3RhbnRzXCI7XG5pbXBvcnQgeyBjcmVhdGVQYWdlRGlhZ25vc3RpY3MgfSBmcm9tIFwiLi9kaWFnbm9zdGljc1wiO1xuaW1wb3J0IHsgY3JlYXRlRXZlbnRRdWV1ZSB9IGZyb20gXCIuL2V2ZW50LXF1ZXVlXCI7XG5pbXBvcnQgeyBpbnN0YWxsTmV0d29ya0NhcHR1cmUgfSBmcm9tIFwiLi9uZXR3b3JrXCI7XG5pbXBvcnQgeyBjcmVhdGVTdHJpbmdpZnlWYWx1ZSB9IGZyb20gXCIuL3NlcmlhbGl6ZXJcIjtcbmltcG9ydCB7IGNyZWF0ZU5vbkZhdGFsUmVwb3J0ZXIsIHRydW5jYXRlIH0gZnJvbSBcIi4vdXRpbHNcIjtcbmV4cG9ydCBmdW5jdGlvbiBpbnN0YWxsRGVidWdnZXJQYWdlUnVudGltZSgpIHtcbiAgICBjb25zdCBzY29wZSA9IHdpbmRvdztcbiAgICBpZiAoc2NvcGVbSU5TVEFMTF9GTEFHXSkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIHNjb3BlW0lOU1RBTExfRkxBR10gPSB0cnVlO1xuICAgIGNvbnN0IGRpYWdub3N0aWNzID0gY3JlYXRlUGFnZURpYWdub3N0aWNzKHdpbmRvdyk7XG4gICAgY29uc3QgcmVwb3J0ZXIgPSBkaWFnbm9zdGljcy5jcmVhdGVSZXBvcnRlcihjcmVhdGVOb25GYXRhbFJlcG9ydGVyKCkpO1xuICAgIGNvbnN0IHsgZW5xdWV1ZUV2ZW50LCBmbHVzaEV2ZW50UXVldWUgfSA9IGNyZWF0ZUV2ZW50UXVldWUoe1xuICAgICAgICByZWNvcmRRdWV1ZWRFdmVudDogZGlhZ25vc3RpY3MucmVjb3JkUXVldWVkRXZlbnQsXG4gICAgICAgIHJlY29yZEZsdXNoZWRCYXRjaDogZGlhZ25vc3RpY3MucmVjb3JkRmx1c2hlZEJhdGNoLFxuICAgIH0pO1xuICAgIGNvbnN0IHN0cmluZ2lmeVZhbHVlID0gY3JlYXRlU3RyaW5naWZ5VmFsdWUocmVwb3J0ZXIpO1xuICAgIGNvbnN0IHBvc3RBY3Rpb24gPSAoYWN0aW9uVHlwZSwgdGFyZ2V0LCBtZXRhZGF0YSkgPT4ge1xuICAgICAgICBkaWFnbm9zdGljcy5yZWNvcmRBY3Rpb25FdmVudCgpO1xuICAgICAgICBlbnF1ZXVlRXZlbnQoe1xuICAgICAgICAgICAga2luZDogXCJhY3Rpb25cIixcbiAgICAgICAgICAgIHRpbWVzdGFtcDogRGF0ZS5ub3coKSxcbiAgICAgICAgICAgIGFjdGlvblR5cGUsXG4gICAgICAgICAgICB0YXJnZXQsXG4gICAgICAgICAgICBtZXRhZGF0YSxcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCBwb3N0Q29uc29sZSA9IChsZXZlbCwgYXJncykgPT4ge1xuICAgICAgICBkaWFnbm9zdGljcy5yZWNvcmRDb25zb2xlRXZlbnQoKTtcbiAgICAgICAgY29uc3Qgc2VyaWFsaXplZEFyZ3MgPSBbXTtcbiAgICAgICAgZm9yIChjb25zdCBhcmcgb2YgYXJncykge1xuICAgICAgICAgICAgc2VyaWFsaXplZEFyZ3MucHVzaChzdHJpbmdpZnlWYWx1ZShhcmcpKTtcbiAgICAgICAgfVxuICAgICAgICBlbnF1ZXVlRXZlbnQoe1xuICAgICAgICAgICAga2luZDogXCJjb25zb2xlXCIsXG4gICAgICAgICAgICB0aW1lc3RhbXA6IERhdGUubm93KCksXG4gICAgICAgICAgICBsZXZlbCxcbiAgICAgICAgICAgIG1lc3NhZ2U6IHRydW5jYXRlKHNlcmlhbGl6ZWRBcmdzLmpvaW4oXCIgXCIpKSxcbiAgICAgICAgICAgIG1ldGFkYXRhOiB7XG4gICAgICAgICAgICAgICAgYXJndW1lbnRDb3VudDogYXJncy5sZW5ndGgsXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IHBvc3ROZXR3b3JrID0gKHBheWxvYWQpID0+IHtcbiAgICAgICAgZGlhZ25vc3RpY3MucmVjb3JkTmV0d29ya0V2ZW50KHBheWxvYWQudXJsKTtcbiAgICAgICAgZW5xdWV1ZUV2ZW50KHtcbiAgICAgICAgICAgIGtpbmQ6IFwibmV0d29ya1wiLFxuICAgICAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgLi4ucGF5bG9hZCxcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBpbnN0YWxsQWN0aW9uQW5kTmF2aWdhdGlvbkNhcHR1cmUoe1xuICAgICAgICBwb3N0QWN0aW9uLFxuICAgIH0pO1xuICAgIGluc3RhbGxDb25zb2xlQ2FwdHVyZSh7XG4gICAgICAgIHJlcG9ydGVyLFxuICAgICAgICBwb3N0Q29uc29sZSxcbiAgICB9KTtcbiAgICB0cnkge1xuICAgICAgICBpbnN0YWxsTmV0d29ya0NhcHR1cmUoe1xuICAgICAgICAgICAgZGlhZ25vc3RpY3MsXG4gICAgICAgICAgICByZXBvcnRlcixcbiAgICAgICAgICAgIHBvc3ROZXR3b3JrLFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJlcG9ydGVyLnJlcG9ydE5vbkZhdGFsRXJyb3IoXCJGYWlsZWQgdG8gaW5zdGFsbCBuZXR3b3JrIGNhcHR1cmUgaW4gZGVidWdnZXIgcnVudGltZVwiLCBlcnJvcik7XG4gICAgfVxuICAgIGNvbnN0IGZsdXNoT25QYWdlSGlkZSA9ICgpID0+IHtcbiAgICAgICAgZmx1c2hFdmVudFF1ZXVlKCk7XG4gICAgfTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInBhZ2VoaWRlXCIsIGZsdXNoT25QYWdlSGlkZSwge1xuICAgICAgICBjYXB0dXJlOiB0cnVlLFxuICAgIH0pO1xuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJ2aXNpYmlsaXR5Y2hhbmdlXCIsICgpID0+IHtcbiAgICAgICAgaWYgKGRvY3VtZW50LnZpc2liaWxpdHlTdGF0ZSA9PT0gXCJoaWRkZW5cIikge1xuICAgICAgICAgICAgZmx1c2hFdmVudFF1ZXVlKCk7XG4gICAgICAgIH1cbiAgICB9LCB7XG4gICAgICAgIGNhcHR1cmU6IHRydWUsXG4gICAgICAgIHBhc3NpdmU6IHRydWUsXG4gICAgfSk7XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL3V0aWxzL2RlZmluZS1jb250ZW50LXNjcmlwdC50c1xuZnVuY3Rpb24gZGVmaW5lQ29udGVudFNjcmlwdChkZWZpbml0aW9uKSB7XG5cdHJldHVybiBkZWZpbml0aW9uO1xufVxuXG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGRlZmluZUNvbnRlbnRTY3JpcHQgfTsiLCJpbXBvcnQgeyBpbnN0YWxsRGVidWdnZXJQYWdlUnVudGltZSB9IGZyb20gXCJAY3Jpa2tldC9jYXB0dXJlLWNvcmUvZGVidWdnZXIvZW5naW5lL3BhZ2VcIlxuaW1wb3J0IHsgZGVmaW5lQ29udGVudFNjcmlwdCB9IGZyb20gXCJ3eHQvdXRpbHMvZGVmaW5lLWNvbnRlbnQtc2NyaXB0XCJcblxuZXhwb3J0IGRlZmF1bHQgZGVmaW5lQ29udGVudFNjcmlwdCh7XG4gIG1hdGNoZXM6IFtcIjxhbGxfdXJscz5cIl0sXG4gIHJ1bkF0OiBcImRvY3VtZW50X3N0YXJ0XCIsXG4gIHdvcmxkOiBcIk1BSU5cIixcbiAgbWFpbigpIHtcbiAgICBpbnN0YWxsRGVidWdnZXJQYWdlUnVudGltZSgpXG4gIH0sXG59KVxuIl0sIm5hbWVzIjpbInJlc3VsdCIsImRlZmluaXRpb24iXSwibWFwcGluZ3MiOiI7O0FBQU8sUUFBTSxjQUFjO0FBQ3BCLFFBQU0sZUFBZTtBQUNyQixRQUFNLGtCQUFrQjtBQUN4QixRQUFNLGtCQUFrQjtBQUN4QixRQUFNLHlCQUF5QjtBQUMvQixRQUFNLDBCQUEwQjtBQUNoQyxRQUFNLGlCQUFpQjtBQUN2QixRQUFNLG9CQUFvQjtBQUMxQixRQUFNLHNCQUFzQjtBQUM1QixRQUFNLHFCQUFxQjtBQUMzQixRQUFNLDRCQUE0QjtBQ1R6QyxRQUFNLGlCQUFpQjtBQUN2QixRQUFNLDBCQUEwQjtBQUFBLElBQzVCO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0o7QUFDQSxRQUFNLDJCQUEyQjtBQUMxQixRQUFNLFdBQVcsQ0FBQyxPQUFPLFlBQVksb0JBQW9CO0FBQzVELFFBQUksTUFBTSxVQUFVLFdBQVc7QUFDM0IsYUFBTztBQUFBLElBQ1g7QUFDQSxXQUFPLEdBQUcsTUFBTSxNQUFNLEdBQUcsU0FBUyxDQUFDO0FBQUEsRUFDdkM7QUFDTyxRQUFNLGtCQUFrQixDQUFDLFVBQVU7QUFDdEMsVUFBTSxrQkFBa0IsTUFBTSxLQUFJLEVBQUcsWUFBVztBQUNoRCxRQUFJLENBQUMsaUJBQWlCO0FBQ2xCLGFBQU87QUFBQSxJQUNYO0FBQ0EsV0FBTyx3QkFBd0IsS0FBSyxDQUFDLFlBQVk7QUFDN0MsYUFBTyxnQkFBZ0IsU0FBUyxPQUFPO0FBQUEsSUFDM0MsQ0FBQztBQUFBLEVBQ0w7QUFDTyxRQUFNLG1CQUFtQixDQUFDLGVBQWU7QUFDNUMsV0FBTyxXQUFXLFNBQVMsVUFBVSxLQUFLLGdCQUFnQixVQUFVO0FBQUEsRUFDeEU7QUFDTyxRQUFNLG1CQUFtQixDQUFDLFdBQVc7QUFDeEMsUUFBSSxFQUFFLGtCQUFrQixVQUFVO0FBQzlCLGFBQU87QUFBQSxJQUNYO0FBQ0EsUUFBSSxPQUFPLElBQUk7QUFDWCxhQUFPLElBQUksT0FBTyxFQUFFO0FBQUEsSUFDeEI7QUFDQSxVQUFNLGFBQWEsT0FBTyxPQUFPLGNBQWMsV0FBVyxPQUFPLFlBQVk7QUFDN0UsVUFBTSxhQUFhLFdBQ2QsTUFBTSxHQUFHLEVBQ1QsSUFBSSxDQUFDLFVBQVUsTUFBTSxLQUFJLENBQUUsRUFDM0IsS0FBSyxDQUFDLFVBQVUsTUFBTSxTQUFTLENBQUM7QUFDckMsUUFBSSxZQUFZO0FBQ1osYUFBTyxHQUFHLE9BQU8sUUFBUSxZQUFXLENBQUUsSUFBSSxVQUFVO0FBQUEsSUFDeEQ7QUFDQSxXQUFPLE9BQU8sUUFBUSxZQUFXO0FBQUEsRUFDckM7QUFDTyxRQUFNLGdCQUFnQixDQUFDLE9BQU8sYUFBYTtBQUM5QyxRQUFJO0FBQ0EsYUFBTyxJQUFJLElBQUksT0FBTyxTQUFTLElBQUksRUFBRSxTQUFRO0FBQUEsSUFDakQsU0FDTyxPQUFPO0FBQ1YsZUFBUyxvQkFBb0IsK0RBQStEO0FBQUEsUUFDeEY7QUFBQSxRQUNBO0FBQUEsTUFDWixDQUFTO0FBQ0QsYUFBTztBQUFBLElBQ1g7QUFBQSxFQUNKO0FBQ08sUUFBTSw2QkFBNkIsQ0FBQyxnQkFBZ0I7QUFDdkQsUUFBSTtBQUNBLFlBQU0sWUFBWSxJQUFJLElBQUksV0FBVztBQUNyQyxpQkFBVyxDQUFDLEdBQUcsS0FBSyxVQUFVLGFBQWEsUUFBTyxHQUFJO0FBQ2xELFlBQUksQ0FBQyxnQkFBZ0IsR0FBRyxHQUFHO0FBQ3ZCO0FBQUEsUUFDSjtBQUNBLGtCQUFVLGFBQWEsSUFBSSxLQUFLLGNBQWM7QUFBQSxNQUNsRDtBQUNBLGFBQU8sVUFBVSxTQUFRO0FBQUEsSUFDN0IsUUFDTTtBQUNGLGFBQU87QUFBQSxJQUNYO0FBQUEsRUFDSjtBQUNBLFFBQU0sMEJBQTBCLENBQUMsT0FBTyxRQUFRLE1BQU07QUFDbEQsUUFBSSxTQUFTLEdBQUc7QUFDWixhQUFPO0FBQUEsSUFDWDtBQUNBLFFBQUksTUFBTSxRQUFRLEtBQUssR0FBRztBQUN0QixhQUFPLE1BQU0sSUFBSSxDQUFDLFNBQVMsd0JBQXdCLE1BQU0sUUFBUSxDQUFDLENBQUM7QUFBQSxJQUN2RTtBQUNBLFFBQUksU0FBUyxPQUFPLFVBQVUsVUFBVTtBQUNwQyxZQUFNQSxVQUFTLENBQUE7QUFDZixpQkFBVyxDQUFDLEtBQUssV0FBVyxLQUFLLE9BQU8sUUFBUSxLQUFLLEdBQUc7QUFDcEQsWUFBSSxnQkFBZ0IsR0FBRyxHQUFHO0FBQ3RCLFVBQUFBLFFBQU8sR0FBRyxJQUFJO0FBQ2Q7QUFBQSxRQUNKO0FBQ0EsUUFBQUEsUUFBTyxHQUFHLElBQUksd0JBQXdCLGFBQWEsUUFBUSxDQUFDO0FBQUEsTUFDaEU7QUFDQSxhQUFPQTtBQUFBLElBQ1g7QUFDQSxRQUFJLE9BQU8sVUFBVSxVQUFVO0FBQzNCLGFBQU8sTUFBTSxRQUFRLDBCQUEwQixLQUFLLGNBQWMsRUFBRTtBQUFBLElBQ3hFO0FBQ0EsV0FBTztBQUFBLEVBQ1g7QUFDQSxRQUFNLHlCQUF5QixDQUFDLFNBQVM7QUFDckMsVUFBTSxTQUFTLElBQUksZ0JBQWdCLElBQUk7QUFDdkMsZUFBVyxDQUFDLEdBQUcsS0FBSyxPQUFPLFFBQU8sR0FBSTtBQUNsQyxVQUFJLENBQUMsZ0JBQWdCLEdBQUcsR0FBRztBQUN2QjtBQUFBLE1BQ0o7QUFDQSxhQUFPLElBQUksS0FBSyxjQUFjO0FBQUEsSUFDbEM7QUFDQSxXQUFPLE9BQU8sU0FBUTtBQUFBLEVBQzFCO0FBQ08sUUFBTSx1QkFBdUIsQ0FBQyxNQUFNLGdCQUFnQjtBQUN2RCxRQUFJLE9BQU8sU0FBUyxZQUFZLEtBQUssV0FBVyxHQUFHO0FBQy9DLGFBQU87QUFBQSxJQUNYO0FBQ0EsVUFBTSx3QkFBd0IsWUFBWSxZQUFXO0FBQ3JELFFBQUksc0JBQXNCLFNBQVMsa0JBQWtCLEdBQUc7QUFDcEQsVUFBSTtBQUNBLGNBQU0sU0FBUyxLQUFLLE1BQU0sSUFBSTtBQUM5QixlQUFPLFNBQVMsS0FBSyxVQUFVLHdCQUF3QixNQUFNLENBQUMsR0FBRyxrQkFBa0IsQ0FBQztBQUFBLE1BQ3hGLFFBQ007QUFDRixlQUFPLFNBQVMsS0FBSyxRQUFRLDBCQUEwQixLQUFLLGNBQWMsRUFBRSxHQUFHLGtCQUFrQixDQUFDO0FBQUEsTUFDdEc7QUFBQSxJQUNKO0FBQ0EsUUFBSSxzQkFBc0IsU0FBUyx1QkFBdUIsR0FBRztBQUN6RCxhQUFPLFNBQVMsdUJBQXVCLElBQUksR0FBRyxrQkFBa0IsQ0FBQztBQUFBLElBQ3JFO0FBQ0EsV0FBTyxTQUFTLEtBQUssUUFBUSwwQkFBMEIsS0FBSyxjQUFjLEVBQUUsR0FBRyxrQkFBa0IsQ0FBQztBQUFBLEVBQ3RHO0FBQ08sV0FBUyx5QkFBeUI7QUFDckMsVUFBTSxzQkFBc0IsUUFBUSxLQUFLLEtBQUssT0FBTztBQUNyRCxVQUFNLG1CQUFtQixvQkFBSSxJQUFHO0FBQ2hDLFdBQU87QUFBQSxNQUNILG9CQUFvQixTQUFTLE9BQU87QUFDaEMsWUFBSSxpQkFBaUIsSUFBSSxPQUFPLEdBQUc7QUFDL0I7QUFBQSxRQUNKO0FBQ0EseUJBQWlCLElBQUksT0FBTztBQUM1Qiw0QkFBb0IsZUFBZSxPQUFPLElBQUksS0FBSztBQUFBLE1BQ3ZEO0FBQUEsSUFDUjtBQUFBLEVBQ0E7QUN0Sk8sV0FBUyxrQ0FBa0MsT0FBTztBQUNyRCxVQUFNLEVBQUUsV0FBVSxJQUFLO0FBQ3ZCLFVBQU0sMkJBQTJCLENBQUMsU0FBUztBQUN2QyxpQkFBVyxjQUFjLFVBQVU7QUFBQSxRQUMvQjtBQUFBLFFBQ0EsS0FBSyxTQUFTO0FBQUEsUUFDZCxNQUFNLFNBQVM7QUFBQSxRQUNmLFFBQVEsU0FBUztBQUFBLFFBQ2pCLE1BQU0sU0FBUztBQUFBLFFBQ2YsT0FBTyxTQUFTO0FBQUEsTUFDNUIsQ0FBUztBQUFBLElBQ0w7QUFDQSxVQUFNLG9CQUFvQjtBQUFBLE1BQ3RCLE9BQU8sQ0FBQyxVQUFVO0FBQ2QsbUJBQVcsU0FBUyxpQkFBaUIsTUFBTSxNQUFNLENBQUM7QUFBQSxNQUN0RDtBQUFBLE1BQ0EsT0FBTyxDQUFDLFVBQVU7QUFDZCxjQUFNLFNBQVMsaUJBQWlCLE1BQU0sTUFBTTtBQUM1QyxZQUFJO0FBQ0osY0FBTSxjQUFjLE1BQU07QUFDMUIsWUFBSSx1QkFBdUIsb0JBQ3ZCLHVCQUF1QixxQkFBcUI7QUFDNUMsd0JBQWMsWUFBWSxNQUFNO0FBQUEsUUFDcEM7QUFDQSxtQkFBVyxTQUFTLFFBQVE7QUFBQSxVQUN4QjtBQUFBLFFBQ2hCLENBQWE7QUFBQSxNQUNMO0FBQUEsTUFDQSxRQUFRLENBQUMsVUFBVTtBQUNmLG1CQUFXLFVBQVUsaUJBQWlCLE1BQU0sTUFBTSxDQUFDO0FBQUEsTUFDdkQ7QUFBQSxJQUNSO0FBQ0ksVUFBTSxvQkFBb0IsQ0FBQyxVQUFVO0FBQ2pDLFVBQUksTUFBTSxTQUFTLFdBQ2YsTUFBTSxTQUFTLFdBQ2YsTUFBTSxTQUFTLFVBQVU7QUFDekI7QUFBQSxNQUNKO0FBQ0Esd0JBQWtCLE1BQU0sSUFBSSxFQUFFLEtBQUs7QUFBQSxJQUN2QztBQUNBLGVBQVcsYUFBYSxDQUFDLFNBQVMsU0FBUyxRQUFRLEdBQUc7QUFDbEQsZUFBUyxpQkFBaUIsV0FBVyxtQkFBbUI7QUFBQSxRQUNwRCxTQUFTO0FBQUEsUUFDVCxTQUFTO0FBQUEsTUFDckIsQ0FBUztBQUFBLElBQ0w7QUFDQSxVQUFNLG9CQUFvQixRQUFRO0FBQ2xDLFlBQVEsWUFBWSxZQUFhLE1BQU07QUFDbkMsd0JBQWtCLE1BQU0sTUFBTSxJQUFJO0FBQ2xDLCtCQUF5QixXQUFXO0FBQUEsSUFDeEM7QUFDQSxVQUFNLHVCQUF1QixRQUFRO0FBQ3JDLFlBQVEsZUFBZSxZQUFhLE1BQU07QUFDdEMsMkJBQXFCLE1BQU0sTUFBTSxJQUFJO0FBQ3JDLCtCQUF5QixjQUFjO0FBQUEsSUFDM0M7QUFDQSxXQUFPLGlCQUFpQixZQUFZLE1BQU07QUFDdEMsK0JBQXlCLFVBQVU7QUFBQSxJQUN2QyxHQUFHO0FBQUEsTUFDQyxTQUFTO0FBQUEsTUFDVCxTQUFTO0FBQUEsSUFDakIsQ0FBSztBQUNELFdBQU8saUJBQWlCLGNBQWMsTUFBTTtBQUN4QywrQkFBeUIsWUFBWTtBQUFBLElBQ3pDLEdBQUc7QUFBQSxNQUNDLFNBQVM7QUFBQSxNQUNULFNBQVM7QUFBQSxJQUNqQixDQUFLO0FBQ0QsNkJBQXlCLFNBQVM7QUFBQSxFQUN0QztBQ3RFTyxXQUFTLHNCQUFzQixPQUFPO0FBQ3pDLFVBQU0sRUFBRSxVQUFVLFlBQVcsSUFBSztBQUNsQyxVQUFNLGdCQUFnQjtBQUFBLE1BQ2xCO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ1I7QUFDSSxlQUFXLFNBQVMsZUFBZTtBQUMvQixZQUFNLFdBQVcsUUFBUSxLQUFLLEVBQUUsS0FBSyxPQUFPO0FBQzVDLGNBQVEsS0FBSyxJQUFJLElBQUksU0FBUztBQUMxQixZQUFJO0FBQ0Esc0JBQVksT0FBTyxJQUFJO0FBQUEsUUFDM0IsU0FDTyxPQUFPO0FBQ1YsbUJBQVMsb0JBQW9CLDREQUE0RCxLQUFLO0FBQUEsUUFDbEc7QUFDQSxpQkFBUyxHQUFHLElBQUk7QUFBQSxNQUNwQjtBQUFBLElBQ0o7QUFBQSxFQUNKO0FDcEJBLFFBQU0sa0JBQWtCO0FBQ3hCLFFBQU0sc0JBQXNCO0FBQzVCLFFBQU0sb0JBQW9CO0FBQzFCLFFBQU0sbUJBQW1CO0FBQ3pCLFFBQU0sZ0NBQWdDLE1BQU07QUFDeEMsV0FBTztBQUFBLE1BQ0gsU0FBUztBQUFBLE1BQ1QsYUFBYSxLQUFLLElBQUc7QUFBQSxNQUNyQixLQUFLLFNBQVM7QUFBQSxNQUNkLE9BQU87QUFBQSxRQUNILE9BQU87QUFBQSxRQUNQLEtBQUs7QUFBQSxNQUNqQjtBQUFBLE1BQ1EsVUFBVTtBQUFBLFFBQ04sY0FBYztBQUFBLFFBQ2QsZUFBZTtBQUFBLFFBQ2YsZUFBZTtBQUFBLFFBQ2YsWUFBWTtBQUFBLFFBQ1osZUFBZTtBQUFBLFFBQ2YsVUFBVTtBQUFBLFFBQ1YsY0FBYztBQUFBLFFBQ2QsZ0JBQWdCO0FBQUEsTUFDNUI7QUFBQSxNQUNRLE1BQU0sQ0FBQTtBQUFBLE1BQ04sUUFBUSxDQUFBO0FBQUEsSUFDaEI7QUFBQSxFQUNBO0FBQ0EsUUFBTSxpQkFBaUIsQ0FBQyxTQUFTLFVBQVU7QUFDdkMsUUFBSSxpQkFBaUIsT0FBTztBQUN4QixhQUFPLEdBQUcsT0FBTyxLQUFLLE1BQU0sT0FBTztBQUFBLElBQ3ZDO0FBQ0EsV0FBTyxHQUFHLE9BQU8sS0FBSyxPQUFPLEtBQUssQ0FBQztBQUFBLEVBQ3ZDO0FBQ08sV0FBUyxzQkFBc0IsT0FBTztBQUN6QyxVQUFNLGVBQWU7QUFDckIsVUFBTSxRQUFRLGFBQWEsZUFBZSxLQUFLLDhCQUE2QjtBQUM1RSxpQkFBYSxlQUFlLElBQUk7QUFDaEMsVUFBTSxjQUFjLEtBQUssSUFBRztBQUM1QixVQUFNLE1BQU0sU0FBUztBQUNyQixVQUFNLE1BQU0sUUFBUTtBQUNwQixVQUFNLE1BQU0sTUFBTTtBQUNsQixXQUFPO0FBQUEsTUFDSDtBQUFBLE1BQ0EsZUFBZSxVQUFVO0FBQ3JCLGNBQU0saUJBQWlCLFNBQVMsb0JBQW9CLEtBQUssUUFBUTtBQUNqRSxlQUFPO0FBQUEsVUFDSCxvQkFBb0IsU0FBUyxPQUFPO0FBQ2hDLGtCQUFNLE9BQU8sS0FBSyxTQUFTLGVBQWUsU0FBUyxLQUFLLEdBQUcsZ0JBQWdCLENBQUM7QUFDNUUsZ0JBQUksTUFBTSxPQUFPLFNBQVMsbUJBQW1CO0FBQ3pDLG9CQUFNLE9BQU8sTUFBSztBQUFBLFlBQ3RCO0FBQ0EsMkJBQWUsU0FBUyxLQUFLO0FBQUEsVUFDakM7QUFBQSxRQUNoQjtBQUFBLE1BQ1E7QUFBQSxNQUNBLG9CQUFvQjtBQUNoQixjQUFNLFNBQVMsZ0JBQWdCO0FBQUEsTUFDbkM7QUFBQSxNQUNBLHFCQUFxQjtBQUNqQixjQUFNLFNBQVMsaUJBQWlCO0FBQUEsTUFDcEM7QUFBQSxNQUNBLG1CQUFtQixLQUFLO0FBQ3BCLGNBQU0sU0FBUyxpQkFBaUI7QUFDaEMsY0FBTSxLQUFLLGFBQWE7QUFBQSxNQUM1QjtBQUFBLE1BQ0Esa0JBQWtCO0FBQ2QsY0FBTSxTQUFTLGNBQWM7QUFBQSxNQUNqQztBQUFBLE1BQ0EsbUJBQW1CLFNBQVM7QUFDeEIsY0FBTSxTQUFTLGlCQUFpQjtBQUNoQyxjQUFNLEtBQUssYUFBYTtBQUFBLE1BQzVCO0FBQUEsTUFDQSxrQkFBa0IsV0FBVztBQUN6QixjQUFNLE1BQU0sUUFBUTtBQUFBLE1BQ3hCO0FBQUEsTUFDQSxnQkFBZ0I7QUFDWixjQUFNLFNBQVMsWUFBWTtBQUFBLE1BQy9CO0FBQUEsTUFDQSxzQkFBc0I7QUFDbEIsY0FBTSxNQUFNLE1BQU07QUFBQSxNQUN0QjtBQUFBLE1BQ0Esb0JBQW9CO0FBQ2hCLGNBQU0sU0FBUyxnQkFBZ0I7QUFBQSxNQUNuQztBQUFBLE1BQ0EscUJBQXFCO0FBQ2pCLGNBQU0sU0FBUyxrQkFBa0I7QUFBQSxNQUNyQztBQUFBLElBQ1I7QUFBQSxFQUNBO0FDeEZPLFdBQVMsaUJBQWlCLFFBQVEsSUFBSTtBQUN6QyxVQUFNLEVBQUUsb0JBQW9CLGtCQUFpQixJQUFLO0FBQ2xELFVBQU0sYUFBYSxDQUFBO0FBQ25CLFFBQUksYUFBYTtBQUNqQixVQUFNLGtCQUFrQixNQUFNO0FBQzFCLG1CQUFhO0FBQ2IsVUFBSSxXQUFXLFdBQVcsR0FBRztBQUN6QjtBQUFBLE1BQ0o7QUFDQSxZQUFNLGdCQUFnQixXQUFXLE9BQU8sR0FBRyxjQUFjO0FBQ3pELDJCQUFrQjtBQUNsQixhQUFPLFlBQVk7QUFBQSxRQUNmLFFBQVE7QUFBQSxRQUNSLFFBQVE7QUFBQSxNQUNwQixHQUFXLEdBQUc7QUFDTixVQUFJLFdBQVcsU0FBUyxHQUFHO0FBQ3ZCLHFCQUFhLFdBQVcsaUJBQWlCLENBQUM7QUFDMUM7QUFBQSxNQUNKO0FBQUEsSUFDSjtBQUNBLFVBQU0scUJBQXFCLE1BQU07QUFDN0IsVUFBSSxZQUFZO0FBQ1o7QUFBQSxNQUNKO0FBQ0EsbUJBQWEsV0FBVyxpQkFBaUIsaUJBQWlCO0FBQUEsSUFDOUQ7QUFDQSxVQUFNLGVBQWUsQ0FBQyxVQUFVO0FBQzVCLGlCQUFXLEtBQUssS0FBSztBQUNyQiwwQkFBaUI7QUFDakIsVUFBSSxXQUFXLFVBQVUsZ0JBQWdCO0FBQ3JDLFlBQUksWUFBWTtBQUNaLHVCQUFhLFVBQVU7QUFBQSxRQUMzQjtBQUNBLHFCQUFhLFdBQVcsaUJBQWlCLENBQUM7QUFDMUM7QUFBQSxNQUNKO0FBQ0EseUJBQWtCO0FBQUEsSUFDdEI7QUFDQSxXQUFPO0FBQUEsTUFDSDtBQUFBLE1BQ0E7QUFBQSxJQUNSO0FBQUEsRUFDQTtBQ3pDQSxRQUFNLHFCQUFxQixDQUFDLFVBQVU7QUFDbEMsUUFBSSxVQUFVLFFBQ1YsT0FBTyxVQUFVLGFBQ2pCLE9BQU8sVUFBVSxVQUFVO0FBQzNCLGFBQU87QUFBQSxRQUNILFNBQVM7QUFBQSxRQUNUO0FBQUEsTUFDWjtBQUFBLElBQ0k7QUFDQSxRQUFJLE9BQU8sVUFBVSxVQUFVO0FBQzNCLGFBQU87QUFBQSxRQUNILFNBQVM7QUFBQSxRQUNULE9BQU8sU0FBUyxLQUFLO0FBQUEsTUFDakM7QUFBQSxJQUNJO0FBQ0EsUUFBSSxPQUFPLFVBQVUsYUFBYTtBQUM5QixhQUFPO0FBQUEsUUFDSCxTQUFTO0FBQUEsUUFDVCxPQUFPO0FBQUEsTUFDbkI7QUFBQSxJQUNJO0FBQ0EsUUFBSSxPQUFPLFVBQVUsVUFBVTtBQUMzQixhQUFPO0FBQUEsUUFDSCxTQUFTO0FBQUEsUUFDVCxPQUFPLEdBQUcsTUFBTSxTQUFRLENBQUU7QUFBQSxNQUN0QztBQUFBLElBQ0k7QUFDQSxRQUFJLE9BQU8sVUFBVSxVQUFVO0FBQzNCLGFBQU87QUFBQSxRQUNILFNBQVM7QUFBQSxRQUNULE9BQU8sTUFBTSxTQUFRO0FBQUEsTUFDakM7QUFBQSxJQUNJO0FBQ0EsUUFBSSxPQUFPLFVBQVUsWUFBWTtBQUM3QixhQUFPO0FBQUEsUUFDSCxTQUFTO0FBQUEsUUFDVCxPQUFPLGFBQWEsTUFBTSxRQUFRLFdBQVc7QUFBQSxNQUN6RDtBQUFBLElBQ0k7QUFDQSxXQUFPO0FBQUEsTUFDSCxTQUFTO0FBQUEsSUFDakI7QUFBQSxFQUNBO0FBQ0EsUUFBTSxpQkFBaUIsQ0FBQyxVQUFVO0FBQzlCLFdBQU87QUFBQSxNQUNILE1BQU0sTUFBTTtBQUFBLE1BQ1osU0FBUyxTQUFTLE1BQU0sT0FBTztBQUFBLE1BQy9CLE9BQU8sT0FBTyxNQUFNLFVBQVUsV0FBVyxTQUFTLE1BQU0sS0FBSyxJQUFJO0FBQUEsSUFDekU7QUFBQSxFQUNBO0FBQ0EsUUFBTSxxQkFBcUIsQ0FBQyxVQUFVO0FBQ2xDLFdBQU8sT0FBTyxnQkFBZ0IsZUFBZSxpQkFBaUI7QUFBQSxFQUNsRTtBQUNBLFFBQU0seUJBQXlCLENBQUMsVUFBVTtBQUN0QyxXQUFPLE9BQU8sZ0JBQWdCLGVBQWUsWUFBWSxPQUFPLEtBQUs7QUFBQSxFQUN6RTtBQUNBLFFBQU0saUJBQWlCLENBQUMsT0FBTyxPQUFPLE9BQU8sTUFBTSxtQkFBbUI7QUFDbEUsVUFBTSxhQUFhLENBQUE7QUFDbkIsVUFBTSxRQUFRLEtBQUssSUFBSSxNQUFNLFFBQVEseUJBQXlCO0FBQzlELGFBQVMsUUFBUSxHQUFHLFFBQVEsT0FBTyxTQUFTLEdBQUc7QUFDM0MsaUJBQVcsS0FBSyxlQUFlLE1BQU0sS0FBSyxHQUFHLE9BQU8sUUFBUSxHQUFHLEdBQUcsSUFBSSxJQUFJLEtBQUssR0FBRyxDQUFDO0FBQUEsSUFDdkY7QUFDQSxRQUFJLE1BQU0sU0FBUyxPQUFPO0FBQ3RCLGlCQUFXLEtBQUssS0FBSyxNQUFNLFNBQVMsS0FBSyxRQUFRO0FBQUEsSUFDckQ7QUFDQSxXQUFPO0FBQUEsRUFDWDtBQUNBLFFBQU0sZUFBZSxDQUFDLE9BQU8sT0FBTyxPQUFPLE1BQU0sbUJBQW1CO0FBQ2hFLFVBQU0sVUFBVSxDQUFBO0FBQ2hCLFFBQUksUUFBUTtBQUNaLGVBQVcsQ0FBQyxVQUFVLFVBQVUsS0FBSyxNQUFNLFFBQU8sR0FBSTtBQUNsRCxVQUFJLFNBQVMsb0JBQW9CO0FBQzdCLGdCQUFRLEtBQUssS0FBSyxNQUFNLE9BQU8sS0FBSyxRQUFRO0FBQzVDO0FBQUEsTUFDSjtBQUNBLGNBQVEsS0FBSztBQUFBLFFBQ1QsZUFBZSxVQUFVLE9BQU8sUUFBUSxHQUFHLEdBQUcsSUFBSSxVQUFVLEtBQUssRUFBRTtBQUFBLFFBQ25FLGVBQWUsWUFBWSxPQUFPLFFBQVEsR0FBRyxHQUFHLElBQUksVUFBVSxLQUFLLEVBQUU7QUFBQSxNQUNqRixDQUFTO0FBQ0QsZUFBUztBQUFBLElBQ2I7QUFDQSxXQUFPO0FBQUEsTUFDSCxNQUFNO0FBQUEsTUFDTjtBQUFBLElBQ1I7QUFBQSxFQUNBO0FBQ0EsUUFBTSxlQUFlLENBQUMsT0FBTyxPQUFPLE9BQU8sTUFBTSxtQkFBbUI7QUFDaEUsVUFBTSxVQUFVLENBQUE7QUFDaEIsUUFBSSxRQUFRO0FBQ1osZUFBVyxTQUFTLE1BQU0sVUFBVTtBQUNoQyxVQUFJLFNBQVMsb0JBQW9CO0FBQzdCLGdCQUFRLEtBQUssS0FBSyxNQUFNLE9BQU8sS0FBSyxRQUFRO0FBQzVDO0FBQUEsTUFDSjtBQUNBLGNBQVEsS0FBSyxlQUFlLE9BQU8sT0FBTyxRQUFRLEdBQUcsR0FBRyxJQUFJLFVBQVUsS0FBSyxFQUFFLENBQUM7QUFDOUUsZUFBUztBQUFBLElBQ2I7QUFDQSxXQUFPO0FBQUEsTUFDSCxNQUFNO0FBQUEsTUFDTixRQUFRO0FBQUEsSUFDaEI7QUFBQSxFQUNBO0FBQ0EsUUFBTSx3QkFBd0IsQ0FBQyxPQUFPLE9BQU8sT0FBTyxNQUFNLG1CQUFtQjtBQUN6RSxVQUFNQSxVQUFTLENBQUE7QUFDZixVQUFNLFVBQVUsT0FBTyxRQUFRLEtBQUs7QUFDcEMsVUFBTSxRQUFRLEtBQUssSUFBSSxRQUFRLFFBQVEsa0JBQWtCO0FBQ3pELGFBQVMsUUFBUSxHQUFHLFFBQVEsT0FBTyxTQUFTLEdBQUc7QUFDM0MsWUFBTSxDQUFDLFVBQVUsVUFBVSxJQUFJLFFBQVEsS0FBSyxLQUFLLENBQUE7QUFDakQsVUFBSSxPQUFPLGFBQWEsVUFBVTtBQUM5QjtBQUFBLE1BQ0o7QUFDQSxNQUFBQSxRQUFPLFFBQVEsSUFBSSxlQUFlLFlBQVksT0FBTyxRQUFRLEdBQUcsR0FBRyxJQUFJLElBQUksUUFBUSxFQUFFO0FBQUEsSUFDekY7QUFDQSxRQUFJLFFBQVEsU0FBUyxPQUFPO0FBQ3hCLE1BQUFBLFFBQU8sa0JBQWtCLFFBQVEsU0FBUztBQUFBLElBQzlDO0FBQ0EsV0FBT0E7QUFBQSxFQUNYO0FBQ0EsUUFBTSxvQkFBb0I7QUFBQSxJQUN0QjtBQUFBLE1BQ0ksV0FBVyxDQUFDLFVBQVUsaUJBQWlCO0FBQUEsTUFDdkMsV0FBVyxDQUFDLFVBQVUsZUFBZSxLQUFLO0FBQUEsSUFDbEQ7QUFBQSxJQUNJO0FBQUEsTUFDSSxXQUFXLENBQUMsVUFBVSxpQkFBaUI7QUFBQSxNQUN2QyxXQUFXLENBQUMsVUFBVSxNQUFNLFlBQVc7QUFBQSxJQUMvQztBQUFBLElBQ0k7QUFBQSxNQUNJLFdBQVcsQ0FBQyxVQUFVLGlCQUFpQjtBQUFBLE1BQ3ZDLFdBQVcsQ0FBQyxVQUFVLE1BQU0sU0FBUTtBQUFBLElBQzVDO0FBQUEsSUFDSTtBQUFBLE1BQ0ksV0FBVyxDQUFDLFVBQVUsT0FBTyxRQUFRLGVBQWUsaUJBQWlCO0FBQUEsTUFDckUsV0FBVyxDQUFDLFVBQVUsTUFBTSxTQUFRO0FBQUEsSUFDNUM7QUFBQSxJQUNJO0FBQUEsTUFDSSxXQUFXLENBQUMsVUFBVSxPQUFPLFlBQVksZUFBZSxpQkFBaUI7QUFBQSxNQUN6RSxXQUFXLENBQUMsVUFBVTtBQUNsQixjQUFNLFVBQVU7QUFDaEIsZUFBTyxpQkFBaUIsT0FBTyxLQUFLLFFBQVEsUUFBUSxZQUFXO0FBQUEsTUFDbkU7QUFBQSxJQUNSO0FBQUEsSUFDSTtBQUFBLE1BQ0ksV0FBVyxDQUFDLFVBQVUsT0FBTyxVQUFVLGVBQWUsaUJBQWlCO0FBQUEsTUFDdkUsV0FBVyxDQUFDLFVBQVU7QUFDbEIsY0FBTSxRQUFRO0FBQ2QsZUFBTztBQUFBLFVBQ0gsTUFBTSxNQUFNO0FBQUEsVUFDWixRQUFRLGlCQUFpQixNQUFNLE1BQU07QUFBQSxRQUNyRDtBQUFBLE1BQ1E7QUFBQSxJQUNSO0FBQUEsSUFDSTtBQUFBLE1BQ0ksV0FBVyxDQUFDLFVBQVUsTUFBTSxRQUFRLEtBQUs7QUFBQSxNQUN6QyxXQUFXLENBQUMsT0FBTyxPQUFPLE9BQU8sTUFBTSxtQkFBbUIsZUFBZSxPQUFPLE9BQU8sT0FBTyxNQUFNLGNBQWM7QUFBQSxJQUMxSDtBQUFBLElBQ0k7QUFBQSxNQUNJLFdBQVcsQ0FBQyxVQUFVLGlCQUFpQjtBQUFBLE1BQ3ZDLFdBQVcsQ0FBQyxPQUFPLE9BQU8sT0FBTyxNQUFNLG1CQUFtQixhQUFhLE9BQU8sT0FBTyxPQUFPLE1BQU0sY0FBYztBQUFBLElBQ3hIO0FBQUEsSUFDSTtBQUFBLE1BQ0ksV0FBVyxDQUFDLFVBQVUsaUJBQWlCO0FBQUEsTUFDdkMsV0FBVyxDQUFDLE9BQU8sT0FBTyxPQUFPLE1BQU0sbUJBQW1CLGFBQWEsT0FBTyxPQUFPLE9BQU8sTUFBTSxjQUFjO0FBQUEsSUFDeEg7QUFBQSxJQUNJO0FBQUEsTUFDSSxXQUFXLENBQUMsVUFBVSxtQkFBbUIsS0FBSztBQUFBLE1BQzlDLFdBQVcsQ0FBQyxVQUFVLGdCQUFnQixNQUFNLFVBQVU7QUFBQSxJQUM5RDtBQUFBLElBQ0k7QUFBQSxNQUNJLFdBQVcsQ0FBQyxVQUFVLHVCQUF1QixLQUFLO0FBQUEsTUFDbEQsV0FBVyxDQUFDLFVBQVU7QUFDbEIsY0FBTSxhQUFhO0FBQ25CLGVBQU8sSUFBSSxXQUFXLFlBQVksSUFBSSxJQUFJLFdBQVcsVUFBVTtBQUFBLE1BQ25FO0FBQUEsSUFDUjtBQUFBLEVBQ0E7QUFDQSxRQUFNLHVCQUF1QixDQUFDLE9BQU8sT0FBTyxPQUFPLE1BQU0sbUJBQW1CO0FBQ3hFLGVBQVcsY0FBYyxtQkFBbUI7QUFDeEMsVUFBSSxDQUFDLFdBQVcsVUFBVSxLQUFLLEdBQUc7QUFDOUI7QUFBQSxNQUNKO0FBQ0EsYUFBTyxXQUFXLFVBQVUsT0FBTyxPQUFPLE9BQU8sTUFBTSxjQUFjO0FBQUEsSUFDekU7QUFDQSxXQUFPLHNCQUFzQixPQUFPLE9BQU8sT0FBTyxNQUFNLGNBQWM7QUFBQSxFQUMxRTtBQUNBLFFBQU0sc0JBQXNCLENBQUMsT0FBTyxPQUFPLE9BQU8sU0FBUztBQUN2RCxVQUFNLFlBQVksbUJBQW1CLEtBQUs7QUFDMUMsUUFBSSxVQUFVLFNBQVM7QUFDbkIsYUFBTyxVQUFVO0FBQUEsSUFDckI7QUFDQSxRQUFJLFNBQVMscUJBQXFCO0FBQzlCLGFBQU87QUFBQSxJQUNYO0FBQ0EsUUFBSSxPQUFPLFVBQVUsWUFBWSxVQUFVLE1BQU07QUFDN0MsYUFBTyxPQUFPLFVBQVUsU0FBUyxLQUFLLEtBQUs7QUFBQSxJQUMvQztBQUNBLFVBQU0sZUFBZSxNQUFNLEtBQUssSUFBSSxLQUFLO0FBQ3pDLFFBQUksY0FBYztBQUNkLGFBQU8sY0FBYyxZQUFZO0FBQUEsSUFDckM7QUFDQSxVQUFNLEtBQUssSUFBSSxPQUFPLElBQUk7QUFDMUIsV0FBTyxxQkFBcUIsT0FBTyxPQUFPLE9BQU8sTUFBTSxtQkFBbUI7QUFBQSxFQUM5RTtBQUNPLFdBQVMscUJBQXFCLFVBQVU7QUFDM0MsV0FBTyxDQUFDLFVBQVU7QUFDZCxVQUFJLE9BQU8sVUFBVSxVQUFVO0FBQzNCLGVBQU8sU0FBUyxLQUFLO0FBQUEsTUFDekI7QUFDQSxVQUFJLE9BQU8sVUFBVSxZQUNqQixPQUFPLFVBQVUsYUFDakIsVUFBVSxRQUNWLE9BQU8sVUFBVSxhQUFhO0FBQzlCLGVBQU8sT0FBTyxLQUFLO0FBQUEsTUFDdkI7QUFDQSxVQUFJO0FBQ0EsY0FBTSxhQUFhLG9CQUFvQixPQUFPO0FBQUEsVUFDMUMsTUFBTSxvQkFBSSxRQUFPO0FBQUEsUUFDakMsR0FBZSxHQUFHLEdBQUc7QUFDVCxZQUFJLE9BQU8sZUFBZSxVQUFVO0FBQ2hDLGlCQUFPLFNBQVMsVUFBVTtBQUFBLFFBQzlCO0FBQ0EsZUFBTyxTQUFTLEtBQUssVUFBVSxVQUFVLENBQUM7QUFBQSxNQUM5QyxTQUNPLE9BQU87QUFDVixpQkFBUyxvQkFBb0IsaUVBQWlFLEtBQUs7QUFDbkcsZUFBTyxTQUFTLE9BQU8sVUFBVSxTQUFTLEtBQUssS0FBSyxDQUFDO0FBQUEsTUFDekQ7QUFBQSxJQUNKO0FBQUEsRUFDSjtBQUNPLFFBQU0sd0JBQXdCLENBQUMsTUFBTSxtQkFBbUI7QUFDM0QsUUFBSSxDQUFDLE1BQU07QUFDUCxhQUFPO0FBQUEsSUFDWDtBQUNBLFFBQUksT0FBTyxTQUFTLFVBQVU7QUFDMUIsYUFBTyxTQUFTLE1BQU0sZUFBZTtBQUFBLElBQ3pDO0FBQ0EsUUFBSSxnQkFBZ0IsaUJBQWlCO0FBQ2pDLGFBQU8sU0FBUyxLQUFLLFNBQVEsR0FBSSxlQUFlO0FBQUEsSUFDcEQ7QUFDQSxRQUFJLE9BQU8sYUFBYSxlQUFlLGdCQUFnQixVQUFVO0FBQzdELFlBQU0sT0FBTyxDQUFBO0FBQ2IsaUJBQVcsT0FBTyxLQUFLLFFBQVE7QUFDM0IsYUFBSyxLQUFLLEdBQUc7QUFBQSxNQUNqQjtBQUNBLGFBQU8sU0FBUyxlQUFlLEtBQUssS0FBSyxHQUFHLENBQUMsSUFBSSxlQUFlO0FBQUEsSUFDcEU7QUFDQSxRQUFJLE9BQU8sU0FBUyxlQUFlLGdCQUFnQixNQUFNO0FBQ3JELGFBQU8sU0FBUyxLQUFLLFFBQVEsU0FBUyxJQUFJLEtBQUssSUFBSTtBQUFBLElBQ3ZEO0FBQ0EsUUFBSSxPQUFPLGdCQUFnQixhQUFhO0FBQ3BDLFVBQUksZ0JBQWdCLGFBQWE7QUFDN0IsZUFBTyxnQkFBZ0IsS0FBSyxVQUFVO0FBQUEsTUFDMUM7QUFDQSxVQUFJLFlBQVksT0FBTyxJQUFJLEdBQUc7QUFDMUIsZUFBTyxJQUFJLEtBQUssWUFBWSxLQUFLLFlBQVcsQ0FBRSxJQUFJLEtBQUssVUFBVTtBQUFBLE1BQ3JFO0FBQUEsSUFDSjtBQUNBLFdBQU8sU0FBUyxlQUFlLElBQUksR0FBRyxlQUFlO0FBQUEsRUFDekQ7QUFDTyxRQUFNLDJCQUEyQixDQUFDLGdCQUFnQjtBQUNyRCxVQUFNLGFBQWEsWUFBWSxZQUFXO0FBQzFDLFdBQVEsV0FBVyxTQUFTLE1BQU0sS0FDOUIsV0FBVyxTQUFTLE1BQU0sS0FDMUIsV0FBVyxTQUFTLEtBQUssS0FDekIsV0FBVyxTQUFTLHVCQUF1QjtBQUFBLEVBQ25EO0FDelFPLFFBQU0saUJBQWlCLENBQUMsVUFBVTtBQUNyQyxRQUFJLENBQUMsT0FBTztBQUNSLGFBQU8sQ0FBQTtBQUFBLElBQ1g7QUFDQSxVQUFNQSxVQUFTLENBQUE7QUFDZixlQUFXLENBQUMsS0FBSyxLQUFLLEtBQUssTUFBTSxRQUFPLEdBQUk7QUFDeEMsWUFBTSxnQkFBZ0IsSUFBSSxLQUFJLEVBQUcsWUFBVztBQUM1QyxVQUFJLENBQUMsaUJBQWlCLGlCQUFpQixhQUFhLEdBQUc7QUFDbkQ7QUFBQSxNQUNKO0FBQ0EsTUFBQUEsUUFBTyxjQUFjLE1BQU0sR0FBRyxzQkFBc0IsQ0FBQyxJQUFJLE1BQU0sTUFBTSxHQUFHLHVCQUF1QjtBQUFBLElBQ25HO0FBQ0EsV0FBT0E7QUFBQSxFQUNYO0FBQ08sUUFBTSxrQkFBa0IsQ0FBQyxlQUFlO0FBQzNDLFVBQU1BLFVBQVMsQ0FBQTtBQUNmLFVBQU0sUUFBUSxXQUFXLE1BQU0sSUFBSTtBQUNuQyxlQUFXLFFBQVEsT0FBTztBQUN0QixZQUFNLGlCQUFpQixLQUFLLFFBQVEsTUFBTSxFQUFFO0FBQzVDLFlBQU0saUJBQWlCLGVBQWUsUUFBUSxHQUFHO0FBQ2pELFVBQUksa0JBQWtCLEdBQUc7QUFDckI7QUFBQSxNQUNKO0FBQ0EsWUFBTSxNQUFNLGVBQWUsTUFBTSxHQUFHLGNBQWMsRUFBRSxLQUFJLEVBQUcsWUFBVztBQUN0RSxVQUFJLENBQUMsT0FBTyxpQkFBaUIsR0FBRyxHQUFHO0FBQy9CO0FBQUEsTUFDSjtBQUNBLFlBQU0sUUFBUSxlQUFlLE1BQU0saUJBQWlCLENBQUMsRUFBRSxLQUFJO0FBQzNELFVBQUksQ0FBQyxPQUFPO0FBQ1I7QUFBQSxNQUNKO0FBQ0EsTUFBQUEsUUFBTyxJQUFJLE1BQU0sR0FBRyxzQkFBc0IsQ0FBQyxJQUFJLE1BQU0sTUFBTSxHQUFHLHVCQUF1QjtBQUFBLElBQ3pGO0FBQ0EsV0FBT0E7QUFBQSxFQUNYO0FDakNPLFFBQU0seUJBQXlCLENBQUMsVUFBVSxTQUFTO0FBQ3RELFVBQU0sY0FBYyxNQUFNO0FBQ3RCLGNBQVEsUUFBUSxLQUFJLENBQUUsRUFBRSxNQUFNLENBQUMsVUFBVTtBQUNyQyxpQkFBUyxvQkFBb0IsbURBQW1ELEtBQUs7QUFBQSxNQUN6RixDQUFDO0FBQUEsSUFDTDtBQUNBLFFBQUksT0FBTyxPQUFPLHdCQUF3QixZQUFZO0FBQ2xELGFBQU8sb0JBQW9CLE1BQU07QUFDN0Isb0JBQVc7QUFBQSxNQUNmLENBQUM7QUFDRDtBQUFBLElBQ0o7QUFDQSxXQUFPLFdBQVcsYUFBYSxDQUFDO0FBQUEsRUFDcEM7QUFDTyxRQUFNLDZCQUE2QixDQUFDLFVBQVUsTUFBTSxnQkFBZ0IsY0FBYyxPQUFPO0FBQzVGLFdBQU8sSUFBSSxRQUFRLENBQUMsWUFBWTtBQUM1Qiw2QkFBdUIsVUFBVSxNQUFNO0FBQ25DLGdCQUFRLHFCQUFxQixzQkFBc0IsTUFBTSxjQUFjLEdBQUcsV0FBVyxDQUFDO0FBQUEsTUFDMUYsQ0FBQztBQUFBLElBQ0wsQ0FBQztBQUFBLEVBQ0w7QUFDTyxRQUFNLDBCQUEwQixDQUFDLFVBQVUsYUFBYSxjQUFjLGFBQWE7QUFDdEYsV0FBTyxJQUFJLFFBQVEsQ0FBQyxZQUFZO0FBQzVCLDZCQUF1QixVQUFVLFlBQVk7QUFDekMsWUFBSSxDQUFDLHlCQUF5QixXQUFXLEdBQUc7QUFDeEMsa0JBQVEsTUFBUztBQUNqQjtBQUFBLFFBQ0o7QUFDQSxZQUFJO0FBQ0Esa0JBQVEscUJBQXFCLFNBQVMsTUFBTSxTQUFRLEdBQUksZUFBZSxHQUFHLFdBQVcsQ0FBQztBQUFBLFFBQzFGLFNBQ08sT0FBTztBQUNWLG1CQUFTLG9CQUFvQixjQUFjLEtBQUs7QUFDaEQsa0JBQVEsTUFBUztBQUFBLFFBQ3JCO0FBQUEsTUFDSixDQUFDO0FBQUEsSUFDTCxDQUFDO0FBQUEsRUFDTDtBQ25DQSxRQUFNLHFCQUFxQixDQUFDLE9BQU8sU0FBUztBQUN4QyxRQUFJLE9BQU8sTUFBTSxXQUFXLFlBQVksS0FBSyxRQUFRO0FBQ2pELGFBQU8sS0FBSyxPQUFPLFlBQVc7QUFBQSxJQUNsQztBQUNBLFFBQUksaUJBQWlCLFNBQVM7QUFDMUIsYUFBTyxNQUFNLE9BQU8sWUFBVztBQUFBLElBQ25DO0FBQ0EsV0FBTztBQUFBLEVBQ1g7QUFDQSxRQUFNLGtCQUFrQixDQUFDLFVBQVU7QUFDL0IsUUFBSSxPQUFPLFVBQVUsVUFBVTtBQUMzQixhQUFPO0FBQUEsSUFDWDtBQUNBLFFBQUksaUJBQWlCLEtBQUs7QUFDdEIsYUFBTyxNQUFNLFNBQVE7QUFBQSxJQUN6QjtBQUNBLFdBQU8sTUFBTTtBQUFBLEVBQ2pCO0FBQ0EsUUFBTSw2QkFBNkIsT0FBTyxPQUFPLE1BQU0sZ0JBQWdCLGdCQUFnQixhQUFhO0FBQ2hHLFVBQU0sa0JBQWtCLHNCQUFzQixNQUFNLE1BQU0sY0FBYztBQUN4RSxRQUFJLGlCQUFpQjtBQUNqQixhQUFPO0FBQUEsSUFDWDtBQUNBLFFBQUksRUFBRSxpQkFBaUIsVUFBVTtBQUM3QixhQUFPO0FBQUEsSUFDWDtBQUNBLFVBQU0sVUFBVSxNQUFNLFVBQVUsTUFBTSxVQUFVLE9BQU8sWUFBVztBQUNsRSxRQUFJLFdBQVcsU0FBUyxXQUFXLFVBQVUsTUFBTSxVQUFVO0FBQ3pELGFBQU87QUFBQSxJQUNYO0FBQ0EsVUFBTSxjQUFjLGdCQUFnQixJQUFJLGNBQWMsS0FDbEQsTUFBTSxRQUFRLElBQUksY0FBYyxLQUNoQztBQUNKLFFBQUksQ0FBQyx5QkFBeUIsV0FBVyxHQUFHO0FBQ3hDLGFBQU87QUFBQSxJQUNYO0FBQ0EsUUFBSTtBQUNBLGFBQU8scUJBQXFCLFNBQVMsTUFBTSxNQUFNLE1BQUssRUFBRyxLQUFJLEdBQUksZUFBZSxHQUFHLFdBQVc7QUFBQSxJQUNsRyxTQUNPLE9BQU87QUFDVixlQUFTLG9CQUFvQixvRUFBb0UsS0FBSztBQUN0RyxhQUFPO0FBQUEsSUFDWDtBQUFBLEVBQ0o7QUFDQSxRQUFNLGlDQUFpQyxDQUFDLGNBQWMsYUFBYSxxQkFBcUIsZ0JBQWdCLFVBQVUseUJBQXlCO0FBQ3ZJLFFBQUksd0JBQXdCLFNBQVM7QUFDakMsYUFBUSxxQkFBcUIsSUFBSSxZQUFZLEtBQ3pDLDJCQUEyQixjQUFjLGFBQWEscUJBQXFCLGdCQUFnQixRQUFRO0FBQUEsSUFDM0c7QUFDQSxXQUFPLDJCQUEyQixjQUFjLGFBQWEscUJBQXFCLGdCQUFnQixRQUFRO0FBQUEsRUFDOUc7QUFDTyxRQUFNLHNCQUFzQixDQUFDLE1BQU0sVUFBVSxnQkFBZ0IseUJBQXlCO0FBQ3pGLFVBQU0sQ0FBQyxjQUFjLFdBQVcsSUFBSTtBQUNwQyxVQUFNLFNBQVMsbUJBQW1CLGNBQWMsV0FBVztBQUMzRCxVQUFNLE1BQU0sZ0JBQWdCLFlBQVk7QUFDeEMsVUFBTSxjQUFjLGNBQWMsS0FBSyxRQUFRO0FBQy9DLFFBQUksQ0FBQyxhQUFhO0FBQ2QsYUFBTztBQUFBLElBQ1g7QUFDQSxRQUFJLHNCQUFzQjtBQUMxQixRQUFJLGFBQWEsU0FBUztBQUN0QixVQUFJO0FBQ0EsOEJBQXNCLElBQUksUUFBUSxZQUFZLE9BQU87QUFBQSxNQUN6RCxTQUNPLE9BQU87QUFDVixpQkFBUyxvQkFBb0IsaUVBQWlFLEtBQUs7QUFBQSxNQUN2RztBQUFBLElBQ0osV0FDUyx3QkFBd0IsU0FBUztBQUN0Qyw0QkFBc0IsYUFBYTtBQUFBLElBQ3ZDO0FBQ0EsVUFBTSxpQkFBaUIsc0JBQ2pCLGVBQWUsbUJBQW1CLElBQ2xDLHdCQUF3QixVQUNwQixlQUFlLGFBQWEsT0FBTyxJQUNuQyxDQUFBO0FBQ1YsVUFBTSxxQkFBcUIscUJBQXFCLElBQUksY0FBYyxNQUM3RCx3QkFBd0IsVUFDbEIsYUFBYSxRQUFRLElBQUksY0FBYyxLQUFLLEtBQzdDO0FBQ1YsVUFBTSxxQkFBcUIsK0JBQStCLGNBQWMsYUFBYSxxQkFBcUIsZ0JBQWdCLFVBQVUsb0JBQW9CO0FBQ3hKLFdBQU87QUFBQSxNQUNIO0FBQUEsTUFDQSxlQUFlLDJCQUEyQixXQUFXO0FBQUEsTUFDckQ7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ1I7QUFBQSxFQUNBO0FBQ08sUUFBTSxtQ0FBbUMsQ0FBQyxVQUFVLGdCQUFnQix5QkFBeUI7QUFDaEcsUUFBSSxPQUFPLE9BQU8sWUFBWSxZQUFZO0FBQ3RDO0FBQUEsSUFDSjtBQUNBLFVBQU0sa0JBQWtCLE9BQU87QUFDL0IsVUFBTSxpQkFBaUIsSUFBSSxNQUFNLGlCQUFpQjtBQUFBLE1BQzlDLFVBQVUsUUFBUSxVQUFVLFdBQVc7QUFDbkMsY0FBTSxDQUFBLEVBQUcsV0FBVyxJQUFJO0FBQ3hCLGNBQU0sa0JBQWtCLFFBQVEsVUFBVSxRQUFRLFVBQVUsU0FBUztBQUNyRSxZQUFJO0FBQ0osWUFBSSxhQUFhLFlBQVksUUFBVztBQUNwQyxjQUFJO0FBQ0Esa0NBQXNCLElBQUksUUFBUSxZQUFZLE9BQU87QUFBQSxVQUN6RCxTQUNPLE9BQU87QUFDVixxQkFBUyxvQkFBb0IsbUVBQW1FLEtBQUs7QUFDckcsa0NBQXNCLGdCQUFnQjtBQUFBLFVBQzFDO0FBQUEsUUFDSixPQUNLO0FBQ0QsZ0NBQXNCLGdCQUFnQjtBQUFBLFFBQzFDO0FBQ0EsY0FBTSxjQUFjLG9CQUFvQixJQUFJLGNBQWMsS0FBSztBQUMvRCxjQUFNLHFCQUFxQixhQUFhLFNBQVMsU0FDM0MsMkJBQTJCLFVBQVUsWUFBWSxNQUFNLGdCQUFnQixXQUFXLElBQ2xGLHdCQUF3QixVQUFVLGFBQWEsbUVBQW1FLE1BQU07QUFDdEgsY0FBSSxnQkFBZ0IsVUFBVTtBQUMxQixtQkFBTyxRQUFRLFFBQVEsRUFBRTtBQUFBLFVBQzdCO0FBQ0EsaUJBQU8sZ0JBQWdCLE1BQUssRUFBRyxLQUFJO0FBQUEsUUFDdkMsQ0FBQztBQUNMLDZCQUFxQixJQUFJLGlCQUFpQixrQkFBa0I7QUFDNUQsZUFBTztBQUFBLE1BQ1g7QUFBQSxJQUNSLENBQUs7QUFDRCxRQUFJO0FBQ0EsYUFBTyxPQUFPLGdCQUFnQixlQUFlO0FBQUEsSUFDakQsU0FDTyxPQUFPO0FBQ1YsZUFBUyxvQkFBb0IsK0VBQStFLEtBQUs7QUFBQSxJQUNySDtBQUNBLFFBQUk7QUFDQSxhQUFPLFVBQVU7QUFBQSxJQUNyQixTQUNPLE9BQU87QUFDVixlQUFTLG9CQUFvQixtRUFBbUUsS0FBSztBQUFBLElBQ3pHO0FBQUEsRUFDSjtBQ3hJQSxRQUFNLCtCQUErQixDQUFDLFVBQVUsYUFBYTtBQUN6RCxVQUFNLGNBQWMsU0FBUyxRQUFRLElBQUksY0FBYyxLQUFLO0FBQzVELFFBQUksQ0FBQyx5QkFBeUIsV0FBVyxLQUFLLFNBQVMsVUFBVTtBQUM3RCxhQUFPO0FBQUEsUUFDSDtBQUFBLFFBQ0EsZUFBZTtBQUFBLE1BQzNCO0FBQUEsSUFDSTtBQUNBLFFBQUk7QUFDQSxhQUFPO0FBQUEsUUFDSDtBQUFBLFFBQ0EsZUFBZSxTQUFTLE1BQUs7QUFBQSxNQUN6QztBQUFBLElBQ0ksU0FDTyxPQUFPO0FBQ1YsZUFBUyxvQkFBb0IsbUVBQW1FLEtBQUs7QUFDckcsYUFBTztBQUFBLFFBQ0g7QUFBQSxRQUNBLGVBQWU7QUFBQSxNQUMzQjtBQUFBLElBQ0k7QUFBQSxFQUNKO0FBQ08sUUFBTSwyQkFBMkIsQ0FBQyxVQUFVLGFBQWEsU0FBUyxVQUFVLGFBQWE7QUFDNUYsVUFBTSxrQkFBa0IsZUFBZSxTQUFTLE9BQU87QUFDdkQsVUFBTSxFQUFFLGFBQWEsY0FBYSxJQUFLLDZCQUE2QixVQUFVLFFBQVE7QUFDdEYsMkJBQXVCLFVBQVUsWUFBWTtBQUN6QyxVQUFJO0FBQ0osVUFBSTtBQUNKLFVBQUk7QUFDQSxzQkFBYyxNQUFNLFFBQVE7QUFBQSxNQUNoQyxTQUNPLE9BQU87QUFDVixpQkFBUyxvQkFBb0Isb0VBQW9FLEtBQUs7QUFBQSxNQUMxRztBQUNBLFVBQUk7QUFDQSx1QkFBZSxNQUFNLHdCQUF3QixVQUFVLGFBQWEsMEVBQTBFLE1BQU07QUFDaEosY0FBSSxDQUFDLGVBQWU7QUFDaEIsbUJBQU8sUUFBUSxRQUFRLEVBQUU7QUFBQSxVQUM3QjtBQUNBLGlCQUFPLGNBQWMsS0FBSTtBQUFBLFFBQzdCLENBQUM7QUFBQSxNQUNMLFNBQ08sT0FBTztBQUNWLGlCQUFTLG9CQUFvQixxRUFBcUUsS0FBSztBQUFBLE1BQzNHO0FBQ0Esa0JBQVk7QUFBQSxRQUNSLFFBQVEsUUFBUTtBQUFBLFFBQ2hCLEtBQUssUUFBUTtBQUFBLFFBQ2IsUUFBUSxTQUFTO0FBQUEsUUFDakI7QUFBQSxRQUNBLGdCQUFnQixRQUFRO0FBQUEsUUFDeEI7QUFBQSxRQUNBLGFBQWEscUJBQXFCLGFBQWEsUUFBUSxrQkFBa0I7QUFBQSxRQUN6RSxjQUFjLHFCQUFxQixjQUFjLFdBQVc7QUFBQSxNQUN4RSxDQUFTO0FBQUEsSUFDTCxDQUFDO0FBQUEsRUFDTDtBQUNPLFFBQU0sMkJBQTJCLENBQUMsVUFBVSxhQUFhLFNBQVMsT0FBTyxXQUFXLG1CQUFtQjtBQUMxRywyQkFBdUIsVUFBVSxZQUFZO0FBQ3pDLFVBQUk7QUFDSixVQUFJO0FBQ0Esc0JBQWMsTUFBTSxRQUFRO0FBQUEsTUFDaEMsU0FDTyxtQkFBbUI7QUFDdEIsc0JBQWM7QUFBQSxNQUNsQjtBQUNBLGtCQUFZO0FBQUEsUUFDUixRQUFRLFFBQVE7QUFBQSxRQUNoQixLQUFLLFFBQVE7QUFBQSxRQUNiLFFBQVE7QUFBQSxRQUNSLFVBQVUsS0FBSyxJQUFHLElBQUs7QUFBQSxRQUN2QixnQkFBZ0IsUUFBUTtBQUFBLFFBQ3hCLGFBQWEscUJBQXFCLGFBQWEsUUFBUSxrQkFBa0I7QUFBQSxRQUN6RSxjQUFjLHFCQUFxQixTQUFTLGVBQWUsS0FBSyxHQUFHLGVBQWUsR0FBRyxFQUFFO0FBQUEsTUFDbkcsQ0FBUztBQUFBLElBQ0wsQ0FBQztBQUFBLEVBQ0w7QUM3RU8sUUFBTSxzQkFBc0IsQ0FBQyxVQUFVO0FBQzFDLFVBQU0sRUFBRSxhQUFhLGFBQWEsU0FBUSxJQUFLO0FBQy9DLFVBQU0saUJBQWlCLHFCQUFxQixRQUFRO0FBQ3BELFVBQU0sdUJBQXVCLG9CQUFJLFFBQU87QUFDeEMsVUFBTSxZQUFZLENBQUMsY0FBYztBQUM3QixhQUFPLFVBQVUsS0FBSyxNQUFNO0FBQUEsSUFDaEM7QUFDQSxxQ0FBaUMsVUFBVSxnQkFBZ0Isb0JBQW9CO0FBQy9FLFFBQUksT0FBTyxPQUFPLFVBQVUsWUFBWTtBQUNwQyxrQkFBWSxrQkFBa0IsUUFBUTtBQUN0QztBQUFBLElBQ0o7QUFDQSxVQUFNLFlBQVksVUFBVSxPQUFPLEtBQUs7QUFDeEMsUUFBSSxnQkFBZ0I7QUFDcEIsUUFBSSx1QkFBdUI7QUFDM0IsVUFBTSxnQkFBZ0IsVUFBVSxTQUFTO0FBQ3JDLFVBQUksc0JBQXNCO0FBRXRCLGVBQU8sVUFBVSxHQUFHLElBQUk7QUFBQSxNQUM1QjtBQUNBLDZCQUF1QjtBQUN2QixrQkFBWSxnQkFBZTtBQUMzQixZQUFNLFlBQVksS0FBSyxJQUFHO0FBQzFCLFlBQU0sVUFBVSxvQkFBb0IsTUFBTSxVQUFVLGdCQUFnQixvQkFBb0I7QUFDeEYsVUFBSSxDQUFDLFNBQVM7QUFDVixZQUFJO0FBQ0EsaUJBQU8sY0FBYyxHQUFHLElBQUk7QUFBQSxRQUNoQyxVQUNaO0FBQ2dCLGlDQUF1QjtBQUFBLFFBQzNCO0FBQUEsTUFDSjtBQUNBLFVBQUk7QUFDQSxjQUFNLFdBQVcsTUFBTSxjQUFjLEdBQUcsSUFBSTtBQUM1QyxjQUFNLFdBQVcsS0FBSyxJQUFHLElBQUs7QUFDOUIsaUNBQXlCLFVBQVUsYUFBYSxTQUFTLFVBQVUsUUFBUTtBQUMzRSxlQUFPO0FBQUEsTUFDWCxTQUNPLE9BQU87QUFDVixvQkFBWSxtQkFBbUIsU0FBUyxlQUFlLEtBQUssR0FBRyxHQUFHLENBQUM7QUFDbkUsaUNBQXlCLFVBQVUsYUFBYSxTQUFTLE9BQU8sV0FBVyxjQUFjO0FBQ3pGLGNBQU07QUFBQSxNQUNWLFVBQ1I7QUFDWSwrQkFBdUI7QUFBQSxNQUMzQjtBQUFBLElBQ0o7QUFDQSxRQUFJO0FBQ0EsYUFBTyxPQUFPLGNBQWMsT0FBTyxLQUFLO0FBQUEsSUFDNUMsU0FDTyxPQUFPO0FBQ1YsZUFBUyxvQkFBb0IsaUVBQWlFLEtBQUs7QUFBQSxJQUN2RztBQUNBLFVBQU0sa0JBQWtCLE9BQU8seUJBQXlCLFFBQVEsT0FBTztBQUN2RSxVQUFNLG1CQUFtQixDQUFDLG1CQUFtQixnQkFBZ0I7QUFDN0QsUUFBSSxrQkFBa0I7QUFDbEIsVUFBSTtBQUNBLGVBQU8sZUFBZSxRQUFRLFNBQVM7QUFBQSxVQUNuQyxjQUFjO0FBQUEsVUFDZCxZQUFZLGlCQUFpQixjQUFjO0FBQUEsVUFDM0MsTUFBTTtBQUNGLG1CQUFPO0FBQUEsVUFDWDtBQUFBLFVBQ0EsSUFBSSxXQUFXO0FBQ1gsZ0JBQUksT0FBTyxjQUFjLFlBQVk7QUFDakM7QUFBQSxZQUNKO0FBQ0EsZ0JBQUksY0FBYyxjQUFjO0FBQzVCO0FBQUEsWUFDSjtBQUNBLDRCQUFnQixVQUFVLFNBQVM7QUFBQSxVQUN2QztBQUFBLFFBQ2hCLENBQWE7QUFDRCxvQkFBWSxrQkFBa0IsVUFBVTtBQUN4QztBQUFBLE1BQ0osU0FDTyxPQUFPO0FBQ1YsaUJBQVMsb0JBQW9CLGdFQUFnRSxLQUFLO0FBQUEsTUFDdEc7QUFBQSxJQUNKO0FBQ0EsUUFBSTtBQUNBLGFBQU8sUUFBUTtBQUNmLGtCQUFZLGtCQUFrQixZQUFZO0FBQUEsSUFDOUMsU0FDTyxPQUFPO0FBQ1Ysa0JBQVksa0JBQWtCLFFBQVE7QUFDdEMsZUFBUyxvQkFBb0IscURBQXFELEtBQUs7QUFBQSxJQUMzRjtBQUFBLEVBQ0o7QUN2Rk8sUUFBTSxvQkFBb0IsQ0FBQyxVQUFVO0FBQ3hDLFVBQU0sRUFBRSxhQUFhLGFBQWEsU0FBUSxJQUFLO0FBQy9DLFVBQU0saUJBQWlCLHFCQUFxQixRQUFRO0FBQ3BELFVBQU0sYUFBYSxvQkFBSSxRQUFPO0FBQzlCLFVBQU0sc0JBQXNCLE9BQU8sUUFBUTtBQUN2QyxZQUFNLFFBQVEsV0FBVyxJQUFJLEdBQUc7QUFDaEMsVUFBSSxDQUFDLE9BQU87QUFDUixlQUFPO0FBQUEsTUFDWDtBQUNBLFlBQU0sZ0JBQWdCLGNBQWMsTUFBTSxLQUFLLFFBQVE7QUFDdkQsVUFBSSxDQUFDLGVBQWU7QUFDaEIsZUFBTztBQUFBLE1BQ1g7QUFDQSxZQUFNLGNBQWMsMkJBQTJCLGFBQWE7QUFDNUQsVUFBSTtBQUNKLFVBQUk7QUFDSixZQUFNLGtCQUFrQixnQkFBZ0IsSUFBSSxzQkFBcUIsQ0FBRTtBQUNuRSxZQUFNLHNCQUFzQixnQkFBZ0IsY0FBYyxLQUFLO0FBQy9ELFVBQUk7QUFDQSxzQkFBYyxNQUFNLE1BQU07QUFBQSxNQUM5QixTQUNPLG1CQUFtQjtBQUN0QixzQkFBYztBQUFBLE1BQ2xCO0FBQ0EsVUFBSTtBQUNBLFlBQUksSUFBSSxpQkFBaUIsTUFBTSxJQUFJLGlCQUFpQixRQUFRO0FBQ3hELHlCQUFlLFNBQVMsSUFBSSxnQkFBZ0IsSUFBSSxlQUFlO0FBQUEsUUFDbkUsV0FDUyxJQUFJLGlCQUFpQixRQUFRO0FBQ2xDLHlCQUFlLFNBQVMsZUFBZSxJQUFJLFFBQVEsR0FBRyxlQUFlO0FBQUEsUUFDekU7QUFBQSxNQUNKLFNBQ08sT0FBTztBQUNWLGlCQUFTLG9CQUFvQixtRUFBbUUsS0FBSztBQUFBLE1BQ3pHO0FBQ0EsYUFBTztBQUFBLFFBQ0gsUUFBUSxNQUFNO0FBQUEsUUFDZCxLQUFLO0FBQUEsUUFDTCxRQUFRLElBQUk7QUFBQSxRQUNaLFVBQVUsS0FBSyxJQUFHLElBQUssTUFBTTtBQUFBLFFBQzdCLGdCQUFnQixNQUFNO0FBQUEsUUFDdEI7QUFBQSxRQUNBLGFBQWEscUJBQXFCLGFBQWEsTUFBTSxlQUFlLGNBQWMsS0FBSyxFQUFFO0FBQUEsUUFDekYsY0FBYyxxQkFBcUIsY0FBYyxtQkFBbUI7QUFBQSxNQUNoRjtBQUFBLElBQ0k7QUFDQSxVQUFNLHNCQUFzQixDQUFDLFFBQVE7QUFDakMsNkJBQXVCLFVBQVUsWUFBWTtBQUN6QyxjQUFNLFVBQVUsTUFBTSxvQkFBb0IsR0FBRztBQUM3QyxZQUFJLENBQUMsU0FBUztBQUNWO0FBQUEsUUFDSjtBQUNBLG9CQUFZLE9BQU87QUFBQSxNQUN2QixDQUFDO0FBQUEsSUFDTDtBQUNBLFVBQU0sZUFBZSxlQUFlLFVBQVU7QUFDOUMsVUFBTSx1QkFBdUI7QUFDN0IsbUJBQWUsVUFBVSxPQUFPLFNBQVUsUUFBUSxLQUFLLE9BQU8sVUFBVSxVQUFVO0FBQzlFLFlBQU0sbUJBQW1CLE9BQU8sV0FBVyxXQUFXLFNBQVM7QUFDL0QsWUFBTSxnQkFBZ0IsT0FBTyxRQUFRLFdBQVcsTUFBTSxPQUFPLE9BQU8sRUFBRTtBQUN0RSxpQkFBVyxJQUFJLE1BQU07QUFBQSxRQUNqQixRQUFRO0FBQUEsUUFDUixLQUFLO0FBQUEsUUFDTCxXQUFXLEtBQUssSUFBRztBQUFBLFFBQ25CLG9CQUFvQixRQUFRLFFBQVEsTUFBUztBQUFBLFFBQzdDLGdCQUFnQixDQUFBO0FBQUEsTUFDNUIsQ0FBUztBQUNELFVBQUksT0FBTyxVQUFVLGFBQ2pCLE9BQU8sYUFBYSxZQUNwQixhQUFhLFFBQ2IsT0FBTyxhQUFhLFlBQ3BCLGFBQWEsTUFBTTtBQUNuQixlQUFPLHFCQUFxQixLQUFLLE1BQU0sUUFBUSxLQUFLLFNBQVMsTUFBTSxVQUFVLFFBQVE7QUFBQSxNQUN6RjtBQUNBLGFBQU8scUJBQXFCLEtBQUssTUFBTSxRQUFRLEdBQUc7QUFBQSxJQUN0RDtBQUNBLFVBQU0sMkJBQTJCLGVBQWUsVUFBVTtBQUMxRCxtQkFBZSxVQUFVLG1CQUFtQixZQUFhLE1BQU07QUFDM0QsWUFBTSxDQUFDLEtBQUssS0FBSyxJQUFJO0FBQ3JCLFlBQU0sT0FBTyxXQUFXLElBQUksSUFBSTtBQUNoQyxVQUFJLE1BQU07QUFDTixjQUFNLGdCQUFnQixJQUFJLEtBQUksRUFBRyxZQUFXO0FBQzVDLFlBQUksQ0FBQyxpQkFBaUIsYUFBYSxHQUFHO0FBQ2xDLGVBQUssZUFBZSxjQUFjLE1BQU0sR0FBRyxzQkFBc0IsQ0FBQyxJQUM5RCxNQUFNLE1BQU0sR0FBRyx1QkFBdUI7QUFBQSxRQUM5QztBQUFBLE1BQ0o7QUFDQSxhQUFPLHlCQUF5QixNQUFNLE1BQU0sSUFBSTtBQUFBLElBQ3BEO0FBQ0EsVUFBTSxlQUFlLGVBQWUsVUFBVTtBQUM5QyxtQkFBZSxVQUFVLE9BQU8sWUFBYSxNQUFNO0FBQy9DLGtCQUFZLGNBQWE7QUFDekIsWUFBTSxPQUFPLFdBQVcsSUFBSSxJQUFJO0FBQ2hDLFVBQUksTUFBTTtBQUNOLGFBQUssWUFBWSxLQUFLLElBQUc7QUFDekIsYUFBSyxxQkFBcUIsMkJBQTJCLFVBQVUsS0FBSyxDQUFDLEdBQUcsZ0JBQWdCLEtBQUssZUFBZSxjQUFjLEtBQUssRUFBRTtBQUFBLE1BQ3JJO0FBQ0EsV0FBSyxpQkFBaUIsV0FBVyxNQUFNO0FBQ25DLDRCQUFvQixJQUFJO0FBQUEsTUFDNUIsR0FBRztBQUFBLFFBQ0MsTUFBTTtBQUFBLE1BQ2xCLENBQVM7QUFDRCxhQUFPLGFBQWEsTUFBTSxNQUFNLElBQUk7QUFBQSxJQUN4QztBQUNBLGdCQUFZLG9CQUFtQjtBQUFBLEVBQ25DO0FDNUdPLFdBQVMsc0JBQXNCLE9BQU87QUFDekMsd0JBQW9CLEtBQUs7QUFDekIsc0JBQWtCLEtBQUs7QUFBQSxFQUMzQjtBQ0dPLFdBQVMsNkJBQTZCO0FBQ3pDLFVBQU0sUUFBUTtBQUNkLFFBQUksTUFBTSxZQUFZLEdBQUc7QUFDckI7QUFBQSxJQUNKO0FBQ0EsVUFBTSxZQUFZLElBQUk7QUFDdEIsVUFBTSxjQUFjLHNCQUFzQixNQUFNO0FBQ2hELFVBQU0sV0FBVyxZQUFZLGVBQWUsdUJBQXNCLENBQUU7QUFDcEUsVUFBTSxFQUFFLGNBQWMsZ0JBQWUsSUFBSyxpQkFBaUI7QUFBQSxNQUN2RCxtQkFBbUIsWUFBWTtBQUFBLE1BQy9CLG9CQUFvQixZQUFZO0FBQUEsSUFDeEMsQ0FBSztBQUNELFVBQU0saUJBQWlCLHFCQUFxQixRQUFRO0FBQ3BELFVBQU0sYUFBYSxDQUFDLFlBQVksUUFBUSxhQUFhO0FBQ2pELGtCQUFZLGtCQUFpQjtBQUM3QixtQkFBYTtBQUFBLFFBQ1QsTUFBTTtBQUFBLFFBQ04sV0FBVyxLQUFLLElBQUc7QUFBQSxRQUNuQjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsTUFDWixDQUFTO0FBQUEsSUFDTDtBQUNBLFVBQU0sY0FBYyxDQUFDLE9BQU8sU0FBUztBQUNqQyxrQkFBWSxtQkFBa0I7QUFDOUIsWUFBTSxpQkFBaUIsQ0FBQTtBQUN2QixpQkFBVyxPQUFPLE1BQU07QUFDcEIsdUJBQWUsS0FBSyxlQUFlLEdBQUcsQ0FBQztBQUFBLE1BQzNDO0FBQ0EsbUJBQWE7QUFBQSxRQUNULE1BQU07QUFBQSxRQUNOLFdBQVcsS0FBSyxJQUFHO0FBQUEsUUFDbkI7QUFBQSxRQUNBLFNBQVMsU0FBUyxlQUFlLEtBQUssR0FBRyxDQUFDO0FBQUEsUUFDMUMsVUFBVTtBQUFBLFVBQ04sZUFBZSxLQUFLO0FBQUEsUUFDcEM7QUFBQSxNQUNBLENBQVM7QUFBQSxJQUNMO0FBQ0EsVUFBTSxjQUFjLENBQUMsWUFBWTtBQUM3QixrQkFBWSxtQkFBbUIsUUFBUSxHQUFHO0FBQzFDLG1CQUFhO0FBQUEsUUFDVCxNQUFNO0FBQUEsUUFDTixXQUFXLEtBQUssSUFBRztBQUFBLFFBQ25CLEdBQUc7QUFBQSxNQUNmLENBQVM7QUFBQSxJQUNMO0FBQ0Esc0NBQWtDO0FBQUEsTUFDOUI7QUFBQSxJQUNSLENBQUs7QUFDRCwwQkFBc0I7QUFBQSxNQUNsQjtBQUFBLE1BQ0E7QUFBQSxJQUNSLENBQUs7QUFDRCxRQUFJO0FBQ0EsNEJBQXNCO0FBQUEsUUFDbEI7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ1osQ0FBUztBQUFBLElBQ0wsU0FDTyxPQUFPO0FBQ1YsZUFBUyxvQkFBb0IseURBQXlELEtBQUs7QUFBQSxJQUMvRjtBQUNBLFVBQU0sa0JBQWtCLE1BQU07QUFDMUIsc0JBQWU7QUFBQSxJQUNuQjtBQUNBLFdBQU8saUJBQWlCLFlBQVksaUJBQWlCO0FBQUEsTUFDakQsU0FBUztBQUFBLElBQ2pCLENBQUs7QUFDRCxhQUFTLGlCQUFpQixvQkFBb0IsTUFBTTtBQUNoRCxVQUFJLFNBQVMsb0JBQW9CLFVBQVU7QUFDdkMsd0JBQWU7QUFBQSxNQUNuQjtBQUFBLElBQ0osR0FBRztBQUFBLE1BQ0MsU0FBUztBQUFBLE1BQ1QsU0FBUztBQUFBLElBQ2pCLENBQUs7QUFBQSxFQUNMO0FDckZBLFdBQVMsb0JBQW9CQyxhQUFZO0FBQ3hDLFdBQU9BO0FBQUEsRUFDUjtBQ0FBLFFBQUEsYUFBZSxvQkFBb0I7QUFBQSxJQUNqQyxTQUFTLENBQUMsWUFBWTtBQUFBLElBQ3RCLE9BQU87QUFBQSxJQUNQLE9BQU87QUFBQSxJQUNQLE9BQU87QUFDTCxpQ0FBQTtBQUFBLElBQ0Y7QUFBQSxFQUNGLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzsiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMTVdfQ==
debuggerPageMain;