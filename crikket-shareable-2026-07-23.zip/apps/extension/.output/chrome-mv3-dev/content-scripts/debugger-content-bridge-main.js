var debuggerContentBridgeMain = (function() {
  "use strict";
  function defineContentScript(definition2) {
    return definition2;
  }
  function reportNonFatalError(context, error, options) {
    console.warn(`[Non-fatal] ${context}`, error);
  }
  const PAGE_BRIDGE_SOURCE = "CRIKKET_DEBUGGER_PAGE_BRIDGE";
  const PAGE_EVENTS_MESSAGE = "CRIKKET_DEBUGGER_PAGE_EVENTS";
  function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
  }
  function isRecordLike(value) {
    return isRecord(value);
  }
  function sendDebuggerMessage(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        message,
        (response) => {
          const runtimeError = chrome.runtime.lastError;
          if (runtimeError) {
            reject(new Error(runtimeError.message));
            return;
          }
          if (!response) {
            reject(new Error("Debugger service did not respond"));
            return;
          }
          if (!response.ok) {
            reject(new Error(response.error));
            return;
          }
          resolve(response.data);
        }
      );
    });
  }
  async function sendDebuggerPageEvents(rawEvents) {
    if (rawEvents.length === 0) {
      return;
    }
    try {
      await sendDebuggerMessage({
        type: PAGE_EVENTS_MESSAGE,
        payload: {
          events: rawEvents
        }
      });
    } catch (error) {
      if (isExpectedRuntimeDisconnectError(error)) {
        return;
      }
      reportNonFatalError("Failed to send debugger page events", error);
    }
  }
  function isDebuggerContentBridgePayload(value) {
    if (!isRecordLike(value)) return false;
    if (value.source !== PAGE_BRIDGE_SOURCE) {
      return false;
    }
    const hasSingleEvent = Object.hasOwn(value, "event");
    const hasEventBatch = Array.isArray(value.events);
    return hasSingleEvent || hasEventBatch;
  }
  function isExpectedRuntimeDisconnectError(error) {
    if (!(error instanceof Error)) {
      return false;
    }
    const message = error.message.toLowerCase();
    return message.includes("extension context invalidated") || message.includes("receiving end does not exist");
  }
  const CONTENT_BRIDGE_INSTALL_FLAG = "__crikketDebuggerContentBridgeInstalled";
  function setupDebuggerContentBridge() {
    if (typeof window === "undefined") {
      return;
    }
    const scope = window;
    if (scope[CONTENT_BRIDGE_INSTALL_FLAG]) {
      return;
    }
    scope[CONTENT_BRIDGE_INSTALL_FLAG] = true;
    const queue = [];
    let flushTimer = null;
    const BATCH_SIZE = 40;
    const FLUSH_INTERVAL_MS = 120;
    const flushQueue = () => {
      flushTimer = null;
      if (queue.length === 0) {
        return;
      }
      const events = queue.splice(0, BATCH_SIZE);
      sendDebuggerPageEvents(events).catch((error) => {
        reportNonFatalError("Failed to forward debugger page events", error);
      });
      if (queue.length > 0) {
        flushTimer = setTimeout(flushQueue, 0);
        return;
      }
    };
    const scheduleFlush = () => {
      if (flushTimer) {
        return;
      }
      flushTimer = setTimeout(flushQueue, FLUSH_INTERVAL_MS);
    };
    const enqueueEvents = (events) => {
      if (events.length === 0) {
        return;
      }
      for (const candidate of events) {
        queue.push(candidate);
      }
      if (queue.length >= BATCH_SIZE) {
        if (flushTimer) {
          clearTimeout(flushTimer);
        }
        flushTimer = setTimeout(flushQueue, 0);
        return;
      }
      scheduleFlush();
    };
    const onWindowMessage = (event) => {
      if (event.source !== window) return;
      if (!isDebuggerContentBridgePayload(event.data)) return;
      if (Array.isArray(event.data.events)) {
        enqueueEvents(event.data.events);
        return;
      }
      enqueueEvents([event.data.event]);
    };
    window.addEventListener("message", onWindowMessage);
    window.addEventListener("pagehide", flushQueue, {
      capture: true
    });
  }
  const definition = defineContentScript({
    matches: ["<all_urls>"],
    runAt: "document_start",
    main() {
      setupDebuggerContentBridge();
    }
  });
  function print$1(method, ...args) {
    if (typeof args[0] === "string") method(`[wxt] ${args.shift()}`, ...args);
    else method("[wxt]", ...args);
  }
  const logger$1 = {
    debug: (...args) => print$1(console.debug, ...args),
    log: (...args) => print$1(console.log, ...args),
    warn: (...args) => print$1(console.warn, ...args),
    error: (...args) => print$1(console.error, ...args)
  };
  const browser$1 = globalThis.browser?.runtime?.id ? globalThis.browser : globalThis.chrome;
  const browser = browser$1;
  var WxtLocationChangeEvent = class WxtLocationChangeEvent2 extends Event {
    static EVENT_NAME = getUniqueEventName("wxt:locationchange");
    constructor(newUrl, oldUrl) {
      super(WxtLocationChangeEvent2.EVENT_NAME, {});
      this.newUrl = newUrl;
      this.oldUrl = oldUrl;
    }
  };
  function getUniqueEventName(eventName) {
    return `${browser?.runtime?.id}:${"debugger-content-bridge-main"}:${eventName}`;
  }
  function createLocationWatcher(ctx) {
    let interval;
    let oldUrl;
    return { run() {
      if (interval != null) return;
      oldUrl = new URL(location.href);
      interval = ctx.setInterval(() => {
        let newUrl = new URL(location.href);
        if (newUrl.href !== oldUrl.href) {
          window.dispatchEvent(new WxtLocationChangeEvent(newUrl, oldUrl));
          oldUrl = newUrl;
        }
      }, 1e3);
    } };
  }
  var ContentScriptContext = class ContentScriptContext2 {
    static SCRIPT_STARTED_MESSAGE_TYPE = getUniqueEventName("wxt:content-script-started");
    id;
    abortController;
    locationWatcher = createLocationWatcher(this);
    constructor(contentScriptName, options) {
      this.contentScriptName = contentScriptName;
      this.options = options;
      this.id = Math.random().toString(36).slice(2);
      this.abortController = new AbortController();
      this.stopOldScripts();
      this.listenForNewerScripts();
    }
    get signal() {
      return this.abortController.signal;
    }
    abort(reason) {
      return this.abortController.abort(reason);
    }
    get isInvalid() {
      if (browser.runtime?.id == null) this.notifyInvalidated();
      return this.signal.aborted;
    }
    get isValid() {
      return !this.isInvalid;
    }
    /**
    * Add a listener that is called when the content script's context is invalidated.
    *
    * @returns A function to remove the listener.
    *
    * @example
    * browser.runtime.onMessage.addListener(cb);
    * const removeInvalidatedListener = ctx.onInvalidated(() => {
    *   browser.runtime.onMessage.removeListener(cb);
    * })
    * // ...
    * removeInvalidatedListener();
    */
    onInvalidated(cb) {
      this.signal.addEventListener("abort", cb);
      return () => this.signal.removeEventListener("abort", cb);
    }
    /**
    * Return a promise that never resolves. Useful if you have an async function that shouldn't run
    * after the context is expired.
    *
    * @example
    * const getValueFromStorage = async () => {
    *   if (ctx.isInvalid) return ctx.block();
    *
    *   // ...
    * }
    */
    block() {
      return new Promise(() => {
      });
    }
    /**
    * Wrapper around `window.setInterval` that automatically clears the interval when invalidated.
    *
    * Intervals can be cleared by calling the normal `clearInterval` function.
    */
    setInterval(handler, timeout) {
      const id = setInterval(() => {
        if (this.isValid) handler();
      }, timeout);
      this.onInvalidated(() => clearInterval(id));
      return id;
    }
    /**
    * Wrapper around `window.setTimeout` that automatically clears the interval when invalidated.
    *
    * Timeouts can be cleared by calling the normal `setTimeout` function.
    */
    setTimeout(handler, timeout) {
      const id = setTimeout(() => {
        if (this.isValid) handler();
      }, timeout);
      this.onInvalidated(() => clearTimeout(id));
      return id;
    }
    /**
    * Wrapper around `window.requestAnimationFrame` that automatically cancels the request when
    * invalidated.
    *
    * Callbacks can be canceled by calling the normal `cancelAnimationFrame` function.
    */
    requestAnimationFrame(callback) {
      const id = requestAnimationFrame((...args) => {
        if (this.isValid) callback(...args);
      });
      this.onInvalidated(() => cancelAnimationFrame(id));
      return id;
    }
    /**
    * Wrapper around `window.requestIdleCallback` that automatically cancels the request when
    * invalidated.
    *
    * Callbacks can be canceled by calling the normal `cancelIdleCallback` function.
    */
    requestIdleCallback(callback, options) {
      const id = requestIdleCallback((...args) => {
        if (!this.signal.aborted) callback(...args);
      }, options);
      this.onInvalidated(() => cancelIdleCallback(id));
      return id;
    }
    addEventListener(target, type, handler, options) {
      if (type === "wxt:locationchange") {
        if (this.isValid) this.locationWatcher.run();
      }
      target.addEventListener?.(type.startsWith("wxt:") ? getUniqueEventName(type) : type, handler, {
        ...options,
        signal: this.signal
      });
    }
    /**
    * @internal
    * Abort the abort controller and execute all `onInvalidated` listeners.
    */
    notifyInvalidated() {
      this.abort("Content script context invalidated");
      logger$1.debug(`Content script "${this.contentScriptName}" context invalidated`);
    }
    stopOldScripts() {
      document.dispatchEvent(new CustomEvent(ContentScriptContext2.SCRIPT_STARTED_MESSAGE_TYPE, { detail: {
        contentScriptName: this.contentScriptName,
        messageId: this.id
      } }));
      window.postMessage({
        type: ContentScriptContext2.SCRIPT_STARTED_MESSAGE_TYPE,
        contentScriptName: this.contentScriptName,
        messageId: this.id
      }, "*");
    }
    verifyScriptStartedEvent(event) {
      const isSameContentScript = event.detail?.contentScriptName === this.contentScriptName;
      const isFromSelf = event.detail?.messageId === this.id;
      return isSameContentScript && !isFromSelf;
    }
    listenForNewerScripts() {
      const cb = (event) => {
        if (!(event instanceof CustomEvent) || !this.verifyScriptStartedEvent(event)) return;
        this.notifyInvalidated();
      };
      document.addEventListener(ContentScriptContext2.SCRIPT_STARTED_MESSAGE_TYPE, cb);
      this.onInvalidated(() => document.removeEventListener(ContentScriptContext2.SCRIPT_STARTED_MESSAGE_TYPE, cb));
    }
  };
  function initPlugins() {
  }
  function print(method, ...args) {
    if (typeof args[0] === "string") method(`[wxt] ${args.shift()}`, ...args);
    else method("[wxt]", ...args);
  }
  const logger = {
    debug: (...args) => print(console.debug, ...args),
    log: (...args) => print(console.log, ...args),
    warn: (...args) => print(console.warn, ...args),
    error: (...args) => print(console.error, ...args)
  };
  const result = (async () => {
    try {
      initPlugins();
      const { main, ...options } = definition;
      return await main(new ContentScriptContext("debugger-content-bridge-main", options));
    } catch (err) {
      logger.error(`The content script "${"debugger-content-bridge-main"}" crashed on startup!`, err);
      throw err;
    }
  })();
  return result;
})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVidWdnZXItY29udGVudC1icmlkZ2UtbWFpbi5qcyIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5idW4vd3h0QDAuMjAuMTcrNzQwNmFkZWI5YmZjZDU1My9ub2RlX21vZHVsZXMvd3h0L2Rpc3QvdXRpbHMvZGVmaW5lLWNvbnRlbnQtc2NyaXB0Lm1qcyIsIi4uLy4uLy4uLy4uLy4uL3BhY2thZ2VzL3NoYXJlZC9zcmMvbGliL2Vycm9ycy50cyIsIi4uLy4uLy4uLy4uLy4uL3BhY2thZ2VzL2NhcHR1cmUtY29yZS9kaXN0L2RlYnVnZ2VyL2NvbnN0YW50cy5qcyIsIi4uLy4uLy4uLy4uLy4uL3BhY2thZ2VzL2NhcHR1cmUtY29yZS9kaXN0L2RlYnVnZ2VyL25vcm1hbGl6ZS5qcyIsIi4uLy4uLy4uL2xpYi9idWctcmVwb3J0LWRlYnVnZ2VyL21lc3NhZ2luZy50cyIsIi4uLy4uLy4uL2xpYi9idWctcmVwb3J0LWRlYnVnZ2VyL2NvbnRlbnQudHMiLCIuLi8uLi8uLi9lbnRyeXBvaW50cy9kZWJ1Z2dlci1jb250ZW50LWJyaWRnZS1tYWluLmNvbnRlbnQudHMiLCIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLmJ1bi93eHRAMC4yMC4xNys3NDA2YWRlYjliZmNkNTUzL25vZGVfbW9kdWxlcy93eHQvZGlzdC91dGlscy9pbnRlcm5hbC9sb2dnZXIubWpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5idW4vQHd4dC1kZXYrYnJvd3NlckAwLjEuMzcvbm9kZV9tb2R1bGVzL0B3eHQtZGV2L2Jyb3dzZXIvc3JjL2luZGV4Lm1qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8uYnVuL3d4dEAwLjIwLjE3Kzc0MDZhZGViOWJmY2Q1NTMvbm9kZV9tb2R1bGVzL3d4dC9kaXN0L2Jyb3dzZXIubWpzIiwiLi4vLi4vLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5idW4vd3h0QDAuMjAuMTcrNzQwNmFkZWI5YmZjZDU1My9ub2RlX21vZHVsZXMvd3h0L2Rpc3QvdXRpbHMvaW50ZXJuYWwvY3VzdG9tLWV2ZW50cy5tanMiLCIuLi8uLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLmJ1bi93eHRAMC4yMC4xNys3NDA2YWRlYjliZmNkNTUzL25vZGVfbW9kdWxlcy93eHQvZGlzdC91dGlscy9pbnRlcm5hbC9sb2NhdGlvbi13YXRjaGVyLm1qcyIsIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy8uYnVuL3d4dEAwLjIwLjE3Kzc0MDZhZGViOWJmY2Q1NTMvbm9kZV9tb2R1bGVzL3d4dC9kaXN0L3V0aWxzL2NvbnRlbnQtc2NyaXB0LWNvbnRleHQubWpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vI3JlZ2lvbiBzcmMvdXRpbHMvZGVmaW5lLWNvbnRlbnQtc2NyaXB0LnRzXG5mdW5jdGlvbiBkZWZpbmVDb250ZW50U2NyaXB0KGRlZmluaXRpb24pIHtcblx0cmV0dXJuIGRlZmluaXRpb247XG59XG5cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgZGVmaW5lQ29udGVudFNjcmlwdCB9OyIsImludGVyZmFjZSBOb25GYXRhbEVycm9yT3B0aW9ucyB7XG4gIG9uY2U/OiBib29sZWFuXG59XG5cbmNvbnN0IHJlcG9ydGVkQ29udGV4dHMgPSBuZXcgU2V0PHN0cmluZz4oKVxuXG5leHBvcnQgZnVuY3Rpb24gcmVwb3J0Tm9uRmF0YWxFcnJvcihcbiAgY29udGV4dDogc3RyaW5nLFxuICBlcnJvcjogdW5rbm93bixcbiAgb3B0aW9ucz86IE5vbkZhdGFsRXJyb3JPcHRpb25zXG4pOiB2b2lkIHtcbiAgaWYgKG9wdGlvbnM/Lm9uY2UpIHtcbiAgICBpZiAocmVwb3J0ZWRDb250ZXh0cy5oYXMoY29udGV4dCkpIHtcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIHJlcG9ydGVkQ29udGV4dHMuYWRkKGNvbnRleHQpXG4gIH1cblxuICBjb25zb2xlLndhcm4oYFtOb24tZmF0YWxdICR7Y29udGV4dH1gLCBlcnJvcilcbn1cblxuaW50ZXJmYWNlIEVycm9yV2l0aENvZGUge1xuICBjb2RlPzogdW5rbm93blxufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNFcnJvcldpdGhDb2RlKFxuICBlcnJvcjogdW5rbm93bixcbiAgY29kZTogc3RyaW5nXG4pOiBlcnJvciBpcyBFcnJvciAmIEVycm9yV2l0aENvZGUge1xuICByZXR1cm4gKFxuICAgIGVycm9yIGluc3RhbmNlb2YgRXJyb3IgJiZcbiAgICBcImNvZGVcIiBpbiBlcnJvciAmJlxuICAgIChlcnJvciBhcyBFcnJvcldpdGhDb2RlKS5jb2RlID09PSBjb2RlXG4gIClcbn1cbiIsImV4cG9ydCBjb25zdCBNQVhfRVZFTlRfQ09VTlQgPSAyMDAwO1xuZXhwb3J0IGNvbnN0IE1BWF9URVhUX0xFTkdUSCA9IDIwMDA7XG5leHBvcnQgY29uc3QgTUFYX1VSTF9MRU5HVEggPSA0MDk2O1xuZXhwb3J0IGNvbnN0IE1BWF9ORVRXT1JLX0JPRFlfTEVOR1RIID0gNDAwMDtcbmV4cG9ydCBjb25zdCBQQUdFX0JSSURHRV9TT1VSQ0UgPSBcIkNSSUtLRVRfREVCVUdHRVJfUEFHRV9CUklER0VcIjtcbmV4cG9ydCBjb25zdCBCQUNLR1JPVU5EX0xJU1RFTkVSX0ZMQUcgPSBcIl9fY3Jpa2tldERlYnVnZ2VyQmFja2dyb3VuZExpc3RlbmVyUmVnaXN0ZXJlZFwiO1xuZXhwb3J0IGNvbnN0IERFQlVHR0VSX1NFU1NJT05TX1NUT1JBR0VfS0VZID0gXCJjcmlra2V0RGVidWdnZXJTZXNzaW9uc1wiO1xuZXhwb3J0IGNvbnN0IERFQlVHR0VSX1JFUExBWV9CVUZGRVJTX1NUT1JBR0VfS0VZID0gXCJjcmlra2V0RGVidWdnZXJSZXBsYXlCdWZmZXJzXCI7XG5leHBvcnQgY29uc3QgREVCVUdHRVJfU0VTU0lPTl9JRF9TVE9SQUdFX0tFWSA9IFwiZGVidWdnZXJTZXNzaW9uSWRcIjtcbmV4cG9ydCBjb25zdCBTVEFSVF9TRVNTSU9OX01FU1NBR0UgPSBcIkNSSUtLRVRfREVCVUdHRVJfU1RBUlRfU0VTU0lPTlwiO1xuZXhwb3J0IGNvbnN0IE1BUktfUkVDT1JESU5HX1NUQVJURURfTUVTU0FHRSA9IFwiQ1JJS0tFVF9ERUJVR0dFUl9NQVJLX1JFQ09SRElOR19TVEFSVEVEXCI7XG5leHBvcnQgY29uc3QgR0VUX1NFU1NJT05fU05BUFNIT1RfTUVTU0FHRSA9IFwiQ1JJS0tFVF9ERUJVR0dFUl9HRVRfU0VTU0lPTl9TTkFQU0hPVFwiO1xuZXhwb3J0IGNvbnN0IERJU0NBUkRfU0VTU0lPTl9NRVNTQUdFID0gXCJDUklLS0VUX0RFQlVHR0VSX0RJU0NBUkRfU0VTU0lPTlwiO1xuZXhwb3J0IGNvbnN0IFBBR0VfRVZFTlRfTUVTU0FHRSA9IFwiQ1JJS0tFVF9ERUJVR0dFUl9QQUdFX0VWRU5UXCI7XG5leHBvcnQgY29uc3QgUEFHRV9FVkVOVFNfTUVTU0FHRSA9IFwiQ1JJS0tFVF9ERUJVR0dFUl9QQUdFX0VWRU5UU1wiO1xuZXhwb3J0IGNvbnN0IEVOU1VSRV9QQUdFX1JVTlRJTUVfTUVTU0FHRSA9IFwiQ1JJS0tFVF9ERUJVR0dFUl9FTlNVUkVfUEFHRV9SVU5USU1FXCI7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb25zdGFudHMuanMubWFwIiwiaW1wb3J0IHsgTUFYX05FVFdPUktfQk9EWV9MRU5HVEgsIE1BWF9URVhUX0xFTkdUSCwgTUFYX1VSTF9MRU5HVEgsIH0gZnJvbSBcIi4vY29uc3RhbnRzXCI7XG5leHBvcnQgZnVuY3Rpb24gbm9ybWFsaXplU3RvcmVkU2Vzc2lvbih2YWx1ZSkge1xuICAgIGlmICghaXNSZWNvcmQodmFsdWUpKVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICBjb25zdCBzZXNzaW9uSWQgPSBhc09wdGlvbmFsU3RyaW5nKHZhbHVlLnNlc3Npb25JZCk7XG4gICAgY29uc3QgY2FwdHVyZVRhYklkID0gYXNPcHRpb25hbE51bWJlcih2YWx1ZS5jYXB0dXJlVGFiSWQpO1xuICAgIGNvbnN0IGNhcHR1cmVUeXBlID0gdmFsdWUuY2FwdHVyZVR5cGU7XG4gICAgY29uc3Qgc3RhcnRlZEF0ID0gYXNPcHRpb25hbE51bWJlcih2YWx1ZS5zdGFydGVkQXQpO1xuICAgIGNvbnN0IHJlY29yZGluZ1N0YXJ0ZWRBdCA9IHZhbHVlLnJlY29yZGluZ1N0YXJ0ZWRBdCA9PT0gbnVsbFxuICAgICAgICA/IG51bGxcbiAgICAgICAgOiBhc09wdGlvbmFsTnVtYmVyKHZhbHVlLnJlY29yZGluZ1N0YXJ0ZWRBdCk7XG4gICAgaWYgKCFzZXNzaW9uSWQgfHwgY2FwdHVyZVRhYklkID09PSB1bmRlZmluZWQgfHwgc3RhcnRlZEF0ID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGlmIChjYXB0dXJlVHlwZSAhPT0gXCJ2aWRlb1wiICYmIGNhcHR1cmVUeXBlICE9PSBcInNjcmVlbnNob3RcIikge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgZXZlbnRzID0gQXJyYXkuaXNBcnJheSh2YWx1ZS5ldmVudHMpXG4gICAgICAgID8gdmFsdWUuZXZlbnRzLm1hcChub3JtYWxpemVEZWJ1Z2dlckV2ZW50KS5maWx0ZXIoaXNEZWZpbmVkKVxuICAgICAgICA6IFtdO1xuICAgIHJldHVybiB7XG4gICAgICAgIHNlc3Npb25JZCxcbiAgICAgICAgY2FwdHVyZVRhYklkLFxuICAgICAgICBjYXB0dXJlVHlwZSxcbiAgICAgICAgc3RhcnRlZEF0LFxuICAgICAgICByZWNvcmRpbmdTdGFydGVkQXQ6IHJlY29yZGluZ1N0YXJ0ZWRBdCA/PyBudWxsLFxuICAgICAgICBldmVudHMsXG4gICAgfTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBub3JtYWxpemVEZWJ1Z2dlckV2ZW50KHZhbHVlKSB7XG4gICAgaWYgKCFpc1JlY29yZCh2YWx1ZSkpXG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIGNvbnN0IGtpbmQgPSB2YWx1ZS5raW5kO1xuICAgIGlmIChraW5kICE9PSBcImFjdGlvblwiICYmIGtpbmQgIT09IFwiY29uc29sZVwiICYmIGtpbmQgIT09IFwibmV0d29ya1wiKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjb25zdCB0aW1lc3RhbXAgPSBhc09wdGlvbmFsTnVtYmVyKHZhbHVlLnRpbWVzdGFtcCk7XG4gICAgaWYgKHRpbWVzdGFtcCA9PT0gdW5kZWZpbmVkKVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICBpZiAoa2luZCA9PT0gXCJhY3Rpb25cIikge1xuICAgICAgICBjb25zdCBhY3Rpb25UeXBlID0gYXNPcHRpb25hbFN0cmluZyh2YWx1ZS5hY3Rpb25UeXBlKTtcbiAgICAgICAgaWYgKCFhY3Rpb25UeXBlKVxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBraW5kLFxuICAgICAgICAgICAgdGltZXN0YW1wLFxuICAgICAgICAgICAgYWN0aW9uVHlwZSxcbiAgICAgICAgICAgIHRhcmdldDogYXNPcHRpb25hbFN0cmluZyh2YWx1ZS50YXJnZXQsIE1BWF9URVhUX0xFTkdUSCksXG4gICAgICAgICAgICBtZXRhZGF0YTogc2FuaXRpemVSZWNvcmQodmFsdWUubWV0YWRhdGEpLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBpZiAoa2luZCA9PT0gXCJjb25zb2xlXCIpIHtcbiAgICAgICAgY29uc3QgbGV2ZWwgPSB2YWx1ZS5sZXZlbDtcbiAgICAgICAgaWYgKGxldmVsICE9PSBcImxvZ1wiICYmXG4gICAgICAgICAgICBsZXZlbCAhPT0gXCJpbmZvXCIgJiZcbiAgICAgICAgICAgIGxldmVsICE9PSBcIndhcm5cIiAmJlxuICAgICAgICAgICAgbGV2ZWwgIT09IFwiZXJyb3JcIiAmJlxuICAgICAgICAgICAgbGV2ZWwgIT09IFwiZGVidWdcIikge1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IGFzT3B0aW9uYWxTdHJpbmcodmFsdWUubWVzc2FnZSwgTUFYX1RFWFRfTEVOR1RIKTtcbiAgICAgICAgaWYgKCFtZXNzYWdlKVxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBraW5kLFxuICAgICAgICAgICAgdGltZXN0YW1wLFxuICAgICAgICAgICAgbGV2ZWwsXG4gICAgICAgICAgICBtZXNzYWdlLFxuICAgICAgICAgICAgbWV0YWRhdGE6IHNhbml0aXplUmVjb3JkKHZhbHVlLm1ldGFkYXRhKSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgY29uc3QgbWV0aG9kID0gYXNPcHRpb25hbFN0cmluZyh2YWx1ZS5tZXRob2QsIDIwKTtcbiAgICBjb25zdCB1cmwgPSBhc09wdGlvbmFsU3RyaW5nKHZhbHVlLnVybCwgTUFYX1VSTF9MRU5HVEgpO1xuICAgIGlmICghKG1ldGhvZCAmJiB1cmwpKVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4ge1xuICAgICAgICBraW5kLFxuICAgICAgICB0aW1lc3RhbXAsXG4gICAgICAgIG1ldGhvZCxcbiAgICAgICAgdXJsLFxuICAgICAgICBzdGF0dXM6IGFzT3B0aW9uYWxOdW1iZXIodmFsdWUuc3RhdHVzKSxcbiAgICAgICAgZHVyYXRpb246IGFzT3B0aW9uYWxOdW1iZXIodmFsdWUuZHVyYXRpb24pLFxuICAgICAgICByZXF1ZXN0SGVhZGVyczogc2FuaXRpemVIZWFkZXJzKHZhbHVlLnJlcXVlc3RIZWFkZXJzKSxcbiAgICAgICAgcmVzcG9uc2VIZWFkZXJzOiBzYW5pdGl6ZUhlYWRlcnModmFsdWUucmVzcG9uc2VIZWFkZXJzKSxcbiAgICAgICAgcmVxdWVzdEJvZHk6IGFzT3B0aW9uYWxTdHJpbmcodmFsdWUucmVxdWVzdEJvZHksIE1BWF9ORVRXT1JLX0JPRFlfTEVOR1RIKSxcbiAgICAgICAgcmVzcG9uc2VCb2R5OiBhc09wdGlvbmFsU3RyaW5nKHZhbHVlLnJlc3BvbnNlQm9keSwgTUFYX05FVFdPUktfQk9EWV9MRU5HVEgpLFxuICAgIH07XG59XG5mdW5jdGlvbiBzYW5pdGl6ZUhlYWRlcnModmFsdWUpIHtcbiAgICBpZiAoIWlzUmVjb3JkKHZhbHVlKSlcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICBjb25zdCByZXN1bHQgPSB7fTtcbiAgICBmb3IgKGNvbnN0IFtrZXksIGhlYWRlclZhbHVlXSBvZiBPYmplY3QuZW50cmllcyh2YWx1ZSkpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBoZWFkZXJWYWx1ZSAhPT0gXCJzdHJpbmdcIilcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICBjb25zdCBub3JtYWxpemVkS2V5ID0ga2V5LnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICBpZiAoIW5vcm1hbGl6ZWRLZXkgfHwgc2hvdWxkSGlkZUhlYWRlcihub3JtYWxpemVkS2V5KSkge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgcmVzdWx0W25vcm1hbGl6ZWRLZXkuc2xpY2UoMCwgMTIwKV0gPSBoZWFkZXJWYWx1ZS5zbGljZSgwLCA1MDApO1xuICAgIH1cbiAgICByZXR1cm4gT2JqZWN0LmtleXMocmVzdWx0KS5sZW5ndGggPiAwID8gcmVzdWx0IDogdW5kZWZpbmVkO1xufVxuZnVuY3Rpb24gc2hvdWxkSGlkZUhlYWRlcihoZWFkZXJOYW1lKSB7XG4gICAgcmV0dXJuIGhlYWRlck5hbWUuaW5jbHVkZXMoXCJkZWJ1Z2dlclwiKTtcbn1cbmZ1bmN0aW9uIHNhbml0aXplUmVjb3JkKHZhbHVlKSB7XG4gICAgaWYgKCFpc1JlY29yZCh2YWx1ZSkpXG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgY29uc3QgcmVzdWx0ID0ge307XG4gICAgZm9yIChjb25zdCBba2V5LCBlbnRyeVZhbHVlXSBvZiBPYmplY3QuZW50cmllcyh2YWx1ZSkpIHtcbiAgICAgICAgY29uc3Qgbm9ybWFsaXplZCA9IHNhbml0aXplSnNvblZhbHVlKGVudHJ5VmFsdWUpO1xuICAgICAgICBpZiAobm9ybWFsaXplZCA9PT0gdW5kZWZpbmVkKVxuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIHJlc3VsdFtrZXkuc2xpY2UoMCwgMTIwKV0gPSBub3JtYWxpemVkO1xuICAgIH1cbiAgICByZXR1cm4gT2JqZWN0LmtleXMocmVzdWx0KS5sZW5ndGggPiAwID8gcmVzdWx0IDogdW5kZWZpbmVkO1xufVxuZnVuY3Rpb24gc2FuaXRpemVKc29uVmFsdWUodmFsdWUsIGRlcHRoID0gMCkge1xuICAgIGlmIChkZXB0aCA+IDMpXG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgaWYgKHZhbHVlID09PSBudWxsIHx8XG4gICAgICAgIHR5cGVvZiB2YWx1ZSA9PT0gXCJib29sZWFuXCIgfHxcbiAgICAgICAgdHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICByZXR1cm4gdmFsdWUuc2xpY2UoMCwgTUFYX1RFWFRfTEVOR1RIKTtcbiAgICB9XG4gICAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZVxuICAgICAgICAgICAgLnNsaWNlKDAsIDMwKVxuICAgICAgICAgICAgLm1hcCgoZW50cnkpID0+IHNhbml0aXplSnNvblZhbHVlKGVudHJ5LCBkZXB0aCArIDEpKVxuICAgICAgICAgICAgLmZpbHRlcihpc0RlZmluZWQpO1xuICAgIH1cbiAgICBpZiAoaXNSZWNvcmQodmFsdWUpKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IHt9O1xuICAgICAgICBmb3IgKGNvbnN0IFtrZXksIGVudHJ5VmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKHZhbHVlKS5zbGljZSgwLCAzMCkpIHtcbiAgICAgICAgICAgIGNvbnN0IG5vcm1hbGl6ZWQgPSBzYW5pdGl6ZUpzb25WYWx1ZShlbnRyeVZhbHVlLCBkZXB0aCArIDEpO1xuICAgICAgICAgICAgaWYgKG5vcm1hbGl6ZWQgPT09IHVuZGVmaW5lZClcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIHJlc3VsdFtrZXkuc2xpY2UoMCwgMTIwKV0gPSBub3JtYWxpemVkO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIHJldHVybiB1bmRlZmluZWQ7XG59XG5mdW5jdGlvbiBhc09wdGlvbmFsU3RyaW5nKHZhbHVlLCBtYXhMZW5ndGggPSBNQVhfVEVYVF9MRU5HVEgpIHtcbiAgICBpZiAodHlwZW9mIHZhbHVlICE9PSBcInN0cmluZ1wiKVxuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIGNvbnN0IHRyaW1tZWQgPSB2YWx1ZS50cmltKCk7XG4gICAgaWYgKCF0cmltbWVkKVxuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIHJldHVybiB0cmltbWVkLnNsaWNlKDAsIG1heExlbmd0aCk7XG59XG5mdW5jdGlvbiBhc09wdGlvbmFsTnVtYmVyKHZhbHVlKSB7XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gXCJudW1iZXJcIiB8fCAhTnVtYmVyLmlzRmluaXRlKHZhbHVlKSkge1xuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICByZXR1cm4gTWF0aC5mbG9vcih2YWx1ZSk7XG59XG5mdW5jdGlvbiBpc1JlY29yZCh2YWx1ZSkge1xuICAgIHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgJiYgdmFsdWUgIT09IG51bGwgJiYgIUFycmF5LmlzQXJyYXkodmFsdWUpO1xufVxuZnVuY3Rpb24gaXNEZWZpbmVkKHZhbHVlKSB7XG4gICAgcmV0dXJuIHZhbHVlICE9PSBudWxsICYmIHZhbHVlICE9PSB1bmRlZmluZWQ7XG59XG5leHBvcnQgZnVuY3Rpb24gaXNSZWNvcmRMaWtlKHZhbHVlKSB7XG4gICAgcmV0dXJuIGlzUmVjb3JkKHZhbHVlKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBub3JtYWxpemVTdG9yZWRSZXBsYXlCdWZmZXIodmFsdWUpIHtcbiAgICBpZiAoIWlzUmVjb3JkKHZhbHVlKSlcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgdGFiSWQgPSBhc09wdGlvbmFsTnVtYmVyKHZhbHVlLnRhYklkKTtcbiAgICBjb25zdCBsYXN0VG91Y2hlZEF0ID0gYXNPcHRpb25hbE51bWJlcih2YWx1ZS5sYXN0VG91Y2hlZEF0KTtcbiAgICBpZiAodGFiSWQgPT09IHVuZGVmaW5lZCB8fFxuICAgICAgICB0YWJJZCA8IDAgfHxcbiAgICAgICAgbGFzdFRvdWNoZWRBdCA9PT0gdW5kZWZpbmVkIHx8XG4gICAgICAgIGxhc3RUb3VjaGVkQXQgPCAwKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjb25zdCBldmVudHMgPSBBcnJheS5pc0FycmF5KHZhbHVlLmV2ZW50cylcbiAgICAgICAgPyB2YWx1ZS5ldmVudHMubWFwKG5vcm1hbGl6ZURlYnVnZ2VyRXZlbnQpLmZpbHRlcihpc0RlZmluZWQpXG4gICAgICAgIDogW107XG4gICAgcmV0dXJuIHtcbiAgICAgICAgdGFiSWQsXG4gICAgICAgIGxhc3RUb3VjaGVkQXQsXG4gICAgICAgIGV2ZW50cyxcbiAgICB9O1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bm9ybWFsaXplLmpzLm1hcCIsImltcG9ydCB7XG4gIERJU0NBUkRfU0VTU0lPTl9NRVNTQUdFLFxuICBFTlNVUkVfUEFHRV9SVU5USU1FX01FU1NBR0UsXG4gIEdFVF9TRVNTSU9OX1NOQVBTSE9UX01FU1NBR0UsXG4gIE1BUktfUkVDT1JESU5HX1NUQVJURURfTUVTU0FHRSxcbiAgUEFHRV9CUklER0VfU09VUkNFLFxuICBQQUdFX0VWRU5UX01FU1NBR0UsXG4gIFBBR0VfRVZFTlRTX01FU1NBR0UsXG4gIFNUQVJUX1NFU1NJT05fTUVTU0FHRSxcbn0gZnJvbSBcIkBjcmlra2V0L2NhcHR1cmUtY29yZS9kZWJ1Z2dlci9jb25zdGFudHNcIlxuaW1wb3J0IHsgaXNSZWNvcmRMaWtlIH0gZnJvbSBcIkBjcmlra2V0L2NhcHR1cmUtY29yZS9kZWJ1Z2dlci9ub3JtYWxpemVcIlxuaW1wb3J0IHR5cGUge1xuICBEZWJ1Z2dlckNvbnRlbnRCcmlkZ2VQYXlsb2FkLFxuICBEZWJ1Z2dlclJ1bnRpbWVNZXNzYWdlLFxuICBEZWJ1Z2dlclJ1bnRpbWVSZXNwb25zZSxcbn0gZnJvbSBcIkBjcmlra2V0L2NhcHR1cmUtY29yZS9kZWJ1Z2dlci90eXBlc1wiXG5pbXBvcnQgeyByZXBvcnROb25GYXRhbEVycm9yIH0gZnJvbSBcIkBjcmlra2V0L3NoYXJlZC9saWIvZXJyb3JzXCJcblxuZXhwb3J0IGZ1bmN0aW9uIHNlbmREZWJ1Z2dlck1lc3NhZ2U8VERhdGE+KFxuICBtZXNzYWdlOiBEZWJ1Z2dlclJ1bnRpbWVNZXNzYWdlXG4pOiBQcm9taXNlPFREYXRhPiB7XG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoXG4gICAgICBtZXNzYWdlLFxuICAgICAgKHJlc3BvbnNlOiBEZWJ1Z2dlclJ1bnRpbWVSZXNwb25zZTxURGF0YT4gfCB1bmRlZmluZWQpID0+IHtcbiAgICAgICAgY29uc3QgcnVudGltZUVycm9yID0gY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yXG4gICAgICAgIGlmIChydW50aW1lRXJyb3IpIHtcbiAgICAgICAgICByZWplY3QobmV3IEVycm9yKHJ1bnRpbWVFcnJvci5tZXNzYWdlKSlcbiAgICAgICAgICByZXR1cm5cbiAgICAgICAgfVxuXG4gICAgICAgIGlmICghcmVzcG9uc2UpIHtcbiAgICAgICAgICByZWplY3QobmV3IEVycm9yKFwiRGVidWdnZXIgc2VydmljZSBkaWQgbm90IHJlc3BvbmRcIikpXG4gICAgICAgICAgcmV0dXJuXG4gICAgICAgIH1cblxuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgICAgcmVqZWN0KG5ldyBFcnJvcihyZXNwb25zZS5lcnJvcikpXG4gICAgICAgICAgcmV0dXJuXG4gICAgICAgIH1cblxuICAgICAgICByZXNvbHZlKHJlc3BvbnNlLmRhdGEpXG4gICAgICB9XG4gICAgKVxuICB9KVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2VuZERlYnVnZ2VyUGFnZUV2ZW50KHJhd0V2ZW50OiB1bmtub3duKTogUHJvbWlzZTx2b2lkPiB7XG4gIGF3YWl0IHNlbmREZWJ1Z2dlclBhZ2VFdmVudHMoW3Jhd0V2ZW50XSlcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNlbmREZWJ1Z2dlclBhZ2VFdmVudHMoXG4gIHJhd0V2ZW50czogdW5rbm93bltdXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKHJhd0V2ZW50cy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm5cbiAgfVxuXG4gIHRyeSB7XG4gICAgYXdhaXQgc2VuZERlYnVnZ2VyTWVzc2FnZTx1bmRlZmluZWQ+KHtcbiAgICAgIHR5cGU6IFBBR0VfRVZFTlRTX01FU1NBR0UsXG4gICAgICBwYXlsb2FkOiB7XG4gICAgICAgIGV2ZW50czogcmF3RXZlbnRzLFxuICAgICAgfSxcbiAgICB9KVxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGlmIChpc0V4cGVjdGVkUnVudGltZURpc2Nvbm5lY3RFcnJvcihlcnJvcikpIHtcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIHJlcG9ydE5vbkZhdGFsRXJyb3IoXCJGYWlsZWQgdG8gc2VuZCBkZWJ1Z2dlciBwYWdlIGV2ZW50c1wiLCBlcnJvcilcbiAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5zdXJlRGVidWdnZXJQYWdlUnVudGltZSgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgdHJ5IHtcbiAgICBhd2FpdCBzZW5kRGVidWdnZXJNZXNzYWdlPHVuZGVmaW5lZD4oe1xuICAgICAgdHlwZTogRU5TVVJFX1BBR0VfUlVOVElNRV9NRVNTQUdFLFxuICAgICAgcGF5bG9hZDoge30sXG4gICAgfSlcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBpZiAoaXNFeHBlY3RlZFJ1bnRpbWVEaXNjb25uZWN0RXJyb3IoZXJyb3IpKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICByZXBvcnROb25GYXRhbEVycm9yKFwiRmFpbGVkIHRvIGVuc3VyZSBkZWJ1Z2dlciBwYWdlIHJ1bnRpbWVcIiwgZXJyb3IpXG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzRGVidWdnZXJSdW50aW1lTWVzc2FnZShcbiAgdmFsdWU6IHVua25vd25cbik6IHZhbHVlIGlzIERlYnVnZ2VyUnVudGltZU1lc3NhZ2Uge1xuICBpZiAoIWlzUmVjb3JkTGlrZSh2YWx1ZSkpIHJldHVybiBmYWxzZVxuXG4gIGNvbnN0IG1lc3NhZ2VUeXBlID0gdmFsdWUudHlwZVxuICBpZiAodHlwZW9mIG1lc3NhZ2VUeXBlICE9PSBcInN0cmluZ1wiKSByZXR1cm4gZmFsc2VcblxuICByZXR1cm4gKFxuICAgIG1lc3NhZ2VUeXBlID09PSBTVEFSVF9TRVNTSU9OX01FU1NBR0UgfHxcbiAgICBtZXNzYWdlVHlwZSA9PT0gTUFSS19SRUNPUkRJTkdfU1RBUlRFRF9NRVNTQUdFIHx8XG4gICAgbWVzc2FnZVR5cGUgPT09IEdFVF9TRVNTSU9OX1NOQVBTSE9UX01FU1NBR0UgfHxcbiAgICBtZXNzYWdlVHlwZSA9PT0gRElTQ0FSRF9TRVNTSU9OX01FU1NBR0UgfHxcbiAgICBtZXNzYWdlVHlwZSA9PT0gUEFHRV9FVkVOVF9NRVNTQUdFIHx8XG4gICAgbWVzc2FnZVR5cGUgPT09IFBBR0VfRVZFTlRTX01FU1NBR0UgfHxcbiAgICBtZXNzYWdlVHlwZSA9PT0gRU5TVVJFX1BBR0VfUlVOVElNRV9NRVNTQUdFXG4gIClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzRGVidWdnZXJDb250ZW50QnJpZGdlUGF5bG9hZChcbiAgdmFsdWU6IHVua25vd25cbik6IHZhbHVlIGlzIERlYnVnZ2VyQ29udGVudEJyaWRnZVBheWxvYWQge1xuICBpZiAoIWlzUmVjb3JkTGlrZSh2YWx1ZSkpIHJldHVybiBmYWxzZVxuXG4gIGlmICh2YWx1ZS5zb3VyY2UgIT09IFBBR0VfQlJJREdFX1NPVVJDRSkge1xuICAgIHJldHVybiBmYWxzZVxuICB9XG5cbiAgY29uc3QgaGFzU2luZ2xlRXZlbnQgPSBPYmplY3QuaGFzT3duKHZhbHVlLCBcImV2ZW50XCIpXG4gIGNvbnN0IGhhc0V2ZW50QmF0Y2ggPSBBcnJheS5pc0FycmF5KHZhbHVlLmV2ZW50cylcblxuICByZXR1cm4gaGFzU2luZ2xlRXZlbnQgfHwgaGFzRXZlbnRCYXRjaFxufVxuXG5mdW5jdGlvbiBpc0V4cGVjdGVkUnVudGltZURpc2Nvbm5lY3RFcnJvcihlcnJvcjogdW5rbm93bik6IGJvb2xlYW4ge1xuICBpZiAoIShlcnJvciBpbnN0YW5jZW9mIEVycm9yKSkge1xuICAgIHJldHVybiBmYWxzZVxuICB9XG5cbiAgY29uc3QgbWVzc2FnZSA9IGVycm9yLm1lc3NhZ2UudG9Mb3dlckNhc2UoKVxuICByZXR1cm4gKFxuICAgIG1lc3NhZ2UuaW5jbHVkZXMoXCJleHRlbnNpb24gY29udGV4dCBpbnZhbGlkYXRlZFwiKSB8fFxuICAgIG1lc3NhZ2UuaW5jbHVkZXMoXCJyZWNlaXZpbmcgZW5kIGRvZXMgbm90IGV4aXN0XCIpXG4gIClcbn1cbiIsImltcG9ydCB7IHJlcG9ydE5vbkZhdGFsRXJyb3IgfSBmcm9tIFwiQGNyaWtrZXQvc2hhcmVkL2xpYi9lcnJvcnNcIlxuaW1wb3J0IHtcbiAgaXNEZWJ1Z2dlckNvbnRlbnRCcmlkZ2VQYXlsb2FkLFxuICBzZW5kRGVidWdnZXJQYWdlRXZlbnRzLFxufSBmcm9tIFwiLi9tZXNzYWdpbmdcIlxuXG5jb25zdCBDT05URU5UX0JSSURHRV9JTlNUQUxMX0ZMQUcgPSBcIl9fY3Jpa2tldERlYnVnZ2VyQ29udGVudEJyaWRnZUluc3RhbGxlZFwiXG5cbmV4cG9ydCBmdW5jdGlvbiBzZXR1cERlYnVnZ2VyQ29udGVudEJyaWRnZSgpOiB2b2lkIHtcbiAgaWYgKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICByZXR1cm5cbiAgfVxuXG4gIGNvbnN0IHNjb3BlID0gd2luZG93IGFzIFdpbmRvdyAmIHtcbiAgICBbQ09OVEVOVF9CUklER0VfSU5TVEFMTF9GTEFHXT86IGJvb2xlYW5cbiAgfVxuXG4gIGlmIChzY29wZVtDT05URU5UX0JSSURHRV9JTlNUQUxMX0ZMQUddKSB7XG4gICAgcmV0dXJuXG4gIH1cbiAgc2NvcGVbQ09OVEVOVF9CUklER0VfSU5TVEFMTF9GTEFHXSA9IHRydWVcblxuICBjb25zdCBxdWV1ZTogdW5rbm93bltdID0gW11cbiAgbGV0IGZsdXNoVGltZXI6IFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+IHwgbnVsbCA9IG51bGxcblxuICBjb25zdCBCQVRDSF9TSVpFID0gNDBcbiAgY29uc3QgRkxVU0hfSU5URVJWQUxfTVMgPSAxMjBcblxuICBjb25zdCBmbHVzaFF1ZXVlID0gKCkgPT4ge1xuICAgIGZsdXNoVGltZXIgPSBudWxsXG5cbiAgICBpZiAocXVldWUubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBjb25zdCBldmVudHMgPSBxdWV1ZS5zcGxpY2UoMCwgQkFUQ0hfU0laRSlcbiAgICBzZW5kRGVidWdnZXJQYWdlRXZlbnRzKGV2ZW50cykuY2F0Y2goKGVycm9yOiB1bmtub3duKSA9PiB7XG4gICAgICByZXBvcnROb25GYXRhbEVycm9yKFwiRmFpbGVkIHRvIGZvcndhcmQgZGVidWdnZXIgcGFnZSBldmVudHNcIiwgZXJyb3IpXG4gICAgfSlcblxuICAgIGlmIChxdWV1ZS5sZW5ndGggPiAwKSB7XG4gICAgICBmbHVzaFRpbWVyID0gc2V0VGltZW91dChmbHVzaFF1ZXVlLCAwKVxuICAgICAgcmV0dXJuXG4gICAgfVxuICB9XG5cbiAgY29uc3Qgc2NoZWR1bGVGbHVzaCA9ICgpID0+IHtcbiAgICBpZiAoZmx1c2hUaW1lcikge1xuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgZmx1c2hUaW1lciA9IHNldFRpbWVvdXQoZmx1c2hRdWV1ZSwgRkxVU0hfSU5URVJWQUxfTVMpXG4gIH1cblxuICBjb25zdCBlbnF1ZXVlRXZlbnRzID0gKGV2ZW50czogdW5rbm93bltdKSA9PiB7XG4gICAgaWYgKGV2ZW50cy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIGZvciAoY29uc3QgY2FuZGlkYXRlIG9mIGV2ZW50cykge1xuICAgICAgcXVldWUucHVzaChjYW5kaWRhdGUpXG4gICAgfVxuXG4gICAgaWYgKHF1ZXVlLmxlbmd0aCA+PSBCQVRDSF9TSVpFKSB7XG4gICAgICBpZiAoZmx1c2hUaW1lcikge1xuICAgICAgICBjbGVhclRpbWVvdXQoZmx1c2hUaW1lcilcbiAgICAgIH1cbiAgICAgIGZsdXNoVGltZXIgPSBzZXRUaW1lb3V0KGZsdXNoUXVldWUsIDApXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBzY2hlZHVsZUZsdXNoKClcbiAgfVxuXG4gIGNvbnN0IG9uV2luZG93TWVzc2FnZSA9IChldmVudDogTWVzc2FnZUV2ZW50PHVua25vd24+KSA9PiB7XG4gICAgaWYgKGV2ZW50LnNvdXJjZSAhPT0gd2luZG93KSByZXR1cm5cbiAgICBpZiAoIWlzRGVidWdnZXJDb250ZW50QnJpZGdlUGF5bG9hZChldmVudC5kYXRhKSkgcmV0dXJuXG5cbiAgICBpZiAoQXJyYXkuaXNBcnJheShldmVudC5kYXRhLmV2ZW50cykpIHtcbiAgICAgIGVucXVldWVFdmVudHMoZXZlbnQuZGF0YS5ldmVudHMpXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBlbnF1ZXVlRXZlbnRzKFtldmVudC5kYXRhLmV2ZW50XSlcbiAgfVxuXG4gIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwibWVzc2FnZVwiLCBvbldpbmRvd01lc3NhZ2UpXG4gIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicGFnZWhpZGVcIiwgZmx1c2hRdWV1ZSwge1xuICAgIGNhcHR1cmU6IHRydWUsXG4gIH0pXG59XG4iLCJpbXBvcnQgeyBkZWZpbmVDb250ZW50U2NyaXB0IH0gZnJvbSBcInd4dC91dGlscy9kZWZpbmUtY29udGVudC1zY3JpcHRcIlxuaW1wb3J0IHsgc2V0dXBEZWJ1Z2dlckNvbnRlbnRCcmlkZ2UgfSBmcm9tIFwiQC9saWIvYnVnLXJlcG9ydC1kZWJ1Z2dlci9jb250ZW50XCJcblxuZXhwb3J0IGRlZmF1bHQgZGVmaW5lQ29udGVudFNjcmlwdCh7XG4gIG1hdGNoZXM6IFtcIjxhbGxfdXJscz5cIl0sXG4gIHJ1bkF0OiBcImRvY3VtZW50X3N0YXJ0XCIsXG4gIG1haW4oKSB7XG4gICAgc2V0dXBEZWJ1Z2dlckNvbnRlbnRCcmlkZ2UoKVxuICB9LFxufSlcbiIsIi8vI3JlZ2lvbiBzcmMvdXRpbHMvaW50ZXJuYWwvbG9nZ2VyLnRzXG5mdW5jdGlvbiBwcmludChtZXRob2QsIC4uLmFyZ3MpIHtcblx0aWYgKGltcG9ydC5tZXRhLmVudi5NT0RFID09PSBcInByb2R1Y3Rpb25cIikgcmV0dXJuO1xuXHRpZiAodHlwZW9mIGFyZ3NbMF0gPT09IFwic3RyaW5nXCIpIG1ldGhvZChgW3d4dF0gJHthcmdzLnNoaWZ0KCl9YCwgLi4uYXJncyk7XG5cdGVsc2UgbWV0aG9kKFwiW3d4dF1cIiwgLi4uYXJncyk7XG59XG4vKipcbiogV3JhcHBlciBhcm91bmQgYGNvbnNvbGVgIHdpdGggYSBcIlt3eHRdXCIgcHJlZml4XG4qL1xuY29uc3QgbG9nZ2VyID0ge1xuXHRkZWJ1ZzogKC4uLmFyZ3MpID0+IHByaW50KGNvbnNvbGUuZGVidWcsIC4uLmFyZ3MpLFxuXHRsb2c6ICguLi5hcmdzKSA9PiBwcmludChjb25zb2xlLmxvZywgLi4uYXJncyksXG5cdHdhcm46ICguLi5hcmdzKSA9PiBwcmludChjb25zb2xlLndhcm4sIC4uLmFyZ3MpLFxuXHRlcnJvcjogKC4uLmFyZ3MpID0+IHByaW50KGNvbnNvbGUuZXJyb3IsIC4uLmFyZ3MpXG59O1xuXG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGxvZ2dlciB9OyIsIi8vICNyZWdpb24gc25pcHBldFxuZXhwb3J0IGNvbnN0IGJyb3dzZXIgPSBnbG9iYWxUaGlzLmJyb3dzZXI/LnJ1bnRpbWU/LmlkXG4gID8gZ2xvYmFsVGhpcy5icm93c2VyXG4gIDogZ2xvYmFsVGhpcy5jaHJvbWU7XG4vLyAjZW5kcmVnaW9uIHNuaXBwZXRcbiIsImltcG9ydCB7IGJyb3dzZXIgYXMgYnJvd3NlciQxIH0gZnJvbSBcIkB3eHQtZGV2L2Jyb3dzZXJcIjtcblxuLy8jcmVnaW9uIHNyYy9icm93c2VyLnRzXG4vKipcbiogQ29udGFpbnMgdGhlIGBicm93c2VyYCBleHBvcnQgd2hpY2ggeW91IHNob3VsZCB1c2UgdG8gYWNjZXNzIHRoZSBleHRlbnNpb24gQVBJcyBpbiB5b3VyIHByb2plY3Q6XG4qIGBgYHRzXG4qIGltcG9ydCB7IGJyb3dzZXIgfSBmcm9tICd3eHQvYnJvd3Nlcic7XG4qXG4qIGJyb3dzZXIucnVudGltZS5vbkluc3RhbGxlZC5hZGRMaXN0ZW5lcigoKSA9PiB7XG4qICAgLy8gLi4uXG4qIH0pXG4qIGBgYFxuKiBAbW9kdWxlIHd4dC9icm93c2VyXG4qL1xuY29uc3QgYnJvd3NlciA9IGJyb3dzZXIkMTtcblxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBicm93c2VyIH07IiwiaW1wb3J0IHsgYnJvd3NlciB9IGZyb20gXCJ3eHQvYnJvd3NlclwiO1xuXG4vLyNyZWdpb24gc3JjL3V0aWxzL2ludGVybmFsL2N1c3RvbS1ldmVudHMudHNcbnZhciBXeHRMb2NhdGlvbkNoYW5nZUV2ZW50ID0gY2xhc3MgV3h0TG9jYXRpb25DaGFuZ2VFdmVudCBleHRlbmRzIEV2ZW50IHtcblx0c3RhdGljIEVWRU5UX05BTUUgPSBnZXRVbmlxdWVFdmVudE5hbWUoXCJ3eHQ6bG9jYXRpb25jaGFuZ2VcIik7XG5cdGNvbnN0cnVjdG9yKG5ld1VybCwgb2xkVXJsKSB7XG5cdFx0c3VwZXIoV3h0TG9jYXRpb25DaGFuZ2VFdmVudC5FVkVOVF9OQU1FLCB7fSk7XG5cdFx0dGhpcy5uZXdVcmwgPSBuZXdVcmw7XG5cdFx0dGhpcy5vbGRVcmwgPSBvbGRVcmw7XG5cdH1cbn07XG4vKipcbiogUmV0dXJucyBhbiBldmVudCBuYW1lIHVuaXF1ZSB0byB0aGUgZXh0ZW5zaW9uIGFuZCBjb250ZW50IHNjcmlwdCB0aGF0J3MgcnVubmluZy5cbiovXG5mdW5jdGlvbiBnZXRVbmlxdWVFdmVudE5hbWUoZXZlbnROYW1lKSB7XG5cdHJldHVybiBgJHticm93c2VyPy5ydW50aW1lPy5pZH06JHtpbXBvcnQubWV0YS5lbnYuRU5UUllQT0lOVH06JHtldmVudE5hbWV9YDtcbn1cblxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBXeHRMb2NhdGlvbkNoYW5nZUV2ZW50LCBnZXRVbmlxdWVFdmVudE5hbWUgfTsiLCJpbXBvcnQgeyBXeHRMb2NhdGlvbkNoYW5nZUV2ZW50IH0gZnJvbSBcIi4vY3VzdG9tLWV2ZW50cy5tanNcIjtcblxuLy8jcmVnaW9uIHNyYy91dGlscy9pbnRlcm5hbC9sb2NhdGlvbi13YXRjaGVyLnRzXG4vKipcbiogQ3JlYXRlIGEgdXRpbCB0aGF0IHdhdGNoZXMgZm9yIFVSTCBjaGFuZ2VzLCBkaXNwYXRjaGluZyB0aGUgY3VzdG9tIGV2ZW50IHdoZW4gZGV0ZWN0ZWQuIFN0b3BzXG4qIHdhdGNoaW5nIHdoZW4gY29udGVudCBzY3JpcHQgaXMgaW52YWxpZGF0ZWQuXG4qL1xuZnVuY3Rpb24gY3JlYXRlTG9jYXRpb25XYXRjaGVyKGN0eCkge1xuXHRsZXQgaW50ZXJ2YWw7XG5cdGxldCBvbGRVcmw7XG5cdHJldHVybiB7IHJ1bigpIHtcblx0XHRpZiAoaW50ZXJ2YWwgIT0gbnVsbCkgcmV0dXJuO1xuXHRcdG9sZFVybCA9IG5ldyBVUkwobG9jYXRpb24uaHJlZik7XG5cdFx0aW50ZXJ2YWwgPSBjdHguc2V0SW50ZXJ2YWwoKCkgPT4ge1xuXHRcdFx0bGV0IG5ld1VybCA9IG5ldyBVUkwobG9jYXRpb24uaHJlZik7XG5cdFx0XHRpZiAobmV3VXJsLmhyZWYgIT09IG9sZFVybC5ocmVmKSB7XG5cdFx0XHRcdHdpbmRvdy5kaXNwYXRjaEV2ZW50KG5ldyBXeHRMb2NhdGlvbkNoYW5nZUV2ZW50KG5ld1VybCwgb2xkVXJsKSk7XG5cdFx0XHRcdG9sZFVybCA9IG5ld1VybDtcblx0XHRcdH1cblx0XHR9LCAxZTMpO1xuXHR9IH07XG59XG5cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgY3JlYXRlTG9jYXRpb25XYXRjaGVyIH07IiwiaW1wb3J0IHsgbG9nZ2VyIH0gZnJvbSBcIi4vaW50ZXJuYWwvbG9nZ2VyLm1qc1wiO1xuaW1wb3J0IHsgZ2V0VW5pcXVlRXZlbnROYW1lIH0gZnJvbSBcIi4vaW50ZXJuYWwvY3VzdG9tLWV2ZW50cy5tanNcIjtcbmltcG9ydCB7IGNyZWF0ZUxvY2F0aW9uV2F0Y2hlciB9IGZyb20gXCIuL2ludGVybmFsL2xvY2F0aW9uLXdhdGNoZXIubWpzXCI7XG5pbXBvcnQgeyBicm93c2VyIH0gZnJvbSBcInd4dC9icm93c2VyXCI7XG5cbi8vI3JlZ2lvbiBzcmMvdXRpbHMvY29udGVudC1zY3JpcHQtY29udGV4dC50c1xuLyoqXG4qIEltcGxlbWVudHMgW2BBYm9ydENvbnRyb2xsZXJgXShodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvQWJvcnRDb250cm9sbGVyKS5cbiogVXNlZCB0byBkZXRlY3QgYW5kIHN0b3AgY29udGVudCBzY3JpcHQgY29kZSB3aGVuIHRoZSBzY3JpcHQgaXMgaW52YWxpZGF0ZWQuXG4qXG4qIEl0IGFsc28gcHJvdmlkZXMgc2V2ZXJhbCB1dGlsaXRpZXMgbGlrZSBgY3R4LnNldFRpbWVvdXRgIGFuZCBgY3R4LnNldEludGVydmFsYCB0aGF0IHNob3VsZCBiZSB1c2VkIGluXG4qIGNvbnRlbnQgc2NyaXB0cyBpbnN0ZWFkIG9mIGB3aW5kb3cuc2V0VGltZW91dGAgb3IgYHdpbmRvdy5zZXRJbnRlcnZhbGAuXG4qXG4qIFRvIGNyZWF0ZSBjb250ZXh0IGZvciB0ZXN0aW5nLCB5b3UgY2FuIHVzZSB0aGUgY2xhc3MncyBjb25zdHJ1Y3RvcjpcbipcbiogYGBgdHNcbiogaW1wb3J0IHsgQ29udGVudFNjcmlwdENvbnRleHQgfSBmcm9tICd3eHQvdXRpbHMvY29udGVudC1zY3JpcHRzLWNvbnRleHQnO1xuKlxuKiB0ZXN0KFwic3RvcmFnZSBsaXN0ZW5lciBzaG91bGQgYmUgcmVtb3ZlZCB3aGVuIGNvbnRleHQgaXMgaW52YWxpZGF0ZWRcIiwgKCkgPT4ge1xuKiAgIGNvbnN0IGN0eCA9IG5ldyBDb250ZW50U2NyaXB0Q29udGV4dCgndGVzdCcpO1xuKiAgIGNvbnN0IGl0ZW0gPSBzdG9yYWdlLmRlZmluZUl0ZW0oXCJsb2NhbDpjb3VudFwiLCB7IGRlZmF1bHRWYWx1ZTogMCB9KTtcbiogICBjb25zdCB3YXRjaGVyID0gdmkuZm4oKTtcbipcbiogICBjb25zdCB1bndhdGNoID0gaXRlbS53YXRjaCh3YXRjaGVyKTtcbiogICBjdHgub25JbnZhbGlkYXRlZCh1bndhdGNoKTsgLy8gTGlzdGVuIGZvciBpbnZhbGlkYXRlIGhlcmVcbipcbiogICBhd2FpdCBpdGVtLnNldFZhbHVlKDEpO1xuKiAgIGV4cGVjdCh3YXRjaGVyKS50b0JlQ2FsbGVkVGltZXMoMSk7XG4qICAgZXhwZWN0KHdhdGNoZXIpLnRvQmVDYWxsZWRXaXRoKDEsIDApO1xuKlxuKiAgIGN0eC5ub3RpZnlJbnZhbGlkYXRlZCgpOyAvLyBVc2UgdGhpcyBmdW5jdGlvbiB0byBpbnZhbGlkYXRlIHRoZSBjb250ZXh0XG4qICAgYXdhaXQgaXRlbS5zZXRWYWx1ZSgyKTtcbiogICBleHBlY3Qod2F0Y2hlcikudG9CZUNhbGxlZFRpbWVzKDEpO1xuKiB9KTtcbiogYGBgXG4qL1xudmFyIENvbnRlbnRTY3JpcHRDb250ZXh0ID0gY2xhc3MgQ29udGVudFNjcmlwdENvbnRleHQge1xuXHRzdGF0aWMgU0NSSVBUX1NUQVJURURfTUVTU0FHRV9UWVBFID0gZ2V0VW5pcXVlRXZlbnROYW1lKFwid3h0OmNvbnRlbnQtc2NyaXB0LXN0YXJ0ZWRcIik7XG5cdGlkO1xuXHRhYm9ydENvbnRyb2xsZXI7XG5cdGxvY2F0aW9uV2F0Y2hlciA9IGNyZWF0ZUxvY2F0aW9uV2F0Y2hlcih0aGlzKTtcblx0Y29uc3RydWN0b3IoY29udGVudFNjcmlwdE5hbWUsIG9wdGlvbnMpIHtcblx0XHR0aGlzLmNvbnRlbnRTY3JpcHROYW1lID0gY29udGVudFNjcmlwdE5hbWU7XG5cdFx0dGhpcy5vcHRpb25zID0gb3B0aW9ucztcblx0XHR0aGlzLmlkID0gTWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc2xpY2UoMik7XG5cdFx0dGhpcy5hYm9ydENvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG5cdFx0dGhpcy5zdG9wT2xkU2NyaXB0cygpO1xuXHRcdHRoaXMubGlzdGVuRm9yTmV3ZXJTY3JpcHRzKCk7XG5cdH1cblx0Z2V0IHNpZ25hbCgpIHtcblx0XHRyZXR1cm4gdGhpcy5hYm9ydENvbnRyb2xsZXIuc2lnbmFsO1xuXHR9XG5cdGFib3J0KHJlYXNvbikge1xuXHRcdHJldHVybiB0aGlzLmFib3J0Q29udHJvbGxlci5hYm9ydChyZWFzb24pO1xuXHR9XG5cdGdldCBpc0ludmFsaWQoKSB7XG5cdFx0aWYgKGJyb3dzZXIucnVudGltZT8uaWQgPT0gbnVsbCkgdGhpcy5ub3RpZnlJbnZhbGlkYXRlZCgpO1xuXHRcdHJldHVybiB0aGlzLnNpZ25hbC5hYm9ydGVkO1xuXHR9XG5cdGdldCBpc1ZhbGlkKCkge1xuXHRcdHJldHVybiAhdGhpcy5pc0ludmFsaWQ7XG5cdH1cblx0LyoqXG5cdCogQWRkIGEgbGlzdGVuZXIgdGhhdCBpcyBjYWxsZWQgd2hlbiB0aGUgY29udGVudCBzY3JpcHQncyBjb250ZXh0IGlzIGludmFsaWRhdGVkLlxuXHQqXG5cdCogQHJldHVybnMgQSBmdW5jdGlvbiB0byByZW1vdmUgdGhlIGxpc3RlbmVyLlxuXHQqXG5cdCogQGV4YW1wbGVcblx0KiBicm93c2VyLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKGNiKTtcblx0KiBjb25zdCByZW1vdmVJbnZhbGlkYXRlZExpc3RlbmVyID0gY3R4Lm9uSW52YWxpZGF0ZWQoKCkgPT4ge1xuXHQqICAgYnJvd3Nlci5ydW50aW1lLm9uTWVzc2FnZS5yZW1vdmVMaXN0ZW5lcihjYik7XG5cdCogfSlcblx0KiAvLyAuLi5cblx0KiByZW1vdmVJbnZhbGlkYXRlZExpc3RlbmVyKCk7XG5cdCovXG5cdG9uSW52YWxpZGF0ZWQoY2IpIHtcblx0XHR0aGlzLnNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgY2IpO1xuXHRcdHJldHVybiAoKSA9PiB0aGlzLnNpZ25hbC5yZW1vdmVFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgY2IpO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybiBhIHByb21pc2UgdGhhdCBuZXZlciByZXNvbHZlcy4gVXNlZnVsIGlmIHlvdSBoYXZlIGFuIGFzeW5jIGZ1bmN0aW9uIHRoYXQgc2hvdWxkbid0IHJ1blxuXHQqIGFmdGVyIHRoZSBjb250ZXh0IGlzIGV4cGlyZWQuXG5cdCpcblx0KiBAZXhhbXBsZVxuXHQqIGNvbnN0IGdldFZhbHVlRnJvbVN0b3JhZ2UgPSBhc3luYyAoKSA9PiB7XG5cdCogICBpZiAoY3R4LmlzSW52YWxpZCkgcmV0dXJuIGN0eC5ibG9jaygpO1xuXHQqXG5cdCogICAvLyAuLi5cblx0KiB9XG5cdCovXG5cdGJsb2NrKCkge1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZSgoKSA9PiB7fSk7XG5cdH1cblx0LyoqXG5cdCogV3JhcHBlciBhcm91bmQgYHdpbmRvdy5zZXRJbnRlcnZhbGAgdGhhdCBhdXRvbWF0aWNhbGx5IGNsZWFycyB0aGUgaW50ZXJ2YWwgd2hlbiBpbnZhbGlkYXRlZC5cblx0KlxuXHQqIEludGVydmFscyBjYW4gYmUgY2xlYXJlZCBieSBjYWxsaW5nIHRoZSBub3JtYWwgYGNsZWFySW50ZXJ2YWxgIGZ1bmN0aW9uLlxuXHQqL1xuXHRzZXRJbnRlcnZhbChoYW5kbGVyLCB0aW1lb3V0KSB7XG5cdFx0Y29uc3QgaWQgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG5cdFx0XHRpZiAodGhpcy5pc1ZhbGlkKSBoYW5kbGVyKCk7XG5cdFx0fSwgdGltZW91dCk7XG5cdFx0dGhpcy5vbkludmFsaWRhdGVkKCgpID0+IGNsZWFySW50ZXJ2YWwoaWQpKTtcblx0XHRyZXR1cm4gaWQ7XG5cdH1cblx0LyoqXG5cdCogV3JhcHBlciBhcm91bmQgYHdpbmRvdy5zZXRUaW1lb3V0YCB0aGF0IGF1dG9tYXRpY2FsbHkgY2xlYXJzIHRoZSBpbnRlcnZhbCB3aGVuIGludmFsaWRhdGVkLlxuXHQqXG5cdCogVGltZW91dHMgY2FuIGJlIGNsZWFyZWQgYnkgY2FsbGluZyB0aGUgbm9ybWFsIGBzZXRUaW1lb3V0YCBmdW5jdGlvbi5cblx0Ki9cblx0c2V0VGltZW91dChoYW5kbGVyLCB0aW1lb3V0KSB7XG5cdFx0Y29uc3QgaWQgPSBzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdGlmICh0aGlzLmlzVmFsaWQpIGhhbmRsZXIoKTtcblx0XHR9LCB0aW1lb3V0KTtcblx0XHR0aGlzLm9uSW52YWxpZGF0ZWQoKCkgPT4gY2xlYXJUaW1lb3V0KGlkKSk7XG5cdFx0cmV0dXJuIGlkO1xuXHR9XG5cdC8qKlxuXHQqIFdyYXBwZXIgYXJvdW5kIGB3aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lYCB0aGF0IGF1dG9tYXRpY2FsbHkgY2FuY2VscyB0aGUgcmVxdWVzdCB3aGVuXG5cdCogaW52YWxpZGF0ZWQuXG5cdCpcblx0KiBDYWxsYmFja3MgY2FuIGJlIGNhbmNlbGVkIGJ5IGNhbGxpbmcgdGhlIG5vcm1hbCBgY2FuY2VsQW5pbWF0aW9uRnJhbWVgIGZ1bmN0aW9uLlxuXHQqL1xuXHRyZXF1ZXN0QW5pbWF0aW9uRnJhbWUoY2FsbGJhY2spIHtcblx0XHRjb25zdCBpZCA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSgoLi4uYXJncykgPT4ge1xuXHRcdFx0aWYgKHRoaXMuaXNWYWxpZCkgY2FsbGJhY2soLi4uYXJncyk7XG5cdFx0fSk7XG5cdFx0dGhpcy5vbkludmFsaWRhdGVkKCgpID0+IGNhbmNlbEFuaW1hdGlvbkZyYW1lKGlkKSk7XG5cdFx0cmV0dXJuIGlkO1xuXHR9XG5cdC8qKlxuXHQqIFdyYXBwZXIgYXJvdW5kIGB3aW5kb3cucmVxdWVzdElkbGVDYWxsYmFja2AgdGhhdCBhdXRvbWF0aWNhbGx5IGNhbmNlbHMgdGhlIHJlcXVlc3Qgd2hlblxuXHQqIGludmFsaWRhdGVkLlxuXHQqXG5cdCogQ2FsbGJhY2tzIGNhbiBiZSBjYW5jZWxlZCBieSBjYWxsaW5nIHRoZSBub3JtYWwgYGNhbmNlbElkbGVDYWxsYmFja2AgZnVuY3Rpb24uXG5cdCovXG5cdHJlcXVlc3RJZGxlQ2FsbGJhY2soY2FsbGJhY2ssIG9wdGlvbnMpIHtcblx0XHRjb25zdCBpZCA9IHJlcXVlc3RJZGxlQ2FsbGJhY2soKC4uLmFyZ3MpID0+IHtcblx0XHRcdGlmICghdGhpcy5zaWduYWwuYWJvcnRlZCkgY2FsbGJhY2soLi4uYXJncyk7XG5cdFx0fSwgb3B0aW9ucyk7XG5cdFx0dGhpcy5vbkludmFsaWRhdGVkKCgpID0+IGNhbmNlbElkbGVDYWxsYmFjayhpZCkpO1xuXHRcdHJldHVybiBpZDtcblx0fVxuXHRhZGRFdmVudExpc3RlbmVyKHRhcmdldCwgdHlwZSwgaGFuZGxlciwgb3B0aW9ucykge1xuXHRcdGlmICh0eXBlID09PSBcInd4dDpsb2NhdGlvbmNoYW5nZVwiKSB7XG5cdFx0XHRpZiAodGhpcy5pc1ZhbGlkKSB0aGlzLmxvY2F0aW9uV2F0Y2hlci5ydW4oKTtcblx0XHR9XG5cdFx0dGFyZ2V0LmFkZEV2ZW50TGlzdGVuZXI/Lih0eXBlLnN0YXJ0c1dpdGgoXCJ3eHQ6XCIpID8gZ2V0VW5pcXVlRXZlbnROYW1lKHR5cGUpIDogdHlwZSwgaGFuZGxlciwge1xuXHRcdFx0Li4ub3B0aW9ucyxcblx0XHRcdHNpZ25hbDogdGhpcy5zaWduYWxcblx0XHR9KTtcblx0fVxuXHQvKipcblx0KiBAaW50ZXJuYWxcblx0KiBBYm9ydCB0aGUgYWJvcnQgY29udHJvbGxlciBhbmQgZXhlY3V0ZSBhbGwgYG9uSW52YWxpZGF0ZWRgIGxpc3RlbmVycy5cblx0Ki9cblx0bm90aWZ5SW52YWxpZGF0ZWQoKSB7XG5cdFx0dGhpcy5hYm9ydChcIkNvbnRlbnQgc2NyaXB0IGNvbnRleHQgaW52YWxpZGF0ZWRcIik7XG5cdFx0bG9nZ2VyLmRlYnVnKGBDb250ZW50IHNjcmlwdCBcIiR7dGhpcy5jb250ZW50U2NyaXB0TmFtZX1cIiBjb250ZXh0IGludmFsaWRhdGVkYCk7XG5cdH1cblx0c3RvcE9sZFNjcmlwdHMoKSB7XG5cdFx0ZG9jdW1lbnQuZGlzcGF0Y2hFdmVudChuZXcgQ3VzdG9tRXZlbnQoQ29udGVudFNjcmlwdENvbnRleHQuU0NSSVBUX1NUQVJURURfTUVTU0FHRV9UWVBFLCB7IGRldGFpbDoge1xuXHRcdFx0Y29udGVudFNjcmlwdE5hbWU6IHRoaXMuY29udGVudFNjcmlwdE5hbWUsXG5cdFx0XHRtZXNzYWdlSWQ6IHRoaXMuaWRcblx0XHR9IH0pKTtcblx0XHR3aW5kb3cucG9zdE1lc3NhZ2Uoe1xuXHRcdFx0dHlwZTogQ29udGVudFNjcmlwdENvbnRleHQuU0NSSVBUX1NUQVJURURfTUVTU0FHRV9UWVBFLFxuXHRcdFx0Y29udGVudFNjcmlwdE5hbWU6IHRoaXMuY29udGVudFNjcmlwdE5hbWUsXG5cdFx0XHRtZXNzYWdlSWQ6IHRoaXMuaWRcblx0XHR9LCBcIipcIik7XG5cdH1cblx0dmVyaWZ5U2NyaXB0U3RhcnRlZEV2ZW50KGV2ZW50KSB7XG5cdFx0Y29uc3QgaXNTYW1lQ29udGVudFNjcmlwdCA9IGV2ZW50LmRldGFpbD8uY29udGVudFNjcmlwdE5hbWUgPT09IHRoaXMuY29udGVudFNjcmlwdE5hbWU7XG5cdFx0Y29uc3QgaXNGcm9tU2VsZiA9IGV2ZW50LmRldGFpbD8ubWVzc2FnZUlkID09PSB0aGlzLmlkO1xuXHRcdHJldHVybiBpc1NhbWVDb250ZW50U2NyaXB0ICYmICFpc0Zyb21TZWxmO1xuXHR9XG5cdGxpc3RlbkZvck5ld2VyU2NyaXB0cygpIHtcblx0XHRjb25zdCBjYiA9IChldmVudCkgPT4ge1xuXHRcdFx0aWYgKCEoZXZlbnQgaW5zdGFuY2VvZiBDdXN0b21FdmVudCkgfHwgIXRoaXMudmVyaWZ5U2NyaXB0U3RhcnRlZEV2ZW50KGV2ZW50KSkgcmV0dXJuO1xuXHRcdFx0dGhpcy5ub3RpZnlJbnZhbGlkYXRlZCgpO1xuXHRcdH07XG5cdFx0ZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihDb250ZW50U2NyaXB0Q29udGV4dC5TQ1JJUFRfU1RBUlRFRF9NRVNTQUdFX1RZUEUsIGNiKTtcblx0XHR0aGlzLm9uSW52YWxpZGF0ZWQoKCkgPT4gZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihDb250ZW50U2NyaXB0Q29udGV4dC5TQ1JJUFRfU1RBUlRFRF9NRVNTQUdFX1RZUEUsIGNiKSk7XG5cdH1cbn07XG5cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgQ29udGVudFNjcmlwdENvbnRleHQgfTsiXSwibmFtZXMiOlsiZGVmaW5pdGlvbiIsInByaW50IiwibG9nZ2VyIiwiYnJvd3NlciIsIld4dExvY2F0aW9uQ2hhbmdlRXZlbnQiLCJDb250ZW50U2NyaXB0Q29udGV4dCJdLCJtYXBwaW5ncyI6Ijs7QUFDQSxXQUFTLG9CQUFvQkEsYUFBWTtBQUN4QyxXQUFPQTtBQUFBLEVBQ1I7QUNHTyxXQUFTLG9CQUNkLFNBQ0EsT0FDQSxTQUNNO0FBU04sWUFBUSxLQUFLLGVBQWUsT0FBTyxJQUFJLEtBQUs7QUFBQSxFQUM5QztBQ2hCTyxRQUFNLHFCQUFxQjtBQVUzQixRQUFNLHNCQUFzQjtBQ21KbkMsV0FBUyxTQUFTLE9BQU87QUFDckIsV0FBTyxPQUFPLFVBQVUsWUFBWSxVQUFVLFFBQVEsQ0FBQyxNQUFNLFFBQVEsS0FBSztBQUFBLEVBQzlFO0FBSU8sV0FBUyxhQUFhLE9BQU87QUFDaEMsV0FBTyxTQUFTLEtBQUs7QUFBQSxFQUN6QjtBQ3ZKTyxXQUFTLG9CQUNkLFNBQ2dCO0FBQ2hCLFdBQU8sSUFBSSxRQUFRLENBQUMsU0FBUyxXQUFXO0FBQ3RDLGFBQU8sUUFBUTtBQUFBLFFBQ2I7QUFBQSxRQUNBLENBQUMsYUFBeUQ7QUFDeEQsZ0JBQU0sZUFBZSxPQUFPLFFBQVE7QUFDcEMsY0FBSSxjQUFjO0FBQ2hCLG1CQUFPLElBQUksTUFBTSxhQUFhLE9BQU8sQ0FBQztBQUN0QztBQUFBLFVBQ0Y7QUFFQSxjQUFJLENBQUMsVUFBVTtBQUNiLG1CQUFPLElBQUksTUFBTSxrQ0FBa0MsQ0FBQztBQUNwRDtBQUFBLFVBQ0Y7QUFFQSxjQUFJLENBQUMsU0FBUyxJQUFJO0FBQ2hCLG1CQUFPLElBQUksTUFBTSxTQUFTLEtBQUssQ0FBQztBQUNoQztBQUFBLFVBQ0Y7QUFFQSxrQkFBUSxTQUFTLElBQUk7QUFBQSxRQUN2QjtBQUFBLE1BQUE7QUFBQSxJQUVKLENBQUM7QUFBQSxFQUNIO0FBTUEsaUJBQXNCLHVCQUNwQixXQUNlO0FBQ2YsUUFBSSxVQUFVLFdBQVcsR0FBRztBQUMxQjtBQUFBLElBQ0Y7QUFFQSxRQUFJO0FBQ0YsWUFBTSxvQkFBK0I7QUFBQSxRQUNuQyxNQUFNO0FBQUEsUUFDTixTQUFTO0FBQUEsVUFDUCxRQUFRO0FBQUEsUUFBQTtBQUFBLE1BQ1YsQ0FDRDtBQUFBLElBQ0gsU0FBUyxPQUFPO0FBQ2QsVUFBSSxpQ0FBaUMsS0FBSyxHQUFHO0FBQzNDO0FBQUEsTUFDRjtBQUVBLDBCQUFvQix1Q0FBdUMsS0FBSztBQUFBLElBQ2xFO0FBQUEsRUFDRjtBQW9DTyxXQUFTLCtCQUNkLE9BQ3VDO0FBQ3ZDLFFBQUksQ0FBQyxhQUFhLEtBQUssRUFBRyxRQUFPO0FBRWpDLFFBQUksTUFBTSxXQUFXLG9CQUFvQjtBQUN2QyxhQUFPO0FBQUEsSUFDVDtBQUVBLFVBQU0saUJBQWlCLE9BQU8sT0FBTyxPQUFPLE9BQU87QUFDbkQsVUFBTSxnQkFBZ0IsTUFBTSxRQUFRLE1BQU0sTUFBTTtBQUVoRCxXQUFPLGtCQUFrQjtBQUFBLEVBQzNCO0FBRUEsV0FBUyxpQ0FBaUMsT0FBeUI7QUFDakUsUUFBSSxFQUFFLGlCQUFpQixRQUFRO0FBQzdCLGFBQU87QUFBQSxJQUNUO0FBRUEsVUFBTSxVQUFVLE1BQU0sUUFBUSxZQUFBO0FBQzlCLFdBQ0UsUUFBUSxTQUFTLCtCQUErQixLQUNoRCxRQUFRLFNBQVMsOEJBQThCO0FBQUEsRUFFbkQ7QUMvSEEsUUFBTSw4QkFBOEI7QUFFN0IsV0FBUyw2QkFBbUM7QUFDakQsUUFBSSxPQUFPLFdBQVcsYUFBYTtBQUNqQztBQUFBLElBQ0Y7QUFFQSxVQUFNLFFBQVE7QUFJZCxRQUFJLE1BQU0sMkJBQTJCLEdBQUc7QUFDdEM7QUFBQSxJQUNGO0FBQ0EsVUFBTSwyQkFBMkIsSUFBSTtBQUVyQyxVQUFNLFFBQW1CLENBQUE7QUFDekIsUUFBSSxhQUFtRDtBQUV2RCxVQUFNLGFBQWE7QUFDbkIsVUFBTSxvQkFBb0I7QUFFMUIsVUFBTSxhQUFhLE1BQU07QUFDdkIsbUJBQWE7QUFFYixVQUFJLE1BQU0sV0FBVyxHQUFHO0FBQ3RCO0FBQUEsTUFDRjtBQUVBLFlBQU0sU0FBUyxNQUFNLE9BQU8sR0FBRyxVQUFVO0FBQ3pDLDZCQUF1QixNQUFNLEVBQUUsTUFBTSxDQUFDLFVBQW1CO0FBQ3ZELDRCQUFvQiwwQ0FBMEMsS0FBSztBQUFBLE1BQ3JFLENBQUM7QUFFRCxVQUFJLE1BQU0sU0FBUyxHQUFHO0FBQ3BCLHFCQUFhLFdBQVcsWUFBWSxDQUFDO0FBQ3JDO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFFQSxVQUFNLGdCQUFnQixNQUFNO0FBQzFCLFVBQUksWUFBWTtBQUNkO0FBQUEsTUFDRjtBQUVBLG1CQUFhLFdBQVcsWUFBWSxpQkFBaUI7QUFBQSxJQUN2RDtBQUVBLFVBQU0sZ0JBQWdCLENBQUMsV0FBc0I7QUFDM0MsVUFBSSxPQUFPLFdBQVcsR0FBRztBQUN2QjtBQUFBLE1BQ0Y7QUFFQSxpQkFBVyxhQUFhLFFBQVE7QUFDOUIsY0FBTSxLQUFLLFNBQVM7QUFBQSxNQUN0QjtBQUVBLFVBQUksTUFBTSxVQUFVLFlBQVk7QUFDOUIsWUFBSSxZQUFZO0FBQ2QsdUJBQWEsVUFBVTtBQUFBLFFBQ3pCO0FBQ0EscUJBQWEsV0FBVyxZQUFZLENBQUM7QUFDckM7QUFBQSxNQUNGO0FBRUEsb0JBQUE7QUFBQSxJQUNGO0FBRUEsVUFBTSxrQkFBa0IsQ0FBQyxVQUFpQztBQUN4RCxVQUFJLE1BQU0sV0FBVyxPQUFRO0FBQzdCLFVBQUksQ0FBQywrQkFBK0IsTUFBTSxJQUFJLEVBQUc7QUFFakQsVUFBSSxNQUFNLFFBQVEsTUFBTSxLQUFLLE1BQU0sR0FBRztBQUNwQyxzQkFBYyxNQUFNLEtBQUssTUFBTTtBQUMvQjtBQUFBLE1BQ0Y7QUFFQSxvQkFBYyxDQUFDLE1BQU0sS0FBSyxLQUFLLENBQUM7QUFBQSxJQUNsQztBQUVBLFdBQU8saUJBQWlCLFdBQVcsZUFBZTtBQUNsRCxXQUFPLGlCQUFpQixZQUFZLFlBQVk7QUFBQSxNQUM5QyxTQUFTO0FBQUEsSUFBQSxDQUNWO0FBQUEsRUFDSDtBQ3ZGQSxRQUFBLGFBQWUsb0JBQW9CO0FBQUEsSUFDakMsU0FBUyxDQUFDLFlBQVk7QUFBQSxJQUN0QixPQUFPO0FBQUEsSUFDUCxPQUFPO0FBQ0wsaUNBQUE7QUFBQSxJQUNGO0FBQUEsRUFDRixDQUFDO0FDUkQsV0FBU0MsUUFBTSxXQUFXLE1BQU07QUFFL0IsUUFBSSxPQUFPLEtBQUssQ0FBQyxNQUFNLFNBQVUsUUFBTyxTQUFTLEtBQUssTUFBQSxDQUFPLElBQUksR0FBRyxJQUFJO0FBQUEsUUFDbkUsUUFBTyxTQUFTLEdBQUcsSUFBSTtBQUFBLEVBQzdCO0FBSUEsUUFBTUMsV0FBUztBQUFBLElBQ2QsT0FBTyxJQUFJLFNBQVNELFFBQU0sUUFBUSxPQUFPLEdBQUcsSUFBSTtBQUFBLElBQ2hELEtBQUssSUFBSSxTQUFTQSxRQUFNLFFBQVEsS0FBSyxHQUFHLElBQUk7QUFBQSxJQUM1QyxNQUFNLElBQUksU0FBU0EsUUFBTSxRQUFRLE1BQU0sR0FBRyxJQUFJO0FBQUEsSUFDOUMsT0FBTyxJQUFJLFNBQVNBLFFBQU0sUUFBUSxPQUFPLEdBQUcsSUFBSTtBQUFBLEVBQ2pEO0FDYk8sUUFBTUUsWUFBVSxXQUFXLFNBQVMsU0FBUyxLQUNoRCxXQUFXLFVBQ1gsV0FBVztBQ1dmLFFBQU0sVUFBVTtBQ1hoQixNQUFJLHlCQUF5QixNQUFNQyxnQ0FBK0IsTUFBTTtBQUFBLElBQ3ZFLE9BQU8sYUFBYSxtQkFBbUIsb0JBQW9CO0FBQUEsSUFDM0QsWUFBWSxRQUFRLFFBQVE7QUFDM0IsWUFBTUEsd0JBQXVCLFlBQVksRUFBRTtBQUMzQyxXQUFLLFNBQVM7QUFDZCxXQUFLLFNBQVM7QUFBQSxJQUNmO0FBQUEsRUFDRDtBQUlBLFdBQVMsbUJBQW1CLFdBQVc7QUFDdEMsV0FBTyxHQUFHLFNBQVMsU0FBUyxFQUFFLElBQUksOEJBQTBCLElBQUksU0FBUztBQUFBLEVBQzFFO0FDVEEsV0FBUyxzQkFBc0IsS0FBSztBQUNuQyxRQUFJO0FBQ0osUUFBSTtBQUNKLFdBQU8sRUFBRSxNQUFNO0FBQ2QsVUFBSSxZQUFZLEtBQU07QUFDdEIsZUFBUyxJQUFJLElBQUksU0FBUyxJQUFJO0FBQzlCLGlCQUFXLElBQUksWUFBWSxNQUFNO0FBQ2hDLFlBQUksU0FBUyxJQUFJLElBQUksU0FBUyxJQUFJO0FBQ2xDLFlBQUksT0FBTyxTQUFTLE9BQU8sTUFBTTtBQUNoQyxpQkFBTyxjQUFjLElBQUksdUJBQXVCLFFBQVEsTUFBTSxDQUFDO0FBQy9ELG1CQUFTO0FBQUEsUUFDVjtBQUFBLE1BQ0QsR0FBRyxHQUFHO0FBQUEsSUFDUCxFQUFDO0FBQUEsRUFDRjtBQ2VBLE1BQUksdUJBQXVCLE1BQU1DLHNCQUFxQjtBQUFBLElBQ3JELE9BQU8sOEJBQThCLG1CQUFtQiw0QkFBNEI7QUFBQSxJQUNwRjtBQUFBLElBQ0E7QUFBQSxJQUNBLGtCQUFrQixzQkFBc0IsSUFBSTtBQUFBLElBQzVDLFlBQVksbUJBQW1CLFNBQVM7QUFDdkMsV0FBSyxvQkFBb0I7QUFDekIsV0FBSyxVQUFVO0FBQ2YsV0FBSyxLQUFLLEtBQUssT0FBTSxFQUFHLFNBQVMsRUFBRSxFQUFFLE1BQU0sQ0FBQztBQUM1QyxXQUFLLGtCQUFrQixJQUFJLGdCQUFlO0FBQzFDLFdBQUssZUFBYztBQUNuQixXQUFLLHNCQUFxQjtBQUFBLElBQzNCO0FBQUEsSUFDQSxJQUFJLFNBQVM7QUFDWixhQUFPLEtBQUssZ0JBQWdCO0FBQUEsSUFDN0I7QUFBQSxJQUNBLE1BQU0sUUFBUTtBQUNiLGFBQU8sS0FBSyxnQkFBZ0IsTUFBTSxNQUFNO0FBQUEsSUFDekM7QUFBQSxJQUNBLElBQUksWUFBWTtBQUNmLFVBQUksUUFBUSxTQUFTLE1BQU0sS0FBTSxNQUFLLGtCQUFpQjtBQUN2RCxhQUFPLEtBQUssT0FBTztBQUFBLElBQ3BCO0FBQUEsSUFDQSxJQUFJLFVBQVU7QUFDYixhQUFPLENBQUMsS0FBSztBQUFBLElBQ2Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBY0EsY0FBYyxJQUFJO0FBQ2pCLFdBQUssT0FBTyxpQkFBaUIsU0FBUyxFQUFFO0FBQ3hDLGFBQU8sTUFBTSxLQUFLLE9BQU8sb0JBQW9CLFNBQVMsRUFBRTtBQUFBLElBQ3pEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBWUEsUUFBUTtBQUNQLGFBQU8sSUFBSSxRQUFRLE1BQU07QUFBQSxNQUFDLENBQUM7QUFBQSxJQUM1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU1BLFlBQVksU0FBUyxTQUFTO0FBQzdCLFlBQU0sS0FBSyxZQUFZLE1BQU07QUFDNUIsWUFBSSxLQUFLLFFBQVMsU0FBTztBQUFBLE1BQzFCLEdBQUcsT0FBTztBQUNWLFdBQUssY0FBYyxNQUFNLGNBQWMsRUFBRSxDQUFDO0FBQzFDLGFBQU87QUFBQSxJQUNSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBTUEsV0FBVyxTQUFTLFNBQVM7QUFDNUIsWUFBTSxLQUFLLFdBQVcsTUFBTTtBQUMzQixZQUFJLEtBQUssUUFBUyxTQUFPO0FBQUEsTUFDMUIsR0FBRyxPQUFPO0FBQ1YsV0FBSyxjQUFjLE1BQU0sYUFBYSxFQUFFLENBQUM7QUFDekMsYUFBTztBQUFBLElBQ1I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9BLHNCQUFzQixVQUFVO0FBQy9CLFlBQU0sS0FBSyxzQkFBc0IsSUFBSSxTQUFTO0FBQzdDLFlBQUksS0FBSyxRQUFTLFVBQVMsR0FBRyxJQUFJO0FBQUEsTUFDbkMsQ0FBQztBQUNELFdBQUssY0FBYyxNQUFNLHFCQUFxQixFQUFFLENBQUM7QUFDakQsYUFBTztBQUFBLElBQ1I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9BLG9CQUFvQixVQUFVLFNBQVM7QUFDdEMsWUFBTSxLQUFLLG9CQUFvQixJQUFJLFNBQVM7QUFDM0MsWUFBSSxDQUFDLEtBQUssT0FBTyxRQUFTLFVBQVMsR0FBRyxJQUFJO0FBQUEsTUFDM0MsR0FBRyxPQUFPO0FBQ1YsV0FBSyxjQUFjLE1BQU0sbUJBQW1CLEVBQUUsQ0FBQztBQUMvQyxhQUFPO0FBQUEsSUFDUjtBQUFBLElBQ0EsaUJBQWlCLFFBQVEsTUFBTSxTQUFTLFNBQVM7QUFDaEQsVUFBSSxTQUFTLHNCQUFzQjtBQUNsQyxZQUFJLEtBQUssUUFBUyxNQUFLLGdCQUFnQixJQUFHO0FBQUEsTUFDM0M7QUFDQSxhQUFPLG1CQUFtQixLQUFLLFdBQVcsTUFBTSxJQUFJLG1CQUFtQixJQUFJLElBQUksTUFBTSxTQUFTO0FBQUEsUUFDN0YsR0FBRztBQUFBLFFBQ0gsUUFBUSxLQUFLO0FBQUEsTUFDaEIsQ0FBRztBQUFBLElBQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBS0Esb0JBQW9CO0FBQ25CLFdBQUssTUFBTSxvQ0FBb0M7QUFDL0NILGVBQU8sTUFBTSxtQkFBbUIsS0FBSyxpQkFBaUIsdUJBQXVCO0FBQUEsSUFDOUU7QUFBQSxJQUNBLGlCQUFpQjtBQUNoQixlQUFTLGNBQWMsSUFBSSxZQUFZRyxzQkFBcUIsNkJBQTZCLEVBQUUsUUFBUTtBQUFBLFFBQ2xHLG1CQUFtQixLQUFLO0FBQUEsUUFDeEIsV0FBVyxLQUFLO0FBQUEsTUFDbkIsRUFBRyxDQUFFLENBQUM7QUFDSixhQUFPLFlBQVk7QUFBQSxRQUNsQixNQUFNQSxzQkFBcUI7QUFBQSxRQUMzQixtQkFBbUIsS0FBSztBQUFBLFFBQ3hCLFdBQVcsS0FBSztBQUFBLE1BQ25CLEdBQUssR0FBRztBQUFBLElBQ1A7QUFBQSxJQUNBLHlCQUF5QixPQUFPO0FBQy9CLFlBQU0sc0JBQXNCLE1BQU0sUUFBUSxzQkFBc0IsS0FBSztBQUNyRSxZQUFNLGFBQWEsTUFBTSxRQUFRLGNBQWMsS0FBSztBQUNwRCxhQUFPLHVCQUF1QixDQUFDO0FBQUEsSUFDaEM7QUFBQSxJQUNBLHdCQUF3QjtBQUN2QixZQUFNLEtBQUssQ0FBQyxVQUFVO0FBQ3JCLFlBQUksRUFBRSxpQkFBaUIsZ0JBQWdCLENBQUMsS0FBSyx5QkFBeUIsS0FBSyxFQUFHO0FBQzlFLGFBQUssa0JBQWlCO0FBQUEsTUFDdkI7QUFDQSxlQUFTLGlCQUFpQkEsc0JBQXFCLDZCQUE2QixFQUFFO0FBQzlFLFdBQUssY0FBYyxNQUFNLFNBQVMsb0JBQW9CQSxzQkFBcUIsNkJBQTZCLEVBQUUsQ0FBQztBQUFBLElBQzVHO0FBQUEsRUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzsiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCw3LDgsOSwxMCwxMSwxMl19
debuggerContentBridgeMain;