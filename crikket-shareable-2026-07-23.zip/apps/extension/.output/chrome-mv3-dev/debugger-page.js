var debuggerPage = (function() {
  "use strict";
  const PAGE_SOURCE = "CRIKKET_DEBUGGER_PAGE_BRIDGE";
  const INSTALL_FLAG = "__crikketDebuggerPageScriptInstalled";
  const MAX_TEXT_LENGTH = 2e3;
  const MAX_BODY_LENGTH = 4e3;
  const MAX_HEADER_NAME_LENGTH = 120;
  const MAX_HEADER_VALUE_LENGTH = 500;
  const MAX_BATCH_SIZE = 40;
  const FLUSH_INTERVAL_MS = 120;
  const MAX_SERIALIZE_DEPTH = 4;
  const MAX_SERIALIZE_KEYS = 30;
  const MAX_SERIALIZE_ARRAY_ITEMS = 30;
  const REDACTED_VALUE = "[REDACTED]";
  const SENSITIVE_NAME_PATTERNS = [
    "authorization",
    "cookie",
    "set-cookie",
    "token",
    "secret",
    "password",
    "passwd",
    "pwd",
    "session",
    "api-key",
    "apikey",
    "x-api-key",
    "refresh-token",
    "refresh_token",
    "access-token",
    "access_token",
    "id-token",
    "id_token",
    "client-secret",
    "client_secret"
  ];
  const REDACTABLE_FIELD_PATTERN = /((?:access[_-]?token|refresh[_-]?token|id[_-]?token|api[_-]?key|client[_-]?secret|password|passwd|pwd|authorization|cookie|session[_-]?id)\s*[:=]\s*)([^&\s",;]+)/gi;
  const truncate = (value, maxLength = MAX_TEXT_LENGTH) => {
    if (value.length <= maxLength) {
      return value;
    }
    return `${value.slice(0, maxLength)}...`;
  };
  const isSensitiveName = (value) => {
    const normalizedValue = value.trim().toLowerCase();
    if (!normalizedValue) {
      return false;
    }
    return SENSITIVE_NAME_PATTERNS.some((pattern) => {
      return normalizedValue.includes(pattern);
    });
  };
  const shouldHideHeader = (headerName) => {
    return headerName.includes("debugger") || isSensitiveName(headerName);
  };
  const getElementTarget = (target) => {
    if (!(target instanceof Element)) {
      return void 0;
    }
    if (target.id) {
      return `#${target.id}`;
    }
    const classNames = typeof target.className === "string" ? target.className : "";
    const firstClass = classNames.split(" ").map((entry) => entry.trim()).find((entry) => entry.length > 0);
    if (firstClass) {
      return `${target.tagName.toLowerCase()}.${firstClass}`;
    }
    return target.tagName.toLowerCase();
  };
  const toAbsoluteUrl = (value, reporter) => {
    try {
      return new URL(value, location.href).toString();
    } catch (error) {
      reporter.reportNonFatalError("Failed to normalize network URL in debugger instrumentation", {
        error,
        value
      });
      return null;
    }
  };
  const redactSensitiveQueryParams = (absoluteUrl) => {
    try {
      const parsedUrl = new URL(absoluteUrl);
      for (const [key] of parsedUrl.searchParams.entries()) {
        if (!isSensitiveName(key)) {
          continue;
        }
        parsedUrl.searchParams.set(key, REDACTED_VALUE);
      }
      return parsedUrl.toString();
    } catch {
      return absoluteUrl;
    }
  };
  const sanitizeStructuredValue = (value, depth = 0) => {
    if (depth >= 6) {
      return "[MaxDepth]";
    }
    if (Array.isArray(value)) {
      return value.map((item) => sanitizeStructuredValue(item, depth + 1));
    }
    if (value && typeof value === "object") {
      const result2 = {};
      for (const [key, nestedValue] of Object.entries(value)) {
        if (isSensitiveName(key)) {
          result2[key] = REDACTED_VALUE;
          continue;
        }
        result2[key] = sanitizeStructuredValue(nestedValue, depth + 1);
      }
      return result2;
    }
    if (typeof value === "string") {
      return value.replace(REDACTABLE_FIELD_PATTERN, `$1${REDACTED_VALUE}`);
    }
    return value;
  };
  const sanitizeUrlEncodedBody = (body) => {
    const params = new URLSearchParams(body);
    for (const [key] of params.entries()) {
      if (!isSensitiveName(key)) {
        continue;
      }
      params.set(key, REDACTED_VALUE);
    }
    return params.toString();
  };
  const sanitizeCapturedBody = (body, contentType) => {
    if (typeof body !== "string" || body.length === 0) {
      return body;
    }
    const normalizedContentType = contentType.toLowerCase();
    if (normalizedContentType.includes("application/json")) {
      try {
        const parsed = JSON.parse(body);
        return truncate(JSON.stringify(sanitizeStructuredValue(parsed)), MAX_TEXT_LENGTH * 2);
      } catch {
        return truncate(body.replace(REDACTABLE_FIELD_PATTERN, `$1${REDACTED_VALUE}`), MAX_TEXT_LENGTH * 2);
      }
    }
    if (normalizedContentType.includes("x-www-form-urlencoded")) {
      return truncate(sanitizeUrlEncodedBody(body), MAX_TEXT_LENGTH * 2);
    }
    return truncate(body.replace(REDACTABLE_FIELD_PATTERN, `$1${REDACTED_VALUE}`), MAX_TEXT_LENGTH * 2);
  };
  function createNonFatalReporter() {
    const originalConsoleWarn = console.warn.bind(console);
    const reportedContexts = /* @__PURE__ */ new Set();
    return {
      reportNonFatalError(context, error) {
        if (reportedContexts.has(context)) {
          return;
        }
        reportedContexts.add(context);
        originalConsoleWarn(`[Non-fatal] ${context}`, error);
      }
    };
  }
  function installActionAndNavigationCapture(input) {
    const { postAction } = input;
    const postNavigationBreadcrumb = (mode) => {
      postAction("navigation", "window", {
        mode,
        url: location.href,
        path: location.pathname,
        search: location.search,
        hash: location.hash,
        title: document.title
      });
    };
    const delegatedHandlers = {
      click: (event) => {
        postAction("click", getElementTarget(event.target));
      },
      input: (event) => {
        const target = getElementTarget(event.target);
        let valueLength;
        const inputTarget = event.target;
        if (inputTarget instanceof HTMLInputElement || inputTarget instanceof HTMLTextAreaElement) {
          valueLength = inputTarget.value.length;
        }
        postAction("input", target, {
          valueLength
        });
      },
      change: (event) => {
        postAction("change", getElementTarget(event.target));
      }
    };
    const delegatedListener = (event) => {
      if (event.type !== "click" && event.type !== "input" && event.type !== "change") {
        return;
      }
      delegatedHandlers[event.type](event);
    };
    for (const eventType of ["click", "input", "change"]) {
      document.addEventListener(eventType, delegatedListener, {
        capture: true,
        passive: true
      });
    }
    const originalPushState = history.pushState;
    history.pushState = function(...args) {
      originalPushState.apply(this, args);
      postNavigationBreadcrumb("pushState");
    };
    const originalReplaceState = history.replaceState;
    history.replaceState = function(...args) {
      originalReplaceState.apply(this, args);
      postNavigationBreadcrumb("replaceState");
    };
    window.addEventListener("popstate", () => {
      postNavigationBreadcrumb("popstate");
    }, {
      capture: true,
      passive: true
    });
    window.addEventListener("hashchange", () => {
      postNavigationBreadcrumb("hashchange");
    }, {
      capture: true,
      passive: true
    });
    postNavigationBreadcrumb("initial");
  }
  function installConsoleCapture(input) {
    const { reporter, postConsole } = input;
    const consoleLevels = [
      "log",
      "info",
      "warn",
      "error",
      "debug"
    ];
    for (const level of consoleLevels) {
      const original = console[level].bind(console);
      console[level] = (...args) => {
        try {
          postConsole(level, args);
        } catch (error) {
          reporter.reportNonFatalError("Failed to post console event in debugger instrumentation", error);
        }
        original(...args);
      };
    }
  }
  const DIAGNOSTICS_KEY = "__crikketDebuggerDiagnostics";
  const DIAGNOSTICS_VERSION = 1;
  const MAX_ERROR_ENTRIES = 25;
  const MAX_ERROR_LENGTH = 300;
  const createDefaultDiagnosticsState = () => {
    return {
      version: DIAGNOSTICS_VERSION,
      installedAt: Date.now(),
      url: location.href,
      hooks: {
        fetch: "pending",
        xhr: false
      },
      counters: {
        actionEvents: 0,
        consoleEvents: 0,
        networkEvents: 0,
        fetchCalls: 0,
        fetchFailures: 0,
        xhrCalls: 0,
        queuedEvents: 0,
        flushedBatches: 0
      },
      last: {},
      errors: []
    };
  };
  const toErrorMessage = (context, error) => {
    if (error instanceof Error) {
      return `${context}: ${error.message}`;
    }
    return `${context}: ${String(error)}`;
  };
  function createPageDiagnostics(scope) {
    const runtimeScope = scope;
    const state = runtimeScope[DIAGNOSTICS_KEY] ?? createDefaultDiagnosticsState();
    runtimeScope[DIAGNOSTICS_KEY] = state;
    state.installedAt = Date.now();
    state.url = location.href;
    state.hooks.fetch = "pending";
    state.hooks.xhr = false;
    return {
      state,
      createReporter(reporter) {
        const originalReport = reporter.reportNonFatalError.bind(reporter);
        return {
          reportNonFatalError(context, error) {
            state.errors.push(truncate(toErrorMessage(context, error), MAX_ERROR_LENGTH));
            if (state.errors.length > MAX_ERROR_ENTRIES) {
              state.errors.shift();
            }
            originalReport(context, error);
          }
        };
      },
      recordActionEvent() {
        state.counters.actionEvents += 1;
      },
      recordConsoleEvent() {
        state.counters.consoleEvents += 1;
      },
      recordNetworkEvent(url) {
        state.counters.networkEvents += 1;
        state.last.networkUrl = url;
      },
      recordFetchCall() {
        state.counters.fetchCalls += 1;
      },
      recordFetchFailure(message) {
        state.counters.fetchFailures += 1;
        state.last.fetchError = message;
      },
      setFetchHookState(nextState) {
        state.hooks.fetch = nextState;
      },
      recordXhrCall() {
        state.counters.xhrCalls += 1;
      },
      setXhrHookInstalled() {
        state.hooks.xhr = true;
      },
      recordQueuedEvent() {
        state.counters.queuedEvents += 1;
      },
      recordFlushedBatch() {
        state.counters.flushedBatches += 1;
      }
    };
  }
  function createEventQueue(input = {}) {
    const { recordFlushedBatch, recordQueuedEvent } = input;
    const eventQueue = [];
    let flushTimer = null;
    const flushEventQueue = () => {
      flushTimer = null;
      if (eventQueue.length === 0) {
        return;
      }
      const batchedEvents = eventQueue.splice(0, MAX_BATCH_SIZE);
      recordFlushedBatch?.();
      window.postMessage({
        source: PAGE_SOURCE,
        events: batchedEvents
      }, "*");
      if (eventQueue.length > 0) {
        flushTimer = setTimeout(flushEventQueue, 0);
        return;
      }
    };
    const scheduleEventFlush = () => {
      if (flushTimer) {
        return;
      }
      flushTimer = setTimeout(flushEventQueue, FLUSH_INTERVAL_MS);
    };
    const enqueueEvent = (event) => {
      eventQueue.push(event);
      recordQueuedEvent?.();
      if (eventQueue.length >= MAX_BATCH_SIZE) {
        if (flushTimer) {
          clearTimeout(flushTimer);
        }
        flushTimer = setTimeout(flushEventQueue, 0);
        return;
      }
      scheduleEventFlush();
    };
    return {
      enqueueEvent,
      flushEventQueue
    };
  }
  const serializePrimitive = (value) => {
    if (value === null || typeof value === "boolean" || typeof value === "number") {
      return {
        handled: true,
        value
      };
    }
    if (typeof value === "string") {
      return {
        handled: true,
        value: truncate(value)
      };
    }
    if (typeof value === "undefined") {
      return {
        handled: true,
        value: "[undefined]"
      };
    }
    if (typeof value === "bigint") {
      return {
        handled: true,
        value: `${value.toString()}n`
      };
    }
    if (typeof value === "symbol") {
      return {
        handled: true,
        value: value.toString()
      };
    }
    if (typeof value === "function") {
      return {
        handled: true,
        value: `[Function ${value.name || "anonymous"}]`
      };
    }
    return {
      handled: false
    };
  };
  const serializeError = (value) => {
    return {
      name: value.name,
      message: truncate(value.message),
      stack: typeof value.stack === "string" ? truncate(value.stack) : void 0
    };
  };
  const isArrayBufferValue = (value) => {
    return typeof ArrayBuffer !== "undefined" && value instanceof ArrayBuffer;
  };
  const isArrayBufferViewValue = (value) => {
    return typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView(value);
  };
  const serializeArray = (value, state, depth, path, serializeValue) => {
    const serialized = [];
    const limit = Math.min(value.length, MAX_SERIALIZE_ARRAY_ITEMS);
    for (let index = 0; index < limit; index += 1) {
      serialized.push(serializeValue(value[index], state, depth + 1, `${path}[${index}]`));
    }
    if (value.length > limit) {
      serialized.push(`[+${value.length - limit} more]`);
    }
    return serialized;
  };
  const serializeMap = (value, state, depth, path, serializeValue) => {
    const entries = [];
    let index = 0;
    for (const [entryKey, entryValue] of value.entries()) {
      if (index >= MAX_SERIALIZE_KEYS) {
        entries.push(`[+${value.size - index} more]`);
        break;
      }
      entries.push([
        serializeValue(entryKey, state, depth + 1, `${path}.mapKey${index}`),
        serializeValue(entryValue, state, depth + 1, `${path}.mapVal${index}`)
      ]);
      index += 1;
    }
    return {
      type: "Map",
      entries
    };
  };
  const serializeSet = (value, state, depth, path, serializeValue) => {
    const entries = [];
    let index = 0;
    for (const entry of value.values()) {
      if (index >= MAX_SERIALIZE_KEYS) {
        entries.push(`[+${value.size - index} more]`);
        break;
      }
      entries.push(serializeValue(entry, state, depth + 1, `${path}.setVal${index}`));
      index += 1;
    }
    return {
      type: "Set",
      values: entries
    };
  };
  const serializeRecordObject = (value, state, depth, path, serializeValue) => {
    const result2 = {};
    const entries = Object.entries(value);
    const limit = Math.min(entries.length, MAX_SERIALIZE_KEYS);
    for (let index = 0; index < limit; index += 1) {
      const [entryKey, entryValue] = entries[index] ?? [];
      if (typeof entryKey !== "string") {
        continue;
      }
      result2[entryKey] = serializeValue(entryValue, state, depth + 1, `${path}.${entryKey}`);
    }
    if (entries.length > limit) {
      result2.__truncatedKeys = entries.length - limit;
    }
    return result2;
  };
  const objectSerializers = [
    {
      canHandle: (value) => value instanceof Error,
      serialize: (value) => serializeError(value)
    },
    {
      canHandle: (value) => value instanceof Date,
      serialize: (value) => value.toISOString()
    },
    {
      canHandle: (value) => value instanceof RegExp,
      serialize: (value) => value.toString()
    },
    {
      canHandle: (value) => typeof URL !== "undefined" && value instanceof URL,
      serialize: (value) => value.toString()
    },
    {
      canHandle: (value) => typeof Element !== "undefined" && value instanceof Element,
      serialize: (value) => {
        const element = value;
        return getElementTarget(element) ?? element.tagName.toLowerCase();
      }
    },
    {
      canHandle: (value) => typeof Event !== "undefined" && value instanceof Event,
      serialize: (value) => {
        const event = value;
        return {
          type: event.type,
          target: getElementTarget(event.target)
        };
      }
    },
    {
      canHandle: (value) => Array.isArray(value),
      serialize: (value, state, depth, path, serializeValue) => serializeArray(value, state, depth, path, serializeValue)
    },
    {
      canHandle: (value) => value instanceof Map,
      serialize: (value, state, depth, path, serializeValue) => serializeMap(value, state, depth, path, serializeValue)
    },
    {
      canHandle: (value) => value instanceof Set,
      serialize: (value, state, depth, path, serializeValue) => serializeSet(value, state, depth, path, serializeValue)
    },
    {
      canHandle: (value) => isArrayBufferValue(value),
      serialize: (value) => `[ArrayBuffer ${value.byteLength}]`
    },
    {
      canHandle: (value) => isArrayBufferViewValue(value),
      serialize: (value) => {
        const bufferView = value;
        return `[${bufferView.constructor.name} ${bufferView.byteLength}]`;
      }
    }
  ];
  const serializeKnownObject = (value, state, depth, path, serializeValue) => {
    for (const serializer of objectSerializers) {
      if (!serializer.canHandle(value)) {
        continue;
      }
      return serializer.serialize(value, state, depth, path, serializeValue);
    }
    return serializeRecordObject(value, state, depth, path, serializeValue);
  };
  const toSerializableValue = (value, state, depth, path) => {
    const primitive = serializePrimitive(value);
    if (primitive.handled) {
      return primitive.value;
    }
    if (depth >= MAX_SERIALIZE_DEPTH) {
      return "[MaxDepth]";
    }
    if (typeof value !== "object" || value === null) {
      return Object.prototype.toString.call(value);
    }
    const existingPath = state.seen.get(value);
    if (existingPath) {
      return `[Circular ~${existingPath}]`;
    }
    state.seen.set(value, path);
    return serializeKnownObject(value, state, depth, path, toSerializableValue);
  };
  function createStringifyValue(reporter) {
    return (value) => {
      if (typeof value === "string") {
        return truncate(value);
      }
      if (typeof value === "number" || typeof value === "boolean" || value === null || typeof value === "undefined") {
        return String(value);
      }
      try {
        const serialized = toSerializableValue(value, {
          seen: /* @__PURE__ */ new WeakMap()
        }, 0, "$");
        if (typeof serialized === "string") {
          return truncate(serialized);
        }
        return truncate(JSON.stringify(serialized));
      } catch (error) {
        reporter.reportNonFatalError("Failed to stringify console value in debugger instrumentation", error);
        return truncate(Object.prototype.toString.call(value));
      }
    };
  }
  const getRequestBodyPreview = (body, stringifyValue) => {
    if (!body) {
      return void 0;
    }
    if (typeof body === "string") {
      return truncate(body, MAX_BODY_LENGTH);
    }
    if (body instanceof URLSearchParams) {
      return truncate(body.toString(), MAX_BODY_LENGTH);
    }
    if (typeof FormData !== "undefined" && body instanceof FormData) {
      const keys = [];
      for (const key of body.keys()) {
        keys.push(key);
      }
      return truncate(`[form-data] ${keys.join(",")}`, MAX_BODY_LENGTH);
    }
    if (typeof Blob !== "undefined" && body instanceof Blob) {
      return `[blob:${body.type || "unknown"}:${body.size}]`;
    }
    if (typeof ArrayBuffer !== "undefined") {
      if (body instanceof ArrayBuffer) {
        return `[arraybuffer:${body.byteLength}]`;
      }
      if (ArrayBuffer.isView(body)) {
        return `[${body.constructor.name.toLowerCase()}:${body.byteLength}]`;
      }
    }
    return truncate(stringifyValue(body), MAX_BODY_LENGTH);
  };
  const shouldCaptureTextContent = (contentType) => {
    const normalized = contentType.toLowerCase();
    return normalized.includes("json") || normalized.includes("text") || normalized.includes("xml") || normalized.includes("x-www-form-urlencoded");
  };
  const toHeaderRecord = (input) => {
    if (!input) {
      return {};
    }
    const result2 = {};
    for (const [key, value] of input.entries()) {
      const normalizedKey = key.trim().toLowerCase();
      if (!normalizedKey || shouldHideHeader(normalizedKey)) {
        continue;
      }
      result2[normalizedKey.slice(0, MAX_HEADER_NAME_LENGTH)] = value.slice(0, MAX_HEADER_VALUE_LENGTH);
    }
    return result2;
  };
  const parseRawHeaders = (rawHeaders) => {
    const result2 = {};
    const lines = rawHeaders.split("\n");
    for (const line of lines) {
      const normalizedLine = line.replace("\r", "");
      const separatorIndex = normalizedLine.indexOf(":");
      if (separatorIndex <= 0) {
        continue;
      }
      const key = normalizedLine.slice(0, separatorIndex).trim().toLowerCase();
      if (!key || shouldHideHeader(key)) {
        continue;
      }
      const value = normalizedLine.slice(separatorIndex + 1).trim();
      if (!value) {
        continue;
      }
      result2[key.slice(0, MAX_HEADER_NAME_LENGTH)] = value.slice(0, MAX_HEADER_VALUE_LENGTH);
    }
    return result2;
  };
  const scheduleBackgroundTask = (reporter, task) => {
    const executeTask = () => {
      Promise.resolve(task()).catch((error) => {
        reporter.reportNonFatalError("Background debugger instrumentation task failed", error);
      });
    };
    if (typeof window.requestIdleCallback === "function") {
      window.requestIdleCallback(() => {
        executeTask();
      });
      return;
    }
    window.setTimeout(executeTask, 0);
  };
  const getRequestBodyPreviewAsync = (reporter, body, stringifyValue, contentType = "") => {
    return new Promise((resolve) => {
      scheduleBackgroundTask(reporter, () => {
        resolve(sanitizeCapturedBody(getRequestBodyPreview(body, stringifyValue), contentType));
      });
    });
  };
  const getTextBodyPreviewAsync = (reporter, contentType, errorContext, readBody) => {
    return new Promise((resolve) => {
      scheduleBackgroundTask(reporter, async () => {
        if (!shouldCaptureTextContent(contentType)) {
          resolve(void 0);
          return;
        }
        try {
          resolve(sanitizeCapturedBody(truncate(await readBody(), MAX_BODY_LENGTH), contentType));
        } catch (error) {
          reporter.reportNonFatalError(errorContext, error);
          resolve(void 0);
        }
      });
    });
  };
  const resolveFetchMethod = (input, init) => {
    if (typeof init?.method === "string" && init.method) {
      return init.method.toUpperCase();
    }
    if (input instanceof Request) {
      return input.method.toUpperCase();
    }
    return "GET";
  };
  const resolveFetchUrl = (input) => {
    if (typeof input === "string") {
      return input;
    }
    if (input instanceof URL) {
      return input.toString();
    }
    return input.url;
  };
  const getFetchRequestBodyPreview = async (input, init, requestHeaders, stringifyValue, reporter) => {
    const initBodyPreview = getRequestBodyPreview(init?.body, stringifyValue);
    if (initBodyPreview) {
      return initBodyPreview;
    }
    if (!(input instanceof Request)) {
      return void 0;
    }
    const method = (init?.method ?? input.method ?? "GET").toUpperCase();
    if (method === "GET" || method === "HEAD" || input.bodyUsed) {
      return void 0;
    }
    const contentType = requestHeaders?.get("content-type") ?? input.headers.get("content-type") ?? "";
    if (!shouldCaptureTextContent(contentType)) {
      return void 0;
    }
    try {
      return sanitizeCapturedBody(truncate(await input.clone().text(), MAX_BODY_LENGTH), contentType);
    } catch (error) {
      reporter.reportNonFatalError("Failed to capture fetch request body in debugger instrumentation", error);
      return void 0;
    }
  };
  const resolveFetchRequestBodyPromise = (requestInput, requestInit, requestHeaderSource, stringifyValue, reporter, requestBodyByRequest) => {
    if (requestInput instanceof Request) {
      return requestBodyByRequest.get(requestInput) ?? getFetchRequestBodyPreview(requestInput, requestInit, requestHeaderSource, stringifyValue, reporter);
    }
    return getFetchRequestBodyPreview(requestInput, requestInit, requestHeaderSource, stringifyValue, reporter);
  };
  const resolveFetchContext = (args, reporter, stringifyValue, requestBodyByRequest) => {
    const [requestInput, requestInit] = args;
    const method = resolveFetchMethod(requestInput, requestInit);
    const url = resolveFetchUrl(requestInput);
    const absoluteUrl = toAbsoluteUrl(url, reporter);
    if (!absoluteUrl) {
      return null;
    }
    let requestHeaderSource = null;
    if (requestInit?.headers) {
      try {
        requestHeaderSource = new Headers(requestInit.headers);
      } catch (error) {
        reporter.reportNonFatalError("Failed to normalize fetch headers in debugger instrumentation", error);
      }
    } else if (requestInput instanceof Request) {
      requestHeaderSource = requestInput.headers;
    }
    const requestHeaders = requestHeaderSource ? toHeaderRecord(requestHeaderSource) : requestInput instanceof Request ? toHeaderRecord(requestInput.headers) : {};
    const requestContentType = requestHeaderSource?.get("content-type") ?? (requestInput instanceof Request ? requestInput.headers.get("content-type") ?? "" : "");
    const requestBodyPromise = resolveFetchRequestBodyPromise(requestInput, requestInit, requestHeaderSource, stringifyValue, reporter, requestBodyByRequest);
    return {
      method,
      normalizedUrl: redactSensitiveQueryParams(absoluteUrl),
      requestHeaders,
      requestContentType,
      requestBodyPromise
    };
  };
  const installRequestConstructorCapture = (reporter, stringifyValue, requestBodyByRequest) => {
    if (typeof window.Request !== "function") {
      return;
    }
    const OriginalRequest = window.Request;
    const patchedRequest = new Proxy(OriginalRequest, {
      construct(target, argArray, newTarget) {
        const [, requestInit] = argArray;
        const requestInstance = Reflect.construct(target, argArray, newTarget);
        let requestHeaderSource;
        if (requestInit?.headers !== void 0) {
          try {
            requestHeaderSource = new Headers(requestInit.headers);
          } catch (error) {
            reporter.reportNonFatalError("Failed to normalize Request headers in debugger instrumentation", error);
            requestHeaderSource = requestInstance.headers;
          }
        } else {
          requestHeaderSource = requestInstance.headers;
        }
        const contentType = requestHeaderSource.get("content-type") ?? "";
        const requestBodyPromise = requestInit?.body !== void 0 ? getRequestBodyPreviewAsync(reporter, requestInit.body, stringifyValue, contentType) : getTextBodyPreviewAsync(reporter, contentType, "Failed to capture Request body text in debugger instrumentation", () => {
          if (requestInstance.bodyUsed) {
            return Promise.resolve("");
          }
          return requestInstance.clone().text();
        });
        requestBodyByRequest.set(requestInstance, requestBodyPromise);
        return requestInstance;
      }
    });
    try {
      Object.assign(patchedRequest, OriginalRequest);
    } catch (error) {
      reporter.reportNonFatalError("Failed to mirror Request constructor properties in debugger instrumentation", error);
    }
    try {
      window.Request = patchedRequest;
    } catch (error) {
      reporter.reportNonFatalError("Failed to patch Request constructor in debugger instrumentation", error);
    }
  };
  const cloneFetchResponseForCapture = (response, reporter) => {
    const contentType = response.headers.get("content-type") ?? "";
    if (!shouldCaptureTextContent(contentType) || response.bodyUsed) {
      return {
        contentType,
        responseClone: null
      };
    }
    try {
      return {
        contentType,
        responseClone: response.clone()
      };
    } catch (error) {
      reporter.reportNonFatalError("Failed to clone fetch response body in debugger instrumentation", error);
      return {
        contentType,
        responseClone: null
      };
    }
  };
  const scheduleFetchSuccessPost = (reporter, postNetwork, context, response, duration) => {
    const responseHeaders = toHeaderRecord(response.headers);
    const { contentType, responseClone } = cloneFetchResponseForCapture(response, reporter);
    scheduleBackgroundTask(reporter, async () => {
      let requestBody;
      let responseBody;
      try {
        requestBody = await context.requestBodyPromise;
      } catch (error) {
        reporter.reportNonFatalError("Failed to resolve fetch request body in debugger instrumentation", error);
      }
      try {
        responseBody = await getTextBodyPreviewAsync(reporter, contentType, "Failed to capture fetch response body text in debugger instrumentation", () => {
          if (!responseClone) {
            return Promise.resolve("");
          }
          return responseClone.text();
        });
      } catch (error) {
        reporter.reportNonFatalError("Failed to capture fetch response body in debugger instrumentation", error);
      }
      postNetwork({
        method: context.method,
        url: context.normalizedUrl,
        status: response.status,
        duration,
        requestHeaders: context.requestHeaders,
        responseHeaders,
        requestBody: sanitizeCapturedBody(requestBody, context.requestContentType),
        responseBody: sanitizeCapturedBody(responseBody, contentType)
      });
    });
  };
  const scheduleFetchFailurePost = (reporter, postNetwork, context, error, startedAt, stringifyValue) => {
    scheduleBackgroundTask(reporter, async () => {
      let requestBody;
      try {
        requestBody = await context.requestBodyPromise;
      } catch (_requestBodyError) {
        requestBody = void 0;
      }
      postNetwork({
        method: context.method,
        url: context.normalizedUrl,
        status: 0,
        duration: Date.now() - startedAt,
        requestHeaders: context.requestHeaders,
        requestBody: sanitizeCapturedBody(requestBody, context.requestContentType),
        responseBody: sanitizeCapturedBody(truncate(stringifyValue(error), MAX_BODY_LENGTH), "")
      });
    });
  };
  const installFetchCapture = (input) => {
    const { diagnostics, postNetwork, reporter } = input;
    const stringifyValue = createStringifyValue(reporter);
    const requestBodyByRequest = /* @__PURE__ */ new WeakMap();
    const bindFetch = (candidate) => {
      return candidate.bind(window);
    };
    installRequestConstructorCapture(reporter, stringifyValue, requestBodyByRequest);
    if (typeof window.fetch !== "function") {
      diagnostics.setFetchHookState("failed");
      return;
    }
    const baseFetch = bindFetch(window.fetch);
    let delegateFetch = baseFetch;
    let isInsidePatchedFetch = false;
    const patchedFetch = (async (...args) => {
      if (isInsidePatchedFetch) {
        return baseFetch(...args);
      }
      isInsidePatchedFetch = true;
      diagnostics.recordFetchCall();
      const startedAt = Date.now();
      const context = resolveFetchContext(args, reporter, stringifyValue, requestBodyByRequest);
      if (!context) {
        try {
          return delegateFetch(...args);
        } finally {
          isInsidePatchedFetch = false;
        }
      }
      try {
        const response = await delegateFetch(...args);
        const duration = Date.now() - startedAt;
        scheduleFetchSuccessPost(reporter, postNetwork, context, response, duration);
        return response;
      } catch (error) {
        diagnostics.recordFetchFailure(truncate(stringifyValue(error), 300));
        scheduleFetchFailurePost(reporter, postNetwork, context, error, startedAt, stringifyValue);
        throw error;
      } finally {
        isInsidePatchedFetch = false;
      }
    });
    try {
      Object.assign(patchedFetch, window.fetch);
    } catch (error) {
      reporter.reportNonFatalError("Failed to mirror fetch properties in debugger instrumentation", error);
    }
    const fetchDescriptor = Object.getOwnPropertyDescriptor(window, "fetch");
    const canRedefineFetch = !fetchDescriptor || fetchDescriptor.configurable;
    if (canRedefineFetch) {
      try {
        Object.defineProperty(window, "fetch", {
          configurable: true,
          enumerable: fetchDescriptor?.enumerable ?? true,
          get() {
            return patchedFetch;
          },
          set(nextFetch) {
            if (typeof nextFetch !== "function") {
              return;
            }
            if (nextFetch === patchedFetch) {
              return;
            }
            delegateFetch = bindFetch(nextFetch);
          }
        });
        diagnostics.setFetchHookState("accessor");
        return;
      } catch (error) {
        reporter.reportNonFatalError("Failed to install fetch accessor in debugger instrumentation", error);
      }
    }
    try {
      window.fetch = patchedFetch;
      diagnostics.setFetchHookState("assignment");
    } catch (error) {
      diagnostics.setFetchHookState("failed");
      reporter.reportNonFatalError("Failed to patch fetch in debugger instrumentation", error);
    }
  };
  const installXhrCapture = (input) => {
    const { diagnostics, postNetwork, reporter } = input;
    const stringifyValue = createStringifyValue(reporter);
    const xhrMetaMap = /* @__PURE__ */ new WeakMap();
    const buildXhrPostPayload = async (xhr) => {
      const state = xhrMetaMap.get(xhr);
      if (!state) {
        return null;
      }
      const normalizedUrl = toAbsoluteUrl(state.url, reporter);
      if (!normalizedUrl) {
        return null;
      }
      const redactedUrl = redactSensitiveQueryParams(normalizedUrl);
      let requestBody;
      let responseBody;
      const responseHeaders = parseRawHeaders(xhr.getAllResponseHeaders());
      const responseContentType = responseHeaders["content-type"] ?? "";
      try {
        requestBody = await state.requestBodyPromise;
      } catch (_requestBodyError) {
        requestBody = void 0;
      }
      try {
        if (xhr.responseType === "" || xhr.responseType === "text") {
          responseBody = truncate(xhr.responseText || "", MAX_BODY_LENGTH);
        } else if (xhr.responseType === "json") {
          responseBody = truncate(stringifyValue(xhr.response), MAX_BODY_LENGTH);
        }
      } catch (error) {
        reporter.reportNonFatalError("Failed to capture XHR response body in debugger instrumentation", error);
      }
      return {
        method: state.method,
        url: redactedUrl,
        status: xhr.status,
        duration: Date.now() - state.startedAt,
        requestHeaders: state.requestHeaders,
        responseHeaders,
        requestBody: sanitizeCapturedBody(requestBody, state.requestHeaders["content-type"] ?? ""),
        responseBody: sanitizeCapturedBody(responseBody, responseContentType)
      };
    };
    const postXhrLoadEndEvent = (xhr) => {
      scheduleBackgroundTask(reporter, async () => {
        const payload = await buildXhrPostPayload(xhr);
        if (!payload) {
          return;
        }
        postNetwork(payload);
      });
    };
    const originalOpen = XMLHttpRequest.prototype.open;
    const openWithOptionalArgs = originalOpen;
    XMLHttpRequest.prototype.open = function(method, url, async, username, password) {
      const normalizedMethod = typeof method === "string" ? method : "GET";
      const normalizedUrl = typeof url === "string" ? url : String(url ?? "");
      xhrMetaMap.set(this, {
        method: normalizedMethod,
        url: normalizedUrl,
        startedAt: Date.now(),
        requestBodyPromise: Promise.resolve(void 0),
        requestHeaders: {}
      });
      if (typeof async === "boolean" || typeof username === "string" || username === null || typeof password === "string" || password === null) {
        return openWithOptionalArgs.call(this, method, url, async ?? true, username, password);
      }
      return openWithOptionalArgs.call(this, method, url);
    };
    const originalSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
    XMLHttpRequest.prototype.setRequestHeader = function(...args) {
      const [key, value] = args;
      const meta = xhrMetaMap.get(this);
      if (meta) {
        const normalizedKey = key.trim().toLowerCase();
        if (!shouldHideHeader(normalizedKey)) {
          meta.requestHeaders[normalizedKey.slice(0, MAX_HEADER_NAME_LENGTH)] = value.slice(0, MAX_HEADER_VALUE_LENGTH);
        }
      }
      return originalSetRequestHeader.apply(this, args);
    };
    const originalSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function(...args) {
      diagnostics.recordXhrCall();
      const meta = xhrMetaMap.get(this);
      if (meta) {
        meta.startedAt = Date.now();
        meta.requestBodyPromise = getRequestBodyPreviewAsync(reporter, args[0], stringifyValue, meta.requestHeaders["content-type"] ?? "");
      }
      this.addEventListener("loadend", () => {
        postXhrLoadEndEvent(this);
      }, {
        once: true
      });
      return originalSend.apply(this, args);
    };
    diagnostics.setXhrHookInstalled();
  };
  function installNetworkCapture(input) {
    installFetchCapture(input);
    installXhrCapture(input);
  }
  function installDebuggerPageRuntime() {
    const scope = window;
    if (scope[INSTALL_FLAG]) {
      return;
    }
    scope[INSTALL_FLAG] = true;
    const diagnostics = createPageDiagnostics(window);
    const reporter = diagnostics.createReporter(createNonFatalReporter());
    const { enqueueEvent, flushEventQueue } = createEventQueue({
      recordQueuedEvent: diagnostics.recordQueuedEvent,
      recordFlushedBatch: diagnostics.recordFlushedBatch
    });
    const stringifyValue = createStringifyValue(reporter);
    const postAction = (actionType, target, metadata) => {
      diagnostics.recordActionEvent();
      enqueueEvent({
        kind: "action",
        timestamp: Date.now(),
        actionType,
        target,
        metadata
      });
    };
    const postConsole = (level, args) => {
      diagnostics.recordConsoleEvent();
      const serializedArgs = [];
      for (const arg of args) {
        serializedArgs.push(stringifyValue(arg));
      }
      enqueueEvent({
        kind: "console",
        timestamp: Date.now(),
        level,
        message: truncate(serializedArgs.join(" ")),
        metadata: {
          argumentCount: args.length
        }
      });
    };
    const postNetwork = (payload) => {
      diagnostics.recordNetworkEvent(payload.url);
      enqueueEvent({
        kind: "network",
        timestamp: Date.now(),
        ...payload
      });
    };
    installActionAndNavigationCapture({
      postAction
    });
    installConsoleCapture({
      reporter,
      postConsole
    });
    try {
      installNetworkCapture({
        diagnostics,
        reporter,
        postNetwork
      });
    } catch (error) {
      reporter.reportNonFatalError("Failed to install network capture in debugger runtime", error);
    }
    const flushOnPageHide = () => {
      flushEventQueue();
    };
    window.addEventListener("pagehide", flushOnPageHide, {
      capture: true
    });
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden") {
        flushEventQueue();
      }
    }, {
      capture: true,
      passive: true
    });
  }
  function defineUnlistedScript(arg) {
    if (arg == null || typeof arg === "function") return { main: arg };
    return arg;
  }
  const definition = defineUnlistedScript(() => {
    installDebuggerPageRuntime();
  });
  function initPlugins() {
  }
  function print(method, ...args) {
    if (typeof args[0] === "string") method(`[wxt] ${args.shift()}`, ...args);
    else method("[wxt]", ...args);
  }
  const logger = {
    debug: (...args) => print(console.debug, ...args),
    log: (...args) => print(console.log, ...args),
    warn: (...args) => print(console.warn, ...args),
    error: (...args) => print(console.error, ...args)
  };
  const result = (() => {
    try {
      initPlugins();
    } catch (err) {
      logger.error(`Failed to initialize plugins for "${"debugger-page"}"`, err);
      throw err;
    }
    let result2;
    try {
      result2 = definition.main();
      if (result2 instanceof Promise) result2 = result2.catch((err) => {
        logger.error(`The unlisted script "${"debugger-page"}" crashed on startup!`, err);
        throw err;
      });
    } catch (err) {
      logger.error(`The unlisted script "${"debugger-page"}" crashed on startup!`, err);
      throw err;
    }
    return result2;
  })();
  return result;
})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVidWdnZXItcGFnZS5qcyIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vcGFja2FnZXMvY2FwdHVyZS1jb3JlL2Rpc3QvZGVidWdnZXIvZW5naW5lL3BhZ2UvY29uc3RhbnRzLmpzIiwiLi4vLi4vLi4vLi4vcGFja2FnZXMvY2FwdHVyZS1jb3JlL2Rpc3QvZGVidWdnZXIvZW5naW5lL3BhZ2UvdXRpbHMuanMiLCIuLi8uLi8uLi8uLi9wYWNrYWdlcy9jYXB0dXJlLWNvcmUvZGlzdC9kZWJ1Z2dlci9lbmdpbmUvcGFnZS9hY3Rpb25zLmpzIiwiLi4vLi4vLi4vLi4vcGFja2FnZXMvY2FwdHVyZS1jb3JlL2Rpc3QvZGVidWdnZXIvZW5naW5lL3BhZ2UvY29uc29sZS5qcyIsIi4uLy4uLy4uLy4uL3BhY2thZ2VzL2NhcHR1cmUtY29yZS9kaXN0L2RlYnVnZ2VyL2VuZ2luZS9wYWdlL2RpYWdub3N0aWNzLmpzIiwiLi4vLi4vLi4vLi4vcGFja2FnZXMvY2FwdHVyZS1jb3JlL2Rpc3QvZGVidWdnZXIvZW5naW5lL3BhZ2UvZXZlbnQtcXVldWUuanMiLCIuLi8uLi8uLi8uLi9wYWNrYWdlcy9jYXB0dXJlLWNvcmUvZGlzdC9kZWJ1Z2dlci9lbmdpbmUvcGFnZS9zZXJpYWxpemVyLmpzIiwiLi4vLi4vLi4vLi4vcGFja2FnZXMvY2FwdHVyZS1jb3JlL2Rpc3QvZGVidWdnZXIvZW5naW5lL3BhZ2UvaGVhZGVycy5qcyIsIi4uLy4uLy4uLy4uL3BhY2thZ2VzL2NhcHR1cmUtY29yZS9kaXN0L2RlYnVnZ2VyL2VuZ2luZS9wYWdlL25ldHdvcmsvc2hhcmVkLmpzIiwiLi4vLi4vLi4vLi4vcGFja2FnZXMvY2FwdHVyZS1jb3JlL2Rpc3QvZGVidWdnZXIvZW5naW5lL3BhZ2UvbmV0d29yay9mZXRjaC9jb250ZXh0LmpzIiwiLi4vLi4vLi4vLi4vcGFja2FnZXMvY2FwdHVyZS1jb3JlL2Rpc3QvZGVidWdnZXIvZW5naW5lL3BhZ2UvbmV0d29yay9mZXRjaC9wb3N0LmpzIiwiLi4vLi4vLi4vLi4vcGFja2FnZXMvY2FwdHVyZS1jb3JlL2Rpc3QvZGVidWdnZXIvZW5naW5lL3BhZ2UvbmV0d29yay9mZXRjaC9pbnN0YWxsLmpzIiwiLi4vLi4vLi4vLi4vcGFja2FnZXMvY2FwdHVyZS1jb3JlL2Rpc3QvZGVidWdnZXIvZW5naW5lL3BhZ2UvbmV0d29yay94aHIuanMiLCIuLi8uLi8uLi8uLi9wYWNrYWdlcy9jYXB0dXJlLWNvcmUvZGlzdC9kZWJ1Z2dlci9lbmdpbmUvcGFnZS9uZXR3b3JrL2luZGV4LmpzIiwiLi4vLi4vLi4vLi4vcGFja2FnZXMvY2FwdHVyZS1jb3JlL2Rpc3QvZGVidWdnZXIvZW5naW5lL3BhZ2UvaW5kZXguanMiLCIuLi8uLi8uLi8uLi9ub2RlX21vZHVsZXMvLmJ1bi93eHRAMC4yMC4xNys3NDA2YWRlYjliZmNkNTUzL25vZGVfbW9kdWxlcy93eHQvZGlzdC91dGlscy9kZWZpbmUtdW5saXN0ZWQtc2NyaXB0Lm1qcyIsIi4uLy4uL2VudHJ5cG9pbnRzL2RlYnVnZ2VyLXBhZ2UudHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IFBBR0VfU09VUkNFID0gXCJDUklLS0VUX0RFQlVHR0VSX1BBR0VfQlJJREdFXCI7XG5leHBvcnQgY29uc3QgSU5TVEFMTF9GTEFHID0gXCJfX2NyaWtrZXREZWJ1Z2dlclBhZ2VTY3JpcHRJbnN0YWxsZWRcIjtcbmV4cG9ydCBjb25zdCBNQVhfVEVYVF9MRU5HVEggPSAyMDAwO1xuZXhwb3J0IGNvbnN0IE1BWF9CT0RZX0xFTkdUSCA9IDQwMDA7XG5leHBvcnQgY29uc3QgTUFYX0hFQURFUl9OQU1FX0xFTkdUSCA9IDEyMDtcbmV4cG9ydCBjb25zdCBNQVhfSEVBREVSX1ZBTFVFX0xFTkdUSCA9IDUwMDtcbmV4cG9ydCBjb25zdCBNQVhfQkFUQ0hfU0laRSA9IDQwO1xuZXhwb3J0IGNvbnN0IEZMVVNIX0lOVEVSVkFMX01TID0gMTIwO1xuZXhwb3J0IGNvbnN0IE1BWF9TRVJJQUxJWkVfREVQVEggPSA0O1xuZXhwb3J0IGNvbnN0IE1BWF9TRVJJQUxJWkVfS0VZUyA9IDMwO1xuZXhwb3J0IGNvbnN0IE1BWF9TRVJJQUxJWkVfQVJSQVlfSVRFTVMgPSAzMDtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNvbnN0YW50cy5qcy5tYXAiLCJpbXBvcnQgeyBNQVhfVEVYVF9MRU5HVEggfSBmcm9tIFwiLi9jb25zdGFudHNcIjtcbmNvbnN0IFJFREFDVEVEX1ZBTFVFID0gXCJbUkVEQUNURURdXCI7XG5jb25zdCBTRU5TSVRJVkVfTkFNRV9QQVRURVJOUyA9IFtcbiAgICBcImF1dGhvcml6YXRpb25cIixcbiAgICBcImNvb2tpZVwiLFxuICAgIFwic2V0LWNvb2tpZVwiLFxuICAgIFwidG9rZW5cIixcbiAgICBcInNlY3JldFwiLFxuICAgIFwicGFzc3dvcmRcIixcbiAgICBcInBhc3N3ZFwiLFxuICAgIFwicHdkXCIsXG4gICAgXCJzZXNzaW9uXCIsXG4gICAgXCJhcGkta2V5XCIsXG4gICAgXCJhcGlrZXlcIixcbiAgICBcIngtYXBpLWtleVwiLFxuICAgIFwicmVmcmVzaC10b2tlblwiLFxuICAgIFwicmVmcmVzaF90b2tlblwiLFxuICAgIFwiYWNjZXNzLXRva2VuXCIsXG4gICAgXCJhY2Nlc3NfdG9rZW5cIixcbiAgICBcImlkLXRva2VuXCIsXG4gICAgXCJpZF90b2tlblwiLFxuICAgIFwiY2xpZW50LXNlY3JldFwiLFxuICAgIFwiY2xpZW50X3NlY3JldFwiLFxuXTtcbmNvbnN0IFJFREFDVEFCTEVfRklFTERfUEFUVEVSTiA9IC8oKD86YWNjZXNzW18tXT90b2tlbnxyZWZyZXNoW18tXT90b2tlbnxpZFtfLV0/dG9rZW58YXBpW18tXT9rZXl8Y2xpZW50W18tXT9zZWNyZXR8cGFzc3dvcmR8cGFzc3dkfHB3ZHxhdXRob3JpemF0aW9ufGNvb2tpZXxzZXNzaW9uW18tXT9pZClcXHMqWzo9XVxccyopKFteJlxcc1wiLDtdKykvZ2k7XG5leHBvcnQgY29uc3QgdHJ1bmNhdGUgPSAodmFsdWUsIG1heExlbmd0aCA9IE1BWF9URVhUX0xFTkdUSCkgPT4ge1xuICAgIGlmICh2YWx1ZS5sZW5ndGggPD0gbWF4TGVuZ3RoKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGAke3ZhbHVlLnNsaWNlKDAsIG1heExlbmd0aCl9Li4uYDtcbn07XG5leHBvcnQgY29uc3QgaXNTZW5zaXRpdmVOYW1lID0gKHZhbHVlKSA9PiB7XG4gICAgY29uc3Qgbm9ybWFsaXplZFZhbHVlID0gdmFsdWUudHJpbSgpLnRvTG93ZXJDYXNlKCk7XG4gICAgaWYgKCFub3JtYWxpemVkVmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gU0VOU0lUSVZFX05BTUVfUEFUVEVSTlMuc29tZSgocGF0dGVybikgPT4ge1xuICAgICAgICByZXR1cm4gbm9ybWFsaXplZFZhbHVlLmluY2x1ZGVzKHBhdHRlcm4pO1xuICAgIH0pO1xufTtcbmV4cG9ydCBjb25zdCBzaG91bGRIaWRlSGVhZGVyID0gKGhlYWRlck5hbWUpID0+IHtcbiAgICByZXR1cm4gaGVhZGVyTmFtZS5pbmNsdWRlcyhcImRlYnVnZ2VyXCIpIHx8IGlzU2Vuc2l0aXZlTmFtZShoZWFkZXJOYW1lKTtcbn07XG5leHBvcnQgY29uc3QgZ2V0RWxlbWVudFRhcmdldCA9ICh0YXJnZXQpID0+IHtcbiAgICBpZiAoISh0YXJnZXQgaW5zdGFuY2VvZiBFbGVtZW50KSkge1xuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBpZiAodGFyZ2V0LmlkKSB7XG4gICAgICAgIHJldHVybiBgIyR7dGFyZ2V0LmlkfWA7XG4gICAgfVxuICAgIGNvbnN0IGNsYXNzTmFtZXMgPSB0eXBlb2YgdGFyZ2V0LmNsYXNzTmFtZSA9PT0gXCJzdHJpbmdcIiA/IHRhcmdldC5jbGFzc05hbWUgOiBcIlwiO1xuICAgIGNvbnN0IGZpcnN0Q2xhc3MgPSBjbGFzc05hbWVzXG4gICAgICAgIC5zcGxpdChcIiBcIilcbiAgICAgICAgLm1hcCgoZW50cnkpID0+IGVudHJ5LnRyaW0oKSlcbiAgICAgICAgLmZpbmQoKGVudHJ5KSA9PiBlbnRyeS5sZW5ndGggPiAwKTtcbiAgICBpZiAoZmlyc3RDbGFzcykge1xuICAgICAgICByZXR1cm4gYCR7dGFyZ2V0LnRhZ05hbWUudG9Mb3dlckNhc2UoKX0uJHtmaXJzdENsYXNzfWA7XG4gICAgfVxuICAgIHJldHVybiB0YXJnZXQudGFnTmFtZS50b0xvd2VyQ2FzZSgpO1xufTtcbmV4cG9ydCBjb25zdCB0b0Fic29sdXRlVXJsID0gKHZhbHVlLCByZXBvcnRlcikgPT4ge1xuICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBuZXcgVVJMKHZhbHVlLCBsb2NhdGlvbi5ocmVmKS50b1N0cmluZygpO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmVwb3J0ZXIucmVwb3J0Tm9uRmF0YWxFcnJvcihcIkZhaWxlZCB0byBub3JtYWxpemUgbmV0d29yayBVUkwgaW4gZGVidWdnZXIgaW5zdHJ1bWVudGF0aW9uXCIsIHtcbiAgICAgICAgICAgIGVycm9yLFxuICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG59O1xuZXhwb3J0IGNvbnN0IHJlZGFjdFNlbnNpdGl2ZVF1ZXJ5UGFyYW1zID0gKGFic29sdXRlVXJsKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcGFyc2VkVXJsID0gbmV3IFVSTChhYnNvbHV0ZVVybCk7XG4gICAgICAgIGZvciAoY29uc3QgW2tleV0gb2YgcGFyc2VkVXJsLnNlYXJjaFBhcmFtcy5lbnRyaWVzKCkpIHtcbiAgICAgICAgICAgIGlmICghaXNTZW5zaXRpdmVOYW1lKGtleSkpIHtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHBhcnNlZFVybC5zZWFyY2hQYXJhbXMuc2V0KGtleSwgUkVEQUNURURfVkFMVUUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBwYXJzZWRVcmwudG9TdHJpbmcoKTtcbiAgICB9XG4gICAgY2F0Y2gge1xuICAgICAgICByZXR1cm4gYWJzb2x1dGVVcmw7XG4gICAgfVxufTtcbmNvbnN0IHNhbml0aXplU3RydWN0dXJlZFZhbHVlID0gKHZhbHVlLCBkZXB0aCA9IDApID0+IHtcbiAgICBpZiAoZGVwdGggPj0gNikge1xuICAgICAgICByZXR1cm4gXCJbTWF4RGVwdGhdXCI7XG4gICAgfVxuICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgICByZXR1cm4gdmFsdWUubWFwKChpdGVtKSA9PiBzYW5pdGl6ZVN0cnVjdHVyZWRWYWx1ZShpdGVtLCBkZXB0aCArIDEpKTtcbiAgICB9XG4gICAgaWYgKHZhbHVlICYmIHR5cGVvZiB2YWx1ZSA9PT0gXCJvYmplY3RcIikge1xuICAgICAgICBjb25zdCByZXN1bHQgPSB7fTtcbiAgICAgICAgZm9yIChjb25zdCBba2V5LCBuZXN0ZWRWYWx1ZV0gb2YgT2JqZWN0LmVudHJpZXModmFsdWUpKSB7XG4gICAgICAgICAgICBpZiAoaXNTZW5zaXRpdmVOYW1lKGtleSkpIHtcbiAgICAgICAgICAgICAgICByZXN1bHRba2V5XSA9IFJFREFDVEVEX1ZBTFVFO1xuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmVzdWx0W2tleV0gPSBzYW5pdGl6ZVN0cnVjdHVyZWRWYWx1ZShuZXN0ZWRWYWx1ZSwgZGVwdGggKyAxKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZS5yZXBsYWNlKFJFREFDVEFCTEVfRklFTERfUEFUVEVSTiwgYCQxJHtSRURBQ1RFRF9WQUxVRX1gKTtcbiAgICB9XG4gICAgcmV0dXJuIHZhbHVlO1xufTtcbmNvbnN0IHNhbml0aXplVXJsRW5jb2RlZEJvZHkgPSAoYm9keSkgPT4ge1xuICAgIGNvbnN0IHBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoYm9keSk7XG4gICAgZm9yIChjb25zdCBba2V5XSBvZiBwYXJhbXMuZW50cmllcygpKSB7XG4gICAgICAgIGlmICghaXNTZW5zaXRpdmVOYW1lKGtleSkpIHtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIHBhcmFtcy5zZXQoa2V5LCBSRURBQ1RFRF9WQUxVRSk7XG4gICAgfVxuICAgIHJldHVybiBwYXJhbXMudG9TdHJpbmcoKTtcbn07XG5leHBvcnQgY29uc3Qgc2FuaXRpemVDYXB0dXJlZEJvZHkgPSAoYm9keSwgY29udGVudFR5cGUpID0+IHtcbiAgICBpZiAodHlwZW9mIGJvZHkgIT09IFwic3RyaW5nXCIgfHwgYm9keS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgcmV0dXJuIGJvZHk7XG4gICAgfVxuICAgIGNvbnN0IG5vcm1hbGl6ZWRDb250ZW50VHlwZSA9IGNvbnRlbnRUeXBlLnRvTG93ZXJDYXNlKCk7XG4gICAgaWYgKG5vcm1hbGl6ZWRDb250ZW50VHlwZS5pbmNsdWRlcyhcImFwcGxpY2F0aW9uL2pzb25cIikpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHBhcnNlZCA9IEpTT04ucGFyc2UoYm9keSk7XG4gICAgICAgICAgICByZXR1cm4gdHJ1bmNhdGUoSlNPTi5zdHJpbmdpZnkoc2FuaXRpemVTdHJ1Y3R1cmVkVmFsdWUocGFyc2VkKSksIE1BWF9URVhUX0xFTkdUSCAqIDIpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVuY2F0ZShib2R5LnJlcGxhY2UoUkVEQUNUQUJMRV9GSUVMRF9QQVRURVJOLCBgJDEke1JFREFDVEVEX1ZBTFVFfWApLCBNQVhfVEVYVF9MRU5HVEggKiAyKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAobm9ybWFsaXplZENvbnRlbnRUeXBlLmluY2x1ZGVzKFwieC13d3ctZm9ybS11cmxlbmNvZGVkXCIpKSB7XG4gICAgICAgIHJldHVybiB0cnVuY2F0ZShzYW5pdGl6ZVVybEVuY29kZWRCb2R5KGJvZHkpLCBNQVhfVEVYVF9MRU5HVEggKiAyKTtcbiAgICB9XG4gICAgcmV0dXJuIHRydW5jYXRlKGJvZHkucmVwbGFjZShSRURBQ1RBQkxFX0ZJRUxEX1BBVFRFUk4sIGAkMSR7UkVEQUNURURfVkFMVUV9YCksIE1BWF9URVhUX0xFTkdUSCAqIDIpO1xufTtcbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVOb25GYXRhbFJlcG9ydGVyKCkge1xuICAgIGNvbnN0IG9yaWdpbmFsQ29uc29sZVdhcm4gPSBjb25zb2xlLndhcm4uYmluZChjb25zb2xlKTtcbiAgICBjb25zdCByZXBvcnRlZENvbnRleHRzID0gbmV3IFNldCgpO1xuICAgIHJldHVybiB7XG4gICAgICAgIHJlcG9ydE5vbkZhdGFsRXJyb3IoY29udGV4dCwgZXJyb3IpIHtcbiAgICAgICAgICAgIGlmIChyZXBvcnRlZENvbnRleHRzLmhhcyhjb250ZXh0KSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJlcG9ydGVkQ29udGV4dHMuYWRkKGNvbnRleHQpO1xuICAgICAgICAgICAgb3JpZ2luYWxDb25zb2xlV2FybihgW05vbi1mYXRhbF0gJHtjb250ZXh0fWAsIGVycm9yKTtcbiAgICAgICAgfSxcbiAgICB9O1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXRpbHMuanMubWFwIiwiaW1wb3J0IHsgZ2V0RWxlbWVudFRhcmdldCB9IGZyb20gXCIuL3V0aWxzXCI7XG5leHBvcnQgZnVuY3Rpb24gaW5zdGFsbEFjdGlvbkFuZE5hdmlnYXRpb25DYXB0dXJlKGlucHV0KSB7XG4gICAgY29uc3QgeyBwb3N0QWN0aW9uIH0gPSBpbnB1dDtcbiAgICBjb25zdCBwb3N0TmF2aWdhdGlvbkJyZWFkY3J1bWIgPSAobW9kZSkgPT4ge1xuICAgICAgICBwb3N0QWN0aW9uKFwibmF2aWdhdGlvblwiLCBcIndpbmRvd1wiLCB7XG4gICAgICAgICAgICBtb2RlLFxuICAgICAgICAgICAgdXJsOiBsb2NhdGlvbi5ocmVmLFxuICAgICAgICAgICAgcGF0aDogbG9jYXRpb24ucGF0aG5hbWUsXG4gICAgICAgICAgICBzZWFyY2g6IGxvY2F0aW9uLnNlYXJjaCxcbiAgICAgICAgICAgIGhhc2g6IGxvY2F0aW9uLmhhc2gsXG4gICAgICAgICAgICB0aXRsZTogZG9jdW1lbnQudGl0bGUsXG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3QgZGVsZWdhdGVkSGFuZGxlcnMgPSB7XG4gICAgICAgIGNsaWNrOiAoZXZlbnQpID0+IHtcbiAgICAgICAgICAgIHBvc3RBY3Rpb24oXCJjbGlja1wiLCBnZXRFbGVtZW50VGFyZ2V0KGV2ZW50LnRhcmdldCkpO1xuICAgICAgICB9LFxuICAgICAgICBpbnB1dDogKGV2ZW50KSA9PiB7XG4gICAgICAgICAgICBjb25zdCB0YXJnZXQgPSBnZXRFbGVtZW50VGFyZ2V0KGV2ZW50LnRhcmdldCk7XG4gICAgICAgICAgICBsZXQgdmFsdWVMZW5ndGg7XG4gICAgICAgICAgICBjb25zdCBpbnB1dFRhcmdldCA9IGV2ZW50LnRhcmdldDtcbiAgICAgICAgICAgIGlmIChpbnB1dFRhcmdldCBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQgfHxcbiAgICAgICAgICAgICAgICBpbnB1dFRhcmdldCBpbnN0YW5jZW9mIEhUTUxUZXh0QXJlYUVsZW1lbnQpIHtcbiAgICAgICAgICAgICAgICB2YWx1ZUxlbmd0aCA9IGlucHV0VGFyZ2V0LnZhbHVlLmxlbmd0aDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHBvc3RBY3Rpb24oXCJpbnB1dFwiLCB0YXJnZXQsIHtcbiAgICAgICAgICAgICAgICB2YWx1ZUxlbmd0aCxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9LFxuICAgICAgICBjaGFuZ2U6IChldmVudCkgPT4ge1xuICAgICAgICAgICAgcG9zdEFjdGlvbihcImNoYW5nZVwiLCBnZXRFbGVtZW50VGFyZ2V0KGV2ZW50LnRhcmdldCkpO1xuICAgICAgICB9LFxuICAgIH07XG4gICAgY29uc3QgZGVsZWdhdGVkTGlzdGVuZXIgPSAoZXZlbnQpID0+IHtcbiAgICAgICAgaWYgKGV2ZW50LnR5cGUgIT09IFwiY2xpY2tcIiAmJlxuICAgICAgICAgICAgZXZlbnQudHlwZSAhPT0gXCJpbnB1dFwiICYmXG4gICAgICAgICAgICBldmVudC50eXBlICE9PSBcImNoYW5nZVwiKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgZGVsZWdhdGVkSGFuZGxlcnNbZXZlbnQudHlwZV0oZXZlbnQpO1xuICAgIH07XG4gICAgZm9yIChjb25zdCBldmVudFR5cGUgb2YgW1wiY2xpY2tcIiwgXCJpbnB1dFwiLCBcImNoYW5nZVwiXSkge1xuICAgICAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKGV2ZW50VHlwZSwgZGVsZWdhdGVkTGlzdGVuZXIsIHtcbiAgICAgICAgICAgIGNhcHR1cmU6IHRydWUsXG4gICAgICAgICAgICBwYXNzaXZlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgY29uc3Qgb3JpZ2luYWxQdXNoU3RhdGUgPSBoaXN0b3J5LnB1c2hTdGF0ZTtcbiAgICBoaXN0b3J5LnB1c2hTdGF0ZSA9IGZ1bmN0aW9uICguLi5hcmdzKSB7XG4gICAgICAgIG9yaWdpbmFsUHVzaFN0YXRlLmFwcGx5KHRoaXMsIGFyZ3MpO1xuICAgICAgICBwb3N0TmF2aWdhdGlvbkJyZWFkY3J1bWIoXCJwdXNoU3RhdGVcIik7XG4gICAgfTtcbiAgICBjb25zdCBvcmlnaW5hbFJlcGxhY2VTdGF0ZSA9IGhpc3RvcnkucmVwbGFjZVN0YXRlO1xuICAgIGhpc3RvcnkucmVwbGFjZVN0YXRlID0gZnVuY3Rpb24gKC4uLmFyZ3MpIHtcbiAgICAgICAgb3JpZ2luYWxSZXBsYWNlU3RhdGUuYXBwbHkodGhpcywgYXJncyk7XG4gICAgICAgIHBvc3ROYXZpZ2F0aW9uQnJlYWRjcnVtYihcInJlcGxhY2VTdGF0ZVwiKTtcbiAgICB9O1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicG9wc3RhdGVcIiwgKCkgPT4ge1xuICAgICAgICBwb3N0TmF2aWdhdGlvbkJyZWFkY3J1bWIoXCJwb3BzdGF0ZVwiKTtcbiAgICB9LCB7XG4gICAgICAgIGNhcHR1cmU6IHRydWUsXG4gICAgICAgIHBhc3NpdmU6IHRydWUsXG4gICAgfSk7XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJoYXNoY2hhbmdlXCIsICgpID0+IHtcbiAgICAgICAgcG9zdE5hdmlnYXRpb25CcmVhZGNydW1iKFwiaGFzaGNoYW5nZVwiKTtcbiAgICB9LCB7XG4gICAgICAgIGNhcHR1cmU6IHRydWUsXG4gICAgICAgIHBhc3NpdmU6IHRydWUsXG4gICAgfSk7XG4gICAgcG9zdE5hdmlnYXRpb25CcmVhZGNydW1iKFwiaW5pdGlhbFwiKTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFjdGlvbnMuanMubWFwIiwiZXhwb3J0IGZ1bmN0aW9uIGluc3RhbGxDb25zb2xlQ2FwdHVyZShpbnB1dCkge1xuICAgIGNvbnN0IHsgcmVwb3J0ZXIsIHBvc3RDb25zb2xlIH0gPSBpbnB1dDtcbiAgICBjb25zdCBjb25zb2xlTGV2ZWxzID0gW1xuICAgICAgICBcImxvZ1wiLFxuICAgICAgICBcImluZm9cIixcbiAgICAgICAgXCJ3YXJuXCIsXG4gICAgICAgIFwiZXJyb3JcIixcbiAgICAgICAgXCJkZWJ1Z1wiLFxuICAgIF07XG4gICAgZm9yIChjb25zdCBsZXZlbCBvZiBjb25zb2xlTGV2ZWxzKSB7XG4gICAgICAgIGNvbnN0IG9yaWdpbmFsID0gY29uc29sZVtsZXZlbF0uYmluZChjb25zb2xlKTtcbiAgICAgICAgY29uc29sZVtsZXZlbF0gPSAoLi4uYXJncykgPT4ge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBwb3N0Q29uc29sZShsZXZlbCwgYXJncyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICByZXBvcnRlci5yZXBvcnROb25GYXRhbEVycm9yKFwiRmFpbGVkIHRvIHBvc3QgY29uc29sZSBldmVudCBpbiBkZWJ1Z2dlciBpbnN0cnVtZW50YXRpb25cIiwgZXJyb3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgb3JpZ2luYWwoLi4uYXJncyk7XG4gICAgICAgIH07XG4gICAgfVxufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y29uc29sZS5qcy5tYXAiLCJpbXBvcnQgeyB0cnVuY2F0ZSB9IGZyb20gXCIuL3V0aWxzXCI7XG5jb25zdCBESUFHTk9TVElDU19LRVkgPSBcIl9fY3Jpa2tldERlYnVnZ2VyRGlhZ25vc3RpY3NcIjtcbmNvbnN0IERJQUdOT1NUSUNTX1ZFUlNJT04gPSAxO1xuY29uc3QgTUFYX0VSUk9SX0VOVFJJRVMgPSAyNTtcbmNvbnN0IE1BWF9FUlJPUl9MRU5HVEggPSAzMDA7XG5jb25zdCBjcmVhdGVEZWZhdWx0RGlhZ25vc3RpY3NTdGF0ZSA9ICgpID0+IHtcbiAgICByZXR1cm4ge1xuICAgICAgICB2ZXJzaW9uOiBESUFHTk9TVElDU19WRVJTSU9OLFxuICAgICAgICBpbnN0YWxsZWRBdDogRGF0ZS5ub3coKSxcbiAgICAgICAgdXJsOiBsb2NhdGlvbi5ocmVmLFxuICAgICAgICBob29rczoge1xuICAgICAgICAgICAgZmV0Y2g6IFwicGVuZGluZ1wiLFxuICAgICAgICAgICAgeGhyOiBmYWxzZSxcbiAgICAgICAgfSxcbiAgICAgICAgY291bnRlcnM6IHtcbiAgICAgICAgICAgIGFjdGlvbkV2ZW50czogMCxcbiAgICAgICAgICAgIGNvbnNvbGVFdmVudHM6IDAsXG4gICAgICAgICAgICBuZXR3b3JrRXZlbnRzOiAwLFxuICAgICAgICAgICAgZmV0Y2hDYWxsczogMCxcbiAgICAgICAgICAgIGZldGNoRmFpbHVyZXM6IDAsXG4gICAgICAgICAgICB4aHJDYWxsczogMCxcbiAgICAgICAgICAgIHF1ZXVlZEV2ZW50czogMCxcbiAgICAgICAgICAgIGZsdXNoZWRCYXRjaGVzOiAwLFxuICAgICAgICB9LFxuICAgICAgICBsYXN0OiB7fSxcbiAgICAgICAgZXJyb3JzOiBbXSxcbiAgICB9O1xufTtcbmNvbnN0IHRvRXJyb3JNZXNzYWdlID0gKGNvbnRleHQsIGVycm9yKSA9PiB7XG4gICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIGAke2NvbnRleHR9OiAke2Vycm9yLm1lc3NhZ2V9YDtcbiAgICB9XG4gICAgcmV0dXJuIGAke2NvbnRleHR9OiAke1N0cmluZyhlcnJvcil9YDtcbn07XG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlUGFnZURpYWdub3N0aWNzKHNjb3BlKSB7XG4gICAgY29uc3QgcnVudGltZVNjb3BlID0gc2NvcGU7XG4gICAgY29uc3Qgc3RhdGUgPSBydW50aW1lU2NvcGVbRElBR05PU1RJQ1NfS0VZXSA/PyBjcmVhdGVEZWZhdWx0RGlhZ25vc3RpY3NTdGF0ZSgpO1xuICAgIHJ1bnRpbWVTY29wZVtESUFHTk9TVElDU19LRVldID0gc3RhdGU7XG4gICAgc3RhdGUuaW5zdGFsbGVkQXQgPSBEYXRlLm5vdygpO1xuICAgIHN0YXRlLnVybCA9IGxvY2F0aW9uLmhyZWY7XG4gICAgc3RhdGUuaG9va3MuZmV0Y2ggPSBcInBlbmRpbmdcIjtcbiAgICBzdGF0ZS5ob29rcy54aHIgPSBmYWxzZTtcbiAgICByZXR1cm4ge1xuICAgICAgICBzdGF0ZSxcbiAgICAgICAgY3JlYXRlUmVwb3J0ZXIocmVwb3J0ZXIpIHtcbiAgICAgICAgICAgIGNvbnN0IG9yaWdpbmFsUmVwb3J0ID0gcmVwb3J0ZXIucmVwb3J0Tm9uRmF0YWxFcnJvci5iaW5kKHJlcG9ydGVyKTtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgcmVwb3J0Tm9uRmF0YWxFcnJvcihjb250ZXh0LCBlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICBzdGF0ZS5lcnJvcnMucHVzaCh0cnVuY2F0ZSh0b0Vycm9yTWVzc2FnZShjb250ZXh0LCBlcnJvciksIE1BWF9FUlJPUl9MRU5HVEgpKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHN0YXRlLmVycm9ycy5sZW5ndGggPiBNQVhfRVJST1JfRU5UUklFUykge1xuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGUuZXJyb3JzLnNoaWZ0KCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgb3JpZ2luYWxSZXBvcnQoY29udGV4dCwgZXJyb3IpO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9O1xuICAgICAgICB9LFxuICAgICAgICByZWNvcmRBY3Rpb25FdmVudCgpIHtcbiAgICAgICAgICAgIHN0YXRlLmNvdW50ZXJzLmFjdGlvbkV2ZW50cyArPSAxO1xuICAgICAgICB9LFxuICAgICAgICByZWNvcmRDb25zb2xlRXZlbnQoKSB7XG4gICAgICAgICAgICBzdGF0ZS5jb3VudGVycy5jb25zb2xlRXZlbnRzICs9IDE7XG4gICAgICAgIH0sXG4gICAgICAgIHJlY29yZE5ldHdvcmtFdmVudCh1cmwpIHtcbiAgICAgICAgICAgIHN0YXRlLmNvdW50ZXJzLm5ldHdvcmtFdmVudHMgKz0gMTtcbiAgICAgICAgICAgIHN0YXRlLmxhc3QubmV0d29ya1VybCA9IHVybDtcbiAgICAgICAgfSxcbiAgICAgICAgcmVjb3JkRmV0Y2hDYWxsKCkge1xuICAgICAgICAgICAgc3RhdGUuY291bnRlcnMuZmV0Y2hDYWxscyArPSAxO1xuICAgICAgICB9LFxuICAgICAgICByZWNvcmRGZXRjaEZhaWx1cmUobWVzc2FnZSkge1xuICAgICAgICAgICAgc3RhdGUuY291bnRlcnMuZmV0Y2hGYWlsdXJlcyArPSAxO1xuICAgICAgICAgICAgc3RhdGUubGFzdC5mZXRjaEVycm9yID0gbWVzc2FnZTtcbiAgICAgICAgfSxcbiAgICAgICAgc2V0RmV0Y2hIb29rU3RhdGUobmV4dFN0YXRlKSB7XG4gICAgICAgICAgICBzdGF0ZS5ob29rcy5mZXRjaCA9IG5leHRTdGF0ZTtcbiAgICAgICAgfSxcbiAgICAgICAgcmVjb3JkWGhyQ2FsbCgpIHtcbiAgICAgICAgICAgIHN0YXRlLmNvdW50ZXJzLnhockNhbGxzICs9IDE7XG4gICAgICAgIH0sXG4gICAgICAgIHNldFhockhvb2tJbnN0YWxsZWQoKSB7XG4gICAgICAgICAgICBzdGF0ZS5ob29rcy54aHIgPSB0cnVlO1xuICAgICAgICB9LFxuICAgICAgICByZWNvcmRRdWV1ZWRFdmVudCgpIHtcbiAgICAgICAgICAgIHN0YXRlLmNvdW50ZXJzLnF1ZXVlZEV2ZW50cyArPSAxO1xuICAgICAgICB9LFxuICAgICAgICByZWNvcmRGbHVzaGVkQmF0Y2goKSB7XG4gICAgICAgICAgICBzdGF0ZS5jb3VudGVycy5mbHVzaGVkQmF0Y2hlcyArPSAxO1xuICAgICAgICB9LFxuICAgIH07XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1kaWFnbm9zdGljcy5qcy5tYXAiLCJpbXBvcnQgeyBGTFVTSF9JTlRFUlZBTF9NUywgTUFYX0JBVENIX1NJWkUsIFBBR0VfU09VUkNFIH0gZnJvbSBcIi4vY29uc3RhbnRzXCI7XG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlRXZlbnRRdWV1ZShpbnB1dCA9IHt9KSB7XG4gICAgY29uc3QgeyByZWNvcmRGbHVzaGVkQmF0Y2gsIHJlY29yZFF1ZXVlZEV2ZW50IH0gPSBpbnB1dDtcbiAgICBjb25zdCBldmVudFF1ZXVlID0gW107XG4gICAgbGV0IGZsdXNoVGltZXIgPSBudWxsO1xuICAgIGNvbnN0IGZsdXNoRXZlbnRRdWV1ZSA9ICgpID0+IHtcbiAgICAgICAgZmx1c2hUaW1lciA9IG51bGw7XG4gICAgICAgIGlmIChldmVudFF1ZXVlLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGJhdGNoZWRFdmVudHMgPSBldmVudFF1ZXVlLnNwbGljZSgwLCBNQVhfQkFUQ0hfU0laRSk7XG4gICAgICAgIHJlY29yZEZsdXNoZWRCYXRjaD8uKCk7XG4gICAgICAgIHdpbmRvdy5wb3N0TWVzc2FnZSh7XG4gICAgICAgICAgICBzb3VyY2U6IFBBR0VfU09VUkNFLFxuICAgICAgICAgICAgZXZlbnRzOiBiYXRjaGVkRXZlbnRzLFxuICAgICAgICB9LCBcIipcIik7XG4gICAgICAgIGlmIChldmVudFF1ZXVlLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIGZsdXNoVGltZXIgPSBzZXRUaW1lb3V0KGZsdXNoRXZlbnRRdWV1ZSwgMCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHNjaGVkdWxlRXZlbnRGbHVzaCA9ICgpID0+IHtcbiAgICAgICAgaWYgKGZsdXNoVGltZXIpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBmbHVzaFRpbWVyID0gc2V0VGltZW91dChmbHVzaEV2ZW50UXVldWUsIEZMVVNIX0lOVEVSVkFMX01TKTtcbiAgICB9O1xuICAgIGNvbnN0IGVucXVldWVFdmVudCA9IChldmVudCkgPT4ge1xuICAgICAgICBldmVudFF1ZXVlLnB1c2goZXZlbnQpO1xuICAgICAgICByZWNvcmRRdWV1ZWRFdmVudD8uKCk7XG4gICAgICAgIGlmIChldmVudFF1ZXVlLmxlbmd0aCA+PSBNQVhfQkFUQ0hfU0laRSkge1xuICAgICAgICAgICAgaWYgKGZsdXNoVGltZXIpIHtcbiAgICAgICAgICAgICAgICBjbGVhclRpbWVvdXQoZmx1c2hUaW1lcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmbHVzaFRpbWVyID0gc2V0VGltZW91dChmbHVzaEV2ZW50UXVldWUsIDApO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHNjaGVkdWxlRXZlbnRGbHVzaCgpO1xuICAgIH07XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZW5xdWV1ZUV2ZW50LFxuICAgICAgICBmbHVzaEV2ZW50UXVldWUsXG4gICAgfTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWV2ZW50LXF1ZXVlLmpzLm1hcCIsImltcG9ydCB7IE1BWF9CT0RZX0xFTkdUSCwgTUFYX1NFUklBTElaRV9BUlJBWV9JVEVNUywgTUFYX1NFUklBTElaRV9ERVBUSCwgTUFYX1NFUklBTElaRV9LRVlTLCB9IGZyb20gXCIuL2NvbnN0YW50c1wiO1xuaW1wb3J0IHsgZ2V0RWxlbWVudFRhcmdldCwgdHJ1bmNhdGUgfSBmcm9tIFwiLi91dGlsc1wiO1xuY29uc3Qgc2VyaWFsaXplUHJpbWl0aXZlID0gKHZhbHVlKSA9PiB7XG4gICAgaWYgKHZhbHVlID09PSBudWxsIHx8XG4gICAgICAgIHR5cGVvZiB2YWx1ZSA9PT0gXCJib29sZWFuXCIgfHxcbiAgICAgICAgdHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBoYW5kbGVkOiB0cnVlLFxuICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgIH07XG4gICAgfVxuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGhhbmRsZWQ6IHRydWUsXG4gICAgICAgICAgICB2YWx1ZTogdHJ1bmNhdGUodmFsdWUpLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBoYW5kbGVkOiB0cnVlLFxuICAgICAgICAgICAgdmFsdWU6IFwiW3VuZGVmaW5lZF1cIixcbiAgICAgICAgfTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJiaWdpbnRcIikge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgaGFuZGxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHZhbHVlOiBgJHt2YWx1ZS50b1N0cmluZygpfW5gLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSBcInN5bWJvbFwiKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBoYW5kbGVkOiB0cnVlLFxuICAgICAgICAgICAgdmFsdWU6IHZhbHVlLnRvU3RyaW5nKCksXG4gICAgICAgIH07XG4gICAgfVxuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgaGFuZGxlZDogdHJ1ZSxcbiAgICAgICAgICAgIHZhbHVlOiBgW0Z1bmN0aW9uICR7dmFsdWUubmFtZSB8fCBcImFub255bW91c1wifV1gLFxuICAgICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBoYW5kbGVkOiBmYWxzZSxcbiAgICB9O1xufTtcbmNvbnN0IHNlcmlhbGl6ZUVycm9yID0gKHZhbHVlKSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgbmFtZTogdmFsdWUubmFtZSxcbiAgICAgICAgbWVzc2FnZTogdHJ1bmNhdGUodmFsdWUubWVzc2FnZSksXG4gICAgICAgIHN0YWNrOiB0eXBlb2YgdmFsdWUuc3RhY2sgPT09IFwic3RyaW5nXCIgPyB0cnVuY2F0ZSh2YWx1ZS5zdGFjaykgOiB1bmRlZmluZWQsXG4gICAgfTtcbn07XG5jb25zdCBpc0FycmF5QnVmZmVyVmFsdWUgPSAodmFsdWUpID0+IHtcbiAgICByZXR1cm4gdHlwZW9mIEFycmF5QnVmZmVyICE9PSBcInVuZGVmaW5lZFwiICYmIHZhbHVlIGluc3RhbmNlb2YgQXJyYXlCdWZmZXI7XG59O1xuY29uc3QgaXNBcnJheUJ1ZmZlclZpZXdWYWx1ZSA9ICh2YWx1ZSkgPT4ge1xuICAgIHJldHVybiB0eXBlb2YgQXJyYXlCdWZmZXIgIT09IFwidW5kZWZpbmVkXCIgJiYgQXJyYXlCdWZmZXIuaXNWaWV3KHZhbHVlKTtcbn07XG5jb25zdCBzZXJpYWxpemVBcnJheSA9ICh2YWx1ZSwgc3RhdGUsIGRlcHRoLCBwYXRoLCBzZXJpYWxpemVWYWx1ZSkgPT4ge1xuICAgIGNvbnN0IHNlcmlhbGl6ZWQgPSBbXTtcbiAgICBjb25zdCBsaW1pdCA9IE1hdGgubWluKHZhbHVlLmxlbmd0aCwgTUFYX1NFUklBTElaRV9BUlJBWV9JVEVNUyk7XG4gICAgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IGxpbWl0OyBpbmRleCArPSAxKSB7XG4gICAgICAgIHNlcmlhbGl6ZWQucHVzaChzZXJpYWxpemVWYWx1ZSh2YWx1ZVtpbmRleF0sIHN0YXRlLCBkZXB0aCArIDEsIGAke3BhdGh9WyR7aW5kZXh9XWApKTtcbiAgICB9XG4gICAgaWYgKHZhbHVlLmxlbmd0aCA+IGxpbWl0KSB7XG4gICAgICAgIHNlcmlhbGl6ZWQucHVzaChgWyske3ZhbHVlLmxlbmd0aCAtIGxpbWl0fSBtb3JlXWApO1xuICAgIH1cbiAgICByZXR1cm4gc2VyaWFsaXplZDtcbn07XG5jb25zdCBzZXJpYWxpemVNYXAgPSAodmFsdWUsIHN0YXRlLCBkZXB0aCwgcGF0aCwgc2VyaWFsaXplVmFsdWUpID0+IHtcbiAgICBjb25zdCBlbnRyaWVzID0gW107XG4gICAgbGV0IGluZGV4ID0gMDtcbiAgICBmb3IgKGNvbnN0IFtlbnRyeUtleSwgZW50cnlWYWx1ZV0gb2YgdmFsdWUuZW50cmllcygpKSB7XG4gICAgICAgIGlmIChpbmRleCA+PSBNQVhfU0VSSUFMSVpFX0tFWVMpIHtcbiAgICAgICAgICAgIGVudHJpZXMucHVzaChgWyske3ZhbHVlLnNpemUgLSBpbmRleH0gbW9yZV1gKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGVudHJpZXMucHVzaChbXG4gICAgICAgICAgICBzZXJpYWxpemVWYWx1ZShlbnRyeUtleSwgc3RhdGUsIGRlcHRoICsgMSwgYCR7cGF0aH0ubWFwS2V5JHtpbmRleH1gKSxcbiAgICAgICAgICAgIHNlcmlhbGl6ZVZhbHVlKGVudHJ5VmFsdWUsIHN0YXRlLCBkZXB0aCArIDEsIGAke3BhdGh9Lm1hcFZhbCR7aW5kZXh9YCksXG4gICAgICAgIF0pO1xuICAgICAgICBpbmRleCArPSAxO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICB0eXBlOiBcIk1hcFwiLFxuICAgICAgICBlbnRyaWVzLFxuICAgIH07XG59O1xuY29uc3Qgc2VyaWFsaXplU2V0ID0gKHZhbHVlLCBzdGF0ZSwgZGVwdGgsIHBhdGgsIHNlcmlhbGl6ZVZhbHVlKSA9PiB7XG4gICAgY29uc3QgZW50cmllcyA9IFtdO1xuICAgIGxldCBpbmRleCA9IDA7XG4gICAgZm9yIChjb25zdCBlbnRyeSBvZiB2YWx1ZS52YWx1ZXMoKSkge1xuICAgICAgICBpZiAoaW5kZXggPj0gTUFYX1NFUklBTElaRV9LRVlTKSB7XG4gICAgICAgICAgICBlbnRyaWVzLnB1c2goYFsrJHt2YWx1ZS5zaXplIC0gaW5kZXh9IG1vcmVdYCk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBlbnRyaWVzLnB1c2goc2VyaWFsaXplVmFsdWUoZW50cnksIHN0YXRlLCBkZXB0aCArIDEsIGAke3BhdGh9LnNldFZhbCR7aW5kZXh9YCkpO1xuICAgICAgICBpbmRleCArPSAxO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICB0eXBlOiBcIlNldFwiLFxuICAgICAgICB2YWx1ZXM6IGVudHJpZXMsXG4gICAgfTtcbn07XG5jb25zdCBzZXJpYWxpemVSZWNvcmRPYmplY3QgPSAodmFsdWUsIHN0YXRlLCBkZXB0aCwgcGF0aCwgc2VyaWFsaXplVmFsdWUpID0+IHtcbiAgICBjb25zdCByZXN1bHQgPSB7fTtcbiAgICBjb25zdCBlbnRyaWVzID0gT2JqZWN0LmVudHJpZXModmFsdWUpO1xuICAgIGNvbnN0IGxpbWl0ID0gTWF0aC5taW4oZW50cmllcy5sZW5ndGgsIE1BWF9TRVJJQUxJWkVfS0VZUyk7XG4gICAgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IGxpbWl0OyBpbmRleCArPSAxKSB7XG4gICAgICAgIGNvbnN0IFtlbnRyeUtleSwgZW50cnlWYWx1ZV0gPSBlbnRyaWVzW2luZGV4XSA/PyBbXTtcbiAgICAgICAgaWYgKHR5cGVvZiBlbnRyeUtleSAhPT0gXCJzdHJpbmdcIikge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgcmVzdWx0W2VudHJ5S2V5XSA9IHNlcmlhbGl6ZVZhbHVlKGVudHJ5VmFsdWUsIHN0YXRlLCBkZXB0aCArIDEsIGAke3BhdGh9LiR7ZW50cnlLZXl9YCk7XG4gICAgfVxuICAgIGlmIChlbnRyaWVzLmxlbmd0aCA+IGxpbWl0KSB7XG4gICAgICAgIHJlc3VsdC5fX3RydW5jYXRlZEtleXMgPSBlbnRyaWVzLmxlbmd0aCAtIGxpbWl0O1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufTtcbmNvbnN0IG9iamVjdFNlcmlhbGl6ZXJzID0gW1xuICAgIHtcbiAgICAgICAgY2FuSGFuZGxlOiAodmFsdWUpID0+IHZhbHVlIGluc3RhbmNlb2YgRXJyb3IsXG4gICAgICAgIHNlcmlhbGl6ZTogKHZhbHVlKSA9PiBzZXJpYWxpemVFcnJvcih2YWx1ZSksXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGNhbkhhbmRsZTogKHZhbHVlKSA9PiB2YWx1ZSBpbnN0YW5jZW9mIERhdGUsXG4gICAgICAgIHNlcmlhbGl6ZTogKHZhbHVlKSA9PiB2YWx1ZS50b0lTT1N0cmluZygpLFxuICAgIH0sXG4gICAge1xuICAgICAgICBjYW5IYW5kbGU6ICh2YWx1ZSkgPT4gdmFsdWUgaW5zdGFuY2VvZiBSZWdFeHAsXG4gICAgICAgIHNlcmlhbGl6ZTogKHZhbHVlKSA9PiB2YWx1ZS50b1N0cmluZygpLFxuICAgIH0sXG4gICAge1xuICAgICAgICBjYW5IYW5kbGU6ICh2YWx1ZSkgPT4gdHlwZW9mIFVSTCAhPT0gXCJ1bmRlZmluZWRcIiAmJiB2YWx1ZSBpbnN0YW5jZW9mIFVSTCxcbiAgICAgICAgc2VyaWFsaXplOiAodmFsdWUpID0+IHZhbHVlLnRvU3RyaW5nKCksXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGNhbkhhbmRsZTogKHZhbHVlKSA9PiB0eXBlb2YgRWxlbWVudCAhPT0gXCJ1bmRlZmluZWRcIiAmJiB2YWx1ZSBpbnN0YW5jZW9mIEVsZW1lbnQsXG4gICAgICAgIHNlcmlhbGl6ZTogKHZhbHVlKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBlbGVtZW50ID0gdmFsdWU7XG4gICAgICAgICAgICByZXR1cm4gZ2V0RWxlbWVudFRhcmdldChlbGVtZW50KSA/PyBlbGVtZW50LnRhZ05hbWUudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgfSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgY2FuSGFuZGxlOiAodmFsdWUpID0+IHR5cGVvZiBFdmVudCAhPT0gXCJ1bmRlZmluZWRcIiAmJiB2YWx1ZSBpbnN0YW5jZW9mIEV2ZW50LFxuICAgICAgICBzZXJpYWxpemU6ICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgZXZlbnQgPSB2YWx1ZTtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgdHlwZTogZXZlbnQudHlwZSxcbiAgICAgICAgICAgICAgICB0YXJnZXQ6IGdldEVsZW1lbnRUYXJnZXQoZXZlbnQudGFyZ2V0KSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH0sXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGNhbkhhbmRsZTogKHZhbHVlKSA9PiBBcnJheS5pc0FycmF5KHZhbHVlKSxcbiAgICAgICAgc2VyaWFsaXplOiAodmFsdWUsIHN0YXRlLCBkZXB0aCwgcGF0aCwgc2VyaWFsaXplVmFsdWUpID0+IHNlcmlhbGl6ZUFycmF5KHZhbHVlLCBzdGF0ZSwgZGVwdGgsIHBhdGgsIHNlcmlhbGl6ZVZhbHVlKSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgY2FuSGFuZGxlOiAodmFsdWUpID0+IHZhbHVlIGluc3RhbmNlb2YgTWFwLFxuICAgICAgICBzZXJpYWxpemU6ICh2YWx1ZSwgc3RhdGUsIGRlcHRoLCBwYXRoLCBzZXJpYWxpemVWYWx1ZSkgPT4gc2VyaWFsaXplTWFwKHZhbHVlLCBzdGF0ZSwgZGVwdGgsIHBhdGgsIHNlcmlhbGl6ZVZhbHVlKSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgY2FuSGFuZGxlOiAodmFsdWUpID0+IHZhbHVlIGluc3RhbmNlb2YgU2V0LFxuICAgICAgICBzZXJpYWxpemU6ICh2YWx1ZSwgc3RhdGUsIGRlcHRoLCBwYXRoLCBzZXJpYWxpemVWYWx1ZSkgPT4gc2VyaWFsaXplU2V0KHZhbHVlLCBzdGF0ZSwgZGVwdGgsIHBhdGgsIHNlcmlhbGl6ZVZhbHVlKSxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgY2FuSGFuZGxlOiAodmFsdWUpID0+IGlzQXJyYXlCdWZmZXJWYWx1ZSh2YWx1ZSksXG4gICAgICAgIHNlcmlhbGl6ZTogKHZhbHVlKSA9PiBgW0FycmF5QnVmZmVyICR7dmFsdWUuYnl0ZUxlbmd0aH1dYCxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgY2FuSGFuZGxlOiAodmFsdWUpID0+IGlzQXJyYXlCdWZmZXJWaWV3VmFsdWUodmFsdWUpLFxuICAgICAgICBzZXJpYWxpemU6ICh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgYnVmZmVyVmlldyA9IHZhbHVlO1xuICAgICAgICAgICAgcmV0dXJuIGBbJHtidWZmZXJWaWV3LmNvbnN0cnVjdG9yLm5hbWV9ICR7YnVmZmVyVmlldy5ieXRlTGVuZ3RofV1gO1xuICAgICAgICB9LFxuICAgIH0sXG5dO1xuY29uc3Qgc2VyaWFsaXplS25vd25PYmplY3QgPSAodmFsdWUsIHN0YXRlLCBkZXB0aCwgcGF0aCwgc2VyaWFsaXplVmFsdWUpID0+IHtcbiAgICBmb3IgKGNvbnN0IHNlcmlhbGl6ZXIgb2Ygb2JqZWN0U2VyaWFsaXplcnMpIHtcbiAgICAgICAgaWYgKCFzZXJpYWxpemVyLmNhbkhhbmRsZSh2YWx1ZSkpIHtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzZXJpYWxpemVyLnNlcmlhbGl6ZSh2YWx1ZSwgc3RhdGUsIGRlcHRoLCBwYXRoLCBzZXJpYWxpemVWYWx1ZSk7XG4gICAgfVxuICAgIHJldHVybiBzZXJpYWxpemVSZWNvcmRPYmplY3QodmFsdWUsIHN0YXRlLCBkZXB0aCwgcGF0aCwgc2VyaWFsaXplVmFsdWUpO1xufTtcbmNvbnN0IHRvU2VyaWFsaXphYmxlVmFsdWUgPSAodmFsdWUsIHN0YXRlLCBkZXB0aCwgcGF0aCkgPT4ge1xuICAgIGNvbnN0IHByaW1pdGl2ZSA9IHNlcmlhbGl6ZVByaW1pdGl2ZSh2YWx1ZSk7XG4gICAgaWYgKHByaW1pdGl2ZS5oYW5kbGVkKSB7XG4gICAgICAgIHJldHVybiBwcmltaXRpdmUudmFsdWU7XG4gICAgfVxuICAgIGlmIChkZXB0aCA+PSBNQVhfU0VSSUFMSVpFX0RFUFRIKSB7XG4gICAgICAgIHJldHVybiBcIltNYXhEZXB0aF1cIjtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gXCJvYmplY3RcIiB8fCB2YWx1ZSA9PT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHZhbHVlKTtcbiAgICB9XG4gICAgY29uc3QgZXhpc3RpbmdQYXRoID0gc3RhdGUuc2Vlbi5nZXQodmFsdWUpO1xuICAgIGlmIChleGlzdGluZ1BhdGgpIHtcbiAgICAgICAgcmV0dXJuIGBbQ2lyY3VsYXIgfiR7ZXhpc3RpbmdQYXRofV1gO1xuICAgIH1cbiAgICBzdGF0ZS5zZWVuLnNldCh2YWx1ZSwgcGF0aCk7XG4gICAgcmV0dXJuIHNlcmlhbGl6ZUtub3duT2JqZWN0KHZhbHVlLCBzdGF0ZSwgZGVwdGgsIHBhdGgsIHRvU2VyaWFsaXphYmxlVmFsdWUpO1xufTtcbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVTdHJpbmdpZnlWYWx1ZShyZXBvcnRlcikge1xuICAgIHJldHVybiAodmFsdWUpID0+IHtcbiAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICAgICAgcmV0dXJuIHRydW5jYXRlKHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiIHx8XG4gICAgICAgICAgICB0eXBlb2YgdmFsdWUgPT09IFwiYm9vbGVhblwiIHx8XG4gICAgICAgICAgICB2YWx1ZSA9PT0gbnVsbCB8fFxuICAgICAgICAgICAgdHlwZW9mIHZhbHVlID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgICAgICByZXR1cm4gU3RyaW5nKHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3Qgc2VyaWFsaXplZCA9IHRvU2VyaWFsaXphYmxlVmFsdWUodmFsdWUsIHtcbiAgICAgICAgICAgICAgICBzZWVuOiBuZXcgV2Vha01hcCgpLFxuICAgICAgICAgICAgfSwgMCwgXCIkXCIpO1xuICAgICAgICAgICAgaWYgKHR5cGVvZiBzZXJpYWxpemVkID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydW5jYXRlKHNlcmlhbGl6ZWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHRydW5jYXRlKEpTT04uc3RyaW5naWZ5KHNlcmlhbGl6ZWQpKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHJlcG9ydGVyLnJlcG9ydE5vbkZhdGFsRXJyb3IoXCJGYWlsZWQgdG8gc3RyaW5naWZ5IGNvbnNvbGUgdmFsdWUgaW4gZGVidWdnZXIgaW5zdHJ1bWVudGF0aW9uXCIsIGVycm9yKTtcbiAgICAgICAgICAgIHJldHVybiB0cnVuY2F0ZShPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodmFsdWUpKTtcbiAgICAgICAgfVxuICAgIH07XG59XG5leHBvcnQgY29uc3QgZ2V0UmVxdWVzdEJvZHlQcmV2aWV3ID0gKGJvZHksIHN0cmluZ2lmeVZhbHVlKSA9PiB7XG4gICAgaWYgKCFib2R5KSB7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgYm9keSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICByZXR1cm4gdHJ1bmNhdGUoYm9keSwgTUFYX0JPRFlfTEVOR1RIKTtcbiAgICB9XG4gICAgaWYgKGJvZHkgaW5zdGFuY2VvZiBVUkxTZWFyY2hQYXJhbXMpIHtcbiAgICAgICAgcmV0dXJuIHRydW5jYXRlKGJvZHkudG9TdHJpbmcoKSwgTUFYX0JPRFlfTEVOR1RIKTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBGb3JtRGF0YSAhPT0gXCJ1bmRlZmluZWRcIiAmJiBib2R5IGluc3RhbmNlb2YgRm9ybURhdGEpIHtcbiAgICAgICAgY29uc3Qga2V5cyA9IFtdO1xuICAgICAgICBmb3IgKGNvbnN0IGtleSBvZiBib2R5LmtleXMoKSkge1xuICAgICAgICAgICAga2V5cy5wdXNoKGtleSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydW5jYXRlKGBbZm9ybS1kYXRhXSAke2tleXMuam9pbihcIixcIil9YCwgTUFYX0JPRFlfTEVOR1RIKTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBCbG9iICE9PSBcInVuZGVmaW5lZFwiICYmIGJvZHkgaW5zdGFuY2VvZiBCbG9iKSB7XG4gICAgICAgIHJldHVybiBgW2Jsb2I6JHtib2R5LnR5cGUgfHwgXCJ1bmtub3duXCJ9OiR7Ym9keS5zaXplfV1gO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIEFycmF5QnVmZmVyICE9PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgIGlmIChib2R5IGluc3RhbmNlb2YgQXJyYXlCdWZmZXIpIHtcbiAgICAgICAgICAgIHJldHVybiBgW2FycmF5YnVmZmVyOiR7Ym9keS5ieXRlTGVuZ3RofV1gO1xuICAgICAgICB9XG4gICAgICAgIGlmIChBcnJheUJ1ZmZlci5pc1ZpZXcoYm9keSkpIHtcbiAgICAgICAgICAgIHJldHVybiBgWyR7Ym9keS5jb25zdHJ1Y3Rvci5uYW1lLnRvTG93ZXJDYXNlKCl9OiR7Ym9keS5ieXRlTGVuZ3RofV1gO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0cnVuY2F0ZShzdHJpbmdpZnlWYWx1ZShib2R5KSwgTUFYX0JPRFlfTEVOR1RIKTtcbn07XG5leHBvcnQgY29uc3Qgc2hvdWxkQ2FwdHVyZVRleHRDb250ZW50ID0gKGNvbnRlbnRUeXBlKSA9PiB7XG4gICAgY29uc3Qgbm9ybWFsaXplZCA9IGNvbnRlbnRUeXBlLnRvTG93ZXJDYXNlKCk7XG4gICAgcmV0dXJuIChub3JtYWxpemVkLmluY2x1ZGVzKFwianNvblwiKSB8fFxuICAgICAgICBub3JtYWxpemVkLmluY2x1ZGVzKFwidGV4dFwiKSB8fFxuICAgICAgICBub3JtYWxpemVkLmluY2x1ZGVzKFwieG1sXCIpIHx8XG4gICAgICAgIG5vcm1hbGl6ZWQuaW5jbHVkZXMoXCJ4LXd3dy1mb3JtLXVybGVuY29kZWRcIikpO1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXNlcmlhbGl6ZXIuanMubWFwIiwiaW1wb3J0IHsgTUFYX0hFQURFUl9OQU1FX0xFTkdUSCwgTUFYX0hFQURFUl9WQUxVRV9MRU5HVEggfSBmcm9tIFwiLi9jb25zdGFudHNcIjtcbmltcG9ydCB7IHNob3VsZEhpZGVIZWFkZXIgfSBmcm9tIFwiLi91dGlsc1wiO1xuZXhwb3J0IGNvbnN0IHRvSGVhZGVyUmVjb3JkID0gKGlucHV0KSA9PiB7XG4gICAgaWYgKCFpbnB1dCkge1xuICAgICAgICByZXR1cm4ge307XG4gICAgfVxuICAgIGNvbnN0IHJlc3VsdCA9IHt9O1xuICAgIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIGlucHV0LmVudHJpZXMoKSkge1xuICAgICAgICBjb25zdCBub3JtYWxpemVkS2V5ID0ga2V5LnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICBpZiAoIW5vcm1hbGl6ZWRLZXkgfHwgc2hvdWxkSGlkZUhlYWRlcihub3JtYWxpemVkS2V5KSkge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgcmVzdWx0W25vcm1hbGl6ZWRLZXkuc2xpY2UoMCwgTUFYX0hFQURFUl9OQU1FX0xFTkdUSCldID0gdmFsdWUuc2xpY2UoMCwgTUFYX0hFQURFUl9WQUxVRV9MRU5HVEgpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufTtcbmV4cG9ydCBjb25zdCBwYXJzZVJhd0hlYWRlcnMgPSAocmF3SGVhZGVycykgPT4ge1xuICAgIGNvbnN0IHJlc3VsdCA9IHt9O1xuICAgIGNvbnN0IGxpbmVzID0gcmF3SGVhZGVycy5zcGxpdChcIlxcblwiKTtcbiAgICBmb3IgKGNvbnN0IGxpbmUgb2YgbGluZXMpIHtcbiAgICAgICAgY29uc3Qgbm9ybWFsaXplZExpbmUgPSBsaW5lLnJlcGxhY2UoXCJcXHJcIiwgXCJcIik7XG4gICAgICAgIGNvbnN0IHNlcGFyYXRvckluZGV4ID0gbm9ybWFsaXplZExpbmUuaW5kZXhPZihcIjpcIik7XG4gICAgICAgIGlmIChzZXBhcmF0b3JJbmRleCA8PSAwKSB7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBrZXkgPSBub3JtYWxpemVkTGluZS5zbGljZSgwLCBzZXBhcmF0b3JJbmRleCkudHJpbSgpLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIGlmICgha2V5IHx8IHNob3VsZEhpZGVIZWFkZXIoa2V5KSkge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdmFsdWUgPSBub3JtYWxpemVkTGluZS5zbGljZShzZXBhcmF0b3JJbmRleCArIDEpLnRyaW0oKTtcbiAgICAgICAgaWYgKCF2YWx1ZSkge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgcmVzdWx0W2tleS5zbGljZSgwLCBNQVhfSEVBREVSX05BTUVfTEVOR1RIKV0gPSB2YWx1ZS5zbGljZSgwLCBNQVhfSEVBREVSX1ZBTFVFX0xFTkdUSCk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aGVhZGVycy5qcy5tYXAiLCJpbXBvcnQgeyBNQVhfQk9EWV9MRU5HVEggfSBmcm9tIFwiLi4vY29uc3RhbnRzXCI7XG5pbXBvcnQgeyBnZXRSZXF1ZXN0Qm9keVByZXZpZXcsIHNob3VsZENhcHR1cmVUZXh0Q29udGVudCB9IGZyb20gXCIuLi9zZXJpYWxpemVyXCI7XG5pbXBvcnQgeyBzYW5pdGl6ZUNhcHR1cmVkQm9keSwgdHJ1bmNhdGUgfSBmcm9tIFwiLi4vdXRpbHNcIjtcbmV4cG9ydCBjb25zdCBzY2hlZHVsZUJhY2tncm91bmRUYXNrID0gKHJlcG9ydGVyLCB0YXNrKSA9PiB7XG4gICAgY29uc3QgZXhlY3V0ZVRhc2sgPSAoKSA9PiB7XG4gICAgICAgIFByb21pc2UucmVzb2x2ZSh0YXNrKCkpLmNhdGNoKChlcnJvcikgPT4ge1xuICAgICAgICAgICAgcmVwb3J0ZXIucmVwb3J0Tm9uRmF0YWxFcnJvcihcIkJhY2tncm91bmQgZGVidWdnZXIgaW5zdHJ1bWVudGF0aW9uIHRhc2sgZmFpbGVkXCIsIGVycm9yKTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBpZiAodHlwZW9mIHdpbmRvdy5yZXF1ZXN0SWRsZUNhbGxiYWNrID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgd2luZG93LnJlcXVlc3RJZGxlQ2FsbGJhY2soKCkgPT4ge1xuICAgICAgICAgICAgZXhlY3V0ZVRhc2soKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgd2luZG93LnNldFRpbWVvdXQoZXhlY3V0ZVRhc2ssIDApO1xufTtcbmV4cG9ydCBjb25zdCBnZXRSZXF1ZXN0Qm9keVByZXZpZXdBc3luYyA9IChyZXBvcnRlciwgYm9keSwgc3RyaW5naWZ5VmFsdWUsIGNvbnRlbnRUeXBlID0gXCJcIikgPT4ge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICBzY2hlZHVsZUJhY2tncm91bmRUYXNrKHJlcG9ydGVyLCAoKSA9PiB7XG4gICAgICAgICAgICByZXNvbHZlKHNhbml0aXplQ2FwdHVyZWRCb2R5KGdldFJlcXVlc3RCb2R5UHJldmlldyhib2R5LCBzdHJpbmdpZnlWYWx1ZSksIGNvbnRlbnRUeXBlKSk7XG4gICAgICAgIH0pO1xuICAgIH0pO1xufTtcbmV4cG9ydCBjb25zdCBnZXRUZXh0Qm9keVByZXZpZXdBc3luYyA9IChyZXBvcnRlciwgY29udGVudFR5cGUsIGVycm9yQ29udGV4dCwgcmVhZEJvZHkpID0+IHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgc2NoZWR1bGVCYWNrZ3JvdW5kVGFzayhyZXBvcnRlciwgYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgaWYgKCFzaG91bGRDYXB0dXJlVGV4dENvbnRlbnQoY29udGVudFR5cGUpKSB7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZSh1bmRlZmluZWQpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZShzYW5pdGl6ZUNhcHR1cmVkQm9keSh0cnVuY2F0ZShhd2FpdCByZWFkQm9keSgpLCBNQVhfQk9EWV9MRU5HVEgpLCBjb250ZW50VHlwZSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgcmVwb3J0ZXIucmVwb3J0Tm9uRmF0YWxFcnJvcihlcnJvckNvbnRleHQsIGVycm9yKTtcbiAgICAgICAgICAgICAgICByZXNvbHZlKHVuZGVmaW5lZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH0pO1xufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXNoYXJlZC5qcy5tYXAiLCJpbXBvcnQgeyBNQVhfQk9EWV9MRU5HVEggfSBmcm9tIFwiLi4vLi4vY29uc3RhbnRzXCI7XG5pbXBvcnQgeyB0b0hlYWRlclJlY29yZCB9IGZyb20gXCIuLi8uLi9oZWFkZXJzXCI7XG5pbXBvcnQgeyBnZXRSZXF1ZXN0Qm9keVByZXZpZXcsIHNob3VsZENhcHR1cmVUZXh0Q29udGVudCwgfSBmcm9tIFwiLi4vLi4vc2VyaWFsaXplclwiO1xuaW1wb3J0IHsgcmVkYWN0U2Vuc2l0aXZlUXVlcnlQYXJhbXMsIHNhbml0aXplQ2FwdHVyZWRCb2R5LCB0b0Fic29sdXRlVXJsLCB0cnVuY2F0ZSwgfSBmcm9tIFwiLi4vLi4vdXRpbHNcIjtcbmltcG9ydCB7IGdldFJlcXVlc3RCb2R5UHJldmlld0FzeW5jLCBnZXRUZXh0Qm9keVByZXZpZXdBc3luYyB9IGZyb20gXCIuLi9zaGFyZWRcIjtcbmNvbnN0IHJlc29sdmVGZXRjaE1ldGhvZCA9IChpbnB1dCwgaW5pdCkgPT4ge1xuICAgIGlmICh0eXBlb2YgaW5pdD8ubWV0aG9kID09PSBcInN0cmluZ1wiICYmIGluaXQubWV0aG9kKSB7XG4gICAgICAgIHJldHVybiBpbml0Lm1ldGhvZC50b1VwcGVyQ2FzZSgpO1xuICAgIH1cbiAgICBpZiAoaW5wdXQgaW5zdGFuY2VvZiBSZXF1ZXN0KSB7XG4gICAgICAgIHJldHVybiBpbnB1dC5tZXRob2QudG9VcHBlckNhc2UoKTtcbiAgICB9XG4gICAgcmV0dXJuIFwiR0VUXCI7XG59O1xuY29uc3QgcmVzb2x2ZUZldGNoVXJsID0gKGlucHV0KSA9PiB7XG4gICAgaWYgKHR5cGVvZiBpbnB1dCA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICByZXR1cm4gaW5wdXQ7XG4gICAgfVxuICAgIGlmIChpbnB1dCBpbnN0YW5jZW9mIFVSTCkge1xuICAgICAgICByZXR1cm4gaW5wdXQudG9TdHJpbmcoKTtcbiAgICB9XG4gICAgcmV0dXJuIGlucHV0LnVybDtcbn07XG5jb25zdCBnZXRGZXRjaFJlcXVlc3RCb2R5UHJldmlldyA9IGFzeW5jIChpbnB1dCwgaW5pdCwgcmVxdWVzdEhlYWRlcnMsIHN0cmluZ2lmeVZhbHVlLCByZXBvcnRlcikgPT4ge1xuICAgIGNvbnN0IGluaXRCb2R5UHJldmlldyA9IGdldFJlcXVlc3RCb2R5UHJldmlldyhpbml0Py5ib2R5LCBzdHJpbmdpZnlWYWx1ZSk7XG4gICAgaWYgKGluaXRCb2R5UHJldmlldykge1xuICAgICAgICByZXR1cm4gaW5pdEJvZHlQcmV2aWV3O1xuICAgIH1cbiAgICBpZiAoIShpbnB1dCBpbnN0YW5jZW9mIFJlcXVlc3QpKSB7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGNvbnN0IG1ldGhvZCA9IChpbml0Py5tZXRob2QgPz8gaW5wdXQubWV0aG9kID8/IFwiR0VUXCIpLnRvVXBwZXJDYXNlKCk7XG4gICAgaWYgKG1ldGhvZCA9PT0gXCJHRVRcIiB8fCBtZXRob2QgPT09IFwiSEVBRFwiIHx8IGlucHV0LmJvZHlVc2VkKSB7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGNvbnN0IGNvbnRlbnRUeXBlID0gcmVxdWVzdEhlYWRlcnM/LmdldChcImNvbnRlbnQtdHlwZVwiKSA/P1xuICAgICAgICBpbnB1dC5oZWFkZXJzLmdldChcImNvbnRlbnQtdHlwZVwiKSA/P1xuICAgICAgICBcIlwiO1xuICAgIGlmICghc2hvdWxkQ2FwdHVyZVRleHRDb250ZW50KGNvbnRlbnRUeXBlKSkge1xuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgICByZXR1cm4gc2FuaXRpemVDYXB0dXJlZEJvZHkodHJ1bmNhdGUoYXdhaXQgaW5wdXQuY2xvbmUoKS50ZXh0KCksIE1BWF9CT0RZX0xFTkdUSCksIGNvbnRlbnRUeXBlKTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJlcG9ydGVyLnJlcG9ydE5vbkZhdGFsRXJyb3IoXCJGYWlsZWQgdG8gY2FwdHVyZSBmZXRjaCByZXF1ZXN0IGJvZHkgaW4gZGVidWdnZXIgaW5zdHJ1bWVudGF0aW9uXCIsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG59O1xuY29uc3QgcmVzb2x2ZUZldGNoUmVxdWVzdEJvZHlQcm9taXNlID0gKHJlcXVlc3RJbnB1dCwgcmVxdWVzdEluaXQsIHJlcXVlc3RIZWFkZXJTb3VyY2UsIHN0cmluZ2lmeVZhbHVlLCByZXBvcnRlciwgcmVxdWVzdEJvZHlCeVJlcXVlc3QpID0+IHtcbiAgICBpZiAocmVxdWVzdElucHV0IGluc3RhbmNlb2YgUmVxdWVzdCkge1xuICAgICAgICByZXR1cm4gKHJlcXVlc3RCb2R5QnlSZXF1ZXN0LmdldChyZXF1ZXN0SW5wdXQpID8/XG4gICAgICAgICAgICBnZXRGZXRjaFJlcXVlc3RCb2R5UHJldmlldyhyZXF1ZXN0SW5wdXQsIHJlcXVlc3RJbml0LCByZXF1ZXN0SGVhZGVyU291cmNlLCBzdHJpbmdpZnlWYWx1ZSwgcmVwb3J0ZXIpKTtcbiAgICB9XG4gICAgcmV0dXJuIGdldEZldGNoUmVxdWVzdEJvZHlQcmV2aWV3KHJlcXVlc3RJbnB1dCwgcmVxdWVzdEluaXQsIHJlcXVlc3RIZWFkZXJTb3VyY2UsIHN0cmluZ2lmeVZhbHVlLCByZXBvcnRlcik7XG59O1xuZXhwb3J0IGNvbnN0IHJlc29sdmVGZXRjaENvbnRleHQgPSAoYXJncywgcmVwb3J0ZXIsIHN0cmluZ2lmeVZhbHVlLCByZXF1ZXN0Qm9keUJ5UmVxdWVzdCkgPT4ge1xuICAgIGNvbnN0IFtyZXF1ZXN0SW5wdXQsIHJlcXVlc3RJbml0XSA9IGFyZ3M7XG4gICAgY29uc3QgbWV0aG9kID0gcmVzb2x2ZUZldGNoTWV0aG9kKHJlcXVlc3RJbnB1dCwgcmVxdWVzdEluaXQpO1xuICAgIGNvbnN0IHVybCA9IHJlc29sdmVGZXRjaFVybChyZXF1ZXN0SW5wdXQpO1xuICAgIGNvbnN0IGFic29sdXRlVXJsID0gdG9BYnNvbHV0ZVVybCh1cmwsIHJlcG9ydGVyKTtcbiAgICBpZiAoIWFic29sdXRlVXJsKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBsZXQgcmVxdWVzdEhlYWRlclNvdXJjZSA9IG51bGw7XG4gICAgaWYgKHJlcXVlc3RJbml0Py5oZWFkZXJzKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXF1ZXN0SGVhZGVyU291cmNlID0gbmV3IEhlYWRlcnMocmVxdWVzdEluaXQuaGVhZGVycyk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICByZXBvcnRlci5yZXBvcnROb25GYXRhbEVycm9yKFwiRmFpbGVkIHRvIG5vcm1hbGl6ZSBmZXRjaCBoZWFkZXJzIGluIGRlYnVnZ2VyIGluc3RydW1lbnRhdGlvblwiLCBlcnJvcik7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZWxzZSBpZiAocmVxdWVzdElucHV0IGluc3RhbmNlb2YgUmVxdWVzdCkge1xuICAgICAgICByZXF1ZXN0SGVhZGVyU291cmNlID0gcmVxdWVzdElucHV0LmhlYWRlcnM7XG4gICAgfVxuICAgIGNvbnN0IHJlcXVlc3RIZWFkZXJzID0gcmVxdWVzdEhlYWRlclNvdXJjZVxuICAgICAgICA/IHRvSGVhZGVyUmVjb3JkKHJlcXVlc3RIZWFkZXJTb3VyY2UpXG4gICAgICAgIDogcmVxdWVzdElucHV0IGluc3RhbmNlb2YgUmVxdWVzdFxuICAgICAgICAgICAgPyB0b0hlYWRlclJlY29yZChyZXF1ZXN0SW5wdXQuaGVhZGVycylcbiAgICAgICAgICAgIDoge307XG4gICAgY29uc3QgcmVxdWVzdENvbnRlbnRUeXBlID0gcmVxdWVzdEhlYWRlclNvdXJjZT8uZ2V0KFwiY29udGVudC10eXBlXCIpID8/XG4gICAgICAgIChyZXF1ZXN0SW5wdXQgaW5zdGFuY2VvZiBSZXF1ZXN0XG4gICAgICAgICAgICA/IChyZXF1ZXN0SW5wdXQuaGVhZGVycy5nZXQoXCJjb250ZW50LXR5cGVcIikgPz8gXCJcIilcbiAgICAgICAgICAgIDogXCJcIik7XG4gICAgY29uc3QgcmVxdWVzdEJvZHlQcm9taXNlID0gcmVzb2x2ZUZldGNoUmVxdWVzdEJvZHlQcm9taXNlKHJlcXVlc3RJbnB1dCwgcmVxdWVzdEluaXQsIHJlcXVlc3RIZWFkZXJTb3VyY2UsIHN0cmluZ2lmeVZhbHVlLCByZXBvcnRlciwgcmVxdWVzdEJvZHlCeVJlcXVlc3QpO1xuICAgIHJldHVybiB7XG4gICAgICAgIG1ldGhvZCxcbiAgICAgICAgbm9ybWFsaXplZFVybDogcmVkYWN0U2Vuc2l0aXZlUXVlcnlQYXJhbXMoYWJzb2x1dGVVcmwpLFxuICAgICAgICByZXF1ZXN0SGVhZGVycyxcbiAgICAgICAgcmVxdWVzdENvbnRlbnRUeXBlLFxuICAgICAgICByZXF1ZXN0Qm9keVByb21pc2UsXG4gICAgfTtcbn07XG5leHBvcnQgY29uc3QgaW5zdGFsbFJlcXVlc3RDb25zdHJ1Y3RvckNhcHR1cmUgPSAocmVwb3J0ZXIsIHN0cmluZ2lmeVZhbHVlLCByZXF1ZXN0Qm9keUJ5UmVxdWVzdCkgPT4ge1xuICAgIGlmICh0eXBlb2Ygd2luZG93LlJlcXVlc3QgIT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IE9yaWdpbmFsUmVxdWVzdCA9IHdpbmRvdy5SZXF1ZXN0O1xuICAgIGNvbnN0IHBhdGNoZWRSZXF1ZXN0ID0gbmV3IFByb3h5KE9yaWdpbmFsUmVxdWVzdCwge1xuICAgICAgICBjb25zdHJ1Y3QodGFyZ2V0LCBhcmdBcnJheSwgbmV3VGFyZ2V0KSB7XG4gICAgICAgICAgICBjb25zdCBbLCByZXF1ZXN0SW5pdF0gPSBhcmdBcnJheTtcbiAgICAgICAgICAgIGNvbnN0IHJlcXVlc3RJbnN0YW5jZSA9IFJlZmxlY3QuY29uc3RydWN0KHRhcmdldCwgYXJnQXJyYXksIG5ld1RhcmdldCk7XG4gICAgICAgICAgICBsZXQgcmVxdWVzdEhlYWRlclNvdXJjZTtcbiAgICAgICAgICAgIGlmIChyZXF1ZXN0SW5pdD8uaGVhZGVycyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgcmVxdWVzdEhlYWRlclNvdXJjZSA9IG5ldyBIZWFkZXJzKHJlcXVlc3RJbml0LmhlYWRlcnMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgcmVwb3J0ZXIucmVwb3J0Tm9uRmF0YWxFcnJvcihcIkZhaWxlZCB0byBub3JtYWxpemUgUmVxdWVzdCBoZWFkZXJzIGluIGRlYnVnZ2VyIGluc3RydW1lbnRhdGlvblwiLCBlcnJvcik7XG4gICAgICAgICAgICAgICAgICAgIHJlcXVlc3RIZWFkZXJTb3VyY2UgPSByZXF1ZXN0SW5zdGFuY2UuaGVhZGVycztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXF1ZXN0SGVhZGVyU291cmNlID0gcmVxdWVzdEluc3RhbmNlLmhlYWRlcnM7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBjb250ZW50VHlwZSA9IHJlcXVlc3RIZWFkZXJTb3VyY2UuZ2V0KFwiY29udGVudC10eXBlXCIpID8/IFwiXCI7XG4gICAgICAgICAgICBjb25zdCByZXF1ZXN0Qm9keVByb21pc2UgPSByZXF1ZXN0SW5pdD8uYm9keSAhPT0gdW5kZWZpbmVkXG4gICAgICAgICAgICAgICAgPyBnZXRSZXF1ZXN0Qm9keVByZXZpZXdBc3luYyhyZXBvcnRlciwgcmVxdWVzdEluaXQuYm9keSwgc3RyaW5naWZ5VmFsdWUsIGNvbnRlbnRUeXBlKVxuICAgICAgICAgICAgICAgIDogZ2V0VGV4dEJvZHlQcmV2aWV3QXN5bmMocmVwb3J0ZXIsIGNvbnRlbnRUeXBlLCBcIkZhaWxlZCB0byBjYXB0dXJlIFJlcXVlc3QgYm9keSB0ZXh0IGluIGRlYnVnZ2VyIGluc3RydW1lbnRhdGlvblwiLCAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChyZXF1ZXN0SW5zdGFuY2UuYm9keVVzZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoXCJcIik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlcXVlc3RJbnN0YW5jZS5jbG9uZSgpLnRleHQoKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJlcXVlc3RCb2R5QnlSZXF1ZXN0LnNldChyZXF1ZXN0SW5zdGFuY2UsIHJlcXVlc3RCb2R5UHJvbWlzZSk7XG4gICAgICAgICAgICByZXR1cm4gcmVxdWVzdEluc3RhbmNlO1xuICAgICAgICB9LFxuICAgIH0pO1xuICAgIHRyeSB7XG4gICAgICAgIE9iamVjdC5hc3NpZ24ocGF0Y2hlZFJlcXVlc3QsIE9yaWdpbmFsUmVxdWVzdCk7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXBvcnRlci5yZXBvcnROb25GYXRhbEVycm9yKFwiRmFpbGVkIHRvIG1pcnJvciBSZXF1ZXN0IGNvbnN0cnVjdG9yIHByb3BlcnRpZXMgaW4gZGVidWdnZXIgaW5zdHJ1bWVudGF0aW9uXCIsIGVycm9yKTtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgICAgd2luZG93LlJlcXVlc3QgPSBwYXRjaGVkUmVxdWVzdDtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJlcG9ydGVyLnJlcG9ydE5vbkZhdGFsRXJyb3IoXCJGYWlsZWQgdG8gcGF0Y2ggUmVxdWVzdCBjb25zdHJ1Y3RvciBpbiBkZWJ1Z2dlciBpbnN0cnVtZW50YXRpb25cIiwgZXJyb3IpO1xuICAgIH1cbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb250ZXh0LmpzLm1hcCIsImltcG9ydCB7IE1BWF9CT0RZX0xFTkdUSCB9IGZyb20gXCIuLi8uLi9jb25zdGFudHNcIjtcbmltcG9ydCB7IHRvSGVhZGVyUmVjb3JkIH0gZnJvbSBcIi4uLy4uL2hlYWRlcnNcIjtcbmltcG9ydCB7IHNob3VsZENhcHR1cmVUZXh0Q29udGVudCB9IGZyb20gXCIuLi8uLi9zZXJpYWxpemVyXCI7XG5pbXBvcnQgeyBzYW5pdGl6ZUNhcHR1cmVkQm9keSwgdHJ1bmNhdGUgfSBmcm9tIFwiLi4vLi4vdXRpbHNcIjtcbmltcG9ydCB7IGdldFRleHRCb2R5UHJldmlld0FzeW5jLCBzY2hlZHVsZUJhY2tncm91bmRUYXNrIH0gZnJvbSBcIi4uL3NoYXJlZFwiO1xuY29uc3QgY2xvbmVGZXRjaFJlc3BvbnNlRm9yQ2FwdHVyZSA9IChyZXNwb25zZSwgcmVwb3J0ZXIpID0+IHtcbiAgICBjb25zdCBjb250ZW50VHlwZSA9IHJlc3BvbnNlLmhlYWRlcnMuZ2V0KFwiY29udGVudC10eXBlXCIpID8/IFwiXCI7XG4gICAgaWYgKCFzaG91bGRDYXB0dXJlVGV4dENvbnRlbnQoY29udGVudFR5cGUpIHx8IHJlc3BvbnNlLmJvZHlVc2VkKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBjb250ZW50VHlwZSxcbiAgICAgICAgICAgIHJlc3BvbnNlQ2xvbmU6IG51bGwsXG4gICAgICAgIH07XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBjb250ZW50VHlwZSxcbiAgICAgICAgICAgIHJlc3BvbnNlQ2xvbmU6IHJlc3BvbnNlLmNsb25lKCksXG4gICAgICAgIH07XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXBvcnRlci5yZXBvcnROb25GYXRhbEVycm9yKFwiRmFpbGVkIHRvIGNsb25lIGZldGNoIHJlc3BvbnNlIGJvZHkgaW4gZGVidWdnZXIgaW5zdHJ1bWVudGF0aW9uXCIsIGVycm9yKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGNvbnRlbnRUeXBlLFxuICAgICAgICAgICAgcmVzcG9uc2VDbG9uZTogbnVsbCxcbiAgICAgICAgfTtcbiAgICB9XG59O1xuZXhwb3J0IGNvbnN0IHNjaGVkdWxlRmV0Y2hTdWNjZXNzUG9zdCA9IChyZXBvcnRlciwgcG9zdE5ldHdvcmssIGNvbnRleHQsIHJlc3BvbnNlLCBkdXJhdGlvbikgPT4ge1xuICAgIGNvbnN0IHJlc3BvbnNlSGVhZGVycyA9IHRvSGVhZGVyUmVjb3JkKHJlc3BvbnNlLmhlYWRlcnMpO1xuICAgIGNvbnN0IHsgY29udGVudFR5cGUsIHJlc3BvbnNlQ2xvbmUgfSA9IGNsb25lRmV0Y2hSZXNwb25zZUZvckNhcHR1cmUocmVzcG9uc2UsIHJlcG9ydGVyKTtcbiAgICBzY2hlZHVsZUJhY2tncm91bmRUYXNrKHJlcG9ydGVyLCBhc3luYyAoKSA9PiB7XG4gICAgICAgIGxldCByZXF1ZXN0Qm9keTtcbiAgICAgICAgbGV0IHJlc3BvbnNlQm9keTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJlcXVlc3RCb2R5ID0gYXdhaXQgY29udGV4dC5yZXF1ZXN0Qm9keVByb21pc2U7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICByZXBvcnRlci5yZXBvcnROb25GYXRhbEVycm9yKFwiRmFpbGVkIHRvIHJlc29sdmUgZmV0Y2ggcmVxdWVzdCBib2R5IGluIGRlYnVnZ2VyIGluc3RydW1lbnRhdGlvblwiLCBlcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJlc3BvbnNlQm9keSA9IGF3YWl0IGdldFRleHRCb2R5UHJldmlld0FzeW5jKHJlcG9ydGVyLCBjb250ZW50VHlwZSwgXCJGYWlsZWQgdG8gY2FwdHVyZSBmZXRjaCByZXNwb25zZSBib2R5IHRleHQgaW4gZGVidWdnZXIgaW5zdHJ1bWVudGF0aW9uXCIsICgpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoIXJlc3BvbnNlQ2xvbmUpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShcIlwiKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlQ2xvbmUudGV4dCgpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICByZXBvcnRlci5yZXBvcnROb25GYXRhbEVycm9yKFwiRmFpbGVkIHRvIGNhcHR1cmUgZmV0Y2ggcmVzcG9uc2UgYm9keSBpbiBkZWJ1Z2dlciBpbnN0cnVtZW50YXRpb25cIiwgZXJyb3IpO1xuICAgICAgICB9XG4gICAgICAgIHBvc3ROZXR3b3JrKHtcbiAgICAgICAgICAgIG1ldGhvZDogY29udGV4dC5tZXRob2QsXG4gICAgICAgICAgICB1cmw6IGNvbnRleHQubm9ybWFsaXplZFVybCxcbiAgICAgICAgICAgIHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzLFxuICAgICAgICAgICAgZHVyYXRpb24sXG4gICAgICAgICAgICByZXF1ZXN0SGVhZGVyczogY29udGV4dC5yZXF1ZXN0SGVhZGVycyxcbiAgICAgICAgICAgIHJlc3BvbnNlSGVhZGVycyxcbiAgICAgICAgICAgIHJlcXVlc3RCb2R5OiBzYW5pdGl6ZUNhcHR1cmVkQm9keShyZXF1ZXN0Qm9keSwgY29udGV4dC5yZXF1ZXN0Q29udGVudFR5cGUpLFxuICAgICAgICAgICAgcmVzcG9uc2VCb2R5OiBzYW5pdGl6ZUNhcHR1cmVkQm9keShyZXNwb25zZUJvZHksIGNvbnRlbnRUeXBlKSxcbiAgICAgICAgfSk7XG4gICAgfSk7XG59O1xuZXhwb3J0IGNvbnN0IHNjaGVkdWxlRmV0Y2hGYWlsdXJlUG9zdCA9IChyZXBvcnRlciwgcG9zdE5ldHdvcmssIGNvbnRleHQsIGVycm9yLCBzdGFydGVkQXQsIHN0cmluZ2lmeVZhbHVlKSA9PiB7XG4gICAgc2NoZWR1bGVCYWNrZ3JvdW5kVGFzayhyZXBvcnRlciwgYXN5bmMgKCkgPT4ge1xuICAgICAgICBsZXQgcmVxdWVzdEJvZHk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXF1ZXN0Qm9keSA9IGF3YWl0IGNvbnRleHQucmVxdWVzdEJvZHlQcm9taXNlO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChfcmVxdWVzdEJvZHlFcnJvcikge1xuICAgICAgICAgICAgcmVxdWVzdEJvZHkgPSB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgICAgcG9zdE5ldHdvcmsoe1xuICAgICAgICAgICAgbWV0aG9kOiBjb250ZXh0Lm1ldGhvZCxcbiAgICAgICAgICAgIHVybDogY29udGV4dC5ub3JtYWxpemVkVXJsLFxuICAgICAgICAgICAgc3RhdHVzOiAwLFxuICAgICAgICAgICAgZHVyYXRpb246IERhdGUubm93KCkgLSBzdGFydGVkQXQsXG4gICAgICAgICAgICByZXF1ZXN0SGVhZGVyczogY29udGV4dC5yZXF1ZXN0SGVhZGVycyxcbiAgICAgICAgICAgIHJlcXVlc3RCb2R5OiBzYW5pdGl6ZUNhcHR1cmVkQm9keShyZXF1ZXN0Qm9keSwgY29udGV4dC5yZXF1ZXN0Q29udGVudFR5cGUpLFxuICAgICAgICAgICAgcmVzcG9uc2VCb2R5OiBzYW5pdGl6ZUNhcHR1cmVkQm9keSh0cnVuY2F0ZShzdHJpbmdpZnlWYWx1ZShlcnJvciksIE1BWF9CT0RZX0xFTkdUSCksIFwiXCIpLFxuICAgICAgICB9KTtcbiAgICB9KTtcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1wb3N0LmpzLm1hcCIsImltcG9ydCB7IGNyZWF0ZVN0cmluZ2lmeVZhbHVlIH0gZnJvbSBcIi4uLy4uL3NlcmlhbGl6ZXJcIjtcbmltcG9ydCB7IHRydW5jYXRlIH0gZnJvbSBcIi4uLy4uL3V0aWxzXCI7XG5pbXBvcnQgeyBpbnN0YWxsUmVxdWVzdENvbnN0cnVjdG9yQ2FwdHVyZSwgcmVzb2x2ZUZldGNoQ29udGV4dCwgfSBmcm9tIFwiLi9jb250ZXh0XCI7XG5pbXBvcnQgeyBzY2hlZHVsZUZldGNoRmFpbHVyZVBvc3QsIHNjaGVkdWxlRmV0Y2hTdWNjZXNzUG9zdCB9IGZyb20gXCIuL3Bvc3RcIjtcbmV4cG9ydCBjb25zdCBpbnN0YWxsRmV0Y2hDYXB0dXJlID0gKGlucHV0KSA9PiB7XG4gICAgY29uc3QgeyBkaWFnbm9zdGljcywgcG9zdE5ldHdvcmssIHJlcG9ydGVyIH0gPSBpbnB1dDtcbiAgICBjb25zdCBzdHJpbmdpZnlWYWx1ZSA9IGNyZWF0ZVN0cmluZ2lmeVZhbHVlKHJlcG9ydGVyKTtcbiAgICBjb25zdCByZXF1ZXN0Qm9keUJ5UmVxdWVzdCA9IG5ldyBXZWFrTWFwKCk7XG4gICAgY29uc3QgYmluZEZldGNoID0gKGNhbmRpZGF0ZSkgPT4ge1xuICAgICAgICByZXR1cm4gY2FuZGlkYXRlLmJpbmQod2luZG93KTtcbiAgICB9O1xuICAgIGluc3RhbGxSZXF1ZXN0Q29uc3RydWN0b3JDYXB0dXJlKHJlcG9ydGVyLCBzdHJpbmdpZnlWYWx1ZSwgcmVxdWVzdEJvZHlCeVJlcXVlc3QpO1xuICAgIGlmICh0eXBlb2Ygd2luZG93LmZldGNoICE9PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgZGlhZ25vc3RpY3Muc2V0RmV0Y2hIb29rU3RhdGUoXCJmYWlsZWRcIik7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgYmFzZUZldGNoID0gYmluZEZldGNoKHdpbmRvdy5mZXRjaCk7XG4gICAgbGV0IGRlbGVnYXRlRmV0Y2ggPSBiYXNlRmV0Y2g7XG4gICAgbGV0IGlzSW5zaWRlUGF0Y2hlZEZldGNoID0gZmFsc2U7XG4gICAgY29uc3QgcGF0Y2hlZEZldGNoID0gKGFzeW5jICguLi5hcmdzKSA9PiB7XG4gICAgICAgIGlmIChpc0luc2lkZVBhdGNoZWRGZXRjaCkge1xuICAgICAgICAgICAgLy8gUHJldmVudCByZWN1cnNpb24gd2hlbiB0aGlyZC1wYXJ0eSBmZXRjaCB3cmFwcGVycyBjYWxsIHdpbmRvdy5mZXRjaCgpLlxuICAgICAgICAgICAgcmV0dXJuIGJhc2VGZXRjaCguLi5hcmdzKTtcbiAgICAgICAgfVxuICAgICAgICBpc0luc2lkZVBhdGNoZWRGZXRjaCA9IHRydWU7XG4gICAgICAgIGRpYWdub3N0aWNzLnJlY29yZEZldGNoQ2FsbCgpO1xuICAgICAgICBjb25zdCBzdGFydGVkQXQgPSBEYXRlLm5vdygpO1xuICAgICAgICBjb25zdCBjb250ZXh0ID0gcmVzb2x2ZUZldGNoQ29udGV4dChhcmdzLCByZXBvcnRlciwgc3RyaW5naWZ5VmFsdWUsIHJlcXVlc3RCb2R5QnlSZXF1ZXN0KTtcbiAgICAgICAgaWYgKCFjb250ZXh0KSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHJldHVybiBkZWxlZ2F0ZUZldGNoKC4uLmFyZ3MpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZmluYWxseSB7XG4gICAgICAgICAgICAgICAgaXNJbnNpZGVQYXRjaGVkRmV0Y2ggPSBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBkZWxlZ2F0ZUZldGNoKC4uLmFyZ3MpO1xuICAgICAgICAgICAgY29uc3QgZHVyYXRpb24gPSBEYXRlLm5vdygpIC0gc3RhcnRlZEF0O1xuICAgICAgICAgICAgc2NoZWR1bGVGZXRjaFN1Y2Nlc3NQb3N0KHJlcG9ydGVyLCBwb3N0TmV0d29yaywgY29udGV4dCwgcmVzcG9uc2UsIGR1cmF0aW9uKTtcbiAgICAgICAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGRpYWdub3N0aWNzLnJlY29yZEZldGNoRmFpbHVyZSh0cnVuY2F0ZShzdHJpbmdpZnlWYWx1ZShlcnJvciksIDMwMCkpO1xuICAgICAgICAgICAgc2NoZWR1bGVGZXRjaEZhaWx1cmVQb3N0KHJlcG9ydGVyLCBwb3N0TmV0d29yaywgY29udGV4dCwgZXJyb3IsIHN0YXJ0ZWRBdCwgc3RyaW5naWZ5VmFsdWUpO1xuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgIH1cbiAgICAgICAgZmluYWxseSB7XG4gICAgICAgICAgICBpc0luc2lkZVBhdGNoZWRGZXRjaCA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgdHJ5IHtcbiAgICAgICAgT2JqZWN0LmFzc2lnbihwYXRjaGVkRmV0Y2gsIHdpbmRvdy5mZXRjaCk7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXBvcnRlci5yZXBvcnROb25GYXRhbEVycm9yKFwiRmFpbGVkIHRvIG1pcnJvciBmZXRjaCBwcm9wZXJ0aWVzIGluIGRlYnVnZ2VyIGluc3RydW1lbnRhdGlvblwiLCBlcnJvcik7XG4gICAgfVxuICAgIGNvbnN0IGZldGNoRGVzY3JpcHRvciA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3Iod2luZG93LCBcImZldGNoXCIpO1xuICAgIGNvbnN0IGNhblJlZGVmaW5lRmV0Y2ggPSAhZmV0Y2hEZXNjcmlwdG9yIHx8IGZldGNoRGVzY3JpcHRvci5jb25maWd1cmFibGU7XG4gICAgaWYgKGNhblJlZGVmaW5lRmV0Y2gpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh3aW5kb3csIFwiZmV0Y2hcIiwge1xuICAgICAgICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICBlbnVtZXJhYmxlOiBmZXRjaERlc2NyaXB0b3I/LmVudW1lcmFibGUgPz8gdHJ1ZSxcbiAgICAgICAgICAgICAgICBnZXQoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBwYXRjaGVkRmV0Y2g7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICBzZXQobmV4dEZldGNoKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbmV4dEZldGNoICE9PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAobmV4dEZldGNoID09PSBwYXRjaGVkRmV0Y2gpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBkZWxlZ2F0ZUZldGNoID0gYmluZEZldGNoKG5leHRGZXRjaCk7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgZGlhZ25vc3RpY3Muc2V0RmV0Y2hIb29rU3RhdGUoXCJhY2Nlc3NvclwiKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHJlcG9ydGVyLnJlcG9ydE5vbkZhdGFsRXJyb3IoXCJGYWlsZWQgdG8gaW5zdGFsbCBmZXRjaCBhY2Nlc3NvciBpbiBkZWJ1Z2dlciBpbnN0cnVtZW50YXRpb25cIiwgZXJyb3IpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICAgIHdpbmRvdy5mZXRjaCA9IHBhdGNoZWRGZXRjaDtcbiAgICAgICAgZGlhZ25vc3RpY3Muc2V0RmV0Y2hIb29rU3RhdGUoXCJhc3NpZ25tZW50XCIpO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgZGlhZ25vc3RpY3Muc2V0RmV0Y2hIb29rU3RhdGUoXCJmYWlsZWRcIik7XG4gICAgICAgIHJlcG9ydGVyLnJlcG9ydE5vbkZhdGFsRXJyb3IoXCJGYWlsZWQgdG8gcGF0Y2ggZmV0Y2ggaW4gZGVidWdnZXIgaW5zdHJ1bWVudGF0aW9uXCIsIGVycm9yKTtcbiAgICB9XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5zdGFsbC5qcy5tYXAiLCJpbXBvcnQgeyBNQVhfQk9EWV9MRU5HVEgsIE1BWF9IRUFERVJfTkFNRV9MRU5HVEgsIE1BWF9IRUFERVJfVkFMVUVfTEVOR1RILCB9IGZyb20gXCIuLi9jb25zdGFudHNcIjtcbmltcG9ydCB7IHBhcnNlUmF3SGVhZGVycyB9IGZyb20gXCIuLi9oZWFkZXJzXCI7XG5pbXBvcnQgeyBjcmVhdGVTdHJpbmdpZnlWYWx1ZSB9IGZyb20gXCIuLi9zZXJpYWxpemVyXCI7XG5pbXBvcnQgeyByZWRhY3RTZW5zaXRpdmVRdWVyeVBhcmFtcywgc2FuaXRpemVDYXB0dXJlZEJvZHksIHNob3VsZEhpZGVIZWFkZXIsIHRvQWJzb2x1dGVVcmwsIHRydW5jYXRlLCB9IGZyb20gXCIuLi91dGlsc1wiO1xuaW1wb3J0IHsgZ2V0UmVxdWVzdEJvZHlQcmV2aWV3QXN5bmMsIHNjaGVkdWxlQmFja2dyb3VuZFRhc2sgfSBmcm9tIFwiLi9zaGFyZWRcIjtcbmV4cG9ydCBjb25zdCBpbnN0YWxsWGhyQ2FwdHVyZSA9IChpbnB1dCkgPT4ge1xuICAgIGNvbnN0IHsgZGlhZ25vc3RpY3MsIHBvc3ROZXR3b3JrLCByZXBvcnRlciB9ID0gaW5wdXQ7XG4gICAgY29uc3Qgc3RyaW5naWZ5VmFsdWUgPSBjcmVhdGVTdHJpbmdpZnlWYWx1ZShyZXBvcnRlcik7XG4gICAgY29uc3QgeGhyTWV0YU1hcCA9IG5ldyBXZWFrTWFwKCk7XG4gICAgY29uc3QgYnVpbGRYaHJQb3N0UGF5bG9hZCA9IGFzeW5jICh4aHIpID0+IHtcbiAgICAgICAgY29uc3Qgc3RhdGUgPSB4aHJNZXRhTWFwLmdldCh4aHIpO1xuICAgICAgICBpZiAoIXN0YXRlKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBub3JtYWxpemVkVXJsID0gdG9BYnNvbHV0ZVVybChzdGF0ZS51cmwsIHJlcG9ydGVyKTtcbiAgICAgICAgaWYgKCFub3JtYWxpemVkVXJsKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZWRhY3RlZFVybCA9IHJlZGFjdFNlbnNpdGl2ZVF1ZXJ5UGFyYW1zKG5vcm1hbGl6ZWRVcmwpO1xuICAgICAgICBsZXQgcmVxdWVzdEJvZHk7XG4gICAgICAgIGxldCByZXNwb25zZUJvZHk7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlSGVhZGVycyA9IHBhcnNlUmF3SGVhZGVycyh4aHIuZ2V0QWxsUmVzcG9uc2VIZWFkZXJzKCkpO1xuICAgICAgICBjb25zdCByZXNwb25zZUNvbnRlbnRUeXBlID0gcmVzcG9uc2VIZWFkZXJzW1wiY29udGVudC10eXBlXCJdID8/IFwiXCI7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXF1ZXN0Qm9keSA9IGF3YWl0IHN0YXRlLnJlcXVlc3RCb2R5UHJvbWlzZTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoX3JlcXVlc3RCb2R5RXJyb3IpIHtcbiAgICAgICAgICAgIHJlcXVlc3RCb2R5ID0gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBpZiAoeGhyLnJlc3BvbnNlVHlwZSA9PT0gXCJcIiB8fCB4aHIucmVzcG9uc2VUeXBlID09PSBcInRleHRcIikge1xuICAgICAgICAgICAgICAgIHJlc3BvbnNlQm9keSA9IHRydW5jYXRlKHhoci5yZXNwb25zZVRleHQgfHwgXCJcIiwgTUFYX0JPRFlfTEVOR1RIKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKHhoci5yZXNwb25zZVR5cGUgPT09IFwianNvblwiKSB7XG4gICAgICAgICAgICAgICAgcmVzcG9uc2VCb2R5ID0gdHJ1bmNhdGUoc3RyaW5naWZ5VmFsdWUoeGhyLnJlc3BvbnNlKSwgTUFYX0JPRFlfTEVOR1RIKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHJlcG9ydGVyLnJlcG9ydE5vbkZhdGFsRXJyb3IoXCJGYWlsZWQgdG8gY2FwdHVyZSBYSFIgcmVzcG9uc2UgYm9keSBpbiBkZWJ1Z2dlciBpbnN0cnVtZW50YXRpb25cIiwgZXJyb3IpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBtZXRob2Q6IHN0YXRlLm1ldGhvZCxcbiAgICAgICAgICAgIHVybDogcmVkYWN0ZWRVcmwsXG4gICAgICAgICAgICBzdGF0dXM6IHhoci5zdGF0dXMsXG4gICAgICAgICAgICBkdXJhdGlvbjogRGF0ZS5ub3coKSAtIHN0YXRlLnN0YXJ0ZWRBdCxcbiAgICAgICAgICAgIHJlcXVlc3RIZWFkZXJzOiBzdGF0ZS5yZXF1ZXN0SGVhZGVycyxcbiAgICAgICAgICAgIHJlc3BvbnNlSGVhZGVycyxcbiAgICAgICAgICAgIHJlcXVlc3RCb2R5OiBzYW5pdGl6ZUNhcHR1cmVkQm9keShyZXF1ZXN0Qm9keSwgc3RhdGUucmVxdWVzdEhlYWRlcnNbXCJjb250ZW50LXR5cGVcIl0gPz8gXCJcIiksXG4gICAgICAgICAgICByZXNwb25zZUJvZHk6IHNhbml0aXplQ2FwdHVyZWRCb2R5KHJlc3BvbnNlQm9keSwgcmVzcG9uc2VDb250ZW50VHlwZSksXG4gICAgICAgIH07XG4gICAgfTtcbiAgICBjb25zdCBwb3N0WGhyTG9hZEVuZEV2ZW50ID0gKHhocikgPT4ge1xuICAgICAgICBzY2hlZHVsZUJhY2tncm91bmRUYXNrKHJlcG9ydGVyLCBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBwYXlsb2FkID0gYXdhaXQgYnVpbGRYaHJQb3N0UGF5bG9hZCh4aHIpO1xuICAgICAgICAgICAgaWYgKCFwYXlsb2FkKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcG9zdE5ldHdvcmsocGF5bG9hZCk7XG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3Qgb3JpZ2luYWxPcGVuID0gWE1MSHR0cFJlcXVlc3QucHJvdG90eXBlLm9wZW47XG4gICAgY29uc3Qgb3BlbldpdGhPcHRpb25hbEFyZ3MgPSBvcmlnaW5hbE9wZW47XG4gICAgWE1MSHR0cFJlcXVlc3QucHJvdG90eXBlLm9wZW4gPSBmdW5jdGlvbiAobWV0aG9kLCB1cmwsIGFzeW5jLCB1c2VybmFtZSwgcGFzc3dvcmQpIHtcbiAgICAgICAgY29uc3Qgbm9ybWFsaXplZE1ldGhvZCA9IHR5cGVvZiBtZXRob2QgPT09IFwic3RyaW5nXCIgPyBtZXRob2QgOiBcIkdFVFwiO1xuICAgICAgICBjb25zdCBub3JtYWxpemVkVXJsID0gdHlwZW9mIHVybCA9PT0gXCJzdHJpbmdcIiA/IHVybCA6IFN0cmluZyh1cmwgPz8gXCJcIik7XG4gICAgICAgIHhock1ldGFNYXAuc2V0KHRoaXMsIHtcbiAgICAgICAgICAgIG1ldGhvZDogbm9ybWFsaXplZE1ldGhvZCxcbiAgICAgICAgICAgIHVybDogbm9ybWFsaXplZFVybCxcbiAgICAgICAgICAgIHN0YXJ0ZWRBdDogRGF0ZS5ub3coKSxcbiAgICAgICAgICAgIHJlcXVlc3RCb2R5UHJvbWlzZTogUHJvbWlzZS5yZXNvbHZlKHVuZGVmaW5lZCksXG4gICAgICAgICAgICByZXF1ZXN0SGVhZGVyczoge30sXG4gICAgICAgIH0pO1xuICAgICAgICBpZiAodHlwZW9mIGFzeW5jID09PSBcImJvb2xlYW5cIiB8fFxuICAgICAgICAgICAgdHlwZW9mIHVzZXJuYW1lID09PSBcInN0cmluZ1wiIHx8XG4gICAgICAgICAgICB1c2VybmFtZSA9PT0gbnVsbCB8fFxuICAgICAgICAgICAgdHlwZW9mIHBhc3N3b3JkID09PSBcInN0cmluZ1wiIHx8XG4gICAgICAgICAgICBwYXNzd29yZCA9PT0gbnVsbCkge1xuICAgICAgICAgICAgcmV0dXJuIG9wZW5XaXRoT3B0aW9uYWxBcmdzLmNhbGwodGhpcywgbWV0aG9kLCB1cmwsIGFzeW5jID8/IHRydWUsIHVzZXJuYW1lLCBwYXNzd29yZCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG9wZW5XaXRoT3B0aW9uYWxBcmdzLmNhbGwodGhpcywgbWV0aG9kLCB1cmwpO1xuICAgIH07XG4gICAgY29uc3Qgb3JpZ2luYWxTZXRSZXF1ZXN0SGVhZGVyID0gWE1MSHR0cFJlcXVlc3QucHJvdG90eXBlLnNldFJlcXVlc3RIZWFkZXI7XG4gICAgWE1MSHR0cFJlcXVlc3QucHJvdG90eXBlLnNldFJlcXVlc3RIZWFkZXIgPSBmdW5jdGlvbiAoLi4uYXJncykge1xuICAgICAgICBjb25zdCBba2V5LCB2YWx1ZV0gPSBhcmdzO1xuICAgICAgICBjb25zdCBtZXRhID0geGhyTWV0YU1hcC5nZXQodGhpcyk7XG4gICAgICAgIGlmIChtZXRhKSB7XG4gICAgICAgICAgICBjb25zdCBub3JtYWxpemVkS2V5ID0ga2V5LnRyaW0oKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICAgICAgaWYgKCFzaG91bGRIaWRlSGVhZGVyKG5vcm1hbGl6ZWRLZXkpKSB7XG4gICAgICAgICAgICAgICAgbWV0YS5yZXF1ZXN0SGVhZGVyc1tub3JtYWxpemVkS2V5LnNsaWNlKDAsIE1BWF9IRUFERVJfTkFNRV9MRU5HVEgpXSA9XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlLnNsaWNlKDAsIE1BWF9IRUFERVJfVkFMVUVfTEVOR1RIKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gb3JpZ2luYWxTZXRSZXF1ZXN0SGVhZGVyLmFwcGx5KHRoaXMsIGFyZ3MpO1xuICAgIH07XG4gICAgY29uc3Qgb3JpZ2luYWxTZW5kID0gWE1MSHR0cFJlcXVlc3QucHJvdG90eXBlLnNlbmQ7XG4gICAgWE1MSHR0cFJlcXVlc3QucHJvdG90eXBlLnNlbmQgPSBmdW5jdGlvbiAoLi4uYXJncykge1xuICAgICAgICBkaWFnbm9zdGljcy5yZWNvcmRYaHJDYWxsKCk7XG4gICAgICAgIGNvbnN0IG1ldGEgPSB4aHJNZXRhTWFwLmdldCh0aGlzKTtcbiAgICAgICAgaWYgKG1ldGEpIHtcbiAgICAgICAgICAgIG1ldGEuc3RhcnRlZEF0ID0gRGF0ZS5ub3coKTtcbiAgICAgICAgICAgIG1ldGEucmVxdWVzdEJvZHlQcm9taXNlID0gZ2V0UmVxdWVzdEJvZHlQcmV2aWV3QXN5bmMocmVwb3J0ZXIsIGFyZ3NbMF0sIHN0cmluZ2lmeVZhbHVlLCBtZXRhLnJlcXVlc3RIZWFkZXJzW1wiY29udGVudC10eXBlXCJdID8/IFwiXCIpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuYWRkRXZlbnRMaXN0ZW5lcihcImxvYWRlbmRcIiwgKCkgPT4ge1xuICAgICAgICAgICAgcG9zdFhockxvYWRFbmRFdmVudCh0aGlzKTtcbiAgICAgICAgfSwge1xuICAgICAgICAgICAgb25jZTogdHJ1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBvcmlnaW5hbFNlbmQuYXBwbHkodGhpcywgYXJncyk7XG4gICAgfTtcbiAgICBkaWFnbm9zdGljcy5zZXRYaHJIb29rSW5zdGFsbGVkKCk7XG59O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9eGhyLmpzLm1hcCIsImltcG9ydCB7IGluc3RhbGxGZXRjaENhcHR1cmUgfSBmcm9tIFwiLi9mZXRjaC9pbnN0YWxsXCI7XG5pbXBvcnQgeyBpbnN0YWxsWGhyQ2FwdHVyZSB9IGZyb20gXCIuL3hoclwiO1xuZXhwb3J0IGZ1bmN0aW9uIGluc3RhbGxOZXR3b3JrQ2FwdHVyZShpbnB1dCkge1xuICAgIGluc3RhbGxGZXRjaENhcHR1cmUoaW5wdXQpO1xuICAgIGluc3RhbGxYaHJDYXB0dXJlKGlucHV0KTtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsImltcG9ydCB7IGluc3RhbGxBY3Rpb25BbmROYXZpZ2F0aW9uQ2FwdHVyZSB9IGZyb20gXCIuL2FjdGlvbnNcIjtcbmltcG9ydCB7IGluc3RhbGxDb25zb2xlQ2FwdHVyZSB9IGZyb20gXCIuL2NvbnNvbGVcIjtcbmltcG9ydCB7IElOU1RBTExfRkxBRyB9IGZyb20gXCIuL2NvbnN0YW50c1wiO1xuaW1wb3J0IHsgY3JlYXRlUGFnZURpYWdub3N0aWNzIH0gZnJvbSBcIi4vZGlhZ25vc3RpY3NcIjtcbmltcG9ydCB7IGNyZWF0ZUV2ZW50UXVldWUgfSBmcm9tIFwiLi9ldmVudC1xdWV1ZVwiO1xuaW1wb3J0IHsgaW5zdGFsbE5ldHdvcmtDYXB0dXJlIH0gZnJvbSBcIi4vbmV0d29ya1wiO1xuaW1wb3J0IHsgY3JlYXRlU3RyaW5naWZ5VmFsdWUgfSBmcm9tIFwiLi9zZXJpYWxpemVyXCI7XG5pbXBvcnQgeyBjcmVhdGVOb25GYXRhbFJlcG9ydGVyLCB0cnVuY2F0ZSB9IGZyb20gXCIuL3V0aWxzXCI7XG5leHBvcnQgZnVuY3Rpb24gaW5zdGFsbERlYnVnZ2VyUGFnZVJ1bnRpbWUoKSB7XG4gICAgY29uc3Qgc2NvcGUgPSB3aW5kb3c7XG4gICAgaWYgKHNjb3BlW0lOU1RBTExfRkxBR10pIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzY29wZVtJTlNUQUxMX0ZMQUddID0gdHJ1ZTtcbiAgICBjb25zdCBkaWFnbm9zdGljcyA9IGNyZWF0ZVBhZ2VEaWFnbm9zdGljcyh3aW5kb3cpO1xuICAgIGNvbnN0IHJlcG9ydGVyID0gZGlhZ25vc3RpY3MuY3JlYXRlUmVwb3J0ZXIoY3JlYXRlTm9uRmF0YWxSZXBvcnRlcigpKTtcbiAgICBjb25zdCB7IGVucXVldWVFdmVudCwgZmx1c2hFdmVudFF1ZXVlIH0gPSBjcmVhdGVFdmVudFF1ZXVlKHtcbiAgICAgICAgcmVjb3JkUXVldWVkRXZlbnQ6IGRpYWdub3N0aWNzLnJlY29yZFF1ZXVlZEV2ZW50LFxuICAgICAgICByZWNvcmRGbHVzaGVkQmF0Y2g6IGRpYWdub3N0aWNzLnJlY29yZEZsdXNoZWRCYXRjaCxcbiAgICB9KTtcbiAgICBjb25zdCBzdHJpbmdpZnlWYWx1ZSA9IGNyZWF0ZVN0cmluZ2lmeVZhbHVlKHJlcG9ydGVyKTtcbiAgICBjb25zdCBwb3N0QWN0aW9uID0gKGFjdGlvblR5cGUsIHRhcmdldCwgbWV0YWRhdGEpID0+IHtcbiAgICAgICAgZGlhZ25vc3RpY3MucmVjb3JkQWN0aW9uRXZlbnQoKTtcbiAgICAgICAgZW5xdWV1ZUV2ZW50KHtcbiAgICAgICAgICAgIGtpbmQ6IFwiYWN0aW9uXCIsXG4gICAgICAgICAgICB0aW1lc3RhbXA6IERhdGUubm93KCksXG4gICAgICAgICAgICBhY3Rpb25UeXBlLFxuICAgICAgICAgICAgdGFyZ2V0LFxuICAgICAgICAgICAgbWV0YWRhdGEsXG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3QgcG9zdENvbnNvbGUgPSAobGV2ZWwsIGFyZ3MpID0+IHtcbiAgICAgICAgZGlhZ25vc3RpY3MucmVjb3JkQ29uc29sZUV2ZW50KCk7XG4gICAgICAgIGNvbnN0IHNlcmlhbGl6ZWRBcmdzID0gW107XG4gICAgICAgIGZvciAoY29uc3QgYXJnIG9mIGFyZ3MpIHtcbiAgICAgICAgICAgIHNlcmlhbGl6ZWRBcmdzLnB1c2goc3RyaW5naWZ5VmFsdWUoYXJnKSk7XG4gICAgICAgIH1cbiAgICAgICAgZW5xdWV1ZUV2ZW50KHtcbiAgICAgICAgICAgIGtpbmQ6IFwiY29uc29sZVwiLFxuICAgICAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgICAgICAgbGV2ZWwsXG4gICAgICAgICAgICBtZXNzYWdlOiB0cnVuY2F0ZShzZXJpYWxpemVkQXJncy5qb2luKFwiIFwiKSksXG4gICAgICAgICAgICBtZXRhZGF0YToge1xuICAgICAgICAgICAgICAgIGFyZ3VtZW50Q291bnQ6IGFyZ3MubGVuZ3RoLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCBwb3N0TmV0d29yayA9IChwYXlsb2FkKSA9PiB7XG4gICAgICAgIGRpYWdub3N0aWNzLnJlY29yZE5ldHdvcmtFdmVudChwYXlsb2FkLnVybCk7XG4gICAgICAgIGVucXVldWVFdmVudCh7XG4gICAgICAgICAgICBraW5kOiBcIm5ldHdvcmtcIixcbiAgICAgICAgICAgIHRpbWVzdGFtcDogRGF0ZS5ub3coKSxcbiAgICAgICAgICAgIC4uLnBheWxvYWQsXG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgaW5zdGFsbEFjdGlvbkFuZE5hdmlnYXRpb25DYXB0dXJlKHtcbiAgICAgICAgcG9zdEFjdGlvbixcbiAgICB9KTtcbiAgICBpbnN0YWxsQ29uc29sZUNhcHR1cmUoe1xuICAgICAgICByZXBvcnRlcixcbiAgICAgICAgcG9zdENvbnNvbGUsXG4gICAgfSk7XG4gICAgdHJ5IHtcbiAgICAgICAgaW5zdGFsbE5ldHdvcmtDYXB0dXJlKHtcbiAgICAgICAgICAgIGRpYWdub3N0aWNzLFxuICAgICAgICAgICAgcmVwb3J0ZXIsXG4gICAgICAgICAgICBwb3N0TmV0d29yayxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXBvcnRlci5yZXBvcnROb25GYXRhbEVycm9yKFwiRmFpbGVkIHRvIGluc3RhbGwgbmV0d29yayBjYXB0dXJlIGluIGRlYnVnZ2VyIHJ1bnRpbWVcIiwgZXJyb3IpO1xuICAgIH1cbiAgICBjb25zdCBmbHVzaE9uUGFnZUhpZGUgPSAoKSA9PiB7XG4gICAgICAgIGZsdXNoRXZlbnRRdWV1ZSgpO1xuICAgIH07XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJwYWdlaGlkZVwiLCBmbHVzaE9uUGFnZUhpZGUsIHtcbiAgICAgICAgY2FwdHVyZTogdHJ1ZSxcbiAgICB9KTtcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwidmlzaWJpbGl0eWNoYW5nZVwiLCAoKSA9PiB7XG4gICAgICAgIGlmIChkb2N1bWVudC52aXNpYmlsaXR5U3RhdGUgPT09IFwiaGlkZGVuXCIpIHtcbiAgICAgICAgICAgIGZsdXNoRXZlbnRRdWV1ZSgpO1xuICAgICAgICB9XG4gICAgfSwge1xuICAgICAgICBjYXB0dXJlOiB0cnVlLFxuICAgICAgICBwYXNzaXZlOiB0cnVlLFxuICAgIH0pO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIiwiLy8jcmVnaW9uIHNyYy91dGlscy9kZWZpbmUtdW5saXN0ZWQtc2NyaXB0LnRzXG5mdW5jdGlvbiBkZWZpbmVVbmxpc3RlZFNjcmlwdChhcmcpIHtcblx0aWYgKGFyZyA9PSBudWxsIHx8IHR5cGVvZiBhcmcgPT09IFwiZnVuY3Rpb25cIikgcmV0dXJuIHsgbWFpbjogYXJnIH07XG5cdHJldHVybiBhcmc7XG59XG5cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgZGVmaW5lVW5saXN0ZWRTY3JpcHQgfTsiLCJpbXBvcnQgeyBpbnN0YWxsRGVidWdnZXJQYWdlUnVudGltZSB9IGZyb20gXCJAY3Jpa2tldC9jYXB0dXJlLWNvcmUvZGVidWdnZXIvZW5naW5lL3BhZ2VcIlxuaW1wb3J0IHsgZGVmaW5lVW5saXN0ZWRTY3JpcHQgfSBmcm9tIFwid3h0L3V0aWxzL2RlZmluZS11bmxpc3RlZC1zY3JpcHRcIlxuXG5leHBvcnQgZGVmYXVsdCBkZWZpbmVVbmxpc3RlZFNjcmlwdCgoKSA9PiB7XG4gIGluc3RhbGxEZWJ1Z2dlclBhZ2VSdW50aW1lKClcbn0pXG4iXSwibmFtZXMiOlsicmVzdWx0Il0sIm1hcHBpbmdzIjoiOztBQUFPLFFBQU0sY0FBYztBQUNwQixRQUFNLGVBQWU7QUFDckIsUUFBTSxrQkFBa0I7QUFDeEIsUUFBTSxrQkFBa0I7QUFDeEIsUUFBTSx5QkFBeUI7QUFDL0IsUUFBTSwwQkFBMEI7QUFDaEMsUUFBTSxpQkFBaUI7QUFDdkIsUUFBTSxvQkFBb0I7QUFDMUIsUUFBTSxzQkFBc0I7QUFDNUIsUUFBTSxxQkFBcUI7QUFDM0IsUUFBTSw0QkFBNEI7QUNUekMsUUFBTSxpQkFBaUI7QUFDdkIsUUFBTSwwQkFBMEI7QUFBQSxJQUM1QjtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUNKO0FBQ0EsUUFBTSwyQkFBMkI7QUFDMUIsUUFBTSxXQUFXLENBQUMsT0FBTyxZQUFZLG9CQUFvQjtBQUM1RCxRQUFJLE1BQU0sVUFBVSxXQUFXO0FBQzNCLGFBQU87QUFBQSxJQUNYO0FBQ0EsV0FBTyxHQUFHLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQztBQUFBLEVBQ3ZDO0FBQ08sUUFBTSxrQkFBa0IsQ0FBQyxVQUFVO0FBQ3RDLFVBQU0sa0JBQWtCLE1BQU0sS0FBSSxFQUFHLFlBQVc7QUFDaEQsUUFBSSxDQUFDLGlCQUFpQjtBQUNsQixhQUFPO0FBQUEsSUFDWDtBQUNBLFdBQU8sd0JBQXdCLEtBQUssQ0FBQyxZQUFZO0FBQzdDLGFBQU8sZ0JBQWdCLFNBQVMsT0FBTztBQUFBLElBQzNDLENBQUM7QUFBQSxFQUNMO0FBQ08sUUFBTSxtQkFBbUIsQ0FBQyxlQUFlO0FBQzVDLFdBQU8sV0FBVyxTQUFTLFVBQVUsS0FBSyxnQkFBZ0IsVUFBVTtBQUFBLEVBQ3hFO0FBQ08sUUFBTSxtQkFBbUIsQ0FBQyxXQUFXO0FBQ3hDLFFBQUksRUFBRSxrQkFBa0IsVUFBVTtBQUM5QixhQUFPO0FBQUEsSUFDWDtBQUNBLFFBQUksT0FBTyxJQUFJO0FBQ1gsYUFBTyxJQUFJLE9BQU8sRUFBRTtBQUFBLElBQ3hCO0FBQ0EsVUFBTSxhQUFhLE9BQU8sT0FBTyxjQUFjLFdBQVcsT0FBTyxZQUFZO0FBQzdFLFVBQU0sYUFBYSxXQUNkLE1BQU0sR0FBRyxFQUNULElBQUksQ0FBQyxVQUFVLE1BQU0sS0FBSSxDQUFFLEVBQzNCLEtBQUssQ0FBQyxVQUFVLE1BQU0sU0FBUyxDQUFDO0FBQ3JDLFFBQUksWUFBWTtBQUNaLGFBQU8sR0FBRyxPQUFPLFFBQVEsWUFBVyxDQUFFLElBQUksVUFBVTtBQUFBLElBQ3hEO0FBQ0EsV0FBTyxPQUFPLFFBQVEsWUFBVztBQUFBLEVBQ3JDO0FBQ08sUUFBTSxnQkFBZ0IsQ0FBQyxPQUFPLGFBQWE7QUFDOUMsUUFBSTtBQUNBLGFBQU8sSUFBSSxJQUFJLE9BQU8sU0FBUyxJQUFJLEVBQUUsU0FBUTtBQUFBLElBQ2pELFNBQ08sT0FBTztBQUNWLGVBQVMsb0JBQW9CLCtEQUErRDtBQUFBLFFBQ3hGO0FBQUEsUUFDQTtBQUFBLE1BQ1osQ0FBUztBQUNELGFBQU87QUFBQSxJQUNYO0FBQUEsRUFDSjtBQUNPLFFBQU0sNkJBQTZCLENBQUMsZ0JBQWdCO0FBQ3ZELFFBQUk7QUFDQSxZQUFNLFlBQVksSUFBSSxJQUFJLFdBQVc7QUFDckMsaUJBQVcsQ0FBQyxHQUFHLEtBQUssVUFBVSxhQUFhLFFBQU8sR0FBSTtBQUNsRCxZQUFJLENBQUMsZ0JBQWdCLEdBQUcsR0FBRztBQUN2QjtBQUFBLFFBQ0o7QUFDQSxrQkFBVSxhQUFhLElBQUksS0FBSyxjQUFjO0FBQUEsTUFDbEQ7QUFDQSxhQUFPLFVBQVUsU0FBUTtBQUFBLElBQzdCLFFBQ007QUFDRixhQUFPO0FBQUEsSUFDWDtBQUFBLEVBQ0o7QUFDQSxRQUFNLDBCQUEwQixDQUFDLE9BQU8sUUFBUSxNQUFNO0FBQ2xELFFBQUksU0FBUyxHQUFHO0FBQ1osYUFBTztBQUFBLElBQ1g7QUFDQSxRQUFJLE1BQU0sUUFBUSxLQUFLLEdBQUc7QUFDdEIsYUFBTyxNQUFNLElBQUksQ0FBQyxTQUFTLHdCQUF3QixNQUFNLFFBQVEsQ0FBQyxDQUFDO0FBQUEsSUFDdkU7QUFDQSxRQUFJLFNBQVMsT0FBTyxVQUFVLFVBQVU7QUFDcEMsWUFBTUEsVUFBUyxDQUFBO0FBQ2YsaUJBQVcsQ0FBQyxLQUFLLFdBQVcsS0FBSyxPQUFPLFFBQVEsS0FBSyxHQUFHO0FBQ3BELFlBQUksZ0JBQWdCLEdBQUcsR0FBRztBQUN0QixVQUFBQSxRQUFPLEdBQUcsSUFBSTtBQUNkO0FBQUEsUUFDSjtBQUNBLFFBQUFBLFFBQU8sR0FBRyxJQUFJLHdCQUF3QixhQUFhLFFBQVEsQ0FBQztBQUFBLE1BQ2hFO0FBQ0EsYUFBT0E7QUFBQSxJQUNYO0FBQ0EsUUFBSSxPQUFPLFVBQVUsVUFBVTtBQUMzQixhQUFPLE1BQU0sUUFBUSwwQkFBMEIsS0FBSyxjQUFjLEVBQUU7QUFBQSxJQUN4RTtBQUNBLFdBQU87QUFBQSxFQUNYO0FBQ0EsUUFBTSx5QkFBeUIsQ0FBQyxTQUFTO0FBQ3JDLFVBQU0sU0FBUyxJQUFJLGdCQUFnQixJQUFJO0FBQ3ZDLGVBQVcsQ0FBQyxHQUFHLEtBQUssT0FBTyxRQUFPLEdBQUk7QUFDbEMsVUFBSSxDQUFDLGdCQUFnQixHQUFHLEdBQUc7QUFDdkI7QUFBQSxNQUNKO0FBQ0EsYUFBTyxJQUFJLEtBQUssY0FBYztBQUFBLElBQ2xDO0FBQ0EsV0FBTyxPQUFPLFNBQVE7QUFBQSxFQUMxQjtBQUNPLFFBQU0sdUJBQXVCLENBQUMsTUFBTSxnQkFBZ0I7QUFDdkQsUUFBSSxPQUFPLFNBQVMsWUFBWSxLQUFLLFdBQVcsR0FBRztBQUMvQyxhQUFPO0FBQUEsSUFDWDtBQUNBLFVBQU0sd0JBQXdCLFlBQVksWUFBVztBQUNyRCxRQUFJLHNCQUFzQixTQUFTLGtCQUFrQixHQUFHO0FBQ3BELFVBQUk7QUFDQSxjQUFNLFNBQVMsS0FBSyxNQUFNLElBQUk7QUFDOUIsZUFBTyxTQUFTLEtBQUssVUFBVSx3QkFBd0IsTUFBTSxDQUFDLEdBQUcsa0JBQWtCLENBQUM7QUFBQSxNQUN4RixRQUNNO0FBQ0YsZUFBTyxTQUFTLEtBQUssUUFBUSwwQkFBMEIsS0FBSyxjQUFjLEVBQUUsR0FBRyxrQkFBa0IsQ0FBQztBQUFBLE1BQ3RHO0FBQUEsSUFDSjtBQUNBLFFBQUksc0JBQXNCLFNBQVMsdUJBQXVCLEdBQUc7QUFDekQsYUFBTyxTQUFTLHVCQUF1QixJQUFJLEdBQUcsa0JBQWtCLENBQUM7QUFBQSxJQUNyRTtBQUNBLFdBQU8sU0FBUyxLQUFLLFFBQVEsMEJBQTBCLEtBQUssY0FBYyxFQUFFLEdBQUcsa0JBQWtCLENBQUM7QUFBQSxFQUN0RztBQUNPLFdBQVMseUJBQXlCO0FBQ3JDLFVBQU0sc0JBQXNCLFFBQVEsS0FBSyxLQUFLLE9BQU87QUFDckQsVUFBTSxtQkFBbUIsb0JBQUksSUFBRztBQUNoQyxXQUFPO0FBQUEsTUFDSCxvQkFBb0IsU0FBUyxPQUFPO0FBQ2hDLFlBQUksaUJBQWlCLElBQUksT0FBTyxHQUFHO0FBQy9CO0FBQUEsUUFDSjtBQUNBLHlCQUFpQixJQUFJLE9BQU87QUFDNUIsNEJBQW9CLGVBQWUsT0FBTyxJQUFJLEtBQUs7QUFBQSxNQUN2RDtBQUFBLElBQ1I7QUFBQSxFQUNBO0FDdEpPLFdBQVMsa0NBQWtDLE9BQU87QUFDckQsVUFBTSxFQUFFLFdBQVUsSUFBSztBQUN2QixVQUFNLDJCQUEyQixDQUFDLFNBQVM7QUFDdkMsaUJBQVcsY0FBYyxVQUFVO0FBQUEsUUFDL0I7QUFBQSxRQUNBLEtBQUssU0FBUztBQUFBLFFBQ2QsTUFBTSxTQUFTO0FBQUEsUUFDZixRQUFRLFNBQVM7QUFBQSxRQUNqQixNQUFNLFNBQVM7QUFBQSxRQUNmLE9BQU8sU0FBUztBQUFBLE1BQzVCLENBQVM7QUFBQSxJQUNMO0FBQ0EsVUFBTSxvQkFBb0I7QUFBQSxNQUN0QixPQUFPLENBQUMsVUFBVTtBQUNkLG1CQUFXLFNBQVMsaUJBQWlCLE1BQU0sTUFBTSxDQUFDO0FBQUEsTUFDdEQ7QUFBQSxNQUNBLE9BQU8sQ0FBQyxVQUFVO0FBQ2QsY0FBTSxTQUFTLGlCQUFpQixNQUFNLE1BQU07QUFDNUMsWUFBSTtBQUNKLGNBQU0sY0FBYyxNQUFNO0FBQzFCLFlBQUksdUJBQXVCLG9CQUN2Qix1QkFBdUIscUJBQXFCO0FBQzVDLHdCQUFjLFlBQVksTUFBTTtBQUFBLFFBQ3BDO0FBQ0EsbUJBQVcsU0FBUyxRQUFRO0FBQUEsVUFDeEI7QUFBQSxRQUNoQixDQUFhO0FBQUEsTUFDTDtBQUFBLE1BQ0EsUUFBUSxDQUFDLFVBQVU7QUFDZixtQkFBVyxVQUFVLGlCQUFpQixNQUFNLE1BQU0sQ0FBQztBQUFBLE1BQ3ZEO0FBQUEsSUFDUjtBQUNJLFVBQU0sb0JBQW9CLENBQUMsVUFBVTtBQUNqQyxVQUFJLE1BQU0sU0FBUyxXQUNmLE1BQU0sU0FBUyxXQUNmLE1BQU0sU0FBUyxVQUFVO0FBQ3pCO0FBQUEsTUFDSjtBQUNBLHdCQUFrQixNQUFNLElBQUksRUFBRSxLQUFLO0FBQUEsSUFDdkM7QUFDQSxlQUFXLGFBQWEsQ0FBQyxTQUFTLFNBQVMsUUFBUSxHQUFHO0FBQ2xELGVBQVMsaUJBQWlCLFdBQVcsbUJBQW1CO0FBQUEsUUFDcEQsU0FBUztBQUFBLFFBQ1QsU0FBUztBQUFBLE1BQ3JCLENBQVM7QUFBQSxJQUNMO0FBQ0EsVUFBTSxvQkFBb0IsUUFBUTtBQUNsQyxZQUFRLFlBQVksWUFBYSxNQUFNO0FBQ25DLHdCQUFrQixNQUFNLE1BQU0sSUFBSTtBQUNsQywrQkFBeUIsV0FBVztBQUFBLElBQ3hDO0FBQ0EsVUFBTSx1QkFBdUIsUUFBUTtBQUNyQyxZQUFRLGVBQWUsWUFBYSxNQUFNO0FBQ3RDLDJCQUFxQixNQUFNLE1BQU0sSUFBSTtBQUNyQywrQkFBeUIsY0FBYztBQUFBLElBQzNDO0FBQ0EsV0FBTyxpQkFBaUIsWUFBWSxNQUFNO0FBQ3RDLCtCQUF5QixVQUFVO0FBQUEsSUFDdkMsR0FBRztBQUFBLE1BQ0MsU0FBUztBQUFBLE1BQ1QsU0FBUztBQUFBLElBQ2pCLENBQUs7QUFDRCxXQUFPLGlCQUFpQixjQUFjLE1BQU07QUFDeEMsK0JBQXlCLFlBQVk7QUFBQSxJQUN6QyxHQUFHO0FBQUEsTUFDQyxTQUFTO0FBQUEsTUFDVCxTQUFTO0FBQUEsSUFDakIsQ0FBSztBQUNELDZCQUF5QixTQUFTO0FBQUEsRUFDdEM7QUN0RU8sV0FBUyxzQkFBc0IsT0FBTztBQUN6QyxVQUFNLEVBQUUsVUFBVSxZQUFXLElBQUs7QUFDbEMsVUFBTSxnQkFBZ0I7QUFBQSxNQUNsQjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNSO0FBQ0ksZUFBVyxTQUFTLGVBQWU7QUFDL0IsWUFBTSxXQUFXLFFBQVEsS0FBSyxFQUFFLEtBQUssT0FBTztBQUM1QyxjQUFRLEtBQUssSUFBSSxJQUFJLFNBQVM7QUFDMUIsWUFBSTtBQUNBLHNCQUFZLE9BQU8sSUFBSTtBQUFBLFFBQzNCLFNBQ08sT0FBTztBQUNWLG1CQUFTLG9CQUFvQiw0REFBNEQsS0FBSztBQUFBLFFBQ2xHO0FBQ0EsaUJBQVMsR0FBRyxJQUFJO0FBQUEsTUFDcEI7QUFBQSxJQUNKO0FBQUEsRUFDSjtBQ3BCQSxRQUFNLGtCQUFrQjtBQUN4QixRQUFNLHNCQUFzQjtBQUM1QixRQUFNLG9CQUFvQjtBQUMxQixRQUFNLG1CQUFtQjtBQUN6QixRQUFNLGdDQUFnQyxNQUFNO0FBQ3hDLFdBQU87QUFBQSxNQUNILFNBQVM7QUFBQSxNQUNULGFBQWEsS0FBSyxJQUFHO0FBQUEsTUFDckIsS0FBSyxTQUFTO0FBQUEsTUFDZCxPQUFPO0FBQUEsUUFDSCxPQUFPO0FBQUEsUUFDUCxLQUFLO0FBQUEsTUFDakI7QUFBQSxNQUNRLFVBQVU7QUFBQSxRQUNOLGNBQWM7QUFBQSxRQUNkLGVBQWU7QUFBQSxRQUNmLGVBQWU7QUFBQSxRQUNmLFlBQVk7QUFBQSxRQUNaLGVBQWU7QUFBQSxRQUNmLFVBQVU7QUFBQSxRQUNWLGNBQWM7QUFBQSxRQUNkLGdCQUFnQjtBQUFBLE1BQzVCO0FBQUEsTUFDUSxNQUFNLENBQUE7QUFBQSxNQUNOLFFBQVEsQ0FBQTtBQUFBLElBQ2hCO0FBQUEsRUFDQTtBQUNBLFFBQU0saUJBQWlCLENBQUMsU0FBUyxVQUFVO0FBQ3ZDLFFBQUksaUJBQWlCLE9BQU87QUFDeEIsYUFBTyxHQUFHLE9BQU8sS0FBSyxNQUFNLE9BQU87QUFBQSxJQUN2QztBQUNBLFdBQU8sR0FBRyxPQUFPLEtBQUssT0FBTyxLQUFLLENBQUM7QUFBQSxFQUN2QztBQUNPLFdBQVMsc0JBQXNCLE9BQU87QUFDekMsVUFBTSxlQUFlO0FBQ3JCLFVBQU0sUUFBUSxhQUFhLGVBQWUsS0FBSyw4QkFBNkI7QUFDNUUsaUJBQWEsZUFBZSxJQUFJO0FBQ2hDLFVBQU0sY0FBYyxLQUFLLElBQUc7QUFDNUIsVUFBTSxNQUFNLFNBQVM7QUFDckIsVUFBTSxNQUFNLFFBQVE7QUFDcEIsVUFBTSxNQUFNLE1BQU07QUFDbEIsV0FBTztBQUFBLE1BQ0g7QUFBQSxNQUNBLGVBQWUsVUFBVTtBQUNyQixjQUFNLGlCQUFpQixTQUFTLG9CQUFvQixLQUFLLFFBQVE7QUFDakUsZUFBTztBQUFBLFVBQ0gsb0JBQW9CLFNBQVMsT0FBTztBQUNoQyxrQkFBTSxPQUFPLEtBQUssU0FBUyxlQUFlLFNBQVMsS0FBSyxHQUFHLGdCQUFnQixDQUFDO0FBQzVFLGdCQUFJLE1BQU0sT0FBTyxTQUFTLG1CQUFtQjtBQUN6QyxvQkFBTSxPQUFPLE1BQUs7QUFBQSxZQUN0QjtBQUNBLDJCQUFlLFNBQVMsS0FBSztBQUFBLFVBQ2pDO0FBQUEsUUFDaEI7QUFBQSxNQUNRO0FBQUEsTUFDQSxvQkFBb0I7QUFDaEIsY0FBTSxTQUFTLGdCQUFnQjtBQUFBLE1BQ25DO0FBQUEsTUFDQSxxQkFBcUI7QUFDakIsY0FBTSxTQUFTLGlCQUFpQjtBQUFBLE1BQ3BDO0FBQUEsTUFDQSxtQkFBbUIsS0FBSztBQUNwQixjQUFNLFNBQVMsaUJBQWlCO0FBQ2hDLGNBQU0sS0FBSyxhQUFhO0FBQUEsTUFDNUI7QUFBQSxNQUNBLGtCQUFrQjtBQUNkLGNBQU0sU0FBUyxjQUFjO0FBQUEsTUFDakM7QUFBQSxNQUNBLG1CQUFtQixTQUFTO0FBQ3hCLGNBQU0sU0FBUyxpQkFBaUI7QUFDaEMsY0FBTSxLQUFLLGFBQWE7QUFBQSxNQUM1QjtBQUFBLE1BQ0Esa0JBQWtCLFdBQVc7QUFDekIsY0FBTSxNQUFNLFFBQVE7QUFBQSxNQUN4QjtBQUFBLE1BQ0EsZ0JBQWdCO0FBQ1osY0FBTSxTQUFTLFlBQVk7QUFBQSxNQUMvQjtBQUFBLE1BQ0Esc0JBQXNCO0FBQ2xCLGNBQU0sTUFBTSxNQUFNO0FBQUEsTUFDdEI7QUFBQSxNQUNBLG9CQUFvQjtBQUNoQixjQUFNLFNBQVMsZ0JBQWdCO0FBQUEsTUFDbkM7QUFBQSxNQUNBLHFCQUFxQjtBQUNqQixjQUFNLFNBQVMsa0JBQWtCO0FBQUEsTUFDckM7QUFBQSxJQUNSO0FBQUEsRUFDQTtBQ3hGTyxXQUFTLGlCQUFpQixRQUFRLElBQUk7QUFDekMsVUFBTSxFQUFFLG9CQUFvQixrQkFBaUIsSUFBSztBQUNsRCxVQUFNLGFBQWEsQ0FBQTtBQUNuQixRQUFJLGFBQWE7QUFDakIsVUFBTSxrQkFBa0IsTUFBTTtBQUMxQixtQkFBYTtBQUNiLFVBQUksV0FBVyxXQUFXLEdBQUc7QUFDekI7QUFBQSxNQUNKO0FBQ0EsWUFBTSxnQkFBZ0IsV0FBVyxPQUFPLEdBQUcsY0FBYztBQUN6RCwyQkFBa0I7QUFDbEIsYUFBTyxZQUFZO0FBQUEsUUFDZixRQUFRO0FBQUEsUUFDUixRQUFRO0FBQUEsTUFDcEIsR0FBVyxHQUFHO0FBQ04sVUFBSSxXQUFXLFNBQVMsR0FBRztBQUN2QixxQkFBYSxXQUFXLGlCQUFpQixDQUFDO0FBQzFDO0FBQUEsTUFDSjtBQUFBLElBQ0o7QUFDQSxVQUFNLHFCQUFxQixNQUFNO0FBQzdCLFVBQUksWUFBWTtBQUNaO0FBQUEsTUFDSjtBQUNBLG1CQUFhLFdBQVcsaUJBQWlCLGlCQUFpQjtBQUFBLElBQzlEO0FBQ0EsVUFBTSxlQUFlLENBQUMsVUFBVTtBQUM1QixpQkFBVyxLQUFLLEtBQUs7QUFDckIsMEJBQWlCO0FBQ2pCLFVBQUksV0FBVyxVQUFVLGdCQUFnQjtBQUNyQyxZQUFJLFlBQVk7QUFDWix1QkFBYSxVQUFVO0FBQUEsUUFDM0I7QUFDQSxxQkFBYSxXQUFXLGlCQUFpQixDQUFDO0FBQzFDO0FBQUEsTUFDSjtBQUNBLHlCQUFrQjtBQUFBLElBQ3RCO0FBQ0EsV0FBTztBQUFBLE1BQ0g7QUFBQSxNQUNBO0FBQUEsSUFDUjtBQUFBLEVBQ0E7QUN6Q0EsUUFBTSxxQkFBcUIsQ0FBQyxVQUFVO0FBQ2xDLFFBQUksVUFBVSxRQUNWLE9BQU8sVUFBVSxhQUNqQixPQUFPLFVBQVUsVUFBVTtBQUMzQixhQUFPO0FBQUEsUUFDSCxTQUFTO0FBQUEsUUFDVDtBQUFBLE1BQ1o7QUFBQSxJQUNJO0FBQ0EsUUFBSSxPQUFPLFVBQVUsVUFBVTtBQUMzQixhQUFPO0FBQUEsUUFDSCxTQUFTO0FBQUEsUUFDVCxPQUFPLFNBQVMsS0FBSztBQUFBLE1BQ2pDO0FBQUEsSUFDSTtBQUNBLFFBQUksT0FBTyxVQUFVLGFBQWE7QUFDOUIsYUFBTztBQUFBLFFBQ0gsU0FBUztBQUFBLFFBQ1QsT0FBTztBQUFBLE1BQ25CO0FBQUEsSUFDSTtBQUNBLFFBQUksT0FBTyxVQUFVLFVBQVU7QUFDM0IsYUFBTztBQUFBLFFBQ0gsU0FBUztBQUFBLFFBQ1QsT0FBTyxHQUFHLE1BQU0sU0FBUSxDQUFFO0FBQUEsTUFDdEM7QUFBQSxJQUNJO0FBQ0EsUUFBSSxPQUFPLFVBQVUsVUFBVTtBQUMzQixhQUFPO0FBQUEsUUFDSCxTQUFTO0FBQUEsUUFDVCxPQUFPLE1BQU0sU0FBUTtBQUFBLE1BQ2pDO0FBQUEsSUFDSTtBQUNBLFFBQUksT0FBTyxVQUFVLFlBQVk7QUFDN0IsYUFBTztBQUFBLFFBQ0gsU0FBUztBQUFBLFFBQ1QsT0FBTyxhQUFhLE1BQU0sUUFBUSxXQUFXO0FBQUEsTUFDekQ7QUFBQSxJQUNJO0FBQ0EsV0FBTztBQUFBLE1BQ0gsU0FBUztBQUFBLElBQ2pCO0FBQUEsRUFDQTtBQUNBLFFBQU0saUJBQWlCLENBQUMsVUFBVTtBQUM5QixXQUFPO0FBQUEsTUFDSCxNQUFNLE1BQU07QUFBQSxNQUNaLFNBQVMsU0FBUyxNQUFNLE9BQU87QUFBQSxNQUMvQixPQUFPLE9BQU8sTUFBTSxVQUFVLFdBQVcsU0FBUyxNQUFNLEtBQUssSUFBSTtBQUFBLElBQ3pFO0FBQUEsRUFDQTtBQUNBLFFBQU0scUJBQXFCLENBQUMsVUFBVTtBQUNsQyxXQUFPLE9BQU8sZ0JBQWdCLGVBQWUsaUJBQWlCO0FBQUEsRUFDbEU7QUFDQSxRQUFNLHlCQUF5QixDQUFDLFVBQVU7QUFDdEMsV0FBTyxPQUFPLGdCQUFnQixlQUFlLFlBQVksT0FBTyxLQUFLO0FBQUEsRUFDekU7QUFDQSxRQUFNLGlCQUFpQixDQUFDLE9BQU8sT0FBTyxPQUFPLE1BQU0sbUJBQW1CO0FBQ2xFLFVBQU0sYUFBYSxDQUFBO0FBQ25CLFVBQU0sUUFBUSxLQUFLLElBQUksTUFBTSxRQUFRLHlCQUF5QjtBQUM5RCxhQUFTLFFBQVEsR0FBRyxRQUFRLE9BQU8sU0FBUyxHQUFHO0FBQzNDLGlCQUFXLEtBQUssZUFBZSxNQUFNLEtBQUssR0FBRyxPQUFPLFFBQVEsR0FBRyxHQUFHLElBQUksSUFBSSxLQUFLLEdBQUcsQ0FBQztBQUFBLElBQ3ZGO0FBQ0EsUUFBSSxNQUFNLFNBQVMsT0FBTztBQUN0QixpQkFBVyxLQUFLLEtBQUssTUFBTSxTQUFTLEtBQUssUUFBUTtBQUFBLElBQ3JEO0FBQ0EsV0FBTztBQUFBLEVBQ1g7QUFDQSxRQUFNLGVBQWUsQ0FBQyxPQUFPLE9BQU8sT0FBTyxNQUFNLG1CQUFtQjtBQUNoRSxVQUFNLFVBQVUsQ0FBQTtBQUNoQixRQUFJLFFBQVE7QUFDWixlQUFXLENBQUMsVUFBVSxVQUFVLEtBQUssTUFBTSxRQUFPLEdBQUk7QUFDbEQsVUFBSSxTQUFTLG9CQUFvQjtBQUM3QixnQkFBUSxLQUFLLEtBQUssTUFBTSxPQUFPLEtBQUssUUFBUTtBQUM1QztBQUFBLE1BQ0o7QUFDQSxjQUFRLEtBQUs7QUFBQSxRQUNULGVBQWUsVUFBVSxPQUFPLFFBQVEsR0FBRyxHQUFHLElBQUksVUFBVSxLQUFLLEVBQUU7QUFBQSxRQUNuRSxlQUFlLFlBQVksT0FBTyxRQUFRLEdBQUcsR0FBRyxJQUFJLFVBQVUsS0FBSyxFQUFFO0FBQUEsTUFDakYsQ0FBUztBQUNELGVBQVM7QUFBQSxJQUNiO0FBQ0EsV0FBTztBQUFBLE1BQ0gsTUFBTTtBQUFBLE1BQ047QUFBQSxJQUNSO0FBQUEsRUFDQTtBQUNBLFFBQU0sZUFBZSxDQUFDLE9BQU8sT0FBTyxPQUFPLE1BQU0sbUJBQW1CO0FBQ2hFLFVBQU0sVUFBVSxDQUFBO0FBQ2hCLFFBQUksUUFBUTtBQUNaLGVBQVcsU0FBUyxNQUFNLFVBQVU7QUFDaEMsVUFBSSxTQUFTLG9CQUFvQjtBQUM3QixnQkFBUSxLQUFLLEtBQUssTUFBTSxPQUFPLEtBQUssUUFBUTtBQUM1QztBQUFBLE1BQ0o7QUFDQSxjQUFRLEtBQUssZUFBZSxPQUFPLE9BQU8sUUFBUSxHQUFHLEdBQUcsSUFBSSxVQUFVLEtBQUssRUFBRSxDQUFDO0FBQzlFLGVBQVM7QUFBQSxJQUNiO0FBQ0EsV0FBTztBQUFBLE1BQ0gsTUFBTTtBQUFBLE1BQ04sUUFBUTtBQUFBLElBQ2hCO0FBQUEsRUFDQTtBQUNBLFFBQU0sd0JBQXdCLENBQUMsT0FBTyxPQUFPLE9BQU8sTUFBTSxtQkFBbUI7QUFDekUsVUFBTUEsVUFBUyxDQUFBO0FBQ2YsVUFBTSxVQUFVLE9BQU8sUUFBUSxLQUFLO0FBQ3BDLFVBQU0sUUFBUSxLQUFLLElBQUksUUFBUSxRQUFRLGtCQUFrQjtBQUN6RCxhQUFTLFFBQVEsR0FBRyxRQUFRLE9BQU8sU0FBUyxHQUFHO0FBQzNDLFlBQU0sQ0FBQyxVQUFVLFVBQVUsSUFBSSxRQUFRLEtBQUssS0FBSyxDQUFBO0FBQ2pELFVBQUksT0FBTyxhQUFhLFVBQVU7QUFDOUI7QUFBQSxNQUNKO0FBQ0EsTUFBQUEsUUFBTyxRQUFRLElBQUksZUFBZSxZQUFZLE9BQU8sUUFBUSxHQUFHLEdBQUcsSUFBSSxJQUFJLFFBQVEsRUFBRTtBQUFBLElBQ3pGO0FBQ0EsUUFBSSxRQUFRLFNBQVMsT0FBTztBQUN4QixNQUFBQSxRQUFPLGtCQUFrQixRQUFRLFNBQVM7QUFBQSxJQUM5QztBQUNBLFdBQU9BO0FBQUEsRUFDWDtBQUNBLFFBQU0sb0JBQW9CO0FBQUEsSUFDdEI7QUFBQSxNQUNJLFdBQVcsQ0FBQyxVQUFVLGlCQUFpQjtBQUFBLE1BQ3ZDLFdBQVcsQ0FBQyxVQUFVLGVBQWUsS0FBSztBQUFBLElBQ2xEO0FBQUEsSUFDSTtBQUFBLE1BQ0ksV0FBVyxDQUFDLFVBQVUsaUJBQWlCO0FBQUEsTUFDdkMsV0FBVyxDQUFDLFVBQVUsTUFBTSxZQUFXO0FBQUEsSUFDL0M7QUFBQSxJQUNJO0FBQUEsTUFDSSxXQUFXLENBQUMsVUFBVSxpQkFBaUI7QUFBQSxNQUN2QyxXQUFXLENBQUMsVUFBVSxNQUFNLFNBQVE7QUFBQSxJQUM1QztBQUFBLElBQ0k7QUFBQSxNQUNJLFdBQVcsQ0FBQyxVQUFVLE9BQU8sUUFBUSxlQUFlLGlCQUFpQjtBQUFBLE1BQ3JFLFdBQVcsQ0FBQyxVQUFVLE1BQU0sU0FBUTtBQUFBLElBQzVDO0FBQUEsSUFDSTtBQUFBLE1BQ0ksV0FBVyxDQUFDLFVBQVUsT0FBTyxZQUFZLGVBQWUsaUJBQWlCO0FBQUEsTUFDekUsV0FBVyxDQUFDLFVBQVU7QUFDbEIsY0FBTSxVQUFVO0FBQ2hCLGVBQU8saUJBQWlCLE9BQU8sS0FBSyxRQUFRLFFBQVEsWUFBVztBQUFBLE1BQ25FO0FBQUEsSUFDUjtBQUFBLElBQ0k7QUFBQSxNQUNJLFdBQVcsQ0FBQyxVQUFVLE9BQU8sVUFBVSxlQUFlLGlCQUFpQjtBQUFBLE1BQ3ZFLFdBQVcsQ0FBQyxVQUFVO0FBQ2xCLGNBQU0sUUFBUTtBQUNkLGVBQU87QUFBQSxVQUNILE1BQU0sTUFBTTtBQUFBLFVBQ1osUUFBUSxpQkFBaUIsTUFBTSxNQUFNO0FBQUEsUUFDckQ7QUFBQSxNQUNRO0FBQUEsSUFDUjtBQUFBLElBQ0k7QUFBQSxNQUNJLFdBQVcsQ0FBQyxVQUFVLE1BQU0sUUFBUSxLQUFLO0FBQUEsTUFDekMsV0FBVyxDQUFDLE9BQU8sT0FBTyxPQUFPLE1BQU0sbUJBQW1CLGVBQWUsT0FBTyxPQUFPLE9BQU8sTUFBTSxjQUFjO0FBQUEsSUFDMUg7QUFBQSxJQUNJO0FBQUEsTUFDSSxXQUFXLENBQUMsVUFBVSxpQkFBaUI7QUFBQSxNQUN2QyxXQUFXLENBQUMsT0FBTyxPQUFPLE9BQU8sTUFBTSxtQkFBbUIsYUFBYSxPQUFPLE9BQU8sT0FBTyxNQUFNLGNBQWM7QUFBQSxJQUN4SDtBQUFBLElBQ0k7QUFBQSxNQUNJLFdBQVcsQ0FBQyxVQUFVLGlCQUFpQjtBQUFBLE1BQ3ZDLFdBQVcsQ0FBQyxPQUFPLE9BQU8sT0FBTyxNQUFNLG1CQUFtQixhQUFhLE9BQU8sT0FBTyxPQUFPLE1BQU0sY0FBYztBQUFBLElBQ3hIO0FBQUEsSUFDSTtBQUFBLE1BQ0ksV0FBVyxDQUFDLFVBQVUsbUJBQW1CLEtBQUs7QUFBQSxNQUM5QyxXQUFXLENBQUMsVUFBVSxnQkFBZ0IsTUFBTSxVQUFVO0FBQUEsSUFDOUQ7QUFBQSxJQUNJO0FBQUEsTUFDSSxXQUFXLENBQUMsVUFBVSx1QkFBdUIsS0FBSztBQUFBLE1BQ2xELFdBQVcsQ0FBQyxVQUFVO0FBQ2xCLGNBQU0sYUFBYTtBQUNuQixlQUFPLElBQUksV0FBVyxZQUFZLElBQUksSUFBSSxXQUFXLFVBQVU7QUFBQSxNQUNuRTtBQUFBLElBQ1I7QUFBQSxFQUNBO0FBQ0EsUUFBTSx1QkFBdUIsQ0FBQyxPQUFPLE9BQU8sT0FBTyxNQUFNLG1CQUFtQjtBQUN4RSxlQUFXLGNBQWMsbUJBQW1CO0FBQ3hDLFVBQUksQ0FBQyxXQUFXLFVBQVUsS0FBSyxHQUFHO0FBQzlCO0FBQUEsTUFDSjtBQUNBLGFBQU8sV0FBVyxVQUFVLE9BQU8sT0FBTyxPQUFPLE1BQU0sY0FBYztBQUFBLElBQ3pFO0FBQ0EsV0FBTyxzQkFBc0IsT0FBTyxPQUFPLE9BQU8sTUFBTSxjQUFjO0FBQUEsRUFDMUU7QUFDQSxRQUFNLHNCQUFzQixDQUFDLE9BQU8sT0FBTyxPQUFPLFNBQVM7QUFDdkQsVUFBTSxZQUFZLG1CQUFtQixLQUFLO0FBQzFDLFFBQUksVUFBVSxTQUFTO0FBQ25CLGFBQU8sVUFBVTtBQUFBLElBQ3JCO0FBQ0EsUUFBSSxTQUFTLHFCQUFxQjtBQUM5QixhQUFPO0FBQUEsSUFDWDtBQUNBLFFBQUksT0FBTyxVQUFVLFlBQVksVUFBVSxNQUFNO0FBQzdDLGFBQU8sT0FBTyxVQUFVLFNBQVMsS0FBSyxLQUFLO0FBQUEsSUFDL0M7QUFDQSxVQUFNLGVBQWUsTUFBTSxLQUFLLElBQUksS0FBSztBQUN6QyxRQUFJLGNBQWM7QUFDZCxhQUFPLGNBQWMsWUFBWTtBQUFBLElBQ3JDO0FBQ0EsVUFBTSxLQUFLLElBQUksT0FBTyxJQUFJO0FBQzFCLFdBQU8scUJBQXFCLE9BQU8sT0FBTyxPQUFPLE1BQU0sbUJBQW1CO0FBQUEsRUFDOUU7QUFDTyxXQUFTLHFCQUFxQixVQUFVO0FBQzNDLFdBQU8sQ0FBQyxVQUFVO0FBQ2QsVUFBSSxPQUFPLFVBQVUsVUFBVTtBQUMzQixlQUFPLFNBQVMsS0FBSztBQUFBLE1BQ3pCO0FBQ0EsVUFBSSxPQUFPLFVBQVUsWUFDakIsT0FBTyxVQUFVLGFBQ2pCLFVBQVUsUUFDVixPQUFPLFVBQVUsYUFBYTtBQUM5QixlQUFPLE9BQU8sS0FBSztBQUFBLE1BQ3ZCO0FBQ0EsVUFBSTtBQUNBLGNBQU0sYUFBYSxvQkFBb0IsT0FBTztBQUFBLFVBQzFDLE1BQU0sb0JBQUksUUFBTztBQUFBLFFBQ2pDLEdBQWUsR0FBRyxHQUFHO0FBQ1QsWUFBSSxPQUFPLGVBQWUsVUFBVTtBQUNoQyxpQkFBTyxTQUFTLFVBQVU7QUFBQSxRQUM5QjtBQUNBLGVBQU8sU0FBUyxLQUFLLFVBQVUsVUFBVSxDQUFDO0FBQUEsTUFDOUMsU0FDTyxPQUFPO0FBQ1YsaUJBQVMsb0JBQW9CLGlFQUFpRSxLQUFLO0FBQ25HLGVBQU8sU0FBUyxPQUFPLFVBQVUsU0FBUyxLQUFLLEtBQUssQ0FBQztBQUFBLE1BQ3pEO0FBQUEsSUFDSjtBQUFBLEVBQ0o7QUFDTyxRQUFNLHdCQUF3QixDQUFDLE1BQU0sbUJBQW1CO0FBQzNELFFBQUksQ0FBQyxNQUFNO0FBQ1AsYUFBTztBQUFBLElBQ1g7QUFDQSxRQUFJLE9BQU8sU0FBUyxVQUFVO0FBQzFCLGFBQU8sU0FBUyxNQUFNLGVBQWU7QUFBQSxJQUN6QztBQUNBLFFBQUksZ0JBQWdCLGlCQUFpQjtBQUNqQyxhQUFPLFNBQVMsS0FBSyxTQUFRLEdBQUksZUFBZTtBQUFBLElBQ3BEO0FBQ0EsUUFBSSxPQUFPLGFBQWEsZUFBZSxnQkFBZ0IsVUFBVTtBQUM3RCxZQUFNLE9BQU8sQ0FBQTtBQUNiLGlCQUFXLE9BQU8sS0FBSyxRQUFRO0FBQzNCLGFBQUssS0FBSyxHQUFHO0FBQUEsTUFDakI7QUFDQSxhQUFPLFNBQVMsZUFBZSxLQUFLLEtBQUssR0FBRyxDQUFDLElBQUksZUFBZTtBQUFBLElBQ3BFO0FBQ0EsUUFBSSxPQUFPLFNBQVMsZUFBZSxnQkFBZ0IsTUFBTTtBQUNyRCxhQUFPLFNBQVMsS0FBSyxRQUFRLFNBQVMsSUFBSSxLQUFLLElBQUk7QUFBQSxJQUN2RDtBQUNBLFFBQUksT0FBTyxnQkFBZ0IsYUFBYTtBQUNwQyxVQUFJLGdCQUFnQixhQUFhO0FBQzdCLGVBQU8sZ0JBQWdCLEtBQUssVUFBVTtBQUFBLE1BQzFDO0FBQ0EsVUFBSSxZQUFZLE9BQU8sSUFBSSxHQUFHO0FBQzFCLGVBQU8sSUFBSSxLQUFLLFlBQVksS0FBSyxZQUFXLENBQUUsSUFBSSxLQUFLLFVBQVU7QUFBQSxNQUNyRTtBQUFBLElBQ0o7QUFDQSxXQUFPLFNBQVMsZUFBZSxJQUFJLEdBQUcsZUFBZTtBQUFBLEVBQ3pEO0FBQ08sUUFBTSwyQkFBMkIsQ0FBQyxnQkFBZ0I7QUFDckQsVUFBTSxhQUFhLFlBQVksWUFBVztBQUMxQyxXQUFRLFdBQVcsU0FBUyxNQUFNLEtBQzlCLFdBQVcsU0FBUyxNQUFNLEtBQzFCLFdBQVcsU0FBUyxLQUFLLEtBQ3pCLFdBQVcsU0FBUyx1QkFBdUI7QUFBQSxFQUNuRDtBQ3pRTyxRQUFNLGlCQUFpQixDQUFDLFVBQVU7QUFDckMsUUFBSSxDQUFDLE9BQU87QUFDUixhQUFPLENBQUE7QUFBQSxJQUNYO0FBQ0EsVUFBTUEsVUFBUyxDQUFBO0FBQ2YsZUFBVyxDQUFDLEtBQUssS0FBSyxLQUFLLE1BQU0sUUFBTyxHQUFJO0FBQ3hDLFlBQU0sZ0JBQWdCLElBQUksS0FBSSxFQUFHLFlBQVc7QUFDNUMsVUFBSSxDQUFDLGlCQUFpQixpQkFBaUIsYUFBYSxHQUFHO0FBQ25EO0FBQUEsTUFDSjtBQUNBLE1BQUFBLFFBQU8sY0FBYyxNQUFNLEdBQUcsc0JBQXNCLENBQUMsSUFBSSxNQUFNLE1BQU0sR0FBRyx1QkFBdUI7QUFBQSxJQUNuRztBQUNBLFdBQU9BO0FBQUEsRUFDWDtBQUNPLFFBQU0sa0JBQWtCLENBQUMsZUFBZTtBQUMzQyxVQUFNQSxVQUFTLENBQUE7QUFDZixVQUFNLFFBQVEsV0FBVyxNQUFNLElBQUk7QUFDbkMsZUFBVyxRQUFRLE9BQU87QUFDdEIsWUFBTSxpQkFBaUIsS0FBSyxRQUFRLE1BQU0sRUFBRTtBQUM1QyxZQUFNLGlCQUFpQixlQUFlLFFBQVEsR0FBRztBQUNqRCxVQUFJLGtCQUFrQixHQUFHO0FBQ3JCO0FBQUEsTUFDSjtBQUNBLFlBQU0sTUFBTSxlQUFlLE1BQU0sR0FBRyxjQUFjLEVBQUUsS0FBSSxFQUFHLFlBQVc7QUFDdEUsVUFBSSxDQUFDLE9BQU8saUJBQWlCLEdBQUcsR0FBRztBQUMvQjtBQUFBLE1BQ0o7QUFDQSxZQUFNLFFBQVEsZUFBZSxNQUFNLGlCQUFpQixDQUFDLEVBQUUsS0FBSTtBQUMzRCxVQUFJLENBQUMsT0FBTztBQUNSO0FBQUEsTUFDSjtBQUNBLE1BQUFBLFFBQU8sSUFBSSxNQUFNLEdBQUcsc0JBQXNCLENBQUMsSUFBSSxNQUFNLE1BQU0sR0FBRyx1QkFBdUI7QUFBQSxJQUN6RjtBQUNBLFdBQU9BO0FBQUEsRUFDWDtBQ2pDTyxRQUFNLHlCQUF5QixDQUFDLFVBQVUsU0FBUztBQUN0RCxVQUFNLGNBQWMsTUFBTTtBQUN0QixjQUFRLFFBQVEsS0FBSSxDQUFFLEVBQUUsTUFBTSxDQUFDLFVBQVU7QUFDckMsaUJBQVMsb0JBQW9CLG1EQUFtRCxLQUFLO0FBQUEsTUFDekYsQ0FBQztBQUFBLElBQ0w7QUFDQSxRQUFJLE9BQU8sT0FBTyx3QkFBd0IsWUFBWTtBQUNsRCxhQUFPLG9CQUFvQixNQUFNO0FBQzdCLG9CQUFXO0FBQUEsTUFDZixDQUFDO0FBQ0Q7QUFBQSxJQUNKO0FBQ0EsV0FBTyxXQUFXLGFBQWEsQ0FBQztBQUFBLEVBQ3BDO0FBQ08sUUFBTSw2QkFBNkIsQ0FBQyxVQUFVLE1BQU0sZ0JBQWdCLGNBQWMsT0FBTztBQUM1RixXQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFDNUIsNkJBQXVCLFVBQVUsTUFBTTtBQUNuQyxnQkFBUSxxQkFBcUIsc0JBQXNCLE1BQU0sY0FBYyxHQUFHLFdBQVcsQ0FBQztBQUFBLE1BQzFGLENBQUM7QUFBQSxJQUNMLENBQUM7QUFBQSxFQUNMO0FBQ08sUUFBTSwwQkFBMEIsQ0FBQyxVQUFVLGFBQWEsY0FBYyxhQUFhO0FBQ3RGLFdBQU8sSUFBSSxRQUFRLENBQUMsWUFBWTtBQUM1Qiw2QkFBdUIsVUFBVSxZQUFZO0FBQ3pDLFlBQUksQ0FBQyx5QkFBeUIsV0FBVyxHQUFHO0FBQ3hDLGtCQUFRLE1BQVM7QUFDakI7QUFBQSxRQUNKO0FBQ0EsWUFBSTtBQUNBLGtCQUFRLHFCQUFxQixTQUFTLE1BQU0sU0FBUSxHQUFJLGVBQWUsR0FBRyxXQUFXLENBQUM7QUFBQSxRQUMxRixTQUNPLE9BQU87QUFDVixtQkFBUyxvQkFBb0IsY0FBYyxLQUFLO0FBQ2hELGtCQUFRLE1BQVM7QUFBQSxRQUNyQjtBQUFBLE1BQ0osQ0FBQztBQUFBLElBQ0wsQ0FBQztBQUFBLEVBQ0w7QUNuQ0EsUUFBTSxxQkFBcUIsQ0FBQyxPQUFPLFNBQVM7QUFDeEMsUUFBSSxPQUFPLE1BQU0sV0FBVyxZQUFZLEtBQUssUUFBUTtBQUNqRCxhQUFPLEtBQUssT0FBTyxZQUFXO0FBQUEsSUFDbEM7QUFDQSxRQUFJLGlCQUFpQixTQUFTO0FBQzFCLGFBQU8sTUFBTSxPQUFPLFlBQVc7QUFBQSxJQUNuQztBQUNBLFdBQU87QUFBQSxFQUNYO0FBQ0EsUUFBTSxrQkFBa0IsQ0FBQyxVQUFVO0FBQy9CLFFBQUksT0FBTyxVQUFVLFVBQVU7QUFDM0IsYUFBTztBQUFBLElBQ1g7QUFDQSxRQUFJLGlCQUFpQixLQUFLO0FBQ3RCLGFBQU8sTUFBTSxTQUFRO0FBQUEsSUFDekI7QUFDQSxXQUFPLE1BQU07QUFBQSxFQUNqQjtBQUNBLFFBQU0sNkJBQTZCLE9BQU8sT0FBTyxNQUFNLGdCQUFnQixnQkFBZ0IsYUFBYTtBQUNoRyxVQUFNLGtCQUFrQixzQkFBc0IsTUFBTSxNQUFNLGNBQWM7QUFDeEUsUUFBSSxpQkFBaUI7QUFDakIsYUFBTztBQUFBLElBQ1g7QUFDQSxRQUFJLEVBQUUsaUJBQWlCLFVBQVU7QUFDN0IsYUFBTztBQUFBLElBQ1g7QUFDQSxVQUFNLFVBQVUsTUFBTSxVQUFVLE1BQU0sVUFBVSxPQUFPLFlBQVc7QUFDbEUsUUFBSSxXQUFXLFNBQVMsV0FBVyxVQUFVLE1BQU0sVUFBVTtBQUN6RCxhQUFPO0FBQUEsSUFDWDtBQUNBLFVBQU0sY0FBYyxnQkFBZ0IsSUFBSSxjQUFjLEtBQ2xELE1BQU0sUUFBUSxJQUFJLGNBQWMsS0FDaEM7QUFDSixRQUFJLENBQUMseUJBQXlCLFdBQVcsR0FBRztBQUN4QyxhQUFPO0FBQUEsSUFDWDtBQUNBLFFBQUk7QUFDQSxhQUFPLHFCQUFxQixTQUFTLE1BQU0sTUFBTSxNQUFLLEVBQUcsS0FBSSxHQUFJLGVBQWUsR0FBRyxXQUFXO0FBQUEsSUFDbEcsU0FDTyxPQUFPO0FBQ1YsZUFBUyxvQkFBb0Isb0VBQW9FLEtBQUs7QUFDdEcsYUFBTztBQUFBLElBQ1g7QUFBQSxFQUNKO0FBQ0EsUUFBTSxpQ0FBaUMsQ0FBQyxjQUFjLGFBQWEscUJBQXFCLGdCQUFnQixVQUFVLHlCQUF5QjtBQUN2SSxRQUFJLHdCQUF3QixTQUFTO0FBQ2pDLGFBQVEscUJBQXFCLElBQUksWUFBWSxLQUN6QywyQkFBMkIsY0FBYyxhQUFhLHFCQUFxQixnQkFBZ0IsUUFBUTtBQUFBLElBQzNHO0FBQ0EsV0FBTywyQkFBMkIsY0FBYyxhQUFhLHFCQUFxQixnQkFBZ0IsUUFBUTtBQUFBLEVBQzlHO0FBQ08sUUFBTSxzQkFBc0IsQ0FBQyxNQUFNLFVBQVUsZ0JBQWdCLHlCQUF5QjtBQUN6RixVQUFNLENBQUMsY0FBYyxXQUFXLElBQUk7QUFDcEMsVUFBTSxTQUFTLG1CQUFtQixjQUFjLFdBQVc7QUFDM0QsVUFBTSxNQUFNLGdCQUFnQixZQUFZO0FBQ3hDLFVBQU0sY0FBYyxjQUFjLEtBQUssUUFBUTtBQUMvQyxRQUFJLENBQUMsYUFBYTtBQUNkLGFBQU87QUFBQSxJQUNYO0FBQ0EsUUFBSSxzQkFBc0I7QUFDMUIsUUFBSSxhQUFhLFNBQVM7QUFDdEIsVUFBSTtBQUNBLDhCQUFzQixJQUFJLFFBQVEsWUFBWSxPQUFPO0FBQUEsTUFDekQsU0FDTyxPQUFPO0FBQ1YsaUJBQVMsb0JBQW9CLGlFQUFpRSxLQUFLO0FBQUEsTUFDdkc7QUFBQSxJQUNKLFdBQ1Msd0JBQXdCLFNBQVM7QUFDdEMsNEJBQXNCLGFBQWE7QUFBQSxJQUN2QztBQUNBLFVBQU0saUJBQWlCLHNCQUNqQixlQUFlLG1CQUFtQixJQUNsQyx3QkFBd0IsVUFDcEIsZUFBZSxhQUFhLE9BQU8sSUFDbkMsQ0FBQTtBQUNWLFVBQU0scUJBQXFCLHFCQUFxQixJQUFJLGNBQWMsTUFDN0Qsd0JBQXdCLFVBQ2xCLGFBQWEsUUFBUSxJQUFJLGNBQWMsS0FBSyxLQUM3QztBQUNWLFVBQU0scUJBQXFCLCtCQUErQixjQUFjLGFBQWEscUJBQXFCLGdCQUFnQixVQUFVLG9CQUFvQjtBQUN4SixXQUFPO0FBQUEsTUFDSDtBQUFBLE1BQ0EsZUFBZSwyQkFBMkIsV0FBVztBQUFBLE1BQ3JEO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNSO0FBQUEsRUFDQTtBQUNPLFFBQU0sbUNBQW1DLENBQUMsVUFBVSxnQkFBZ0IseUJBQXlCO0FBQ2hHLFFBQUksT0FBTyxPQUFPLFlBQVksWUFBWTtBQUN0QztBQUFBLElBQ0o7QUFDQSxVQUFNLGtCQUFrQixPQUFPO0FBQy9CLFVBQU0saUJBQWlCLElBQUksTUFBTSxpQkFBaUI7QUFBQSxNQUM5QyxVQUFVLFFBQVEsVUFBVSxXQUFXO0FBQ25DLGNBQU0sQ0FBQSxFQUFHLFdBQVcsSUFBSTtBQUN4QixjQUFNLGtCQUFrQixRQUFRLFVBQVUsUUFBUSxVQUFVLFNBQVM7QUFDckUsWUFBSTtBQUNKLFlBQUksYUFBYSxZQUFZLFFBQVc7QUFDcEMsY0FBSTtBQUNBLGtDQUFzQixJQUFJLFFBQVEsWUFBWSxPQUFPO0FBQUEsVUFDekQsU0FDTyxPQUFPO0FBQ1YscUJBQVMsb0JBQW9CLG1FQUFtRSxLQUFLO0FBQ3JHLGtDQUFzQixnQkFBZ0I7QUFBQSxVQUMxQztBQUFBLFFBQ0osT0FDSztBQUNELGdDQUFzQixnQkFBZ0I7QUFBQSxRQUMxQztBQUNBLGNBQU0sY0FBYyxvQkFBb0IsSUFBSSxjQUFjLEtBQUs7QUFDL0QsY0FBTSxxQkFBcUIsYUFBYSxTQUFTLFNBQzNDLDJCQUEyQixVQUFVLFlBQVksTUFBTSxnQkFBZ0IsV0FBVyxJQUNsRix3QkFBd0IsVUFBVSxhQUFhLG1FQUFtRSxNQUFNO0FBQ3RILGNBQUksZ0JBQWdCLFVBQVU7QUFDMUIsbUJBQU8sUUFBUSxRQUFRLEVBQUU7QUFBQSxVQUM3QjtBQUNBLGlCQUFPLGdCQUFnQixNQUFLLEVBQUcsS0FBSTtBQUFBLFFBQ3ZDLENBQUM7QUFDTCw2QkFBcUIsSUFBSSxpQkFBaUIsa0JBQWtCO0FBQzVELGVBQU87QUFBQSxNQUNYO0FBQUEsSUFDUixDQUFLO0FBQ0QsUUFBSTtBQUNBLGFBQU8sT0FBTyxnQkFBZ0IsZUFBZTtBQUFBLElBQ2pELFNBQ08sT0FBTztBQUNWLGVBQVMsb0JBQW9CLCtFQUErRSxLQUFLO0FBQUEsSUFDckg7QUFDQSxRQUFJO0FBQ0EsYUFBTyxVQUFVO0FBQUEsSUFDckIsU0FDTyxPQUFPO0FBQ1YsZUFBUyxvQkFBb0IsbUVBQW1FLEtBQUs7QUFBQSxJQUN6RztBQUFBLEVBQ0o7QUN4SUEsUUFBTSwrQkFBK0IsQ0FBQyxVQUFVLGFBQWE7QUFDekQsVUFBTSxjQUFjLFNBQVMsUUFBUSxJQUFJLGNBQWMsS0FBSztBQUM1RCxRQUFJLENBQUMseUJBQXlCLFdBQVcsS0FBSyxTQUFTLFVBQVU7QUFDN0QsYUFBTztBQUFBLFFBQ0g7QUFBQSxRQUNBLGVBQWU7QUFBQSxNQUMzQjtBQUFBLElBQ0k7QUFDQSxRQUFJO0FBQ0EsYUFBTztBQUFBLFFBQ0g7QUFBQSxRQUNBLGVBQWUsU0FBUyxNQUFLO0FBQUEsTUFDekM7QUFBQSxJQUNJLFNBQ08sT0FBTztBQUNWLGVBQVMsb0JBQW9CLG1FQUFtRSxLQUFLO0FBQ3JHLGFBQU87QUFBQSxRQUNIO0FBQUEsUUFDQSxlQUFlO0FBQUEsTUFDM0I7QUFBQSxJQUNJO0FBQUEsRUFDSjtBQUNPLFFBQU0sMkJBQTJCLENBQUMsVUFBVSxhQUFhLFNBQVMsVUFBVSxhQUFhO0FBQzVGLFVBQU0sa0JBQWtCLGVBQWUsU0FBUyxPQUFPO0FBQ3ZELFVBQU0sRUFBRSxhQUFhLGNBQWEsSUFBSyw2QkFBNkIsVUFBVSxRQUFRO0FBQ3RGLDJCQUF1QixVQUFVLFlBQVk7QUFDekMsVUFBSTtBQUNKLFVBQUk7QUFDSixVQUFJO0FBQ0Esc0JBQWMsTUFBTSxRQUFRO0FBQUEsTUFDaEMsU0FDTyxPQUFPO0FBQ1YsaUJBQVMsb0JBQW9CLG9FQUFvRSxLQUFLO0FBQUEsTUFDMUc7QUFDQSxVQUFJO0FBQ0EsdUJBQWUsTUFBTSx3QkFBd0IsVUFBVSxhQUFhLDBFQUEwRSxNQUFNO0FBQ2hKLGNBQUksQ0FBQyxlQUFlO0FBQ2hCLG1CQUFPLFFBQVEsUUFBUSxFQUFFO0FBQUEsVUFDN0I7QUFDQSxpQkFBTyxjQUFjLEtBQUk7QUFBQSxRQUM3QixDQUFDO0FBQUEsTUFDTCxTQUNPLE9BQU87QUFDVixpQkFBUyxvQkFBb0IscUVBQXFFLEtBQUs7QUFBQSxNQUMzRztBQUNBLGtCQUFZO0FBQUEsUUFDUixRQUFRLFFBQVE7QUFBQSxRQUNoQixLQUFLLFFBQVE7QUFBQSxRQUNiLFFBQVEsU0FBUztBQUFBLFFBQ2pCO0FBQUEsUUFDQSxnQkFBZ0IsUUFBUTtBQUFBLFFBQ3hCO0FBQUEsUUFDQSxhQUFhLHFCQUFxQixhQUFhLFFBQVEsa0JBQWtCO0FBQUEsUUFDekUsY0FBYyxxQkFBcUIsY0FBYyxXQUFXO0FBQUEsTUFDeEUsQ0FBUztBQUFBLElBQ0wsQ0FBQztBQUFBLEVBQ0w7QUFDTyxRQUFNLDJCQUEyQixDQUFDLFVBQVUsYUFBYSxTQUFTLE9BQU8sV0FBVyxtQkFBbUI7QUFDMUcsMkJBQXVCLFVBQVUsWUFBWTtBQUN6QyxVQUFJO0FBQ0osVUFBSTtBQUNBLHNCQUFjLE1BQU0sUUFBUTtBQUFBLE1BQ2hDLFNBQ08sbUJBQW1CO0FBQ3RCLHNCQUFjO0FBQUEsTUFDbEI7QUFDQSxrQkFBWTtBQUFBLFFBQ1IsUUFBUSxRQUFRO0FBQUEsUUFDaEIsS0FBSyxRQUFRO0FBQUEsUUFDYixRQUFRO0FBQUEsUUFDUixVQUFVLEtBQUssSUFBRyxJQUFLO0FBQUEsUUFDdkIsZ0JBQWdCLFFBQVE7QUFBQSxRQUN4QixhQUFhLHFCQUFxQixhQUFhLFFBQVEsa0JBQWtCO0FBQUEsUUFDekUsY0FBYyxxQkFBcUIsU0FBUyxlQUFlLEtBQUssR0FBRyxlQUFlLEdBQUcsRUFBRTtBQUFBLE1BQ25HLENBQVM7QUFBQSxJQUNMLENBQUM7QUFBQSxFQUNMO0FDN0VPLFFBQU0sc0JBQXNCLENBQUMsVUFBVTtBQUMxQyxVQUFNLEVBQUUsYUFBYSxhQUFhLFNBQVEsSUFBSztBQUMvQyxVQUFNLGlCQUFpQixxQkFBcUIsUUFBUTtBQUNwRCxVQUFNLHVCQUF1QixvQkFBSSxRQUFPO0FBQ3hDLFVBQU0sWUFBWSxDQUFDLGNBQWM7QUFDN0IsYUFBTyxVQUFVLEtBQUssTUFBTTtBQUFBLElBQ2hDO0FBQ0EscUNBQWlDLFVBQVUsZ0JBQWdCLG9CQUFvQjtBQUMvRSxRQUFJLE9BQU8sT0FBTyxVQUFVLFlBQVk7QUFDcEMsa0JBQVksa0JBQWtCLFFBQVE7QUFDdEM7QUFBQSxJQUNKO0FBQ0EsVUFBTSxZQUFZLFVBQVUsT0FBTyxLQUFLO0FBQ3hDLFFBQUksZ0JBQWdCO0FBQ3BCLFFBQUksdUJBQXVCO0FBQzNCLFVBQU0sZ0JBQWdCLFVBQVUsU0FBUztBQUNyQyxVQUFJLHNCQUFzQjtBQUV0QixlQUFPLFVBQVUsR0FBRyxJQUFJO0FBQUEsTUFDNUI7QUFDQSw2QkFBdUI7QUFDdkIsa0JBQVksZ0JBQWU7QUFDM0IsWUFBTSxZQUFZLEtBQUssSUFBRztBQUMxQixZQUFNLFVBQVUsb0JBQW9CLE1BQU0sVUFBVSxnQkFBZ0Isb0JBQW9CO0FBQ3hGLFVBQUksQ0FBQyxTQUFTO0FBQ1YsWUFBSTtBQUNBLGlCQUFPLGNBQWMsR0FBRyxJQUFJO0FBQUEsUUFDaEMsVUFDWjtBQUNnQixpQ0FBdUI7QUFBQSxRQUMzQjtBQUFBLE1BQ0o7QUFDQSxVQUFJO0FBQ0EsY0FBTSxXQUFXLE1BQU0sY0FBYyxHQUFHLElBQUk7QUFDNUMsY0FBTSxXQUFXLEtBQUssSUFBRyxJQUFLO0FBQzlCLGlDQUF5QixVQUFVLGFBQWEsU0FBUyxVQUFVLFFBQVE7QUFDM0UsZUFBTztBQUFBLE1BQ1gsU0FDTyxPQUFPO0FBQ1Ysb0JBQVksbUJBQW1CLFNBQVMsZUFBZSxLQUFLLEdBQUcsR0FBRyxDQUFDO0FBQ25FLGlDQUF5QixVQUFVLGFBQWEsU0FBUyxPQUFPLFdBQVcsY0FBYztBQUN6RixjQUFNO0FBQUEsTUFDVixVQUNSO0FBQ1ksK0JBQXVCO0FBQUEsTUFDM0I7QUFBQSxJQUNKO0FBQ0EsUUFBSTtBQUNBLGFBQU8sT0FBTyxjQUFjLE9BQU8sS0FBSztBQUFBLElBQzVDLFNBQ08sT0FBTztBQUNWLGVBQVMsb0JBQW9CLGlFQUFpRSxLQUFLO0FBQUEsSUFDdkc7QUFDQSxVQUFNLGtCQUFrQixPQUFPLHlCQUF5QixRQUFRLE9BQU87QUFDdkUsVUFBTSxtQkFBbUIsQ0FBQyxtQkFBbUIsZ0JBQWdCO0FBQzdELFFBQUksa0JBQWtCO0FBQ2xCLFVBQUk7QUFDQSxlQUFPLGVBQWUsUUFBUSxTQUFTO0FBQUEsVUFDbkMsY0FBYztBQUFBLFVBQ2QsWUFBWSxpQkFBaUIsY0FBYztBQUFBLFVBQzNDLE1BQU07QUFDRixtQkFBTztBQUFBLFVBQ1g7QUFBQSxVQUNBLElBQUksV0FBVztBQUNYLGdCQUFJLE9BQU8sY0FBYyxZQUFZO0FBQ2pDO0FBQUEsWUFDSjtBQUNBLGdCQUFJLGNBQWMsY0FBYztBQUM1QjtBQUFBLFlBQ0o7QUFDQSw0QkFBZ0IsVUFBVSxTQUFTO0FBQUEsVUFDdkM7QUFBQSxRQUNoQixDQUFhO0FBQ0Qsb0JBQVksa0JBQWtCLFVBQVU7QUFDeEM7QUFBQSxNQUNKLFNBQ08sT0FBTztBQUNWLGlCQUFTLG9CQUFvQixnRUFBZ0UsS0FBSztBQUFBLE1BQ3RHO0FBQUEsSUFDSjtBQUNBLFFBQUk7QUFDQSxhQUFPLFFBQVE7QUFDZixrQkFBWSxrQkFBa0IsWUFBWTtBQUFBLElBQzlDLFNBQ08sT0FBTztBQUNWLGtCQUFZLGtCQUFrQixRQUFRO0FBQ3RDLGVBQVMsb0JBQW9CLHFEQUFxRCxLQUFLO0FBQUEsSUFDM0Y7QUFBQSxFQUNKO0FDdkZPLFFBQU0sb0JBQW9CLENBQUMsVUFBVTtBQUN4QyxVQUFNLEVBQUUsYUFBYSxhQUFhLFNBQVEsSUFBSztBQUMvQyxVQUFNLGlCQUFpQixxQkFBcUIsUUFBUTtBQUNwRCxVQUFNLGFBQWEsb0JBQUksUUFBTztBQUM5QixVQUFNLHNCQUFzQixPQUFPLFFBQVE7QUFDdkMsWUFBTSxRQUFRLFdBQVcsSUFBSSxHQUFHO0FBQ2hDLFVBQUksQ0FBQyxPQUFPO0FBQ1IsZUFBTztBQUFBLE1BQ1g7QUFDQSxZQUFNLGdCQUFnQixjQUFjLE1BQU0sS0FBSyxRQUFRO0FBQ3ZELFVBQUksQ0FBQyxlQUFlO0FBQ2hCLGVBQU87QUFBQSxNQUNYO0FBQ0EsWUFBTSxjQUFjLDJCQUEyQixhQUFhO0FBQzVELFVBQUk7QUFDSixVQUFJO0FBQ0osWUFBTSxrQkFBa0IsZ0JBQWdCLElBQUksc0JBQXFCLENBQUU7QUFDbkUsWUFBTSxzQkFBc0IsZ0JBQWdCLGNBQWMsS0FBSztBQUMvRCxVQUFJO0FBQ0Esc0JBQWMsTUFBTSxNQUFNO0FBQUEsTUFDOUIsU0FDTyxtQkFBbUI7QUFDdEIsc0JBQWM7QUFBQSxNQUNsQjtBQUNBLFVBQUk7QUFDQSxZQUFJLElBQUksaUJBQWlCLE1BQU0sSUFBSSxpQkFBaUIsUUFBUTtBQUN4RCx5QkFBZSxTQUFTLElBQUksZ0JBQWdCLElBQUksZUFBZTtBQUFBLFFBQ25FLFdBQ1MsSUFBSSxpQkFBaUIsUUFBUTtBQUNsQyx5QkFBZSxTQUFTLGVBQWUsSUFBSSxRQUFRLEdBQUcsZUFBZTtBQUFBLFFBQ3pFO0FBQUEsTUFDSixTQUNPLE9BQU87QUFDVixpQkFBUyxvQkFBb0IsbUVBQW1FLEtBQUs7QUFBQSxNQUN6RztBQUNBLGFBQU87QUFBQSxRQUNILFFBQVEsTUFBTTtBQUFBLFFBQ2QsS0FBSztBQUFBLFFBQ0wsUUFBUSxJQUFJO0FBQUEsUUFDWixVQUFVLEtBQUssSUFBRyxJQUFLLE1BQU07QUFBQSxRQUM3QixnQkFBZ0IsTUFBTTtBQUFBLFFBQ3RCO0FBQUEsUUFDQSxhQUFhLHFCQUFxQixhQUFhLE1BQU0sZUFBZSxjQUFjLEtBQUssRUFBRTtBQUFBLFFBQ3pGLGNBQWMscUJBQXFCLGNBQWMsbUJBQW1CO0FBQUEsTUFDaEY7QUFBQSxJQUNJO0FBQ0EsVUFBTSxzQkFBc0IsQ0FBQyxRQUFRO0FBQ2pDLDZCQUF1QixVQUFVLFlBQVk7QUFDekMsY0FBTSxVQUFVLE1BQU0sb0JBQW9CLEdBQUc7QUFDN0MsWUFBSSxDQUFDLFNBQVM7QUFDVjtBQUFBLFFBQ0o7QUFDQSxvQkFBWSxPQUFPO0FBQUEsTUFDdkIsQ0FBQztBQUFBLElBQ0w7QUFDQSxVQUFNLGVBQWUsZUFBZSxVQUFVO0FBQzlDLFVBQU0sdUJBQXVCO0FBQzdCLG1CQUFlLFVBQVUsT0FBTyxTQUFVLFFBQVEsS0FBSyxPQUFPLFVBQVUsVUFBVTtBQUM5RSxZQUFNLG1CQUFtQixPQUFPLFdBQVcsV0FBVyxTQUFTO0FBQy9ELFlBQU0sZ0JBQWdCLE9BQU8sUUFBUSxXQUFXLE1BQU0sT0FBTyxPQUFPLEVBQUU7QUFDdEUsaUJBQVcsSUFBSSxNQUFNO0FBQUEsUUFDakIsUUFBUTtBQUFBLFFBQ1IsS0FBSztBQUFBLFFBQ0wsV0FBVyxLQUFLLElBQUc7QUFBQSxRQUNuQixvQkFBb0IsUUFBUSxRQUFRLE1BQVM7QUFBQSxRQUM3QyxnQkFBZ0IsQ0FBQTtBQUFBLE1BQzVCLENBQVM7QUFDRCxVQUFJLE9BQU8sVUFBVSxhQUNqQixPQUFPLGFBQWEsWUFDcEIsYUFBYSxRQUNiLE9BQU8sYUFBYSxZQUNwQixhQUFhLE1BQU07QUFDbkIsZUFBTyxxQkFBcUIsS0FBSyxNQUFNLFFBQVEsS0FBSyxTQUFTLE1BQU0sVUFBVSxRQUFRO0FBQUEsTUFDekY7QUFDQSxhQUFPLHFCQUFxQixLQUFLLE1BQU0sUUFBUSxHQUFHO0FBQUEsSUFDdEQ7QUFDQSxVQUFNLDJCQUEyQixlQUFlLFVBQVU7QUFDMUQsbUJBQWUsVUFBVSxtQkFBbUIsWUFBYSxNQUFNO0FBQzNELFlBQU0sQ0FBQyxLQUFLLEtBQUssSUFBSTtBQUNyQixZQUFNLE9BQU8sV0FBVyxJQUFJLElBQUk7QUFDaEMsVUFBSSxNQUFNO0FBQ04sY0FBTSxnQkFBZ0IsSUFBSSxLQUFJLEVBQUcsWUFBVztBQUM1QyxZQUFJLENBQUMsaUJBQWlCLGFBQWEsR0FBRztBQUNsQyxlQUFLLGVBQWUsY0FBYyxNQUFNLEdBQUcsc0JBQXNCLENBQUMsSUFDOUQsTUFBTSxNQUFNLEdBQUcsdUJBQXVCO0FBQUEsUUFDOUM7QUFBQSxNQUNKO0FBQ0EsYUFBTyx5QkFBeUIsTUFBTSxNQUFNLElBQUk7QUFBQSxJQUNwRDtBQUNBLFVBQU0sZUFBZSxlQUFlLFVBQVU7QUFDOUMsbUJBQWUsVUFBVSxPQUFPLFlBQWEsTUFBTTtBQUMvQyxrQkFBWSxjQUFhO0FBQ3pCLFlBQU0sT0FBTyxXQUFXLElBQUksSUFBSTtBQUNoQyxVQUFJLE1BQU07QUFDTixhQUFLLFlBQVksS0FBSyxJQUFHO0FBQ3pCLGFBQUsscUJBQXFCLDJCQUEyQixVQUFVLEtBQUssQ0FBQyxHQUFHLGdCQUFnQixLQUFLLGVBQWUsY0FBYyxLQUFLLEVBQUU7QUFBQSxNQUNySTtBQUNBLFdBQUssaUJBQWlCLFdBQVcsTUFBTTtBQUNuQyw0QkFBb0IsSUFBSTtBQUFBLE1BQzVCLEdBQUc7QUFBQSxRQUNDLE1BQU07QUFBQSxNQUNsQixDQUFTO0FBQ0QsYUFBTyxhQUFhLE1BQU0sTUFBTSxJQUFJO0FBQUEsSUFDeEM7QUFDQSxnQkFBWSxvQkFBbUI7QUFBQSxFQUNuQztBQzVHTyxXQUFTLHNCQUFzQixPQUFPO0FBQ3pDLHdCQUFvQixLQUFLO0FBQ3pCLHNCQUFrQixLQUFLO0FBQUEsRUFDM0I7QUNHTyxXQUFTLDZCQUE2QjtBQUN6QyxVQUFNLFFBQVE7QUFDZCxRQUFJLE1BQU0sWUFBWSxHQUFHO0FBQ3JCO0FBQUEsSUFDSjtBQUNBLFVBQU0sWUFBWSxJQUFJO0FBQ3RCLFVBQU0sY0FBYyxzQkFBc0IsTUFBTTtBQUNoRCxVQUFNLFdBQVcsWUFBWSxlQUFlLHVCQUFzQixDQUFFO0FBQ3BFLFVBQU0sRUFBRSxjQUFjLGdCQUFlLElBQUssaUJBQWlCO0FBQUEsTUFDdkQsbUJBQW1CLFlBQVk7QUFBQSxNQUMvQixvQkFBb0IsWUFBWTtBQUFBLElBQ3hDLENBQUs7QUFDRCxVQUFNLGlCQUFpQixxQkFBcUIsUUFBUTtBQUNwRCxVQUFNLGFBQWEsQ0FBQyxZQUFZLFFBQVEsYUFBYTtBQUNqRCxrQkFBWSxrQkFBaUI7QUFDN0IsbUJBQWE7QUFBQSxRQUNULE1BQU07QUFBQSxRQUNOLFdBQVcsS0FBSyxJQUFHO0FBQUEsUUFDbkI7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ1osQ0FBUztBQUFBLElBQ0w7QUFDQSxVQUFNLGNBQWMsQ0FBQyxPQUFPLFNBQVM7QUFDakMsa0JBQVksbUJBQWtCO0FBQzlCLFlBQU0saUJBQWlCLENBQUE7QUFDdkIsaUJBQVcsT0FBTyxNQUFNO0FBQ3BCLHVCQUFlLEtBQUssZUFBZSxHQUFHLENBQUM7QUFBQSxNQUMzQztBQUNBLG1CQUFhO0FBQUEsUUFDVCxNQUFNO0FBQUEsUUFDTixXQUFXLEtBQUssSUFBRztBQUFBLFFBQ25CO0FBQUEsUUFDQSxTQUFTLFNBQVMsZUFBZSxLQUFLLEdBQUcsQ0FBQztBQUFBLFFBQzFDLFVBQVU7QUFBQSxVQUNOLGVBQWUsS0FBSztBQUFBLFFBQ3BDO0FBQUEsTUFDQSxDQUFTO0FBQUEsSUFDTDtBQUNBLFVBQU0sY0FBYyxDQUFDLFlBQVk7QUFDN0Isa0JBQVksbUJBQW1CLFFBQVEsR0FBRztBQUMxQyxtQkFBYTtBQUFBLFFBQ1QsTUFBTTtBQUFBLFFBQ04sV0FBVyxLQUFLLElBQUc7QUFBQSxRQUNuQixHQUFHO0FBQUEsTUFDZixDQUFTO0FBQUEsSUFDTDtBQUNBLHNDQUFrQztBQUFBLE1BQzlCO0FBQUEsSUFDUixDQUFLO0FBQ0QsMEJBQXNCO0FBQUEsTUFDbEI7QUFBQSxNQUNBO0FBQUEsSUFDUixDQUFLO0FBQ0QsUUFBSTtBQUNBLDRCQUFzQjtBQUFBLFFBQ2xCO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNaLENBQVM7QUFBQSxJQUNMLFNBQ08sT0FBTztBQUNWLGVBQVMsb0JBQW9CLHlEQUF5RCxLQUFLO0FBQUEsSUFDL0Y7QUFDQSxVQUFNLGtCQUFrQixNQUFNO0FBQzFCLHNCQUFlO0FBQUEsSUFDbkI7QUFDQSxXQUFPLGlCQUFpQixZQUFZLGlCQUFpQjtBQUFBLE1BQ2pELFNBQVM7QUFBQSxJQUNqQixDQUFLO0FBQ0QsYUFBUyxpQkFBaUIsb0JBQW9CLE1BQU07QUFDaEQsVUFBSSxTQUFTLG9CQUFvQixVQUFVO0FBQ3ZDLHdCQUFlO0FBQUEsTUFDbkI7QUFBQSxJQUNKLEdBQUc7QUFBQSxNQUNDLFNBQVM7QUFBQSxNQUNULFNBQVM7QUFBQSxJQUNqQixDQUFLO0FBQUEsRUFDTDtBQ3JGQSxXQUFTLHFCQUFxQixLQUFLO0FBQ2xDLFFBQUksT0FBTyxRQUFRLE9BQU8sUUFBUSxXQUFZLFFBQU8sRUFBRSxNQUFNLElBQUc7QUFDaEUsV0FBTztBQUFBLEVBQ1I7QUNEQSxRQUFBLGFBQWUscUJBQXFCLE1BQU07QUFDeEMsK0JBQUE7QUFBQSxFQUNGLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OyIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlsxNV19
debuggerPage;